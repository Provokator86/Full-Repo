 <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
            <th align="left" valign="middle"><?php echo addslashes(t('Jobs Title'))?></th>
             <th align="left" valign="middle"><?php echo addslashes(t('Category'))?></th>
             <th align="center" valign="middle"  class=" margin00"><?php echo addslashes(t('Quote(s)'))?></th>
             <th align="center" valign="middle"  class=" margin00"><?php echo addslashes(t('Option'))?></th>
      </tr>
	  
	  <?php if($job_list) { 
	  			$cnt = 1;
	  
	  		foreach($job_list as $val)
				{ 
				$class = ($cnt%2 == 0)?'class="bgcolor"':'';
	   ?>
      <tr <?php echo $class ?>>
            <td align="left" valign="middle" class="leftboder" width="40%"><h5>
			<a href="javascript:void(0);"><?php echo $val['s_title'] ?></a></h5> 
            <p><?php echo string_part($val['s_description'],300) ?></p> <ul> 
			<li><?php echo addslashes(t('Time left'))?>: <span><?php echo $val['i_days_left']>0?$val['i_days_left']:0; ?> <?php echo addslashes(t('day'))?></span> </li><li>|</li><li><?php echo addslashes(t('Budget'))?>: <span><?php echo $val['s_budget_price'] ?></span></li></ul></td>
            <td align="left" valign="middle"><?php echo $val['s_category_name'] ?></td>
            <td align="center" valign="middle" ><strong><?php echo $val['i_quotes'] ?></strong></td>
            <td align="center" valign="middle">
			<input class="small_button" value="<?php echo addslashes(t('View'))?>" type="button" onclick="window.location.href='<?php echo base_url().'job-details/'.encrypt($val['id']) ?>'" />
			</td>
      </tr>
	  <?php $cnt++; } } 
	  else { 
	  ?>
	  <tr>
		  <td class="leftboder">
			<p><?php echo addslashes(t('No item found')) ?></p>
		  </td>
		  <td align="left" valign="middle"></td>
		  <td align="right" valign="middle"  class="text02"></td>
		  <td align="center" valign="middle"></td>
		  
	  </tr>
	  <?php } ?>
	
     
</table>


 <div class="page">
 <?php echo $page_links ?>
 <!-- <ul>
  <li><a href="javascript:void(0);" class="select">1</a></li>
   <li><a href="javascript:void(0);">2</a></li>
	<li><a href="javascript:void(0);">3</a></li>
	 <li><a href="javascript:void(0);">4</a></li>
	  <li><a href="javascript:void(0);">5</a></li>
  </ul>-->
</div>
