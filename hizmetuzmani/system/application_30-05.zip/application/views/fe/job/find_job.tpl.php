<script type="text/javascript">
$(document).ready(function() {

$('input[id^="btn_save"]').each(function(i){
   $(this).click(function(){
   
       //$.blockUI({ message: 'Just a moment please...' });
       $("#frm_adv_src").submit();
	   //check_duplicate();
   }); 
});  

///////////Submitting the form/////////
$("#frm_adv_src").submit(function(){
    var b_valid=true;
    var s_err="";
    $("#div_err").hide("slow"); 
	   
    /////////validating//////
    if(!b_valid)
    {
        //$.unblockUI();  
        $("#div_err").html('<div id="err_msg" class="error_massage">'+s_err+'</div>').show("slow");
    }
    
    return b_valid;
}); 		
		
<?php if($posted['src_job_category_id']) { ?>

var cat_id = <?php echo decrypt($posted['src_job_category_id']) ?>;

//i_category_id_child   === i_category_id_msa_0
//alert($("#i_category_id_msa_1").text());

<?php } ?>

});  // end of document ready

function get_city_state_name(inputString) {
		var p = $("#txt_city");
		var offset = p.offset();
		
		if(inputString.length>1) {	
			//var opt_state = $("#opt_state").val();
			var opt_city = $("#txt_city").val();
			//var txt_zip = $("#txt_zip").val();
			
			$.post("<?=base_url()?>home/ajax_autocomplete_city_state/"+opt_city+"/", {queryString: "" + inputString + ""}, function(data){
					if(data.length >0) {
					
						$('#suggestionsSearch').show();
						$('#autoSuggestionsListSearch').html(data);
						$('#suggestionsSearch').css('left',offset.left);
					}
					else
					{
						$('#suggestionsSearch').hide();
					}
				});
			}
			else
				$('#suggestionsSearch').hide();	
	} // lookup

	function business_fill(thisValue) {
		var b=new Array();
		b["&amp;"]="&";
		b["&quot;"]='"';
		b["&#039;"]="'";
		b["&lt;"]="<";
		b["&gt;"]=">";
		var r;
		for(var i in b){
			r=new RegExp(i,"g");
			thisValue = thisValue.replace(r,b[i]);
		}
		var prop_val = thisValue.split('^');		
		
		$('#opt_city_id').val(prop_val[1]);
		$('#txt_city').val(prop_val[0]);
		$('#suggestionsSearch').hide();
		
	}
</script>
<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">
            <div class="top_part"></div>
            <div class="midd_part height02">
                  <?php include_once(APPPATH."views/fe/common/job_category_list.tpl.php"); ?>
                  <div class="find_job">
                        <h5><?php echo addslashes(t('Find Job'))?></h5>
                        <div class="found_box"><img src="images/fe/search.png" alt="" /> <?php echo $tot_job?> <?php echo addslashes(t('Job(s) found'))?></div>
                        <p class="required02"><?php echo addslashes(t('You can search jobs easily specifing job type, category and location'))?></p>
                        <div class="spacer"></div>
						
						<form name="frm_adv_src" id="frm_adv_src" action="<?php echo base_url().'job/find-job'?>" method="post">
						
                        <div class="job_search_box">
                        
                        <div class="lable"><?php echo addslashes(t('Category'))?></div>
                        <div class="textfell05"><?php //echo '=='.decrypt($posted['src_job_category_id']) ?>
						<select name="i_category_id" id="i_category_id" style="width:244px;">                     
						<option value=""> <?php echo addslashes(t('All'))?></option>
                     <?php echo makeOptionCategory(" c.i_status=1 ", $posted['src_job_category_id']);?>
                        </select>
						<!--<select id="category" name="category" style=" width:249px;">
                        <option>All</option>
                        </select>-->
                        <script type="text/javascript">
						$(document).ready(function() {
						  $("#i_category_id").msDropDown();
						   $("#i_category_id").hide();
						   $('#i_category_id_msdd').css("background-image", "url(images/fe/select02.png)");
						   $('#i_category_id_msdd').css("background-repeat", "no-repeat");
						   $('#i_category_id_msdd').css("width", "249px");
						   $('#i_category_id_msdd').css("margin-top", "0px");
						   $('#i_category_id_msdd').css("padding", "0px");
						    $('#i_category_id_msdd').css("height", "38px");
						     $('#i_category_id_msdd').css("margin-right", "20px");
						});
					
					</script>
                        </div>                        
                        
               
                     <div class="lable"><?php echo addslashes(t('City'))?> </div>
                        <div class="textfell05">
						<div class="parent_city">
						<input type="text"  name="txt_city" id="txt_city" onkeyup="get_city_state_name(this.value)" value="<?php echo $posted['txt_city'] ?>" autocomplete="off" />
						<input type="hidden" name="opt_city_id" id="opt_city_id"  />
					</div>
					<div class="suggestionsBox" id="suggestionsSearch" style="display: none; width:230px; overflow-x:hidden; position:absolute;">
						<div class="arrow_autocom"> &nbsp; </div>
						<div class="suggestionList" id="autoSuggestionsListSearch" style="height:130px; overflow:auto;"> &nbsp; </div>
			  
                              
                              
                              					  		
                    </div>     
                    <span><?php echo addslashes(t('Please enter 2 characters to get a suggestion'))?></span>
						<!--<select id="jobtype" name="jobtype" style=" width:249px;">
                        <option>All</option>
                        </select>
                        <script type="text/javascript">
						$(document).ready(function() {
						  $("#jobtype").msDropDown();
						   $("#jobtype").hide();
						   $('#jobtype_msdd').css("background-image", "url(images/fe/select02.png)");
						   $('#jobtype_msdd').css("background-repeat", "no-repeat");
						   $('#jobtype_msdd').css("width", "249px");
						   $('#jobtype_msdd').css("margin-top", "0px");
						   $('#jobtype_msdd').css("padding", "0px");
						    $('#jobtype_msdd').css("height", "38px");
						   
						});
					
					</script>-->
                        </div>       
                             
                        
                          <div class="spacer margin05"></div>
                          <div class="lable"><?php echo addslashes(t('Keywords'))?> </div>
                        <div class="textfell07">
                        <input name="txt_keyword" id="txt_keyword" value="<?php echo $posted['src_job_keyword']?>" type="text" />
                        </div>
						<input type="hidden" name="txt_fulltext_src" id="txt_fulltext_src" value="<?php echo $posted['src_job_fulltext_src']?>" />
				<input type="hidden" name="txt_fulladd_src" id="txt_fulladd_src" value="<?php echo $posted['src_job_fulladd_src']?>" />
                        <input class="small_button margintop0" id="btn_save" value="<?php echo addslashes(t('Search'))?>" type="button"/>
                        <div class="spacer"></div>
                        
                         
                        
                        <div class="spacer"></div>
                        
                        </div>
						
						</form>
                        
						<!-- job listing  -->
                        <div class="find_box02" id="job_list">
						
                         	<?php echo $job_contents;?>
							
                        </div>
						<!-- job listing  -->
						<!-- pagination div -->
                       
                  		<!-- pagination div -->
                      <div class="spacer"></div>
					 <?php //pr($loggedin); 
					 if(empty($loggedin) || decrypt($loggedin['user_type_id'])!=2) {
					  ?>
						 <h5 class="righttext">
						<a href="<?php echo base_url().'job/job-post' ?>"><?php echo addslashes(t('Are you ready to post your job'))?>?</a>
						</h5>
				<?php } ?>
                  </div>
                  
                  
                  <div class="spacer"></div>
                  
            </div>
            <div class="spacer"></div>
            <div class="bottom_part"></div>
      </div>