<div class="job_categories">
            <div class="top_part"></div>
            <div class="midd_part height02">
                  <div class="username_box">
                        <div class="left_box02"> <?php echo showThumbImageDefault('user_profile',$info_tradesman['s_image'],'no_image_man.png',259,178); ?>
                              <div class="spacer"></div>
                              <input type="button" value="Get a Quote" class="button marginleft02"  onclick="window.location.href='javascript:void(0);'"/>
                              
                              
                              <div class="rating">98,5% ratiting <br/>
<img src="images/fe/blue-star.png" alt="" /><img src="images/fe/blue-star.png" alt="" /><img src="images/fe/blue-star.png" alt="" /><img src="images/fe/blue-star.png" alt="" /><img src="images/fe/blue-star.png" alt="" /></div>
                        </div>
                        <div class="right_box02">
                              <h2><?php echo $info_tradesman['s_username'] ; ?> (#) <span><img src="images/fe/Verified.png" alt="" /> Verified Tradesman </span></h2>
                              <h3><?php echo $info_tradesman['s_city_name'].' - '.$info_tradesman['s_province']; ?></h3>
                              <div class="spacer"></div>
                              <div class="categories">
                                    <h4>Categories of expertise</h4>
                                    <ul>
                                    <?php 
                                    if(!empty($arr_cat))
                                    {
                                        foreach($arr_cat as $val)
                                        { 
                                    ?>
                                    
                                          <li><img src="images/fe/tick.png" alt="" /><span><?php echo $val['s_category_name']?></span><em><?php echo $val['s_experience'].' ' ; echo ($val['s_experience']==1)?addslashes(t('year')):addslashes(t('years')); ?> </em></li>
                              <?php                                            
                                        }
                                    }
                                ?>
                                         
                                    </ul>
                              </div>
                              <div class="categories lastbox">
                                    <h4>About working info</h4>
                                    <ul>
                                    <?php
                                    if(!empty($work_place))
                                    {
                                        foreach($work_place as $val)
                                        {
                                    ?>
                                         <li><img src="images/fe/tick.png" alt="" /><?php echo $val['s_work_place'];  ?></li>
                                    <?php        
                                        }
                                    }
                                    ?>
                                         
                                         
                                    </ul>
                              </div>
                              <div class="spacer"></div>
                              
                             <div class="keyword_box"> 
                             <ul class="keyword">
                              <li><strong>keywords:</strong></li>
                              <?php 
                              if(!empty($arr_keyword)) 
                              {
                                foreach($arr_keyword as $val)
                                {
                              ?>
                               <li> <a href="javascript:void(0);"><?php echo $val; ?></a></li>
                              <li>,&nbsp;</li>
                              
                              <?php       
                                }    
                              }
                               ?>
                             
                             
                              </ul> <div class="spacer"></div></div>
                              
                        </div>
                        <div class="spacer"></div>
                        <div class="body_left">
                        <div class="box03_out">
                              <div class="box03">
                                    <h3><?php echo addslashes(t('Profile Verified By'));  ?></h3>
                                    <?php if($info_tradesman['i_ssn_verified'] ||  $info_tradesman['i_address_verified']  || $info_tradesman['i_mobile_verified'] || $info_tradesman['i_verified'])
                                    {
                                        ?>
                                        <img src="images/fe/Verified02.png" alt="" />
                                   <?php   
                                    } 
                                        ?>
                                    
                                    <div class="spacer"></div>
                                    <ul class="next_box03">
                                          <li><img src="<?php // echo ($info_tradesman['i_ssn_verified'])?'images/fe/tick.png':'images/fe/deactivated.png' ; ?>"><?php echo addslashes(t('Social security number'));  ?></li>
                                          <li><img src="<?php // echo ($info_tradesman['i_address_verified'])?'images/fe/tick.png':'images/fe/deactivated.png' ; ?>"><?php  echo addslashes(t('Address proof'));  ?></li>
                                          <li><img src="<?php // echo ($info_tradesman['i_mobile_verified'])?'images/fe/tick.png':'images/fe/deactivated.png' ; ?>"><?php  echo addslashes(t('Mobile phone'));  ?></li>
                                          <li><img src="<?php // echo ($info_tradesman['i_verified'])?'images/fe/tick.png':'images/fe/deactivated.png' ; ?>"><?php echo addslashes(t('Email'));  ?></li>
                                    </ul>
                                    <div class="spacer"></div>
                                   <!--<h4>Note: Only email verification not enough to get this</h4>-->
                                    <div class="spacer"></div>
                              </div></div>
                              
                              <div class="box03_out">
                              <div class="box03">
                                    <h3>User stats</h3>
                                    <ul class="next_box">
                                          <li><?php echo addslashes(t('Member since')); ?> <?php echo $info_tradesman['s_created_on']; ?></li>
                                          <li><?php echo addslashes(t('Last Login')); ?>: <?php echo $info_tradesman['s_last_login_on']; ?></li>
                                          <li> <?php echo $won_jobs.' '.addslashes(t('Won Jobs')); ?></li>
                                          <li><?php echo $quote_placed.' '.addslashes(t('quote placed')); ?></li>
                                          <!--<li># people viewed</li>   -->
                                    </ul>
                                    <div class="spacer"></div>
                              </div>
                              </div>
                              <div class="box03_out">
                              <div class="box03">
                                    <h3><?php echo addslashes(t('Similar tradesmen')); ?></h3>
                                    <ul class="next_box02">
                                    <?php
                                    // similar tradesman bhy category
                                    if(!empty($similar_tradesman))
                                    {
                                        foreach($similar_tradesman as $val)
                                        {
                                    ?>
                                        <li><a href="<?php echo base_url().'tradesman-profile/'.encrypt($val['i_user_id']) ?>"><?php echo $val['s_username']; ?></a></li>  
                                    <?php
                                        }
                                    }
                                    ?>

                                    </ul>
                                    <div class="spacer"></div>
                              </div>
                              </div>
                              <div class="box03_out">
                              <div class="box03">
                                    <h3>Adsense  box</h3>
                                    <p>ADSENSE</p>
                                    <div class="spacer"></div>
                              </div>
                              </div>
                        </div>
                        <div class="body_right">
                              <div id="div_container">
                                    <ul class="tab7">
                                          <li><a href="JavaScript:void(0);" title="post_a_Job" class="tab2 active1"><span><?php echo addslashes(t('About tradesmen')); ?></span></a></li>
                                          <li>|</li>
                                          <li><a href="JavaScript:void(0);" title="get_quotes" class="tab2"><span><?php echo addslashes(t('Contact info')); ?></span></a></li>
                                          <li>|</li>
                                          <li><a href="JavaScript:void(0);" title="tradesman" class="tab2"><span><?php echo addslashes(t('Feedback')); ?></span></a></li>
                                    </ul>
                                    <div class="spacer"></div>
                                    <div class="body_right_03_inner">
                                          <!--1st tab-->
                                          <div class="tsb_text02" id="post_a_Job" style="display:block;">
                                                <p><?php echo $info_tradesman['s_about_me']; ?></p>
                                                <div class="spacer"></div>
                                          </div>
                                          <!--1st tab-->
                                          <!--2nd tab-->
                                          <div class="tsb_text02" id="get_quotes" style="display:none;">
                                                <div class="lable03">Firm/Company name:</div>
                                                <div class="lable05"><?php echo $info_tradesman['s_about_me']; ?></div>
                                                <div class="spacer"></div>
                                                <div class="lable03">Address:</div>
                                                <div class="lable05"><?php echo $info_tradesman['s_address']; ?></div>
                                                <div class="spacer"></div>
                                                <div class="lable03">Contact number:</div>
                                                <div class="lable05"><?php  echo $info_tradesman['s_contact_no']; ?></div>
                                                <div class="spacer"></div>
                                                <!--<div class="lable03">Mobile:</div>
                                                <div class="lable05"></div>
                                                <div class="spacer"></div>-->
                                                <div class="lable03">Email:</div>
                                                <div class="lable05"><?php echo $info_tradesman['s_email']; ?></div>
                                                <div class="spacer"></div>
                                                <!--<div class="lable03">Website:</div>
                                                <div class="lable05"></div>-->
                                                <div class="spacer"></div>
                                                <h4>Photo Album</h4>
                                                <div class="photo_album1">
                                                <?php if(!empty($info_album))
                                                {
                                                    foreach($info_album as $val)
                                                    {
                                                ?>
                                                <div class="photo"><a onclick="show_dialog('photo_zoom02')"><?php echo showThumbImageDefault('trades_album',$val['s_image'],'no_image.jpg',100,100); ?></a></div>
                                                
                                                <?php
                                                    }
                                                } 
                                                ?>
                                                      <div class="spacer"></div>
                                                </div>
                                          </div>
                                          <!--2nd tab-->
                                          <!--3rd tab-->
                                          <div class="tsb_text02" id="tradesman" style="display:none;">
                                          <?php 
                                          if(!empty($feedback_contents))
                                          {
                                              foreach($feedback_contents as $val)
                                              {
                                          ?>
                                           <div class="main_faq">
                                                      <div class="faq_heading"><?php echo $val['s_job_title'] ; ?></div>
                                                      <div class="faq_contant">
                                                           <div class="feed_back width02">
                                                             <div class="left_feedback"><h5><img src="images/fe/dot1.png" alt="" /><?php echo $val['s_comments'] ; ?></h5>
                                                             <?php if($val['i_positive']==1)
                                                              {
                                                              ?>
                                                                    <h6><img src="images/fe/Positive.png" alt="" /><?php echo addslashes(t('Positive feedback')) ;?></h6>
                                                              <?php    
                                                              }
                                                              else
                                                              {
                                                              ?>
                                                                    <h6><img src="images/fe/Negetive.png" alt="" /><?php echo addslashes(t('Negetive feedback')) ;?></h6>
                                                              <?php    
                                                              }
                                                              ?>
                                                             
                                                             </div>
                                                             <div class="right_feedback">
                                                             <h6><?php echo $val['s_sender_user'] ; ?><br/><span><?php echo $val['dt_created_on'] ; ?></span></h6>
                                                             <?php echo show_star($val['i_rating']); ?>
                                                             </div>
                                                             <div class="spacer"></div>
                                                           </div>
                                                      </div>
                                           </div>
                                          <?php
                                              }
                                          }
                                          else
                                          {
                                              echo '<p>'.addslashes(t('No item found')).'</p>'; 
                                          }
                                          ?>
                                               
                                         </div>
                                          <!--3rd tab-->
                                    </div>
                              </div>
                              
                              <h3><?php echo addslashes(t('History'))?> </h3>
                              <ul class="next06">
							  <?php if(count($tradesman_history)>0) {
							  		foreach($tradesman_history as $val)
									{
							   ?>
                              <li><?php echo $val['msg_str'] .' , '.time_ago($val['i_create_date'])?></li>
							  <?php } } else { ?>
							  <li><?php echo addslashes(t('No item found')) ?></li>
							  <?php } ?>
                              </ul>
                        </div>
                        <div class="spacer"></div>

                        
                  </div>
                  <div class="spacer"></div>
            </div>
            <div class="spacer"></div>
            <div class="bottom_part"></div>
      </div>