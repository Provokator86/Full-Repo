<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">    
	<div class="top_part"></div>
	<div class="midd_part height02">
	<?php include_once(APPPATH.'views/fe/common/message.tpl.php'); ?>
	<h2><?php echo addslashes(t('Abuse Report'))?></h2>
	<div class="margin10"></div>
	<p><?php echo addslashes(t('Thank you for your opinion. You will get reply soon'))?>.</p>
	</div>         
</div>