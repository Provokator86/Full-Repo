<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">
            <div class="top_part"></div>
            <div class="midd_part height02">
                  <div class="spacer"></div>
                  <h2><?php echo $info[0]['s_title'] ?> </h2>
                  <div class="content_box">
				  	<?php echo $info[0]['s_desc_full'] ?>                 
                  </div>
                  
            </div>
	<div class="spacer"></div>
	<div class="bottom_part"></div>
</div>