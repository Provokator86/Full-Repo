<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">
	<div class="top_part"></div>
       <div class="midd_part height02">
		  <div class="spacer"></div>
		  	<h2><?php echo $news_details['s_title'] ?></h2>
                 <div class="content_box">
					  <p><?php echo $news_details['s_description'] ?></p>
					 <div class="spacer"></div> 
		  		</div>
		  
		</div>
		<div class="spacer"></div>
	<div class="bottom_part"></div>
</div>