<div class="icon_bar">
  <ul>
	  <li><img src="images/fe/edit.png" alt="" /> Edit</li>
	  <li>|</li>
	  <li><img src="images/fe/view.png" alt="" /> View</li>
	   <li>|</li>
	  <li><img src="images/fe/history.png" alt="" />History</li>
	   <li>|</li>
	  <li><img src="images/fe/delete.png" alt="" />Delete</li>
	  <li>|</li>
	  <li><img src="images/fe/feedback.png" alt="" />Feedback</li>
	  <li>|</li>
	  <li><img src="images/fe/mass.png" alt="" />Messages</li>
	  <li>|</li>
	  <li class="last"><img src="images/fe/new.png" alt="" />New</li>
  </ul>
   <div class="spacer"></div>
</div>