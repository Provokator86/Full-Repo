<script type="text/javascript">
function submit_job()
{
$("#form_job_post").submit();
}
</script>
<div class="banner_sh">
  <div id="banner">
    <ul class="tab6">
      <li><a href="JavaScript:void(0);" title="reviews" class="tab1 active1"><?php echo addslashes(t('I Need That'))?>.. </a></li>
      <li><a href="JavaScript:void(0);" title="certificatess" class="tab1 "><?php echo addslashes(t('I Am Tradesman'))?></a></li>
      <li><a href="JavaScript:void(0);" title="pictures" class="tab1 "><?php echo addslashes(t('How It  Works'))?></a></li>
    </ul>
    <div class="body_right_03_inner">
      <!--1st tab-->
      <div class="tsb_text" id="reviews" style="display:block;">
	  <form name="form_job_post" id="form_job_post" method="post" action="<?php echo base_url().'freesearch'?>">
        <div class="tab01">
          <h2><?php echo addslashes(t('The Better Way to Find Builders'))?></h2>
          <p><?php echo addslashes(t('Every day, thousands of people depend on MyBuilder\'s trusted review system to take the worry out of finding professional local builders &amp; tradesmen'))?>.</p>
          <div class="textfell">
            <input type="text" id="service" name="txt_service" value="<?php echo addslashes(t('What service do you need'))?> ?" size="35" onclick="if(this.value=='<?php echo addslashes(t('What service do you need'))?> ?')
 document.getElementById('service').value ='';" onblur="if(this.value=='') document.getElementById('service')
.value ='<?php echo addslashes(t('What service do you need'))?> ?';" />
          </div>
          <div class="spacer"></div>
          <div class="textfell02">
            <input type="text" id="where" name="txt_where" value="<?php echo addslashes(t('Where'))?> ?" size="35" onclick="if(this.value=='<?php echo addslashes(t('Where'))?> ?')
 document.getElementById('where').value ='';" onblur="if(this.value=='') document.getElementById('where')
.value ='Where ?';" />
          </div>
          <input class="button" type="button" onclick="submit_job()" value="<?php echo addslashes(t('Post Your Job for free'))?>" />
        </div>
	  </form>	
      </div>
      <!--1st tab-->
      <!--2nd tab-->
      <div class="tsb_text" id="certificatess" style="display:none;">
     <div class="tab01 tab02">
     <h2><?php echo addslashes(t('What job are you looking for'))?></h2>
     <p><?php echo addslashes(t('It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English'))?>.
 </p>
     <div class="textfell02">
	 		<form name="frm_indx_job_src" method="post" action="<?php echo base_url().'job/find-job'?>">
            <input type="text" id="dgr" name="txt_fulladd_src" value="<?php echo addslashes(t('Where ?'))?>" size="35" onclick="if(this.value=='<?php echo addslashes(t('Where ?'))?>')
 document.getElementById('dgr').value ='';" onblur="if(this.value=='') document.getElementById('dgr')
.value ='<?php echo addslashes(t('Where ?'))?>';" />
          </div>
          <input class="button" type="submit" value="<?php echo addslashes(t('Search'))?>" />
		  </form>
     </div>
       
      </div>
      <!--2nd tab-->
      <!--3rd tab-->
      <div class="tsb_text" id="pictures" style="display:none;">
        <div class="tab01 tab03">
        <h2><?php echo addslashes(t('Benefits for users'))?></h2>
        <div class="left_part"><h3><?php echo addslashes(t('Benefits for tradesman'))?></h3>
        <div class=" spacer"></div>
        <p><?php echo addslashes(t('Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)'))?>.</p></div>
         <div class="left_part"><h4><?php echo addslashes(t('Reating profile is for free'))?> </h4>

 <ul>
 <li><?php echo addslashes(t('No listing fees'))?></li>
 <li><?php echo addslashes(t('No membership fees for users'))?></li>
 <li><?php echo addslashes(t('Low comissions for tradesmen'))?></li>
 <li><?php echo addslashes(t('Membership not a'))?> "<strong><?php echo addslashes(t('must'))?></strong>"  </li>
 <li><?php echo addslashes(t('Open quotes to see actual bids'))?> </li>
 </ul></div>
        
 
  <input class="button" type="button" value="<?php echo addslashes(t('Join us'))?> " onclick="show_dialog('photo_zoom')" />
 
        </div>
      </div>
      <!--3rd tab-->
    </div>
    <div class="join_us">
      <input class="join_us_button" type="button" value=""   onclick="show_dialog('photo_zoom')"/>
      <div class="spacer"></div>
      <div class="icon"> <a href="https://twitter.com/#!/hizmet_uzmani"><img src="images/fe/tw.png" alt="" onmouseover="this.src='images/fe/tw-hover.png'" onmouseout="this.src='images/fe/tw.png'" /></a> <a href="https://www.facebook.com/hizmetuzmani"><img src="images/fe/facebook.png" alt="" onmouseover="this.src='images/fe/facebook-hover.png'" onmouseout="this.src='images/fe/facebook.png'" /></a> <a href="javascript:void(0);"><img src="images/fe/rss.png" alt="" onmouseover="this.src='images/fe/rss-hover.png'" onmouseout="this.src='images/fe/rss.png'" /></a> </div>
    </div>
  </div>
  </div>
  
  <!--bar-->
  <div class="bar">
    <ul>
      <li><span>1.</span><?php echo addslashes(t('Post a Job'))?></li>
      <li><span>2.</span><?php echo addslashes(t('Get Quotes'))?></li>
      <li><span>3.</span><?php echo addslashes(t('Hire a Tradesman'))?></li>
      <li class="marginright"><span>4.</span><?php echo addslashes(t('Leave FeedBack'))?></li>
    </ul>
  </div>
 
  <!--bar-->