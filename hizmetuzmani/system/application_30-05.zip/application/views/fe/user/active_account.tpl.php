<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">    
	<div class="top_part"></div>
	<div class="midd_part height02">
	<?php include_once(APPPATH.'views/fe/common/message.tpl.php'); ?>	
	<p><?php echo addslashes(t('Your account has been activated successfully, you can login now'))?>.</p>
	</div>         
</div>

