   <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                      <tr>
                                                            <th  align="left" valign="middle">Name</th>
                                                            <th align="left" valign="middle">Email</th>
                                                            <th align="center" valign="middle" class="margin00">Recommend Date</th>
                                                            <th  align="center" valign="middle" class="margin00">Status </th>
                                                      </tr>
                                                      <tr>
                                                            <td valign="middle" align="left" class="leftboder">Ispum</td>
                                                            <td align="left" valign="middle"><a href="mailto:lorem@gmail.com">lorem@gmail.com</a></td>
                                                            <td valign="middle" align="center">12.05.2011</td>
                                                            <td align="center" valign="middle">Accepted</td>
                                                      </tr>
                                                      <tr class="bgcolor">
                                                            <td valign="middle" align="left" class="leftboder">Ispum</td>
                                                            <td align="left" valign="middle"><a href="mailto:lorem@gmail.com">lorem@gmail.com</a></td>
                                                            <td valign="middle" align="center">12.05.2011</td>
                                                            <td align="center" valign="middle">Pending</td>
                                                      </tr>
                                                      <tr>
                                                            <td valign="middle" align="left" class="leftboder">Ispum</td>
                                                            <td align="left" valign="middle"><a href="mailto:lorem@gmail.com">lorem@gmail.com</a></td>
                                                            <td valign="middle" align="center">12.05.2011</td>
                                                            <td align="center" valign="middle">Accepted</td>
                                                      </tr>
                                                      <tr class="bgcolor">
                                                            <td valign="middle" align="left" class="leftboder">Ispum</td>
                                                            <td align="left" valign="middle"><a href="mailto:lorem@gmail.com">lorem@gmail.com</a></td>
                                                            <td valign="middle" align="center">12.05.2011</td>
                                                            <td align="center" valign="middle">Pending</td>
                                                      </tr>
                                                </tbody>
                                          </table>
