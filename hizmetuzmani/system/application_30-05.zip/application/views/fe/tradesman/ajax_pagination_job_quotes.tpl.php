<script type="text/javascript">
	$(document).ready(function(){
	//$("input[id^='txt_quote_']").numeric({});
	/******** validation for text box of GSM NUMBER, and FIRM PHONE to allow only numeric *******/
    
$(".numeric_valid").keydown(function(e){
		if(e.keyCode==8 || e.keyCode==9 || e.keyCode==46)
		{
			return true; 
		}    
		if($(this).val().length>9) // check for more than 7 digit
		{
			return false;
		}
		 
		 return (e.keyCode>=48 && e.keyCode<=57 || e.keyCode>=96 && e.keyCode<=105) //Only 0-9 digits are allowed

})  ;
/******** validation for text box to allow only numeric *******/ 
	 
});
	function quote_edit(elem)
	{	
		$("span[id^='sp_save_']").hide();
		$("span[id^='sp_edit_']").show();
		$("input[id^='txt_quote_']").addClass('disable_css');
		$("input[id^='txt_quote_']").attr("disabled","disabled");
		$("#txt_quote_"+elem).removeAttr("disabled");
		$("#txt_quote_"+elem).removeClass('disable_css');
		$("#txt_quote_"+elem).addClass('enable_css');
		$("#sp_edit_"+elem).hide();
		$("#sp_save_"+elem).show();
	}

	function quote_save(elem,jobs_id,quote_id)
	{
		var b_valid = true;
		
		if($.trim($("#txt_quote_"+elem).val())=='')
			b_valid = false;
		
		if(b_valid)
		{
			$.ajax({
				type: "POST",
			    url: base_url + "tradesman/do_quote_update",
			   data: {
			   			s_job_id:jobs_id,
						d_quote_amt:$("#txt_quote_"+elem).val(),
						s_quote_id:quote_id
			   		},
			   dataType: 'JSON',
			   success: function(res){
			 
				 if(res.flag)
				 {
				 	
					$('#div_err1').html('<div class="success_massage">'+res.msg+'<div>').show();
					//window.location.reload();
					$("span[id^='sp_save_']").hide();
					$("span[id^='sp_edit_']").show();
					$("input[id^='txt_quote_']").addClass('disable_css');
					$("input[id^='txt_quote_']").attr("disabled","disabled");
				 }
				 else
				 {
				 	$('#div_err1').html('<div class="error_massage">'+res.msg+'<div>').show();;
				 }
			   }

			});
		}
		else
		{
		$('#div_err1').html('<div class="error_massage"><?php echo addslashes(t('Quoted price can not be left blank.'))?><div>');
		}
	}
</script>
<div id="div_err1">
</div>
<div class="div01 noboder">
	<div class="find_box02">
	  <table width="100%" cellspacing="0" cellpadding="0" border="0">
		<tbody>
		  <tr>
				<th   align="left" valign="middle"><?php echo addslashes(t('Job Details'))?> </th>
				<th  align="center" valign="middle" class="margin00"><?php echo addslashes(t('Location'))?></th>
				<th  align="left" valign="middle" ><?php echo addslashes(t('Quoted Price'))?></th>
				<th  align="center" valign="middle" class="margin00"><?php echo addslashes(t('Option'))?> </th>
		  </tr>
		  
		  <?php if($job_quotes) { 
					$i = 1;
		  
				foreach($job_quotes as $val)
					{ 
					$class = ($i%2 == 0)?'class="bgcolor"':'';
		   ?>
			  
		  <tr <?php echo $class ?>>
				<td valign="middle" align="left" class="leftboder"><h5>
				<a href="<?php echo base_url().'job-details/'.encrypt($val['job_details']['id']) ?>"><?php echo string_part($val['job_details']['s_title'],30) ?></a></h5>
					  <?php echo string_part($val['job_details']['s_description'],150) ?>
					  <div class="spacer"></div>
					  <ul>
							<li><?php echo addslashes(t('Category'))?>: <span><?php echo $val['job_details']['s_category'] ?></span> </li>
							<li>|</li>
							<li><?php echo addslashes(t('Expiry Date'))?> <span><?php echo $val['job_details']['dt_expire_date'];?></span></li>
							</ul>
							<ul class=" spacer">
							
							<li><?php echo addslashes(t('Budget'))?>:<span> <?php echo $val['job_details']['s_budget_price'] ?></span></li>
					  </ul></td>
				<td valign="middle" align="center" class="width20"><?php echo $val['job_details']['s_province'].','. $val['job_details']['s_city'].','.'<br/>'.
$val['job_details']['s_postal_code'] ?></td>
			<td valign="middle" align="left" class="width22">
			   <h3>TL</h3>
			   <?php if($val['i_job_status']==1 && $val['i_status']==1){ ?>
					  <div class="textfell">					  
					  <input type="text" class="disable_css" value="<?php echo $val['d_quote']?>" class="numeric_valid" disabled="disabled" name="txt_quote_<?php echo $i?>" id="txt_quote_<?php echo $i?>" />
					  
				</div>
			<span id="sp_edit_<?=$i?>">
			<a href="javascript:void(0);" class="icon" onclick="javascript:quote_edit(<?=$i?>)">
			<img src="images/fe/edit02.png" alt="<?php echo addslashes(t('Edit'))?>" title="<?php echo addslashes(t('Edit'))?>" />
			</a>
			</span>
			
			<span id="sp_save_<?=$i?>" style="display:none">
			  <a href="javascript:void(0);" 
			  onclick="javascript:quote_save(<?=$i?>,'<?=encrypt($val['i_job_id'])?>','<?=encrypt($val['id'])?>')">
			 <img src="images/fe/save.png" alt="<?php echo addslashes(t('Save'))?>" title="<?php echo addslashes(t('Save'))?>" />
			 </a>
			 </span>
			<?php  } else { ?>
			<div class="textfell">
				<input type="text" class="disable_css" value="<?php echo $val['d_quote']; ?>" class="numeric_valid" disabled="disabled" />
			</div>
			<?php } ?>
				 
			<div class="spacer margin05"></div>
			<?php echo string_part($val['s_comment'],35) ?>
				
				
				</td>
				<td valign="middle" align="center" class="width18"> 
				<a href="<?php echo base_url().'job-details/'.encrypt($val['job_details']['id']) ?>" target="_blank"><img src="images/fe/view.png" alt="" onmouseover="this.src='images/fe/view-hover.png'" onmouseout="this.src='images/fe/view.png'"  onclick="this.src='images/fe/view.png'"  title="view"/></a>
				
				<a href="<?php echo base_url().'tradesman/pmb_landing/'.encrypt($val['job_details']['id'])  ;?>"><img src="images/fe/mass.png" alt="" onmouseover="this.src='images/fe/mass-hover.png'" onmouseout="this.src='images/fe/mass.png'"  onclick="this.src='images/fe/mass.png'"  title="message"/></a>                                                             </td>
		  </tr>			  
			  
		  <?php $i++; } } 
			  else { 
	      ?>
		  <tr>
			  <td class="leftboder">
				<p><?php echo addslashes(t('No item found')) ?></p>
			  </td>
			  <td align="left" valign="middle"></td>
			  <td align="right" valign="middle"  class="text02"></td>
			  <td align="center" valign="middle"></td>
			  
		  </tr>
	     <?php } ?>	
		  	  
		</tbody>
	  </table>
	</div>
</div>
<div class="spacer"></div>
  <div class="page">
	<?php echo $page_links ?>	
  </div>