<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">  
  <div class="top_part"></div>
	<div class="midd_part height02">
	  <div class="username_box">
		<div class="right_box03">
		   <h4><?php echo addslashes(t('Quotes'))?> </h4>
		  <div class="div01">
				<p><?php echo addslashes(t('This section consists of all the bids you have placed in respect to all the jobs that are relevant to you'))?></p>
				
				<div class="spacer"></div>
			  
		  </div>
		  <!-- quote list -->
		  <div id="job_quotes">
		  <?php echo $job_quotes ?>
		  </div>
		  <!-- quote list -->
			  
		  <div class="spacer"></div>
			  
			<!--- icon bar -->  
		  <div class="icon_bar">
			  <ul>
				  <li><img src="images/fe/edit.png" alt="" /> <?php echo addslashes(t('Edit'))?></li>
				  <li>|</li>
				  <li><img src="images/fe/view.png" alt="" /> <?php echo addslashes(t('View'))?></li>
				   <li>|</li>				  
				  <li class="last"><img src="images/fe/mass.png" alt="" /><?php echo addslashes(t('Messages'))?></li>
			  </ul>
		   <div class="spacer"></div>
		  </div>
		  <!--- icon bar --> 
		  
		 <div class="spacer"></div>
		</div>
			<?php include_once(APPPATH."views/fe/common/tradesman_left_menu.tpl.php"); ?>
			<div class="spacer"></div>
	  </div>
		  <div class="spacer"></div>
	</div>
  <div class="spacer"></div>
  <div class="bottom_part"></div>
</div>