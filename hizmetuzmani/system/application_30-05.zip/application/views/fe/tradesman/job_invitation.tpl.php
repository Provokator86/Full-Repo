<script type="text/javascript">
 $(document).ready(function() {
 	var param_id = '';
 	$(".login_button02").click(function() {
	param_id = $(this).attr('rel');
	$("#h_job_id").val(param_id);
	show_dialog('photo_zoom02');
	});
 	
	$("#btn_quote").click(function() { 
		var b_valid = true;
		var quote_val = /^[0-9]+$/;
		if($.trim($("#txt_quote").val())=="") //// For  name 
		{
			$("#err_txt_quote").text('<?php echo addslashes(t('Please provide your bid'))?>').slideDown('slow');
			b_valid  =  false;
		}
		else if(quote_val.test($.trim($("#txt_quote").val()))==false)
		{
			$("#err_txt_quote").text('<?php echo addslashes(t('Please provide numeric value with no decimal point'))?>').slideDown('slow');
			b_valid  =  false;
		}
		else
		{
			$("#err_txt_quote").slideUp('slow').text('<?php echo addslashes(t(''))?>');
		}
		if($.trim($("#ta_message").val())=="") //// For  name 
		{
			$("#err_ta_message").text('<?php echo addslashes(t('Please provide message'))?>').slideDown('slow');
			b_valid  =  false;
		}
		else
		{
			$("#err_ta_message").slideUp('slow').text('<?php echo addslashes(t(''))?>');
		}
		 if(!b_valid)
		{
		   // $.unblockUI();  
			$("#div_err").html(s_err).show("slow");
		}
		
		else
		{
		//$("#ajax_frm_job_confirm").submit();
		var quote 	= $("#txt_quote").val();
		
		var comment = $("#ta_message").val();
		var job_id = $("#h_job_id").val();
		 		$.ajax({
                        type: "POST",
                        async: false,
                        url: base_url+'job/save_quote_job',
                        data: "txt_quote="+quote+"&ta_message="+comment+"&h_job_id="+job_id,
                        success: function(msg){
                            if(msg)
                            {
								msg = msg.split('|');
								alert(msg);
								var s_msg = msg[1];								
								if(msg[0]==1)
								{
									$('#div_err1').html('<div class="success_massage">'+s_msg+'<div>');
								}
								else
									$('#div_err1').html('<div class="error_massage">'+s_msg+'<div>');
							}
                        }
                    });
			setTimeout('window.location.reload()',2000);		
		}
		return false;
	});
	
	});	
</script>
<?php include_once(APPPATH."views/fe/common/breadcrumb.tpl.php"); ?>
<div class="job_categories">
            <div class="top_part"></div>
	<div class="midd_part height02">
	  <div class="username_box">
		<div class="right_box03">
			  <h4><?php echo addslashes(t('Job Invitations'))?></h4>
			  
			  <div class="div01">
			  <p><?php echo addslashes(t('Here you will find all the Job Invitations by the Buyers.'))?></p>
			  <div class="spacer"></div>
			  </div>
			  <div id="job_list">
			  <?php echo $job_contents; ?>
			  </div>
			  
			  <div class="spacer"></div>
			  
			  <div class="icon_bar">
			  <ul>
			  <li><img src="images/fe/view.png" alt="" /> <?php echo addslashes(t('View'))?></li>
			   <li>|</li>
			  <li class="last"><img src="images/fe/delete.png" alt="" /><?php echo addslashes(t('Delete'))?></li>
			  </ul>
			   <div class="spacer"></div>
			  </div>
			   <div class="spacer"></div>
			  
		</div>
			<?php include_once(APPPATH."views/fe/common/tradesman_left_menu.tpl.php"); ?>
			<div class="spacer"></div>
	  </div>
		  <div class="spacer"></div>
	</div>
	<div class="spacer"></div>
	<div class="bottom_part"></div>
</div>

<!--lightbox-->
<div class="lightbox02 photo_zoom02 width04">
<div id="div_err1">
</div>
      <div class="close"><a href="javascript:void(0);" onclick="hide_dialog()"><img src="images/fe/Close.png" alt="" /></a></div>
      <h3>Place Quote</h3>
      <div class=" lable04">Your bid :</div>
     
	 <div class="textfell">
	 	<input type="hidden" name="h_job_id" id="h_job_id" value="" />
        <input name="txt_quote" id="txt_quote" type="text" />
	 </div>	<div class="lable03">TL</div> 
	 <div class="spacer"></div>
	  <div id="err_txt_quote" class="err" style="margin-left:130px;"><?php echo form_error('txt_quote') ?></div>
	  
      <div class="spacer"></div>
	  <div class=" lable04"><?php echo addslashes(t('Message'))?> :</div>
      <div class="textfell06">
          <textarea name="ta_message" id="ta_message"></textarea>
      </div>
	  <div class="spacer"></div>
	  <div id="err_ta_message" class="err" style="margin-left:130px;"><?php echo form_error('ta_message') ?></div>
      <div class="spacer"></div>	
       
	<div class="lable04"></div>
	<input class="small_button" id="btn_quote" type="button" value="<?php echo addslashes(t('Submit'))?>" />


</div>
<!--lightbox quote -->
<!--lightbox delete -->
<div class="lightbox04 photo_zoom06">
      <div class="close"><a href="javascript:void(0);" onclick="hide_dialog()"><img src="images/fe/Close.png" alt="" /></a></div>
<h3>Are you sure you want to delete the Job?</h3>>
<div class="buttondiv">
<input class="login_button flote02" type="button" value="Yes" />
<input class="login_button flote02" type="button" value="No" />
</div>
</div>
<!--lightbox-->