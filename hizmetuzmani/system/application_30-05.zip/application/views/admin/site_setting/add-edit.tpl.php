<div id="right_panel">
    <h2>Accounts</h2>
    <p>&nbsp;</p>
    <div class="left"><input name="input3" type="button" value="Save" /> <input name="input4" type="button" value="Cancel" /></div>
    <div class="add_edit">
    <div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th width="15%" align="left"><h4>Account Information</h4></th>
          <th width="35%" align="left">&nbsp;</th>
          <th width="15%">&nbsp;</th>
          <th width="35%">&nbsp;</th>
        </tr>
        <tr>
          <td>Name:</td>
          <td><input type="text" size="39" /></td>
          <td>Phone Office: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Website: </td>
          <td><input type="text" value="http://" size="39" /></td>
          <td>Phone Fax: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Ticker Symbol:</td>
          <td><input type="text" size="39" /></td>
          <td>Other Phone: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Member of: </td>
          <td><input type="text" size="16" /> <input type="button" value="Select" /> <input type="button" value="Clear" /></td>
          <td>Employees: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Ownership: </td>
          <td><input type="text" size="39" /></td>
          <td>Rating: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Industry: </td>
          <td><span class="left">
            <select name="select">
              <option>Select</option>
                        </select>
          </span></td>
          <td>SIC Code:</td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Type: </td>
          <td><span class="left">
            <select name="select2">
              <option>Select</option>
            </select>
          </span></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Campaign: </td>
          <td><input type="text" size="16" /> <input type="button" value="Select" /> <input type="button" value="Clear" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Assigned to: </td>
          <td><input type="text" value="alexadmin" size="16" /> 
            <input type="button" value="Select" /> <input type="button" value="Clear" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Deneme: </td>
          <td><input type="text" size="16" /> <input type="button" value="Select" /> <input type="button" value="Clear" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>ATRIX_CustomProspects:</td>
          <td><input type="text" size="16" /> <input type="button" value="Select" /> <input type="button" value="Clear" /></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      </div>
    </div>
    <div class="add_edit">
    	<div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th width="15%" align="left"><h4>Financials</h4></th>
          <th width="35%" align="left">&nbsp;</th>
          <th width="15%">&nbsp;</th>
          <th width="35%">&nbsp;</th>
        </tr>
        <tr>
          <td>Annual Revenue:</td>
          <td><input type="text" size="39" /></td>
          <td>Ticker Code: </td>
          <td><input type="text" size="39" /></td>
        </tr>
      </table>
      </div>
    </div>
    <div class="add_edit">
    	<div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>

          <th width="15%" align="left"><h4>Address Information</h4></th>
          <th width="35%" align="left">&nbsp;</th>
          <th width="18%">&nbsp;</th>
          <th width="32%">&nbsp;</th>
        </tr>
        <tr>
          <td valign="top">Billing Address:</td>
          <td valign="top"><textarea cols="36" rows="4"></textarea></td>
          <td valign="top">Shipping Address: </td>
          <td valign="top"><textarea name="textarea" cols="36" rows="4"></textarea></td>
        </tr>
        <tr>
          <td>City: </td>
          <td><input type="text" size="39" /></td>
          <td>City: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>State: </td>
          <td><input type="text" size="39" /></td>
          <td>State: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Postal Code: </td>
          <td><input type="text" size="39" /></td>
          <td>Postal Code: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>Country: </td>
          <td><input type="text" size="39" /></td>
          <td>Country: </td>
          <td><input type="text" size="39" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>Copy address from left:</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      </div>
    </div>
    <div class="add_edit">
    <div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th width="15%" align="left"><h4>Email</h4></th>
          <th width="25%" align="left">&nbsp;</th>
          <th width="10%" align="left">&nbsp;</th>
          <th width="15%" align="left">&nbsp;</th>
          <th width="10%" align="left">&nbsp;</th>
          <th width="43%" align="left">&nbsp;</th>
        </tr>
        <tr>
          <td>Email Address: </td>
          <td><input type="button" value="Add" /></td>
          <td align="center">Primary </td>
          <td align="center">Opted Out </td>
          <td align="center">Invalid </td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input type="text" size="28" /> <a href="#"><img src="images/admin/delete_inline.gif" alt="" width="12" height="12" /></a></td>
          <td align="center"><input name="" type="radio" value="" checked="checked" /></td>
          <td align="center"><input name="" type="checkbox" value="" /></td>
          <td align="center"><input name="" type="checkbox" value="" /></td>
          <td>&nbsp;</td>
        </tr>
      </table>
    </div>
    </div>
    <div class="add_edit">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th width="15%" align="left"><h4>Description Information</h4></th>
          <th width="85%">&nbsp;</th>
        </tr>
        <tr>
          <td valign="top">Description: </td>
          <td valign="top"><textarea name="textarea2" cols="80" rows="5"></textarea></td>
        </tr>
        <tr>
          <td>omeTest: </td>
          <td><input type="text" value="Default Test" size="39" /></td>
        </tr>
      </table>
    </div>
    <div class="left"><input name="input3" type="button" value="Save" /> <input name="input4" type="button" value="Cancel" /></div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  </div>