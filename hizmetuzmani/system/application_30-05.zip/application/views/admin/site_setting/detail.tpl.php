<div id="right_panel">
    <h2>Accounts: alex</h2>
    <p>&nbsp;</p>
    <div class="left">
      <input name="input3" type="button" value="Edit" />
      <input name="input4" type="button" value="Duplicate" />
      <input name="input4" type="button" value="Delete" />
      <input name="input4" type="button" value="Find Duplicate" />
      <input name="input4" type="button" value="View Change Log" />
    </div>
    <div class="right"><a href="#" class="links"><img src="images/admin/help.gif" alt="" />Help</a></div>
    <div class="right"><a href="#" class="links"><img src="images/admin/print.gif" alt="" />Print</a></div>
    <div class="add_edit">
      <div class="right">
        <ul class="pagination">
          <li class="previous-off">&laquo;Previous</li>
          <li class="active">1</li>
          <li><a href="?page=2">2</a></li>
          <li><a href="?page=3">3</a></li>
          <li><a href="?page=4">4</a></li>
          <li><a href="?page=5">5</a></li>
          <li><a href="?page=6">6</a></li>
          <li><a href="?page=7">7</a></li>
          <li class="next"><a href="?page=8">Next&raquo;</a></li>
        </ul>
      </div>
      <div class="right"><span class="left">
        <input name="input" type="button" value="Return to List" onclick="window.location='view.html'" />
        </span></div>
      <div>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="15%" align="left"><h4>Account Information</h4></th>
            <th width="35%" align="left">&nbsp;</th>
            <th width="15%">&nbsp;</th>
            <th width="35%">&nbsp;</th>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Name:</td>
            <td>Alex</td>
            <td bgcolor="#f1f1f1">Phone Office: </td>
            <td>123456</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Website: </td>
            <td><a href="http://www.abc.com" target="_blank">www.abc.com</a> </td>
            <td bgcolor="#f1f1f1">Phone Fax: </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Ticker Symbol:</td>
            <td>&nbsp;</td>
            <td bgcolor="#f1f1f1">Other Phone: </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Member of: </td>
            <td><a href="#">abcdef</a></td>
            <td bgcolor="#f1f1f1">Employees: </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Ownership: </td>
            <td>&nbsp;</td>
            <td bgcolor="#f1f1f1">Rating: </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Industry: </td>
            <td>Communications </td>
            <td bgcolor="#f1f1f1">SIC Code:</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Type: </td>
            <td>Customer </td>
            <td bgcolor="#f1f1f1">Annual Revenue:</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Date Modified:</td>
            <td>10/21/2010 02:01pm by sugaradmin </td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Assigned to: </td>
            <td>alexadmin</td>
            <td bgcolor="#f1f1f1">Date Entered:</td>
            <td>10/01/2010 02:34am by sugaradmin </td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#f1f1f1">Billing Address: </td>
            <td valign="top"><div class="left">
                <p>Abcdefght</p>
                <p>Hauptstr. 33</p>
                <p>Berlin Berlin��</p>
                <p>Germany </p>
              </div>
              <div class="right">
                <input name="input2" type="button" value="Copy" />
              </div></td>
            <td valign="top" bgcolor="#f1f1f1">Shipping Address:</td>
            <td valign="top"><div class="left">
                <p>Abcdefght</p>
                <p>Hauptstr. 33</p>
                <p>Berlin Berlin��</p>
                <p>Germany </p>
              </div>
              <div class="right">
                <input name="input2" type="button" value="Copy" />
              </div></td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Description:</td>
            <td>abcd</td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Campaign: </td>
            <td><a href="#">happy</a></td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Email Address: </td>
            <td><em>-- None --</em></td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Deneme:</td>
            <td>&nbsp;</td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">ATRIX_CustomProspects:</td>
            <td>&nbsp;</td>
            <td bgcolor="#f1f1f1">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </div>
    </div>
    <div class="add_edit">
      <div>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="15%" align="left"><h4>Financials</h4></th>
            <th width="35%" align="left">&nbsp;</th>
            <th width="15%">&nbsp;</th>
            <th width="35%">&nbsp;</th>
          </tr>
          <tr>
            <td bgcolor="#f1f1f1">Annual Revenue:</td>
            <td>&nbsp;</td>
            <td bgcolor="#f1f1f1">Ticker Code: </td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </div>
    </div>
    <div class="add_edit">
      <div id="tabbar2">
        <ul>
          <li><a href="javascript:void(0)" class="select" id="1"><span>All</span></a></li>
          <li><a href="javascript:void(0)" id="2"><span>Sales</span></a></li>
          <li><a href="javascript:void(0)" id="3"><span>Marketing</span></a></li>
          <li><a href="javascript:void(0)" id="4"><span>Support</span></a></li>
          <li><a href="javascript:void(0)" id="5"><span>Activities</span></a></li>
          <li><a href="javascript:void(0)" id="6"><span>Other</span></a></li>
        </ul>
      </div>
      <div id="tabcontent">
        <div id="div1">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> History</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Contacts</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="7"><div class="left">
                      <input name="input5" type="button" value="Create" />
                      <input name="input5" type="button" value="Select" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">Name</th>
                  <th align="left">City</th>
                  <th align="left">State</th>
                  <th align="left">Email</th>
                  <th align="left">Office Phone</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="25%"><a href="#">Alex</a></td>
                  <td width="14%"><span sugar="slot19b">Hamburg</span></td>
                  <td width="14%">&nbsp;</td>
                  <td width="21%"><a href="#">alex@alex.co.in</a></td>
                  <td width="10%">123456789</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div id="div2" style="display:none;">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Sales</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div id="div3" style="display:none;">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Marketing</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div id="div4" style="display:none;">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Support</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div id="div5" style="display:none;">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Activities</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <div id="div6" style="display:none;">
          <div class="details_box">
            <div class="heading"><a href="#"><img src="images/admin/collapse.gif" alt="" /></a> Other</div>
            <div class="description">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td colspan="8"><div class="left">
                      <input name="input5" type="button" value="Create Note or Attachment" />
                      <input name="input5" type="button" value="Archive Email" />
                      <input name="input5" type="button" value="View Summary" />
                    </div>
                    <div class="right">
                      <ul class="pagination">
                        <li class="previous-off">&laquo;Previous</li>
                        <li class="active">1</li>
                        <li><a href="?page=2">2</a></li>
                        <li><a href="?page=3">3</a></li>
                        <li><a href="?page=4">4</a></li>
                        <li><a href="?page=5">5</a></li>
                        <li><a href="?page=6">6</a></li>
                        <li><a href="?page=7">7</a></li>
                        <li class="next"><a href="?page=8">Next&raquo;</a></li>
                      </ul>
                    </div></td>
                </tr>
                <tr>
                  <th align="left">&nbsp;</th>
                  <th align="left">Subject</th>
                  <th align="left">Status</th>
                  <th align="left">Contact</th>
                  <th align="left">Date Modified</th>
                  <th align="left">Assigned User</th>
                  <th align="left">&nbsp;</th>
                  <th align="left">&nbsp;</th>
                </tr>
                <tr>
                  <td width="3%"><a href="#"><img src="images/admin/Emails.gif" alt="" width="16" height="16" /></a></td>
                  <td width="25%"><a href="#">test</a></td>
                  <td width="14%">Sent</td>
                  <td width="14%">&nbsp;</td>
                  <td width="14%">11/04/2010 07:36pm</td>
                  <td width="14%">alexadmin</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
                <tr>
                  <td><a href="#"><img src="images/admin/Notes.gif" alt="" width="16" height="16" /></a></td>
                  <td><a href="#">abcde</a></td>
                  <td><span sugar="slot11b">Note</span></td>
                  <td><a href="#">Admin</a></td>
                  <td><span sugar="slot13b">10/05/2010 10:59am</span></td>
                  <td>&nbsp;</td>
                  <td width="8%"><img src="images/admin/edit_inline.gif" alt="" class="img" /> <a href="#">Edit</a></td>
                  <td width="8%"><img src="images/admin/delete_inline.gif" alt="" class="img" /> <a href="#">Delete</a></td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>