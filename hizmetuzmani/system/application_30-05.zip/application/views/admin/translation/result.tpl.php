<div id="result">
	<?php echo $translation_list; ?>
</div>

