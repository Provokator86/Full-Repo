<div id="footer">
		<p>Make all your multilanguage websites using TMX file format.</p>
	</div> 
