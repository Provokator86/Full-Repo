<?php
  /*********
  * Author: Sahinul Haque
  * Date  : 04 Jan 2011
  * Modified By: 
  * Modified Date:
  * 
  * Purpose:
  *  Set of commonly used methods for frontend Controllers
  */
  
interface InfControllerFe
{
  
    /****
    * Display the static contents in frontend
    * 
    */
    public function show_cms();   
  
}
?>
