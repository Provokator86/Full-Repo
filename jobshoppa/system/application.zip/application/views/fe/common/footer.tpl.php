<div id="footer">
        <div class="section01">
            <div class="box01">
                <h6>Clients &raquo;</h6>
                <ul>
                    <li><a href="<?php echo base_url().'job/job_post'?>">Post a Job free</a></li>
                    <li><a href="<?php echo base_url().'home/how_it_works/TVNOaFkzVT0'; ?>">How it Works</a></li>
                    <li><a href="<?php echo base_url().'home/faq/TVNOaFkzVT0'; ?>">FAQ</a></li>
                </ul>
            </div>
            <div class="line01"></div>
            <div class="box01">
                <h6>Service Professional &raquo;</h6>
                <ul>
                    <li><a href="<?php echo base_url().'job/find_job'?>">Find a Job</a></li>
                    <li><a href="<?php echo base_url().'home/how_it_works/TWlOaFkzVT0'; ?>">How it Works</a></li>
                    <li><a href="<?php echo base_url().'home/faq/TWlOaFkzVT0'; ?>">FAQ</a></li>
                </ul>
            </div>
            <div class="line01"></div>
            <div class="box01">
                <h6>About Us &raquo; </h6>
                <ul>
                    <li><a href="<?php echo base_url().'home/cms/about_us'; ?>">About Us</a></li>
                    <li><a href="<?php echo base_url().'home/cms/careers'; ?>">Career</a></li>
                </ul>
            </div>
            <div class="line01"></div>
            <div class="box01">
                <h6>Legal &raquo; </h6>
                <ul>
                    <li><a href="<?php echo base_url().'home/cms/privacy_policy'; ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo base_url().'home/cms/terms_condition'; ?>">Terms &amp; Conditions</a></li>
                    <li><a href="<?php echo base_url().'home/abuse_report'; ?>">Abuse Report</a></li>
                    <li><a href="<?php echo base_url().'home/cms/safety'; ?>">Safety</a></li>
                </ul>
            </div>
            <div class="line01"></div>
            <div class="box01">
                <h6>Support &raquo; </h6>
                <ul>
                    <li><a href="<?php echo base_url().'home/customer_support'; ?>">Customer Support</a></li>
                    <!--<li><a href="<?php echo base_url().'home/help'; ?>">Help</a></li>-->
                    <li><a href="<?php echo base_url().'home/blog'; ?>">Blog</a></li>
                    <li><a href="<?php echo base_url().'home/contact_us'; ?>">Contact Us</a></li>
                </ul>
            </div>
        </div>
        <div class="section02">
            <div class="left">&copy; Copyright 2011 by <span>JobShoppa.com</span>. All Rights Reserved.</div>
            <div class="right">Follow us: <a href="http://www.facebook.com/pages/Jobshoppa/146950728720680"><img src="images/fe/icon-facebook.png" alt="" /></a> <a href="http://www.twitter.com/Jobshoppa"><img src="images/fe/icon-twitter.png" alt="" /></a> <a href="https://plus.google.com/u/0/b/103214525717344127511/"><img src="images/fe/icon-googleplus.png" alt="" /></a></div>
        </div>
    </div>