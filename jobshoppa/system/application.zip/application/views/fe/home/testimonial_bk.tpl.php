<div id="banner_section">
    <?php
	include_once(APPPATH."views/fe/common/header_top.tpl.php");
	?>
</div>
<!-- /BANNER SECTION -->
<!-- SERVICES SECTION -->
    <?php
	include_once(APPPATH."views/fe/common/common_search.tpl.php");
	?>

<!-- /SERVICES SECTION -->
<!-- CONTENT SECTION -->

    <div id="content">	
	<!--<div class="success_massage"><span>SUCCESS!</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>-->
        <div id="inner_container02">
            <div class="title">
                <h3><span>About</span> Us</h3>
            </div>
            <div class="content_box">
                <p>Founded in 2010, Jobshoppa is a unique online marketplace for the residents of the UK. Homeowners and consumers can find the right professional and contractor here. Professional can secure contracts easily and regularly at Jobshoppa as well.</p>
                <p>&nbsp;</p>
                <p>Homeowners and consumers can post requirements for professional or handymen for free. Professional and handymen can register with the site for free, and quote for jobs posted on the site.</p>
                <p>&nbsp;</p>
                <p>For instance, if someone needs to hire a cleaning service or a builder or a gardener, he simply has to post that as a job and describe the same clearly and in detail. Professional registered with the site will view the job, and those among them who feel that they are capable of doing the job will quote or bid for it. After availing of the services of the chosen workman, the user leaves review on his services. Homeowners and professional alike benefit from reviews.</p>
                <p>&nbsp;</p>
                <p>Jobshoppa is a broad-spectrum marketplace where all sorts of professional and contractors are registered: from builders, roofers.</p>
            </div>
        </div>
        <div class="clr"></div>
    </div>