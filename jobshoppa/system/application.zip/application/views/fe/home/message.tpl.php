<div id="banner_section">
    <?php
	include_once(APPPATH."views/fe/common/header_top.tpl.php");
	?>
</div>
<!-- /BANNER SECTION -->
<!-- SERVICES SECTION -->
    <?php
	include_once(APPPATH."views/fe/common/common_search.tpl.php");
	?>
<!-- /SERVICES SECTION -->
<!-- CONTENT SECTION -->
<div id="content_section">
    <div id="content">
		
        <div id="inner_container02">
           <!-- <div class="title"></div>-->
			<?php include_once(APPPATH.'views/fe/common/message.tpl.php'); ?>
            <div class="content_box"></div>
        </div>
        <div class="clr"></div>
    </div>
    <div class="clr"></div>
</div>	 