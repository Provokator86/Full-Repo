<div class="lightbox1" style="display:block;">
    <!--<div class="close"><a href="javascript:void(0)" onclick="hide_dialog()"><img src="../images/close.png" alt="" /></a></div>-->
    <div class="top">&nbsp;</div>
    <div class="mid">
        
           <!-- <h3><span>How do you like to choose to use Jobshoppa ?</h3>-->
			<div class="box01">How do you like to choose to use Jobshoppa</div>
        
        <div class="clr"></div> 
		<div class="box02">
            <div class="link_box05"><a href="<?php echo base_url().'user/registration/TWlOaFkzVT0';?>">Professional Registration</a></div>
            <div class="link_box06"><a href="<?php echo base_url().'user/registration/TVNOaFkzVT0';?>">Client Registration</a></div>
        
      </div>
    </div>
    <div class="bot">&nbsp;</div>
</div>