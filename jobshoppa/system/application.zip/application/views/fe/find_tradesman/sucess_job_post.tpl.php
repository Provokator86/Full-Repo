<div class="body_bg">
            <div class="banner">
                  <?php include_once(APPPATH.'views/fe/common/common_search.tpl.php'); ?>
            </div>
            <div class="shadow_big confirmation">
                  <div class="right_box_all_inner">
                  <h1 style="color:#f6315c;"> <?php echo t('Thank you for Submitting the job.')?></h1><?php echo t('Admin will review this job.')?>
                  </div>
            </div>
      </div>