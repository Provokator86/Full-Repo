<?php
/*********
* Author:Jagannath Samanta
* Date  : 20 July 2011
* Modified By: 
* Modified Date:
* 
* Purpose:
* View For Newsletter Subscribers Add & Edit
* 
* @package Content Management
* @subpackage Newsletter Subscribers
* 
* @link InfController.php 
* @link My_Controller.php
* @link views/admin/newsletter_subscribers/
*/

?>
 <?php
    /////////Javascript For List View//////////
?>
<script type="text/javascript" src="js/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript" src="js/tinymce/tinymce_load.js"></script>

<script language="javascript">
jQuery.noConflict();///$ can be used by other prototype which is not jquery
jQuery(function($) {
$(document).ready(function(){

var g_controller="<?php echo $pathtoclass;?>";//controller Path 
    
$('input[id^="btn_cancel"]').each(function(i){
   $(this).click(function(){
       $.blockUI({ message: 'Just a moment please...' });
       window.location.href=g_controller+"show_list";
   }); 
});      
    
$('input[id^="btn_save"]').each(function(i){
   $(this).click(function(){
       $.blockUI({ message: 'Just a moment please...' });
      // $("#frm_add_edit").submit();
	   check_duplicate();
   }); 
});    
    
//////////Checking Duplicate/////////
function check_duplicate(){
    var $this = $("#txt_email");
    $this.next().remove("#err_msg");  
	$(".star_err1").remove();
	$(".star_succ1").remove();
	
    if($this.val()!="")
    {
        $.blockUI({ message: 'Checking duplicates.Just a moment please...' });
        $.post(g_controller+"ajax_checkduplicate",
               {"h_id":$("#h_id").val(),
                "h_duplicate_value":$this.val()
                },
                function(data)
                {
                  if(data!="valid")////invalid 
                  {
                      $this.focus();
                      $('<div id="err_msg" class="star_err1" style="color:#F00">Duplicate email exists.</div>')
                      .insertAfter("#txt_email");
                      
                  }
                  else
                  {
                      $("#frm_add_edit").submit();                 
                  }
                });
    }
    else
    {
         $("#frm_add_edit").submit();  
    }
    

}
    
    
///////////Submitting the form/////////
$("#frm_add_edit").submit(function(){
    var b_valid=true;
	var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/; 
    var s_err="";
    $("#div_err").hide("slow"); 

    
	if($.trim($("#txt_name").val())=="") 
		{
			s_err +='Please provide subscriber name.<br />';
			b_valid=false;
		}
				/////////  EMAIL VERIFICATION ////////
				
	 if($.trim($("#txt_email").val())=="") 
		{
			s_err +='Please provide email.<br />';
			b_valid=false;
		}
	else if(!emailPattern.test($.trim($("#txt_email").val())))
		{
			s_err +='Please provide proper email.<br />';
			b_valid=false;
		}
  
		  ///////////// END OF EMAIL VERIFICATION  //////////
	
		  
    /////////validating//////
    if(!b_valid)
		{
			$.unblockUI();  
			$("#div_err").html('<div id="err_msg" class="error_massage">'+s_err+'</div>').show("slow");
		}
    
    return b_valid;
});    
///////////end Submitting the form/////////    
    
})});  
 /////////end Javascript For List View//////////    
</script>    
 
<div id="right_panel">
<form id="frm_add_edit" name="frm_add_edit" method="post" action="">
<!--<input type="hidden" id="h_mode" name="h_mode" value="<?php echo $posted["h_mode"];?>">-->
<input type="hidden" id="h_id" name="h_id" value="<?php echo $posted["h_id"];?>"> 
    <h2><?php echo $heading;?></h2>
    <p>&nbsp;</p>
        <div id="div_err">
            <?php
              show_msg("error");  
              echo validation_errors();
			/*  pr($posted);*/
            ?>
        </div>     
    
    
    <div class="left"><!--<input id="btn_save" name="btn_save" type="button" value="Save" title="Click here to save information." /> <input id="btn_cancel" name="btn_cancel" type="button" value="Cancel" title="Click here to cancel saving information and return to previous page."/>--></div>
    <div class="add_edit">
    <? /*****Modify Section Starts*******/?>
    <div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th colspan="3" align="left"><h4><?php echo $heading;?></h4></th>
        </tr>        
		<tr>
          <td>Name *:</td>
          <td><input id="txt_name" name="txt_name" value="<?php echo $posted["txt_name"];?>" type="text" size="50" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td valign="top">Email *:</td>
          <td><input id="txt_email" name="txt_email" value="<?php echo $posted["txt_email"];?>" type="text" size="50" />
          </td>
          <td>&nbsp;</td>
        </tr>
        
           
        <tr>
          <td>Status :</td>
          <td><input id="i_cat_is_active" name="i_cat_is_active" value="1" <?php if($posted["i_cat_is_active"]==2) echo ''; else echo 'checked="checked"';?>  type="checkbox" /></td>
          <td>&nbsp;</td>
        </tr>
      </table>
      </div>
    <? /***** end Modify Section *******/?>      
    </div>
    <div class="left">
    <input id="btn_save" name="btn_save" type="button" value="Save" title="Click here to save information." /> 
    <input id="btn_cancel" name="btn_cancel" type="button" value="Cancel" title="Click here to cancel saving information and return to previous page."/>
    </div>
    
</form>
</div>