// js for "public-api-calls" page...

var headerArr = new Array();
headerArr['day-sales'] = "day_sales";
headerArr['employees'] = "employees";
headerArr['zreport']   = "zreport";
headerArr['time-attendance'] = "time_attendance";
headerArr['by-val-by-month'] = "inventory_details_by_val_by_month";
headerArr['cogs-by-day'] 	 = "inventory_value_N_cogs_by_day";
headerArr['cogs-by-month'] 	 = "inventory_value_N_cogs_by_month";
headerArr['invoices-daily']  = "invoices_daily";
headerArr['sales-product-group-by-day']  = "sales_by_product_group_by_day";

$(document).ready(function() {
	
	$('a.api-sidebar').on('click', function() {
		
		if(window.location.href.indexOf("public-api-calls") > -1) {
			var selected_id = $(this).attr('id');
			perform(selected_id);
		} else {
			window.location.href = doc_base_url +'documentation/public-api-calls/';
		}
		
	});
	
	// for scroll toTop...
	$('body').scrollToTop({skin: 'cycle'});
	
});

	
// function to perform div display...
function perform(selectedID) {

	var div_to_show = '#div-'+ selectedID;
	var selected_href = 'a#'+ selectedID;
	$('div[id^="div-"]').fadeOut('slow', function() {
		$('a.api-sidebar').removeClass('active-trail active'); // remove all active class from href(s)
		$(selected_href).addClass('active-trail active');  // add active class to selected href
		
		// change in header-part...
		$('#h1_header').html( headerArr[selectedID] );
		$(div_to_show).show();	// display the required div
	});
	
}
