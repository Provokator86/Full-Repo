//// Gross Margin
$(document).ready(function() {

	// field(s) show-hide effect [Begin]
		$(".name").focus(function(){
		  $(".name-help").slideDown(500);
		}).blur(function(){
		  $(".name-help").slideUp(500);
		});

		$(".email").focus(function(){
		  $(".email-help").slideDown(500);
		}).blur(function(){
		  $(".email-help").slideUp(500);
		});
	
	// form object
	frm_obj = $('#frmGrossMargin');
	
	// date-picker...
	$(function(){
		$('#date1').datetimepicker({
			format:'Y-m-d',
			formatDate:'Y-m-d',
			onShow:function( ct ){
				this.setOptions({
					maxDate:$('#date2').val()? $('#date2').val(): false
				})
			},
			timepicker:false
		});
		$('#date2').datetimepicker({
			format:'Y-m-d',
			formatDate:'Y-m-d',
			onShow:function( ct ){
				this.setOptions({
					minDate:$('#date1').val()?$('#date1').val():false
				})
			},
			timepicker:false
		});
	});

	// show store-id based on result-type(s) selection...
	$('#result_type').on('change', function() {
		
		if( $(this).val()=='store' ) {	// if option "store"
			$('#store_id').slideDown('', function() {
			
				if( $('#i_usr_type').val()==1 ) {	// only if "Admin"
					$(this).val('');
					$(this).attr('readonly', false);
				}
				
				$('.div_store_id').slideDown();
			});
		} else {	// other options
			$('#store_id').slideUp('', function() {
				$('.div_store_id').slideUp();
			});
		}
		
	});

	
	// show store-id field according to the selected result-type...
	if( $('#result_type').val()=='store' ) {
		$('#store_id').slideDown('', function() {
			$('.div_store_id').slideDown();
		});
	}

});


/////////////// AJAX FOR "DISCOUNT%" [BEGIN] //////////////
	
	function frm_submit_AJAX()
	{
		var form_action_url;
		form_action_url = base_url +'daily-scoop/gross-margin/validate-form-details-AJAX';
		
		// for AJAX page-submission...
		optionsArr = {
			beforeSubmit:  showBusyScreen,  // pre-submit callback 
			success		:  validateFrm, // post-submit callback 
			url			:  form_action_url
		};
	 
		// form ajax-submit...
		$(frm_obj).ajaxSubmit(optionsArr);
		
		return false; 
	}
	
	
	// validate ajax-submission...
	function validateFrm(data)
	{
		var result_obj = JSON.parse(data);
	
		if(result_obj.result=='success') {
			var api_url = result_obj.api_url;
			//window.location.href = api_url;
			
			// new window
			var params = [
				'height='+screen.height,
				'width='+screen.width,
				'scrollbars=1',
				'fullscreen=yes' // only works in IE, but here for completeness
			].join(',');

			var popup = window.open(api_url, 'popup_window', params); 
			popup.moveTo(0,0);
		}
	
		// clean-up(or hide) existing error-message(s)...
        hide_err_msgs();
        
		if(result_obj.result=='error') 
        {
            // #1 - for error message field(s)
            for ( var id in result_obj.arr_messages ){
                
                var div_class = '.'+ id +'-help';
                
                if( $(div_class)!=null )
                    $(div_class).slideDown(500);
                    
            }
          }
		
		// hide busy-screen...
		hideBusyScreen();
	}
    
    // function to hide error message(s)...
    function hide_err_msgs() {
        
        $(".name-help, .email-help").slideUp(500);
       
    }
	
	
/////////////// AJAX FOR "DISCOUNT%" [END] //////////////