$(document).ready(function() {

	$('#link_gross_sales1').on('click', function() {
		
		// I: show the dive area...
		$('#div_placeholder1').show('slow');
		
	});	
});