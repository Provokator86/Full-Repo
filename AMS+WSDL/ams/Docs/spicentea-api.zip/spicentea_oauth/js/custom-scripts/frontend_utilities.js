//// Javascript document for "ADMIN COMMON UTILITIES" page [from top header]...

var dialog = null;
var dialog_loading = null;
var ajax_req = null;


//// function to show dialog window [Start]...
var dialog = null;

function show_dialog (id)
{
	if(!dialog) dialog = null;
	dialog = new ModalDialog ("#"+id);
	dialog.show();
}

function hide_dialog ()
{
	dialog.hide();
	if(!dialog) dialog = null;
}
//// function to show dialog window [End]...


//// function to show/hide busy-screen [Start]
function showBusyScreen()
{
	if(!dialog_loading) dialog_loading = null;
	dialog_loading = new ModalDialog ("#loading_dialog");
	
	dialog_loading.show();
}

function hideBusyScreen()
{
	if(dialog_loading) dialog_loading.hide();
}
//// function to show/hide busy-screen [End]




/* ==== show blockUI message ==== */
function showUIMsg(msg)
{
	$.blockUI({
		message: msg,
		css: {
				border: 'none',
				padding: '15px',
				fontSize: '12px',
				backgroundColor: '#000000',
				'-webkit-border-radius': '10px',
				'-moz-border-radius': '10px',
				opacity: '1',
				color: '#ffffff'
		},
		overlayCSS: { backgroundColor: '#000000' }
	});

	setTimeout($.unblockUI, 2000);
}






/* ############## ELEMENT BLOCKING LOADER [BEGIN] ############## */

	// loading screen...
	function showAJAXLoader(divID)
	{
		var HTML = '<img src="'+ base_url +'images/loader_atom.gif" />';
		var element_div = 'div#'+ divID;
		
		$(element_div).block({
			message: HTML,
			css: {
					border: 'none',
					color: '#ffffff'
				 },
			overlayCSS: { backgroundColor: '#ffffff' }
		});
	}
	
	// now, hiding the loading screen...
	function hideAJAXLoader(divID)
	{
		var element_div = 'div#'+ divID;
		$(element_div).unblock();
	}

/* ############## ELEMENT BLOCKING LOADER [END] ############## */


	//// SHOW FB LOADER...
	function show_FB_loader(loading_div_id)
	{
		var loader_img = base_url +'images/admin/fb-loader.gif';
		var loading_HTML = '<img src="'+ loader_img +'" />';
		
		var loading_position = '#'+ loading_div_id;
		$(loading_position).html(loading_HTML);
	}
	
	// function to hide small FB loader...
	function hide_FB_loader(loading_div_id)
	{
		var loading_position = '#'+ loading_div_id;
		$(loading_position).empty();
	}
	
	
	//// FUNCTION TO AMRK INPUT BOXES AS "UNIFORM"...
	function _mark_uniform() {
		
		$("input:checkbox, input:radio, input:file").not('[data-no-uniform="true"],#uniform-is-ajax').uniform();
		
	}