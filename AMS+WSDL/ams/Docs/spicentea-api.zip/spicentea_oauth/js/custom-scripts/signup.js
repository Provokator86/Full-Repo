$(document).ready(function() {

	// field(s) show-hide effect [Begin]
		$(".name").focus(function(){
		  $(".name-help").slideDown(500);
		}).blur(function(){
		  $(".name-help").slideUp(500);
		});

		$(".email").focus(function(){
		  $(".email-help").slideDown(500);
		}).blur(function(){
		  $(".email-help").slideUp(500);
		});

		$(".password").focus(function(){
		  $(".password-help").slideDown(500);
		}).blur(function(){
		  $(".password-help").slideUp(500);
		});

		$(".conf-password").focus(function(){
		  $(".conf-password-help").slideDown(500);
		}).blur(function(){
		  $(".conf-password-help").slideUp(500);
		});
	// field(s) show-hide effect [End]
	
	frm_obj = $('#frmSignUp');
	
});


/////////////// AJAX FOR "USER SIGN-UP" [BEGIN] //////////////
	
	
	function usr_signup_AJAX()
	{
		var form_action_url;
		form_action_url = base_url +'signup/validate-signup-AJAX';
		
		// for AJAX page-submission...
		optionsArr = { 
			beforeSubmit:  showBusyScreen,  // pre-submit callback 
			success		:  validateFrm, // post-submit callback 
			url			:  form_action_url
		};
	 
		// form ajax-submit...
		$(frm_obj).ajaxSubmit(optionsArr);
		
		return false; 
	}
	
	
	// validate ajax-submission...
	function validateFrm(data)
	{
		var result_obj = JSON.parse(data);
	
		if(result_obj.result=='success') {
			
			// 1: populate message div...
			$('.success-msg-prt').html(result_obj.msg);
			
			// 2: populate key & secret...
			var consumer_info_arr = result_obj.consumer_info;
			$('#span_key').html(consumer_info_arr['consumer_key']);
			$('#span_secret').html(consumer_info_arr['consumer_secret']);
			
			// 3: finally showing the <p>...
			$('.success-msg').show('slow');
			$('#frmSignUp')[0].reset();
		}
	
		// clean-up(or hide) existing error-message(s)...
        hide_err_msgs();
        
		if(result_obj.result=='error') 
        {
            // #1 - for error message field(s)
            for ( var id in result_obj.arr_messages ){
                
                var div_class = '.'+ id +'-help';
                
                if( $(div_class)!=null )
                    $(div_class).slideDown(500);
                    
            }
          }
		
		// hide busy-screen...
		hideBusyScreen();
	}
    
    // function to hide error message(s)...
    function hide_err_msgs() {
        
        $(".name-help, .email-help, .password-help, .conf-password-help").slideUp(500);
       
    }
	
	
/////////////// AJAX FOR "USER SIGN-UP" [END] //////////////