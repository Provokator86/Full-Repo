$(document).ready(function() {

	// field(s) show-hide effect [Begin]
		$(".name").focus(function(){
		  $(".name-help").slideDown(500);
		}).blur(function(){
		  $(".name-help").slideUp(500);
		});

		$(".password").focus(function(){
		  $(".password-help").slideDown(500);
		}).blur(function(){
		  $(".password-help").slideUp(500);
		});
		
	frm_obj = $('#frmSignIn');
	
});

/*$(document).on('submit', 'form#frmSignIn', function(){
	var frm_action_url = base_url + 'login/process-login';
	$(this).attr('action', frm_action_url);
});*/