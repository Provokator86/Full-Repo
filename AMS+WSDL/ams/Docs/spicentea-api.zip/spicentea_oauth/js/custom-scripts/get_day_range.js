$(document).ready(function() {

	// field(s) show-hide effect [Begin]
		$(".name").focus(function(){
		  $(".name-help").slideDown(500);
		}).blur(function(){
		  $(".name-help").slideUp(500);
		});

		$(".email").focus(function(){
		  $(".email-help").slideDown(500);
		}).blur(function(){
		  $(".email-help").slideUp(500);
		});
	
	// form object
	frm_obj = $('#frmDayRange');
	
	// date-picker...
	$('#date1, #date2').datetimepicker({
		timepicker:false,
		format:'Y-m-d',
		formatDate:'Y-m-d',
		theme:'dark'
	});
});


/////////////// AJAX FOR "DAY WISE SALES" [BEGIN] //////////////
	
	function frm_submit_AJAX()
	{
		var form_action_url;
		form_action_url = base_url +'day-sales/get-gross-sales/validate-dayrange-sales-AJAX';
		
		// for AJAX page-submission...
		optionsArr = {
			beforeSubmit:  showBusyScreen,  // pre-submit callback 
			success		:  validateFrm, // post-submit callback 
			url			:  form_action_url
		};
	 
		// form ajax-submit...
		$(frm_obj).ajaxSubmit(optionsArr);
		
		return false; 
	}
	
	
	// validate ajax-submission...
	function validateFrm(data)
	{
		var result_obj = JSON.parse(data);
	
		if(result_obj.result=='success') {
			var api_url = result_obj.api_url;
			window.location.href = api_url;
		}
	
		// clean-up(or hide) existing error-message(s)...
        hide_err_msgs();
        
		if(result_obj.result=='error') 
        {
            // #1 - for error message field(s)
            for ( var id in result_obj.arr_messages ){
                
                var div_class = '.'+ id +'-help';
                
                if( $(div_class)!=null )
                    $(div_class).slideDown(500);
                    
            }
          }
		
		// hide busy-screen...
		hideBusyScreen();
	}
    
    // function to hide error message(s)...
    function hide_err_msgs() {
        
        $(".name-help, .email-help").slideUp(500);
       
    }
	
	
/////////////// AJAX FOR "DAY WISE SALES" [END] //////////////