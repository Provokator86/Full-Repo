<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "index";
$route['404_override'] = '';


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#            CUSTOM ROUTING RULE(S) - BEGIN
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    $route['logout'] = 'login/logout';
    
    // Average Ticket
    $route['daily-scoop/get-average-ticket-sales/(:any)/(:any)/(:any)'] = 'daily-scoop/get_average_ticket_sales/index/$1/$2/$3';
    $route['daily-scoop/get-average-ticket-sales/(:any)/(:any)/(:any)/(:d)'] = 'daily-scoop/get_average_ticket_sales/index/$1/$2/$3/$4';

    
    // Gross Margin
    $route['daily-scoop/get-gross-margin/(:any)/(:any)/(:any)'] = 'daily-scoop/get_gross_margin/index/$1/$2/$3';
    $route['daily-scoop/get-gross-margin/(:any)/(:any)/(:any)/(:d)'] = 'daily-scoop/get_gross_margin/index/$1/$2/$3/$4';
    
    
    // Discount%
    $route['daily-scoop/get-discount-percentage/(:any)/(:any)/(:any)'] = 'daily-scoop/get_discount_percentage/index/$1/$2/$3';
    $route['daily-scoop/get-discount-percentage/(:any)/(:any)/(:any)/(:d)'] = 'daily-scoop/get_discount_percentage/index/$1/$2/$3/$4';
    
    
    //// NEW API CALLS [BEGIN]
        
        # Get-Day-Sales
        $route['api-calls/get-store-day-sales/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_day_sales/index/$1/$2/$3/$4';
        #$route['daily-scoop/get-average-ticket-sales/(:any)/(:any)/(:any)/(:d)'] = 'daily-scoop/get_average_ticket_sales/index/$1/$2/$3/$4';

        # Get-Employees
        $route['api-calls/get-store-employees/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_employees/index/$1/$2/$3/$4';
    
        # Get-ZReport
        $route['api-calls/get-store-zreport/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_zreport/index/$1/$2/$3/$4';

        # Get-Time-Attendance
        $route['api-calls/get-store-time-attendance/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_time_attendance/index/$1/$2/$3/$4';
        
        # Get-Inventory-Details-By-Value-By-Month
        $route['api-calls/get-store-inventory-details-value-month/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_inventory_details_value_month/index/$1/$2/$3/$4';
        
        # Get-Inventory-Value-N-Cogs-By-Day
        $route['api-calls/get-store-inventory-value-n-cogs-day/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_inventory_value_n_cogs_day/index/$1/$2/$3/$4';
        
        # Get-Inventory-Value-N-Cogs-By-Month
        $route['api-calls/get-store-inventory-value-n-cogs-month/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_inventory_value_n_cogs_month/index/$1/$2/$3/$4';
        
        # Get-Invoices-Daily
        $route['api-calls/get-store-invoices-daily/(:any)/(:any)/(:any)'] = 'api-calls/get_store_invoices_daily/index/$1/$2/$3';
        
        # Get-Sales-By-Product-Group-By-Day
        $route['api-calls/get-store-sales-by-product-group-by-day/(:num)/(:any)/(:any)/(:any)'] = 'api-calls/get_store_sales_by_product_group_by_day/index/$1/$2/$3/$4';
        

        //// FETCH-API-CALL(s)
            # Fetch-Day-Sales
            $route['api-calls/fetch-day-sales/(.*)'] = 'api-calls/fetch_day_sales/index/$1';

            # Fetch-Employees
            $route['api-calls/fetch-employees/(.*)'] = 'api-calls/fetch_employees/index/$1';
        
            # Fetch-ZReport
            $route['api-calls/fetch-zreport/(.*)'] = 'api-calls/fetch_zreport/index/$1';

            # Fetch-Time-Attendance
            $route['api-calls/fetch-time-attendance/(.*)'] = 'api-calls/fetch_time_attendance/index/$1';
            
            # Fetch-Inventory-Details-By-Value-By-Month
            $route['api-calls/fetch-inventory-details-value-month/(.*)'] = 'api-calls/fetch_inventory_details_value_month/index/$1';
            
            # Fetch-Inventory-Value-N-Cogs-By-Day
            $route['api-calls/fetch-inventory-value-n-cogs-day/(.*)'] = 'api-calls/fetch_inventory_value_n_cogs_day/index/$1';
            
            # Fetch-Inventory-Value-N-Cogs-By-Month
            $route['api-calls/fetch-inventory-value-n-cogs-month/(.*)'] = 'api-calls/fetch_inventory_value_n_cogs_month/index/$1';
            
            # Fetch-Invoices-Daily
            $route['api-calls/fetch-invoices-daily/(.*)'] = 'api-calls/fetch_invoices_daily/index/$1';

            # Fetch-Sales-By-Product-Group-By-Day
            $route['api-calls/fetch-store-sales-by-product-group-by-day/(.*)'] = 'api-calls/fetch_store_sales_by_product_group_by_day/index/$1';
            
    //// NEW API CALLS [END]
    

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#            CUSTOM ROUTING RULE(S) - END
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ================================================================================
#                   DOCUMENTATION ROUTING [BEGIN]
# ================================================================================
    
    $route['documentation'] = 'documentation/index';
    $route['documentation/overview'] = 'documentation/index';
    
# ================================================================================
#                   DOCUMENTATION ROUTING [END]
# ================================================================================

//// NEW - for phpinfo()
	$route['info'] = 'test/server_info';


/* End of file routes.php */
/* Location: ./application/config/routes.php */
