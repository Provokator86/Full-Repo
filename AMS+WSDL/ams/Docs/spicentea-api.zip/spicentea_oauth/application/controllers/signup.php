<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signup extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helpers...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	# index function definition...
	public function index()
	{
		try {
            $data = $this->data;
            
            # adjusting header & footer sections [Start]...
                parent::_set_title(':: Registration Form with oAuth2.0 ::');
                parent::_set_meta_desc('Registration Form with oAuth2.0');
                parent::_set_meta_keywords('Registration Form with oAuth2.0');
                
                parent::_add_js_arr( array('js/custom-scripts/signup.js'=>'header'));
            # adjusting header & footer sections [End]...
            
            
            # view file...
            $VIEW = "signup.phtml";
            parent::_render($data, $VIEW);
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}


    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              AJAX VALIDATION & USER SIGN-UP [BEGIN]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        
        # function to validate form submit...
        public function validate_signup_AJAX() {
            
            try
            {
                // Error Messages for Required Fields...
                $REQD_FLD_MSG = '* required field';
                $required_fields = array('s_username', 's_account_no', 's_email',
                                         's_password', 's_conf_password');
                $css_class_arr   = array('name', 'name', 'email',
                                         'password', 'conf-password');
                    
                // adjusting err-messages part accordingly...
                $arr_messages = array();
                
                ////////////// VALIDATION CHECKS - BEGIN //////////////
                    
                    # validation for singular fields (i.e. appearing once)...
                    foreach($required_fields as $key=>$required_field) {
                        
                        if( $_POST[$required_field]=='' && in_array($required_field, $required_fields) )
                            $arr_messages[$css_class_arr[$key]] = $REQD_FLD_MSG;
                        
                    }
                    
                    # check for valid email address...
                        if( $_POST['s_email']!='' ) {
                            
                            if( !filter_var($_POST['s_email'], FILTER_VALIDATE_EMAIL) )
                                $arr_messages['email'] = '* not a valid email address';
                            else {
                                
                                if( $this->users_model->email_exists( $_POST['s_email'] ) )
                                    $arr_messages['email'] = '* email already exists';
                            }
                            
                        }
                        
                    
                    # check for passowrd match...
                        $PASSWD = trim($this->input->post('s_password', true));
                        $CONFIRM_PASSWD = trim($this->input->post('s_conf_password', true));
                        if( $PASSWD!='' && $CONFIRM_PASSWD!='' ) {
                            
                            if( $PASSWD!=$CONFIRM_PASSWD )
                                $arr_messages['password'] = 'Password mismatch!';
                        }
                    
                ////////////// VALIDATION CHECKS - END //////////////

                if( count($arr_messages)==0 ) 
                {
                    $this->signup_new_user_AJAX();
                    
                } else {
                    echo json_encode(array('result'=>'error',
                                           'arr_messages'=>$arr_messages));
                    exit;
                }
            }
             catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }
            
        }
        
        
        
        # function to add new user to the system [AJAX CALL]...
        public function signup_new_user_AJAX()
        {
            # db info array...
            $arr_usr = $arr_oauth = array();
            
            //// Now, retrieving submitted/posted values [BEGIN]...
                $arr_usr['i_portal_company_id'] = trim( $this->input->post('i_company_id', true) );
                $arr_usr['s_portal_account_number'] = trim( $this->input->post('s_account_no', true) );
                #$arr_usr['s_company_name'] = trim( $this->input->post('s_company_name', true) );
                $arr_usr['s_username'] = $arr_oauth['requester_name'] = trim( $this->input->post('s_username', true) );
                $arr_usr['s_email']    = $arr_oauth['requester_email'] = trim( $this->input->post('s_email', true) );
                $arr_usr['s_password'] = get_salted_password(trim( $this->input->post('s_password', true) ));
                $arr_usr['dt_created'] = get_db_datetime();
                $arr_usr['i_user_type'] = ( empty($arr_usr['s_portal_account_number']) )? 1: 2;
            //// retrieving submitted/posted values [END]...
            
            
            //// insert into "users" table...
            $new_user_id = $this->users_model->add_info( $arr_usr );
            $new_company_id = $this->users_model->add_company_info( $arr_usr );  // NEW - add company info
            
            # if new user created successfully...
            if( $new_user_id ) {
                # I: reset user array...
                    unset($arr_usr);
                    $arr_usr = array();
                
                # II: now, updating user with consumer-key & secret...
                    $API_URL = $this->config->item('api_url') .'api/example/user/id/1/format/xml';
                    $arr_oauth['application_uri'] = $API_URL;
                    $arr_oauth['callback_uri'] = '';
                    $key = $this->storeObj->updateConsumer($arr_oauth, $new_user_id, true); // updating consumer
                    
                    $c = $this->storeObj->getConsumer($key, $new_user_id);
                    
                    $arr_oauth['consumer_key'] = $c['consumer_key'];
                    $arr_oauth['consumer_secret'] = $c['consumer_secret'];
                    $arr_oauth['server_uri'] = base_url();
                    $arr_oauth['request_token_uri'] = $this->config->item('oauth_request_token_uri');
                    $arr_oauth['authorize_uri'] = $this->config->item('oauth_authorize_uri');
                    $arr_oauth['access_token_uri'] = $this->config->item('oauth_access_token_uri');
                    $this->storeObj->updateServer($arr_oauth, $new_user_id, true);  // updating server
                    
                    $arr_usr['s_consumer_key'] = $c['consumer_key'];
                    $arr_usr['s_consumer_secret'] = $c['consumer_secret'];
                    
                    $this->users_model->edit_info( $arr_usr, $new_user_id );
                    $this->users_model->edit_company_info( $arr_usr, $new_company_id );    // NEW - update company-info
                    
                # III: sending email...
                   //// EMAIL SENDING CODE [Begin]
                        $this->load->helper('file');
                        $mail_txt_path = APPPATH .'../email-formats/new-user-mail.txt';
                        $body = htmlspecialchars_decode(read_file($mail_txt_path), ENT_QUOTES);
                        
                        
                        $body = sprintf3( $body, array('name'           => $arr_oauth['requester_name'],
                                                       'consumer_key'   => $arr_usr['s_consumer_key'],
                                                       'consumer_secret'=> $arr_usr['s_consumer_secret']));
                       
                       
                        //echo $body;
                        $mail_subject = 'your account created successfully!';
                        $arr['subject'] = htmlspecialchars_decode($mail_subject, ENT_QUOTES);
                        $arr['to']      = $arr_oauth['requester_email'];
                       
                        $arr['bcc']    = 'acumen.demo@gmail.com';
                        $arr['from_email'] = $this->config->item('no_reply_email');
                        $arr['from_name'] = "Team TSTE";
                        $arr['message'] = $body;
                        #dump($arr); exit;
                
                        send_mail($arr);
                   //// EMAIL SENDING CODE [End]
                
            }
            
            
            # success message...
            $SUCCESS_MSG = "Registered successfully!!!";

            echo json_encode(array('result'=>'success',
                                   'consumer_info'=>$c,
                                   'msg'=>$SUCCESS_MSG));
            exit;
            
        }
        
        
    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              AJAX VALIDATION & USER SIGN-UP [END]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */