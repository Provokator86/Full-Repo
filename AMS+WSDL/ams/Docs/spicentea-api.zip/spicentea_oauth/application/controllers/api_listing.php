<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api_listing extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            parent::_check_login();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
     
	 */
	public function index()
	{
		try {
            $data = $this->data;
            
            # adjusting header & footer sections [Start]...
                parent::_set_title(':: TSTE API(s) secured with oAuth2.0 ::');
                parent::_set_meta_desc('TSTE API(s) secured with oAuth2.0');
                parent::_set_meta_keywords('TSTE API(s) secured with oAuth2.0');
                
                parent::_add_js_arr( array('js/custom-scripts/api_listing.js'=>'header'));
            # adjusting header & footer sections [End]...
            
            
            # view file...
            $VIEW = "api-listing.phtml";
            parent::_render($data, $VIEW);
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}

    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //             AJAX AUTO-COMPLETE FOR COMPANY-ID & PORTAL-NUMBER [BEGIN]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
        # function to fetch ajax auto-complete Company-ID(s) [AJAX CALL]...
        public function ajax_autocomplete_storeID()
        {
            try
            {
                $DB_api = $this->load->database('api', TRUE);
                $this->tbl_daysales = $DB_api->DAYSALES;
                
                # input tag
                $USER_INPUT = $this->input->get('term', true);
                
                # query into "daysales" table using the input-term...
                $SQL = sprintf("SELECT
                                    `id`, `company_id`, `erply_account_number`
                                FROM %s
                                WHERE
                                    `erply_account_number` LIKE '%s%%'
                                GROUP BY `erply_account_number` ",
                                $this->tbl_daysales, $USER_INPUT);
                
                $return_arr = array();
                if( $DB_api->query($SQL)->num_rows() ) {
                    
                    $result = 'success';
                    $ROWS = $DB_api->query($SQL)->result_array();
                    
                    # looping thru records...
                    foreach($ROWS as $record) {
                        
                        $LBL = ( !empty($record['erply_account_number']) )? $record['erply_account_number']: '';
                        $return_arr[] = array(   
                                                'id'    => $record['id'],
                                                'value' => $LBL,
                                                'label' => $LBL,
                                                'other_val'=> $record['company_id']
                                             );  // Add a row to array
                    }
                    
                    
                } else {
                    $result = 'error';
                }
                
                echo json_encode( $return_arr );
                exit;
                
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }         
        }

        # function to fetch ajax auto-complete Portal-CompanyID(s) [AJAX CALL]...
        public function ajax_autocomplete_portal_companyID()
        {
            try
            {
                $DB_api = $this->load->database('api', TRUE);
                $this->tbl_daysales = $DB_api->DAYSALES;
                
                # input tag
                $USER_INPUT = $this->input->get('term', true);
                
                # query into "daysales" table using the input-term...
                $SQL = sprintf("SELECT
                                    `id`, `company_id`
                                FROM %s
                                WHERE
                                    `company_id` LIKE '%s%%'
                                GROUP BY `company_id` ",
                                $this->tbl_daysales, $USER_INPUT);
                
                $return_arr = array();
                if( $DB_api->query($SQL)->num_rows() ) {
                    
                    $result = 'success';
                    $ROWS = $DB_api->query($SQL)->result_array();
                    
                    # looping thru records...
                    foreach($ROWS as $record) {
                        
                        $LBL = ( !empty($record['company_id']) )? $record['company_id']: '';
                        $return_arr[] = array(   
                                                'id'    => $record['id'],
                                                'value' => $LBL,
                                                'label' => $LBL
                                             );  // Add a row to array
                    }
                    
                    
                } else {
                    $result = 'error';
                }
                
                echo json_encode( $return_arr );
                exit;
                
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }         
        }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //             AJAX AUTO-COMPLETE FOR COMPANY-ID & PORTAL-NUMBER [END]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}

/* End of file api_listing.php */
/* Location: ./application/controllers/api_listing.php */