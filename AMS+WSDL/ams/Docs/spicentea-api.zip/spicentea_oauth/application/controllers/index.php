<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Controller Definition...
class Index extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	# index function definition...
	public function index()
	{
		try {
            
			if( $this->session->userdata('sess_user_id') )	// if session set
				@redirect(base_url() ."api-listing");
			else
				@redirect(base_url() ."login");
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}
    
    

}

/* End of file index.php */
/* Location: ./application/controllers/index.php */