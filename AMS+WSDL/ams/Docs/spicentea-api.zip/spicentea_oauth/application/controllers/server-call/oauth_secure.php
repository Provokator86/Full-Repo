<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Oauth_secure extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		try {
            
            
            
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}


    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              REQUEST & AUTHORIZE TOKEN(s) [BEGIN]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        
        # function to request for grant-access-Token...
        public function request_token() {
            
            try
            {
                # oAuth request for Token...
                $this->serverObj->requestToken();
                
            }  catch(Exception $err_obj)  {
                show_error($err_obj->getMessage());
            }
            
        }
        
        
        # function for access-Token...
        public function access_token() {
            
            try
            {
                # oAuth access Token...
                $this->serverObj->accessToken();
                
            }  catch(Exception $err_obj)  {
                show_error($err_obj->getMessage());
            }
            
        }
        
        
        # function to verify authorization...
        public function verify_authorization() {
            
            try {
                
                // Check if there is a valid request token in the current request.
                // This returns an array with the consumer key, consumer secret,
                // token, token secret, and token type.
                $rs = $this->serverObj->authorizeVerify();
                // See if the user clicked the 'allow' submit button (or whatever
                // you choose)
                $authorized = true;
                // Set the request token to be authorized or not authorized
                // When there was a oauth_callback then this will redirect to
                // the consumer
                $id = $this->session->userdata('sess_user_id');
                $this->serverObj->authorizeFinish($authorized, $id);
                
            } catch(Exception $err_obj) {
                $err_obj->getMessage();
            }
            
        }
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              REQUEST & AUTHORIZE TOKEN(s) [END]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */