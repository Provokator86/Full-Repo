<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/*********
* Author: 
* Date  : 
* Modified By:
* Modified Date: 
* Purpose:
* 
* @include 
*/
   
 
class Base_controller extends CI_Controller 
{
    protected $data = array();
    protected $storeObj, $serverObj;
    
    # constructor definition...
    public function __construct () {
        try{ 
            parent::__construct();
            
            $this->load->helper('common_helper');
           
            /******************************** Layout based codes *********************** */
            $this->js_files = array();
            $this->css_files = array();
            $this->header_html = array();
            $this->title = '';
            $this->meta_desc = '';
            $this->meta_keywords = '';  // new 4 meta keywords...
            $this->layout = 'layouts/layout.phtml';
            /*************************************************************************** */

            # to include default JS & CSS file(s)...
                $this->_add_default_js_files();
                $this->_add_default_css_files();
            
                
            # NEW - instantiate oAuth2.0 settings...
                $this->_load_oauth_settings();
            
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }



    /* ****************************** Layout based codes *********************** */
    
    /****
    * put your comment there...
    * 
    * @param array $files
    */
    
    /* e.g. array('js/jquery.js'=>'header', 'js/stepcarousel.js'=>'header') 
    OR     array('js/jquery.js', 'js/stepcarousel.js') 
    */
    protected function _add_js($js_file, $position='footer') 
    {
        try{
            $this->js_files[$js_file] = $position;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }

    /****
    * put your comment there...
    * 
    * @param array $files
    */    
    protected function _add_js_arr(array $js_files_arr) 
    {
        try{
            /* if associative array position is supplied */
            if( is_assoc($js_files_arr) ) {
                $this->js_files = array_merge($this->js_files, $js_files_arr);
            }
    
            /* if associative array position is not supplied. default of footer is used */
            else {
                //$this->js_files = array_merge($this->js_files, $js_files_arr);
                $arr = array();
                foreach($js_files_arr as $js_file) {
                    $arr[$js_file] = 'header';
                }
                $this->js_files = array_merge($this->js_files, $arr);
            }
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }

    /****
    * put your comment there...
    * 
    * @param array $files
    */
    /* e.g. 'css/style.css', array('MEDIA'=>'print')
    */
    protected function _add_css($css_file, array $attrs = array()) 
    {
        try{
            if( is_array($attrs) && count($attrs) ) {
                $css_files[$item_css] = $attrs;
            }
            else {
                $css_files[$item_css] = array();
            }
            $this->css_files = array_merge($this->css_files, $css_files);
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }

    /****
    * put your comment there...
    * 
    * @param array $files
    */
    
    
    /* e.g. array('css/style.css'=>array('MEDIA'=>'aural'), 'css/thickbox.css'=>array('MEDIA'=>'screen, print', 'TITLE'=>'24-bit Color Style'))
    * default structure is <link href="'.$css_file.'" rel="stylesheet" type="text/css" />, do not add href, rel and type attributes.
    */
    protected function _add_css_arr(array $css_files_arr) 
    {
        try{
            foreach($css_files_arr as $key_css=>$item_css) {
                if( is_numeric($key_css) && !is_array($item_css) ) {
                    $css_files[$item_css] = array();
                }
                else {
                    $css_files[$key_css] = $item_css;
                }
                //$this->css_files = array_merge($this->css_files, $css_files_arr);
            }
            $this->css_files = array_merge($this->css_files, $css_files);
            
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }

    /****
    * put your comment there...
    * 
    * @param array $files
    */
    protected function _add_header_html($html) 
    {
        try{
            $this->header_html[] = $html;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }
    
    
    /****
    * put your comment there...
    * 
    * @param array $files
    */
    protected function _set_title($title) 
    {
        try{
            $this->title = $title;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }


    /****
    * put your comment there...
    * 
    * @param array $files
    */
    protected function _set_meta_desc($desc) 
    {
        try{
            $this->meta_desc = $desc;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }

   
    /****
    * put your comment there...
    * 
    * @param array $files
    */
    protected function _set_meta_keywords($keywords)
    {
        try{
            $this->meta_keywords = $keywords;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }
    
    /****
    * put your comment there...
    * 
    * @param array $files
    */
    protected function _set_layout($layout) 
    {
        try{
            $this->layout = $layout;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
        
    }
    
    
    # function to add default JS file(s)...
    protected function _add_default_js_files() {
        
        ///////// NEW CODE [FOR DEFAULT JS FILES - BEGIN] /////////
        $default_js_arr = array('js/jquery-1.11.3.js'=>'header',
                                
                                # miscellaneous
                                'js/jquery.form.js'=>'header',
                                'js/jquery.blockUI.js'=>'header',
                                'js/json2.js'=>'header',
                               
                                'js/ModalDialog.js'=>'header',
                                'js/custom-scripts/frontend_utilities.js'=>'header');
                                
                                
        $this->_add_js_arr($default_js_arr);

    }
    
    
    # function to add default css files...
    protected function _add_default_css_files() {
        
        $default_css_arr = array('css/style.css'=>array('media'=>'all'));
                                
        $this->_add_css_arr($default_css_arr);
    }


    /****
    * put your comment there...
    * 
    * @param array $files
    */
    // When _render() is used it releases the output as there is flush() call in the layout fle views/layouts/layout.php
    // so to get a string return one has to change layout file using _set_layout(). 
    // flush() call makes js and css parallel download possible so page loads faster.
    protected function _render(array $data = array(), $view_script='', $bool_string = false) 
    {
        try{
                $data = array_merge($data, $this->data);
                if($view_script == '') {
                    if($this->router->directory=='') {
                        $view_script = $this->router->class.'.phtml';
                    }
                    else {
                        $view_script = $this->router->directory.'/'.$this->router->class.'.phtml';
                    }
                }
        
                $matches_view = array();
                preg_match('/^(.*?)(\.[^\.]+)?$/', $view_script, $matches_view);
                $js_script =  base64_encode($matches_view[1].'.js');
                $css_script = base64_encode($matches_view[1].'.css');
        
                //$this->js_files = array_unique($this->js_files);
                //$this->css_files = array_unique($this->css_files);
                $this->header_html = array_unique($this->header_html);
        
                $data['header']['header_html'] = '';
                $data['header']['footer_html'] = '';
        
                $data['header']['header_html'] .= '<title>'.$this->title.'</title>'."\n";
        
                // NEW CODE [ meta content-type and base href] - START
                    $data['header']['header_html'] .= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'."\n";
                    $data['header']['header_html'] .= "<base href=\"". base_url() ."\" />\n";
                // NEW CODE [ meta content-type and base href] - END
                
                
                if( $this->meta_desc != '' ) {
                    $data['header']['header_html'] .= '<meta name="description" content="'.$this->meta_desc.'" />'."\n";
                }
        
                ////// "meta keywords" setting [Begin] //////
                if( $this->meta_keywords != '' ) {
                    $data['header']['header_html'] .= '<meta name="keywords" content="'.$this->meta_keywords.'" />'."\n";
                }
                        ////// "meta keywords" setting [End] //////
        
                ///////// NEW CODE [FOR DEFAULT CSS FILES - BEGIN] /////////

                if( is_array($this->css_files) && count($this->css_files) ) {
                    foreach($this->css_files as $key_css=>$item_css) {
                        if( is_array($item_css) && count($item_css) ) {
                            $attr = '';
                            foreach($item_css as $key_attr=>$attr_value) {
                                $attr .= ' '.$key_attr.'="'.$attr_value.'"';
                            }
                            $data['header']['header_html'] .= '<link href="'.base_url().$key_css.'" rel="stylesheet" type="text/css"'.$attr.' />'."\n";
                        }
                        else {
                            $data['header']['header_html'] .= '<link href="'.base_url().$key_css.'" rel="stylesheet" type="text/css" />'."\n";
                        }
                    }
                }
        
        
                // Inline css will be written in a file with the same name as view file 
                // and will be parsed by controller parse, action css.
                $data['header']['header_html'] .= '<link href="'.base_url().'parse/css/'.$css_script.'" rel="stylesheet" type="text/css" />'."\n";
        
                //dump($this->js_files);
                
                
                $data['header']['header_html'] .= "<script type=\"text/javascript\">
                                                   <!--
                                                    var base_url = '".base_url()."';
                                                    var is_login = '".$this->session->userdata('loggedin')."';
                                                   //-->
                                                  </script>";
                
                
        
                ///////// NEW CODE [FOR DEFAULT JS FILES] /////////
                $default_js_arr = array();
                
                if( is_array($this->js_files) && count($this->js_files) ) {
                    
                    $this->js_files = array_merge($this->js_files, $default_js_arr);
                    
                    foreach($this->js_files as $js_file=>$position) {
                        if($position == 'footer') {
                            //echo 'footer';
                            $data['header']['footer_html'] .= '<script type="text/javascript" src="'.base_url().$js_file.'"></script>'."\n";
                        }
                        else {
                            //echo 'header';
                            $data['header']['header_html'] .= '<script type="text/javascript" src="'.base_url().$js_file.'"></script>'."\n";
                        }
                    }
                }
        
                // Inline js will be written in a file with the same name as view file 
                // and will be parsed by controller parse, action js
                $data['header']['header_html'] .= '<script type="text/javascript" src="'.base_url().'parse/js/'.$js_script.'"></script>'."\n";
        
                if( is_array($this->header_html) && count($this->header_html) ) {
                    foreach($this->header_html as $header_html) {
                        $data['header']['header_html'] .= $header_html."\n";
                    }
                }
                
        
                # LOADING THE HEADER, SIDEBAR & FOOTER HTML PART (IF ANY) [START]...
                    $header_html_script = "layouts/header.phtml";
                    $data['header']['header_part'] = $this->load->view($header_html_script, $data, true);

                    $footer_html_script = "layouts/footer.phtml";
                    $data['header']['footer_part'] = $this->load->view($footer_html_script, $data, true);
                # LOADING THE HEADER, SIDEBAR & FOOTER HTML PART (IF ANY) [END]...
                
                $data['content'] = $this->load->view($view_script, $data, true);
                
                
        
                if(!$bool_string) {
                    $this->load->view($this->layout, $data);
                }
                else {
                    return $this->load->view($this->layout, $data, true);
                }
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }
    /* ************************************************************************* */

   
    
    // ==============================================================================================
    //                  NEW FUNCTION DEFINITION(S) - BEGIN
    // ==============================================================================================

        # function to load oAuth library settings site-wide...
        public function _load_oauth_settings() {
            
            try {
                
                // Add a header indicating this is an OAuth server
                header('X-XRDS-Location: '. base_url() .'services.xrds.php');
                 
                // Connect to database - MySQLi DB connection credentials...
                /*$mysqli_conn_arr = array('server'   => 'localhost',
                                         'username' => 'spicentea_usr',
                                         'password' => 'usr123',
                                         'database' => 'spicentea_oauth');*/
                $mysqli_conn_arr = array('server'   => 'localhost',
				                		 'username' => 'root',
				                		 'password' => 'shld123',
				                		 'database' => 'spicentea_oauth');
                 
                // Create a new instance of OAuthStore and OAuthServer
                $this->storeObj = $store = OAuthStore::instance('MySQLi', $mysqli_conn_arr);
                $this->serverObj = $server = new OAuthServer();
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        


        # function to check logged in state...
        public function _check_login() 
        {
             try{
                
                if( !$this->session->userdata('sess_user_id') )
                    redirect( base_url() );
                
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            } 
        }
                
    
    // ==============================================================================================
    //                  NEW FUNCTION DEFINITION(S) - END
    // ==============================================================================================
    
	
}