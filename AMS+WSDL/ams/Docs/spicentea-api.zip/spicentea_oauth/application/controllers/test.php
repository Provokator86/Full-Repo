<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	# index function definition...
	public function index()
	{
		try {
            $data = $this->data;
            
            $this->load->helper('file');
            $mail_txt_path = APPPATH .'../email-formats/new-user-mail.txt';
            $body = htmlspecialchars_decode(read_file($mail_txt_path), ENT_QUOTES);
            
            
            $body = sprintf3( $body, array('name'           => 'test',
                                           'consumer_key'   => 'xxyyzz',
                                           'consumer_secret'=> 'aabbcc'));
           
           
            //echo $body;
            $mail_subject = 'your account created successfully!';
            $arr['subject'] = htmlspecialchars_decode($mail_subject, ENT_QUOTES);
            $arr['to']      = 'test@test.com';
           
            $arr['bcc']    = 'acumen.demo@gmail.com';
            $arr['from_email'] = $this->config->item('no_reply_email');
            $arr['from_name'] = "Team TSTE";
            $arr['message'] = $body;
            #dump($arr); exit;
    
            send_mail($arr);
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}
    
    
    
    # process login
    public function process_login() {
        
        try {
            
            // I: retrieving submitted values...
            $USERNAME = trim( $this->input->post('s_username', true) );
            $PASSWORD = trim( $this->input->post('s_password', true) );
            
            // check if the login information is valid and get the user's ID
            $sql = sprintf("SELECT * FROM %susers
                            WHERE
                                BINARY `s_username`='%s' AND `s_password`='%s' ",
                            $this->db->dbprefix, $USERNAME, get_salted_password($PASSWORD));
            $row = $this->db->query($sql)->row_array();
             
            if (!$row) {
                // incorrect login
                $redirect_url = base_url() ."?err=1";
                redirect($redirect_url);
                exit;
            }
            $id = $row['i_id'];
            $usr_type = $row['i_user_type'];
            
            // set in session...
            $this->session->set_userdata('sess_user_id', $id);
            $this->session->set_userdata('sess_user_type', $usr_type);
            
            
            # redirect to desired page...
            $redirect_url = base_url() ."api-listing";
            redirect($redirect_url);           
                        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
        
    }
    
    
    # logout function...
    public function logout() {
        
        try{
            # clearing sessions...
            $this->session->unset_userdata('sess_user_id');
            $this->session->unset_userdata('sess_user_type');
            
            redirect(base_url());
            
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
        
    }


	// NEW - server info...
	public function server_info() {
		
		phpinfo();
		
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
