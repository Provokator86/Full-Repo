<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Store_employees extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            parent::_check_login();
                     
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
    // =========================== GET DAY SALES - SEARCH VIEW [BEGIN] ===========================
        
	    # to display "Get-Day-Sales" search form...
	    public function index()
	    {
		    try {
                $data = $this->data;
                
                # adjusting header & footer sections [Start]...
                    parent::_set_title(':: Store - Get Employees ::');
                    parent::_set_meta_desc('Store - Get Employees');
                    parent::_set_meta_keywords('Store - Get Employees');
                    
                    parent::_add_js_arr( array('js/datetimepicker/jquery.datetimepicker.js'=>'header',
                                               'js/custom-scripts/form_common_script.js'=>'header'));
                                               
                    parent::_add_css_arr( array('js/datetimepicker/jquery.datetimepicker.css') );
                # adjusting header & footer sections [End]...
                
                
                # view file...
                $VIEW = "api-calls/store-employees.phtml";
                parent::_render($data, $VIEW);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
	    }
        
        
        # function to validate form details [AJAX CALL]
        public function validate_form_details_AJAX() {
            
            try {
            
                // Error Messages for Required Fields...
                $REQD_FLD_MSG = '* required field';
                $required_fields = array('store_id', 'date1');
                $css_class_arr   = array('name', 'email');
                    
                // adjusting err-messages part accordingly...
                $arr_messages = array();
                
                ////////////// VALIDATION CHECKS - BEGIN //////////////
                    
                    # validation for singular fields (i.e. appearing once)...
                    foreach($required_fields as $key=>$required_field) {
                        
                        if( $_POST[$required_field]=='' && in_array($required_field, $required_fields) )
                            $arr_messages[$css_class_arr[$key]] = $REQD_FLD_MSG;
                        
                    }
                    
                ////////////// VALIDATION CHECKS - END //////////////

                if( count($arr_messages)==0 ) 
                {
                    $this->submit_form_details_AJAX();
                    
                } else {
                    echo json_encode(array('result'=>'error',
                                           'arr_messages'=>$arr_messages));
                    exit;
                }
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }

        
        # function to submit the form on successful form-validation [AJAX CALL]...
        public function submit_form_details_AJAX()
        {
            try {
                $arr_return = array();
                
                //// Now, retrieving submitted/posted values [BEGIN]...
                    $STORE_ID = trim( $this->input->post('store_id', true) );
                    $DAY1 = trim( $this->input->post('date1', true) );
                    $DAY2 = trim( $this->input->post('date2', true) );
                    $FORMAT = trim( $this->input->post('format_type', true) );
                //// retrieving submitted/posted values [END]...
                
                $API_URL = base_url() ."api-calls/get-store-employees/";
                $API_URL .= "{$STORE_ID}";
                $API_URL .= "/{$DAY1}";
                $API_URL .= ( !empty($DAY2) )? "/{$DAY2}": "/0";
                $API_URL .= ( !empty($FORMAT) )? "/{$FORMAT}": "/xml";
                
                echo json_encode(array('result'=>'success',
                                       'api_url'=>$API_URL));
                exit;
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }
        
    // =========================== GET DAY SALES - SEARCH VIEW [END] ===========================
    
}

/* End of file index.php */
/* Location: ./application/controllers/index.php */