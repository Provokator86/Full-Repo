<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Controller Definition
class Get_store_sales_by_product_group_by_day extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
    # store-day-sales...
    public function index($store_id, $day1, $day2=0, $format='xml')
    {
        try {
            $data = $this->data;
            $id = $this->session->userdata('sess_user_id');
            $usr_type = $this->session->userdata('sess_user_type');
            
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            //              OAUTH RELATED CODE [BEGIN]
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            
                define('OAUTH_HOST', base_url());

                # I: options array form...
                $options = array(
                    'server_uri' => base_url(),
                    'request_token_uri' => $this->config->item('oauth_request_token_uri'),
                    'authorize_uri' => $this->config->item('oauth_authorize_uri'),
                    'access_token_uri' => $this->config->item('oauth_access_token_uri')
                );
                
                
                $user_data = $this->users_model->fetch_this($id);
                $options['consumer_key'] = $user_data['s_consumer_key'];
                $options['consumer_secret'] = $user_data['s_consumer_secret'];
                
                # II: main logic...
                if (empty($_GET['oauth_token'])) {
                	
                    // get a request token
                    $tokenResultParams = OAuthRequester::requestRequestToken($options['consumer_key'], $id);
                    
                    $callback_url = base_url() ."api-calls/get-store-sales-by-product-group-by-day/{$store_id}/{$day1}";
                    $callback_url .= ( !empty($day2) )? "/{$day2}": "/0";
                    $callback_url .= "/{$format}";
                    $login_redirect_url = $options['authorize_uri'] 
                                          . '?oauth_token=' . $tokenResultParams['token']
                                          . '&oauth_callback=' . urlencode($callback_url);
                 
                    header('Location: ' . $login_redirect_url);
                } else {
                    
                    $API_URL = $this->config->item('api_url') ."api-calls/store_sales_by_product_group_by_day_stats/sales_info/";
                    $API_URL .= "store/{$store_id}/day1/{$day1}";
                    $API_URL .= ( !empty($day2) )? "/day2/{$day2}": '/day2/0';
                    $API_URL .= ( !empty($format) )? "/usr_type/{$usr_type}/format/{$format}": "/usr_type/{$usr_type}/format/xml";
                    
                    // get an access token
                    $oauthToken = $_GET['oauth_token'];
                    $tokenResultParams = $_GET;
                    
                    OAuthRequester::requestAccessToken($options['consumer_key'], $tokenResultParams['oauth_token'], $id, 'POST', $_GET);
                    $request = new OAuthRequester($API_URL, 'GET', $tokenResultParams);
                    $result = $request->doRequest($id);
                    
                    
                    
                    if ($result['code'] == 200) {
                        
                        /*if( $format!='json' )
                            echo header ("Content-Type:text/{$format}");*/
                        echo header ("Content-Type:application/{$format}");
                        echo $result['body'];
                    
                    }
                    else {
                        
                        echo 'Error';
                    }
                }
            
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            //              OAUTH RELATED CODE [END]
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
}

/* End of file get_store_sales_by_product_group_by_day.php */
/* Location: ./application/controllers/api-calls/get_store_sales_by_product_group_by_day.php */