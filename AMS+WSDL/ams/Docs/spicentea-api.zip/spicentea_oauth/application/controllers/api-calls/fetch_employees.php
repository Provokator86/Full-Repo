<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fetch_employees extends Base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
    # store-employees...
    public function index($usr_api_key=null, $usr_api_secret=null, $erply_account_no=null, $day1=null, $day2=null, $format='xml')
    {
        try {
            $data = $this->data;
            
            # ~~~~~~~~~ NEW - Form an array with all these passed parameter(s) [Begin]...
                $PARAM_ARR = array('consumer_key'   => $usr_api_key,
                                   'consumer_secret'=> $usr_api_secret,
                                   'account_number' => $erply_account_no,
                                   #'day_from'       => $day1,
                                   'response_format'=> $format);
            # ~~~~~~~~~ NEW - Form an array with all these passed parameter(s) [End]...
            
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            //              OAUTH RELATED CODE [BEGIN]
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            
                # A : check for INPUT-ERROR i.e. mandatory parameter(s) missing OR not...
                if( !if_input_error_trapped($PARAM_ARR) ) {
                    
                    # B : check for FORMAT-ERROR i.e. inputs are in proper format OR not...
                    $ARR =  array( array( data_type         => "string", 
                                          consumer_key      => $usr_api_key
                                        ),
                                   array( data_type         => "string", 
                                          consumer_secret   => $usr_api_secret
                                        ),
                                   array( data_type         => "string", 
                                          account_number    => $erply_account_no
                                        ),
                                   array( data_type         => "date", 
                                          day_from          => $day1
                                        ),
                                   array( data_type         => "date", 
                                          day_to            => $day2
                                        ),
                                   array( data_type         => "string", 
                                          response_format   => $format
                                        )
                                 );

                    
                    if( !if_format_error_trapped($ARR, true) ) :
                        
                        define('OAUTH_HOST', base_url());

                        # I: options array form...
                        $options = array(
                            'server_uri' => base_url(),
                            'request_token_uri' => $this->config->item('oauth_request_token_uri'),
                            'authorize_uri' => $this->config->item('oauth_authorize_uri'),
                            'access_token_uri' => $this->config->item('oauth_access_token_uri')
                        );
                        
                        
                        $user_data = $this->users_model->fetch_info_by_key_N_secret($usr_api_key, $usr_api_secret);
                        if( empty( $user_data ) ) {    // no valid consumer key & secret...
                            
                            $RESPONSE_ERR_ARR = form_key_N_secret_error_response();
                            $ARR = _fetch_error_content($RESPONSE_ERR_ARR, $format);
                            
                            $ERR_CONTENT = $ARR['content'];
                            $format = $ARR['format'];
                        
                            echo header("Content-type:application/{$format}");
                            echo $ERR_CONTENT;
                            exit;
                            
                        } else {    // i.e. valid consumer-key & secret...
                        
                            if( !if_valid_storeID($erply_account_no) ) {  // throw error if not valid store-ID
                                $RESPONSE_ERR_ARR = form_valid_storeID_error_response($erply_account_no);
                                $ARR = _fetch_error_content($RESPONSE_ERR_ARR, $format);
                                
                                $ERR_CONTENT = $ARR['content'];
                                $format = $ARR['format'];
                            
                                echo header("Content-type:application/{$format}");
                                echo $ERR_CONTENT;
                                exit;
                            } else {
                                $id = $user_data['i_id'];
                                $usr_type = $user_data['i_user_type'];
                                
                                # set user-type into session...
                                $this->session->set_userdata('sess_user_type', $usr_type);
                            }
                            
                        }
                        
                        $options['consumer_key'] = $user_data['s_consumer_key'];
                        $options['consumer_secret'] = $user_data['s_consumer_secret'];
                        
                        # II: main logic...
                        if (empty($_GET['oauth_token'])) {
                            // get a request token
                            $tokenResultParams = OAuthRequester::requestRequestToken($options['consumer_key'], $id);
                            
                            $callback_url = base_url() ."api-calls/fetch-employees/{$usr_api_key}/{$usr_api_secret}/{$erply_account_no}";
                            $callback_url .= ( !empty($day1) )? "/{$day1}": "/0";
                            $callback_url .= ( !empty($day2) )? "/{$day2}": "/0";
                            $callback_url .= "/{$format}";
                            
                            $login_redirect_url = $options['authorize_uri'] 
                                                  . '?oauth_token=' . $tokenResultParams['token']
                                                  . '&oauth_callback=' . urlencode($callback_url);
                         
                            header('Location: ' . $login_redirect_url);
                        } else {
                            
                            $API_URL = $this->config->item('api_url') ."api-calls/store_employees_stats/info/";
                            $API_URL .= "store/{$erply_account_no}/day1/{$day1}";
                            $API_URL .= ( !empty($day2) )? "/day2/{$day2}": '/day2/0';
                            $API_URL .= ( !empty($format) )? "/usr_type/{$usr_type}/format/{$format}": "/usr_type/{$usr_type}/format/xml";
                            
                            // get an access token
                            $oauthToken = $_GET['oauth_token'];
                            $tokenResultParams = $_GET;
                            
                            OAuthRequester::requestAccessToken($options['consumer_key'], $tokenResultParams['oauth_token'], $id, 'POST', $_GET);
                            $request = new OAuthRequester($API_URL, 'GET', $tokenResultParams);
                            $result = $request->doRequest($id);
                            
                            if ($result['code'] == 200) {
                                
                                echo header ("Content-Type:application/{$format}");
                                echo $result['body'];
                            
                            }
                            else {
                                echo 'Error';
                            }
                        }
                        
                    else :  // for Formatted-Input Error
                    
                        $RESPONSE_ERR_ARR = form_input_format_error_response($ARR, true);
                        $ARR = _fetch_error_content($RESPONSE_ERR_ARR, $format);
                        
                        $ERR_CONTENT = $ARR['content'];
                        $format = $ARR['format'];
                    
                        echo header("Content-type:application/{$format}");
                        echo $ERR_CONTENT;
                            
                    endif;
                    
                } else {    // Mandatory Input Error
                    
                    $RESPONSE_ERR_ARR = form_input_error_response($PARAM_ARR);
                    $ARR = _fetch_error_content($RESPONSE_ERR_ARR, $format);
                    
                    $ERR_CONTENT = $ARR['content'];
                    $format = $ARR['format'];
                
                    echo header("Content-type:application/{$format}");
                    echo $ERR_CONTENT;
                }
                        
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            //              OAUTH RELATED CODE [END]
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
}

/* End of file get_average_ticket_sales.php */
/* Location: ./application/controllers/get_average_ticket_sales.php */