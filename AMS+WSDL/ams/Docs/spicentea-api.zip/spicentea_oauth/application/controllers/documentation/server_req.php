<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// 
class Server_req extends Doc_base_controller {

    # constructor definition...
    public function __construct()
    {
        try
        {
            parent::__construct();
            
            # loading required model(s) & helper(s)...
            $this->load->model('users_model');
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }  

    }

    
	# index function definition...
	public function index()
	{
		try {
            $data = $this->data;
            
            # Menu-Specific Settings
            $data['DOC_BREADCRUMB_HEADER'] = "Server Requirement(s)";
            $data['CURRENT_MENU'] = 'server-req';
            
            # adjusting header & footer sections [Start]...
                parent::_set_title(':: TSTE API Documentation - Server Requirement(s) ::');
                parent::_set_meta_desc('TSTE API Documentation - Server Requirement(s)');
                parent::_set_meta_keywords('TSTE API Documentation - Server Requirement(s)');
                
                parent::_add_js_arr( array('js/jquery-1.11.3.js'=>'header',
                                           
                                           // scroll-to-top
                                           'js/toTop/jquery-scrollToTop.js'=>'header',
                                           
                                           'js/custom-scripts/documentation/common_calls.js'=>'header'));
                parent::_add_css_arr( array('css/toTop/easing.css',
                                            'css/toTop/scrollToTop.css') );
            # adjusting header & footer sections [End]...
            
            # view file...
            $VIEW = "documentation/server-req.phtml";
            parent::_render($data, $VIEW);
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
	}
    
    
}

/* End of file oauth.php */
/* Location: ./application/controllers/documentation/oauth.php */