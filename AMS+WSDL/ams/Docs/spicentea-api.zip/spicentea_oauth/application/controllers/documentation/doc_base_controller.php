<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

class Doc_base_controller extends Base_Controller
{
    
    # constructor definition...
    public function __construct () {

        try
        {
            parent::__construct();
            
            $this->load->helper('common_helper');
    
            /******************************** Layout based codes *********************** */
                $this->js_files = array();
                $this->css_files = array();
                $this->header_html = array();
                $this->title = '';
                $this->meta_desc = '';
                $this->layout = 'layouts/documentation/doc_layout.phtml';
            /*************************************************************************** */
            
            
            # call to add default css & js file(s) - Begin
                $this->_add_default_doc_js_files();
                $this->_add_default_doc_css_files();
            # call to add default css & js file(s) - End
            
           
            # NEW - storing base-url in data...
            $this->data['site_url'] = base_url();
            
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }


    // When _render() is used it releases the output as there is flush() call in the layout fle views/layout.php
    // so to get a string return one has to change layout file using _set_layout(). 
    // flush() call makes js and css parallel download possible so page loads faster.
    protected function _render($data = array(), $view_script='', $ajax_call = false, $bool_string = false)
    {
        try{

            if($view_script == '') {
                if($this->router->directory=='') {
                   $view_script = $this->router->class.'.phtml';
                }
                else {
                    $view_script = $this->router->directory.'/'.$this->router->class.'.phtml';
                }
            }

            if( !$ajax_call )   {

                $matches_view = array();
                preg_match('/^(.*?)(\.[^\.]+)?$/', $view_script, $matches_view);
                
                $js_script =  base64_encode($matches_view[1].'.js');
                $css_script = base64_encode($matches_view[1].'.css');
                
                $this->header_html = array_unique($this->header_html);

                $data['header']['header_html'] = '';
                $data['header']['footer_html'] = '';

                $data['header']['header_html'] .= '<title>'.$this->title.'</title>'."\n";

                if( $this->meta_desc != '' ) {
                        $data['header']['header_html'] .= '<meta name="description" content="'.$this->meta_desc.'" />'."\n";
                }

                
                $data['header']['header_html'] .= "<script type=\"text/javascript\">
                                                   <!--
                                                        var doc_base_url = '".base_url()."';
                                                   //-->
                                                  </script>";
                
                if( is_array($this->js_files) && count($this->js_files) ) {
                        foreach($this->js_files as $js_file=>$position) {
                            if($position == 'footer') {
                                $data['header']['footer_html'] .= '<script type="text/javascript" src="'. base_url().$js_file .'"></script>'."\n";
                            }
                            else {
                                $data['header']['header_html'] .= '<script type="text/javascript" src="'. base_url().$js_file .'"></script>'."\n";
                            }
                        }
                }

                // Inline js will be written in a file with the same name as view file
                // and will be parsed by controller parse, action js
                $data['header']['header_html'] .= '<script type="text/javascript" src="'.base_url().'parse/js/'.$js_script.'"></script>'."\n";

                if( is_array($this->css_files) && count($this->css_files) ) {
                    foreach($this->css_files as $key_css=>$item_css) {
                        if( is_array($item_css) && count($item_css) ) {
                            $attr = '';
                            foreach($item_css as $key_attr=>$attr_value) {
                                $attr .= ' '.$key_attr.'="'.$attr_value.'"';
                            }
                            $data['header']['header_html'] .= '<link href="'. base_url().$key_css .'" rel="stylesheet" type="text/css"'.$attr.' />'."\n";
                        }
                        else {
                            $data['header']['header_html'] .= '<link href="'. base_url().$key_css .'" rel="stylesheet" type="text/css" />'."\n";
                        }
                    }
                }
                
                // Inline css will be written in a file with the same name as view file
                // and will be parsed by controller parse, action css.
                $data['header']['header_html'] .= '<link href="'.base_url().'parse/css/'.$css_script.'" rel="stylesheet" type="text/css" />'."\n";


                if( is_array($this->header_html) && count($this->header_html) ) {
                    foreach($this->header_html as $header_html) {
                        $data['header']['header_html'] .= $header_html."\n";
                    }
                }
                
                

            }   // end of AJAX call check...
            

            # LOADING THE ADMIN HEADER, SIDEBAR & FOOTER HTML PART [START]...
                
                //// loading Documentation-Menu options [Begin]
                    $data['menu_parent_arr'] = $this->config->item('doc_menu_parent');
                    $data['menu_sub_arr'] = $this->config->item('doc_menu_sub');
                //// loading Documentation-Menu options [End]
                
                
                $header_navbar_html_script = "layouts/documentation/doc_header_navbar.phtml";
                $data['header']['header_nav_part'] = $this->load->view($header_navbar_html_script, $data, true);
                
                $sidebar_html_script = "layouts/documentation/doc_sidebar.phtml";
                $data['header']['sidebar_part'] = $this->load->view($sidebar_html_script, $data, true);
                
                $header_html_script = "layouts/documentation/doc_header.phtml";
                $data['header']['header_part'] = $this->load->view($header_html_script, $data, true);
                
                $footer_html_script = "layouts/documentation/doc_footer.phtml";
                $data['header']['footer_part'] = $this->load->view($footer_html_script, $data, true);
            # LOADING THE ADMIN HEADER, SIDEBAR & FOOTER HTML PART [END]...
            
            $data['content'] = $this->load->view($view_script, $data, true);

            if(!$bool_string) {

                if( !$ajax_call )
                    $this->load->view($this->layout, $data);
                else
                    $this->load->view($view_script, $data);

            }
            else {

                if( !$ajax_call )
                    return $this->load->view($this->layout, $data);
                else
                    return $this->load->view($view_script, $data);
                        
            }
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        } 
    }
    /* ************************************************************************* */
    
    
    
    // =========================================================================================================
    //          NEW FUNCTION DEFINITION(S) [BEGIN]
    // =========================================================================================================
        
        # function to add default documentation-side js files...
        protected function _add_default_doc_js_files() {
            
            ///////// NEW CODE [FOR DEFAULT JS FILES - BEGIN] /////////
            $default_js_arr = array('js/jquery-1.11.3.js'=>'footer',
                                    
                                    # custom files...
                                    'js/jquery.blockUI.js'=>'footer',
                                    'js/jquery.form.js'   =>'footer',
                                    'js/json2.js'         =>'footer',
                                    'js/ModalDialog.js'   =>'footer');
                                    
                                    
            $this->_add_js_arr($default_js_arr);

        }
        
        
        
        # function to add documentation default css files...
        protected function _add_default_doc_css_files() {

            $default_css_arr = array('css/documentation/main.css'=>array('media'=>'all'),
                                     'css/documentation/side-bar.css'=>array('media'=>'all'));
                                    
            # fix for "css_files" array...
            /*if( is_array($this->css_files) && count($this->css_files) ) {
                $this->css_files = array_merge($default_css_arr, $this->js_files);
            } else {
                $this->css_files = $default_css_arr;
            }*/
            
            $this->_add_css_arr($default_css_arr);
        }
        
        
    // =========================================================================================================
    //          NEW FUNCTION DEFINITION(S) [BEGIN]
    // =========================================================================================================
    
    
}

