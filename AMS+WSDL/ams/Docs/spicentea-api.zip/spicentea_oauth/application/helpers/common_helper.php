<?php
# including oAuth-php...
set_include_path(APPPATH.'libraries' . PATH_SEPARATOR . get_include_path());

include('app_string_helper.php');
include('app_url_helper.php');
include_once('api_error_helper.php');   // NEW - for API error-reporting
include_once('my_mail_helper.php');   // NEW - email-helper