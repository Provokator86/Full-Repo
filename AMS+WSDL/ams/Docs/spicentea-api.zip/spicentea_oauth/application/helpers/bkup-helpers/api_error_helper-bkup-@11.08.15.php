<?php
//// API(s) error-reporting functions...
    
    //// INPUT-ERROR
        # I: function to know whether error occurrred OR not...
        function if_input_error_trapped($param_arr) {
            
            try {
                
                $return_flag = false;
                if( empty($param_arr['consumer_key']) )
                    $return_flag = true;
                elseif( empty($param_arr['consumer_secret']) )
                    $return_flag = true;
                elseif( empty($param_arr['account_number']) )
                    $return_flag = true;
                elseif( empty($param_arr['day_from']) )
                    $return_flag = true;
                else
                    $return_flag = false;
                    
                    
                return $return_flag;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }

        # II : function to trap & report error...
        function form_input_error_response($param_arr) {
            
            try {
                
                $err_msg = array();
                $err_msg = _chk_input_err_msg($param_arr);
                
                return $err_msg;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
    
    
    //// FORMAT-ERROR
        # III : function to check whether input-parameters are properly formatted OR not...
        function if_format_error_trapped($param_arr) {
            
            try {
                
                $CI = get_instance();
                $CI->load->helper('inflector');
                
                $return_flag = false;
                
                $FORMAT_ARR = $CI->config->item('valid_response_formats');
                $date_regex = '/^(19|20)\d\d[\-\/.](0[1-9]|1[012])[\-\/.](0[1-9]|[12][0-9]|3[01])$/';
                
                foreach($param_arr as $err_arr) {   // begin - foreach
                    
                    if( $err_arr['data_type']=='date' ) {
                        $DATE = ( !empty($err_arr['day_from']) )? $err_arr['day_from']: $err_arr['day_to'];
                        if ( !preg_match($date_regex, $DATE) && !empty($DATE) ) {
                            $return_flag = true;
                            break;                            
                        }
                    } elseif( $err_arr['data_type']=='string' ) {
                        
                        if( isset($err_arr['response_format']) && !empty($err_arr['response_format']) ) {
                            if( !in_array($err_arr['response_format'], $FORMAT_ARR) ) :
                                $return_flag = true;
                                break;
                            endif;
                            
                        }
                    }
                        
                }  // end - foreach
                
                return $return_flag;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        
        }
    
        # IV : function to trap & report input-format error...
        function form_input_format_error_response($param_arr) {
            
            try {
                
                $err_msg = array();
                $err_msg = _chk_format_err_msg($param_arr);
                
                return $err_msg;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        

    //// KEY-SECRET ERROR
        # V : function to trap & report consumer secret/key error...
        function form_key_N_secret_error_response() {
            
            try {
                
                $err_msg = array();
                $err_msg = _chk_key_N_secret_err_msg();
                
                return $err_msg;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
    
        
    //// STORE-ID (i.e. ERPLY-ACCOUNT-NUMBER) ERROR
        # VI : function to check whether valid Store-ID OR not...
        function if_valid_storeID($store_id) {
            
            try {
                
                $CI = get_instance();
                
                # DB Check [Begin]
                    $DB_api = $CI->load->database('api', TRUE);
                    $CI->tbl_daysales = $DB_api->DAYSALES;
                    $SQL = sprintf("SELECT COUNT(*) AS `record_count` FROM %s
                                    WHERE `erply_account_number`=%d ",
                                    $CI->tbl_daysales, $store_id);
                    $ROW = $DB_api->query($SQL)->row_array();
                    $DB_api->close();   // close this db connection...
                # DB Check [End]
                
                if( !$ROW['record_count'] )
                    return false;
                
                return true;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        
        }
        
        # VII : function to trap & report erply-account-number error...
        function form_valid_storeID_error_response($store_id) {
            
            try {
                
                $err_msg = array();
                $err_msg = _chk_valid_storeID_err_msg($store_id);
                
                return $err_msg;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
    
    # =======================================================================================
    #           PARAM SPECIFIC ERROR CODES & MESSAGES [BEGIN]
    # =======================================================================================
        
        //// INPUT-ERROR : for input error codes & messages...
        function _chk_input_err_msg($param_arr=null) {
            
            try {
                
                $CI = get_instance();
                $CI->load->helper('inflector');
                
                $ERR = array();
                
                $arr_code = 1;
                $arr_index = 0;
                
                # looping through input-parameters...
                foreach($param_arr as $param_key=>$param_val) {
                    
                    if( empty($param_val) ) {
                        $reqd_param = humanize($param_key);
                        $ERR[$arr_index]['error_code'] = _format_error_code($arr_code);
                        $ERR[$arr_index]['error_msg'] = "{$reqd_param} is required";
                        
                        $arr_index++;
                    }
                    
                    $arr_code++;    // as, error-code(s) needs to be fixed ones...
                    
                }
                
                return $ERR;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        //// FORMAT-ERROR : for input-format error codes & messages...
        function _chk_format_err_msg($param_arr=null) {
            
            try {
                
                $CI = get_instance();
                
                # proper format checking...
                $FORMAT_ARR = $CI->config->item('valid_response_formats');
                $date_regex = '/^(19|20)\d\d[\-\/.](0[1-9]|1[012])[\-\/.](0[1-9]|[12][0-9]|3[01])$/';
                
                $ERR = array();
                
                $arr_code = 5;
                $arr_index = 0;
                
                # looping through input-parameters...
                foreach($param_arr as $err_arr) {
                    
                    if( $err_arr['data_type']=='date' ) {
                        $DATE = ( !empty($err_arr['day_from']) )? $err_arr['day_from']: $err_arr['day_to'];
                        if ( !preg_match($date_regex, $DATE) && !empty($DATE) ) {
                            $ERR[$arr_index]['error_code'] = _format_error_code($arr_code);
                            $ERR[$arr_index]['error_msg'] = "Correct date-format is <yyyy-mm-dd>";
                            
                            $arr_index++;
                        }
                    } elseif( $err_arr['data_type']=='string' ) {
                        
                        if( isset($err_arr['response_format']) && !empty($err_arr['response_format']) ) {
                            
                            if( !in_array($err_arr['response_format'], $FORMAT_ARR) ) :
                                $ERR[$arr_index]['error_code'] = _format_error_code($arr_code);
                                $ERR[$arr_index]['error_msg'] = "Use proper response data-formats e.g. XML, JSON, CSV.";
                                
                                $arr_index++;
                            endif;
                            
                        }
                    }
                    
                    $arr_code++;    // as, error-code(s) needs to be fixed ones...
                    
                }
                
                return $ERR;
                
            }  catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        //// KEY-SECRET ERROR : function to check for valid user key/secret...
        function _chk_key_N_secret_err_msg() {
            
            try {
                
                $ERR = array();
                $arr_index = 0;
                
                $ERR[$arr_index]['error_code'] = _format_error_code(11);
                $ERR[$arr_index]['error_msg'] = 'Invalid consumer key/secret';
                
                return $ERR;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }


        //// STORE-ID (i.e. ERPLY-ACCOUNT-NUMBER) ERROR : function to check whether it's a valid StoreID or not...
        function _chk_valid_storeID_err_msg($store_id) {
            
            try {
                
                $ERR = array();
                $arr_index = 0;
                
                $CI = get_instance();
                
                # DB Check [Begin]
                    $DB_api = $CI->load->database('api', TRUE);
                    $CI->tbl_daysales = $DB_api->DAYSALES;
                    $SQL = sprintf("SELECT COUNT(*) AS `record_count` FROM %s
                                    WHERE `erply_account_number`=%d ",
                                    $CI->tbl_daysales, $store_id);
                    $ROW = $DB_api->query($SQL)->row_array();
                    $DB_api->close();   // close this db connection...
                # DB Check [End]
                
                if( !$ROW['record_count'] ) {
                    $ERR[$arr_index]['error_code'] = _format_error_code(12);
                    $ERR[$arr_index]['error_msg'] = 'StoreID not found in the system';
                }
                    
                return $ERR;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        
    # =======================================================================================
    #           PARAM SPECIFIC ERROR CODES & MESSAGES [END]
    # =======================================================================================
    
    
    
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               MISCELLANEOUS FUNCTION(S) - BEGIN
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        //// function to check if format is a valid format OR not...
        function _check_if_valid_format($format) {
            
            try {
                
                $CI = get_instance();
                
                if( in_array($format, $CI->config->item('valid_response_formats')) )
                    return true;
                    
                return false;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        
        //// function to handle/manage error(s) of different type(s)...
        function _fetch_error_content($error_arr, $format) {
            
            try {
                
                $return_arr = null;
                $CI = get_instance();
                
                if( !_check_if_valid_format($format) )
                    $format = $CI->config->item('default_response_format');
                $format_function = "to_{$format}";
                
                $CI->load->library('Format', $error_arr);
                $return_arr['content'] = $CI->format->{$format_function}($error_arr);
                $return_arr['format']  = $format;
                
                return $return_arr;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }
        
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               MISCELLANEOUS FUNCTION(S) - END
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~