<?php
function short_text($txt, $length) {
    return preg_replace('/(.*\.)[^\.]*$/', '$1', substr($txt, 0, $length));
}

function my_substr($txt,$length) {
    if(utf8_strlen($txt)>$length) {
        return utf8_substr($txt, 0, $length).'...';
    }
    else
        return $txt;
}


function is_int_val($data) {
    if (is_int($data) === true)
        return true;

    elseif (is_string($data) === true && is_numeric($data) === true) {
        return (utf8_strpos($data, '.') === false);
    }
    return false;
}

function is_numeric_val($data) {
    return preg_match('/^[\d]*[\.]?[\d]*$/', $data);
}


function sprintf3($str, $vars, $char = '%%') {
    $tmp = array();
    foreach($vars as $k => $v) {
        $tmp[$char . $k . $char] = $v;
    }
    return str_replace(array_keys($tmp), array_values($tmp), $str);
}

function implode_with_quote($glue, $arr) { //like Array(21,suman,hello) converted to "'21', 'suman', 'hello'"
    $csv='';
    for($i=0; $i<count($arr); $i++) {
        $item = utf8_trim($arr[$i]);

        if($item!='') {
            if($i!=count($arr)-1)
                $csv .= "'".$item."'".$glue;
            else
                $csv .= "'".$item."'";
        }
    }
    return $csv;
}

function explode_trim($seperator, $str) {
    $arr = explode($seperator, $str);
    $new_arr = array();
    foreach($arr as $key=>$item) {
        $new_arr[$key] = $item;
    }

    return $new_arr;
}

function basic_array($arr) {
    $new_arr = array();
    foreach($arr as $item) {
        $new_arr = array_merge($new_arr, array_values($item));
    }

    return array_unique($new_arr);
}

function basic_array_by_field($arr, $field) {
    $new_arr = array();
    foreach($arr as $item) {
        $new_arr[] = $item[$field];
    }

    return array_unique($new_arr);
}


function correct_csv($csv) {
    $csv = utf8_trim(preg_replace('/(,[\s]*)(?:[,\s]+)/', '$1', $csv), ',');
    $arr = explode(',', $csv);
    $correct_csv = implode(',', array_unique($arr));
    return $correct_csv;
}

function put_in_set($source, $list) {
    $new_array = array_unique($source);

    if( is_array($list) && count($list)>0 ) {
        $temp_arr = array_diff($list, $source);
        $new_array = array_merge($new_array, $temp_arr);
    }
    else if( ! is_array($list) && $list!='' ) {
        if( !in_array($list, $source) ) {
            $new_array[] = $list;
        }
    }
    else {
        return array_unique($source);
    }

    return $new_array;
}

function count_csv($str) {
    if( utf8_trim($str)=='' ) {
        return 0;
    }
    $arr = explode(',', $str);
    return count($arr);
}

function br2nl($text) {
    return preg_replace('/<br\\s*?\/??>/i', '', $text);
}

function file_get_contents_utf8($fn) {
    $content = file_get_contents($fn);
    return mb_convert_encoding($content, 'UTF-8');
}


function get_ext($filename) {
    $matches = array();
    $return_arr = array('filename'=>'', 'ext'=>'');

    preg_match('/(^.*)\.([^\.]*)/', $filename, $matches);
    if( isset($matches[1]) ) {
        $return_arr['filename'] = $matches[1];
    }
    if( isset($matches[2]) ) {
        $return_arr['ext'] = $matches[2];
    }

    return $return_arr;
}

function is_assoc($array) {
    foreach (array_keys($array) as $k => $v) {
        if ($k !== $v) {
            return true;
        }
    }
    return false;
}


function escape_singlequotes($str) {
    $chars= array("'", "&#039;");
    foreach($chars as $char) {
        switch ($char) {
            case "'":
                $str = str_replace($char, "\'", $str);
                break;
            case "\"":
                $str = str_replace($char, "\\\"", $str);
                break;
            case "&#039;":
                $str = str_replace($char, "\&#039;", $str);
                break;
            case "&quot;":
                $str = str_replace($char, "\&quot;", $str);
                break;
        }
    }

    return $str;
}

function escape_doublequotes($str) {
    $chars= array("\"", "&quot;");
    foreach($chars as $char) {
        switch ($char) {
            case "'":
                $str = str_replace($char, "\'", $str);
                break;
            case "\"":
                $str = str_replace($char, "\\\"", $str);
                break;
            case "&#039;":
                $str = str_replace($char, "\&#039;", $str);
                break;
            case "&quot;":
                $str = str_replace($char, "\&quot;", $str);
                break;
        }
    }

    return $str;
}


function nl2br2($string) {
    $string = str_replace(array("\r\n", "\r", "\n"), "", $string);
    return $string;
}


function dump($obj) {
    echo '<pre>';
    print_r($obj);
    echo '</pre>';
}

/**
 * @params string $source_language 'Skills r in user lang'
 * @params string $target_language '2 b displayed in this lang'
 */
function wrap_interests_translated($start_wrapper, $end_wrapper, $interests, $source_language='', $target_language='',$tags_type ='') 
{
    //echo 'source='.$source_language.' target='.$target_language;
    $ci = get_instance();
//     if($source_language==$target_language) {
//         return $skills;
//     }

    if($target_language=='') {
        $target_language = $_SESSION['current_language'];
    }

    if($source_language=='') {
        $arr = array_diff(array('en', 'fr'), array($_SESSION['current_language']));
        shuffle($arr);
        $source_language = $arr[0];
    }

    $interests = correct_csv($interests);
    $arr_interests = explode(',', $interests);
    
    $translated_interests = '';
    if( count($arr_interests) ) {
        foreach( $arr_interests as $interest ) {
            //echo ' '.$interest;
          $sql = sprintf("SELECT * FROM %sadmin_tag_suggest where tags_type ='{$tags_type}' AND tags = binary '%s'", $ci->db->dbprefix, ($interest));
            $query = $ci->db->query($sql);
            $result_arr = $query->result_array();

            if( is_array($result_arr) && count($result_arr) && is_array($result_arr[0]) && count($result_arr[0]) ) {
                if( trim($result_arr[0]["tags"])!='' ) {
                    $start = sprintf3($start_wrapper, array('interest_id'=>$result_arr[0]['id']));
                    $translated_interests .= $start.$result_arr[0]["tags"].$end_wrapper.', ';
                }
                else {
                    $start = sprintf3($start_wrapper, array('interest_id'=>$result_arr[0]['id']));
                    $translated_interests .= $start.$interest.$end_wrapper.', ';
                }
            }else
            {
               
               $translated_interests .= $interest.', ';
            }
            
        }

        //echo $translated_interests;
        return trim($translated_interests, ', ');
    }
    else {
        return $interests;
    }
}



/*
* helper function to form magazine-tags
* section and search-by-tags accordingly
*/
function form_tags_string($tag_string)
{
    $tags_arr = explode(",", $tag_string);
    
    $HTML = '';
    
    
    foreach($tags_arr as $key=>$val)
    {
        $tag = trim($val);
        
        $HTML .= '<a class="grey_link" href="'. base_url()."magazine/search-by-magazine-tags/{$tag}" .'">';
        $HTML .= $tag;
        $HTML .= '</a>';
        $HTML .= ', ';
    }
    
    $HTML = substr($HTML, 0, -2);
    
    return $HTML;
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//              MISCELLANEOUS FUNCTION(S) - BEGIN
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# for salted password...
function get_salted_password($password) {
    $ci = get_instance();
    $salt = $ci->config->item('salt');

    return sha1($salt.$password);
}

/****
* Function to format input string
*
*****/
function get_formatted_string($str)
{
    try
    {    
        return htmlspecialchars(trim($str),ENT_QUOTES, 'UTF-8');
    }
    catch(Exception $err_obj)
    {
      show_error($err_obj->getMessage());
    }         
}

# get db datetime...
function get_db_datetime() {
    try
    { 
        return date('Y-m-d H:i:s');
    }
    catch(Exception $err_obj)
    {
        show_error($err_obj->getMessage());
    }   
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//              MISCELLANEOUS FUNCTION(S) - END
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~