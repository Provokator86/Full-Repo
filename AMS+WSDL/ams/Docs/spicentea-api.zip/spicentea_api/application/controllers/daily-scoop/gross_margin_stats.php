<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
 * @link		http://philsturgeon.co.uk/code/
*/

class Gross_margin_stats extends REST_Controller
{
	public function gross_margin_get()
    {
        if(!$this->get('result') && !$this->get('day'))
        {
        	$this->response(NULL, 400);
        }

        // retrieving required data...
        $RESULT_TYPE = trim($this->get('result'));
        $DAY1 = trim($this->get('day1'));
        $DAY2 = trim($this->get('day2'));
        $USER_TYPE = ( $this->get('usr_type') )? trim($this->get('usr_type')): null;
        $STORE_ID = ( $this->get('store') )? trim($this->get('store')): null;
        
        if( !empty($DAY2) )
            $SQL = sprintf("CALL SP_gross_margin_stats_range('%s', '%s', '%s', %d, %d) ", $RESULT_TYPE, $DAY1, $DAY2, $STORE_ID, $USER_TYPE);
        else
            $SQL = sprintf("CALL SP_gross_margin_stats('%s', '%s', %d, %d) ", $RESULT_TYPE, $DAY1, $STORE_ID, $USER_TYPE);
        
        $ROW = $this->db->query($SQL)->result_array();
    	
        if($ROW)
        {
            $this->response($ROW, 200); // 200 being the HTTP response code
        }
        else
        {
            $this->response(array('error' => 'Data could not be found'), 404);
        }
    }
    
}