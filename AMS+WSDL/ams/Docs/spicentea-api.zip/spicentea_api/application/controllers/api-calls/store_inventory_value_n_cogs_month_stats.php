<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
 * @link		http://philsturgeon.co.uk/code/
*/

class Store_inventory_value_n_cogs_month_stats extends REST_Controller
{
	public function info_get()
    {
        if(!$this->get('store') && !$this->get('day1'))
        {
        	$this->response(NULL, 400);
        }
        
        // retrieving required data...
        $STORE_ID = trim($this->get('store'));
        $DAY1 = trim($this->get('day1'));
        $DAY2 = trim($this->get('day2'));
        $USER_TYPE = ( $this->get('usr_type') )? trim($this->get('usr_type')): null;
        
        if( !empty($DAY2) )
            $SQL = sprintf("CALL SP_store_inventory_value_n_cogs_month_range(%d, '%s', '%s', %d) ", $STORE_ID, $DAY1, $DAY2, $USER_TYPE);
        else
            $SQL = sprintf("CALL SP_store_inventory_value_n_cogs_month(%d, '%s', %d) ", $STORE_ID, $DAY1, $USER_TYPE);
        
        
        $ROW = $this->db->query($SQL)->result_array();
    	
        if($ROW)
        {
            # ~~~~~~~~~~ NEW - Adding url-to-be-called part to the ResultSet [Begin] ~~~~~~~~~~
                
                /*$API_URL = $this->config->item('baseURL') ."spicentea_oauth/api-calls/";
                $API_URL .= "fetch-inventory-value-n-cogs-month/<your-consumer-key>/<your-consumer-secret>/<erply-account-number>";
                $API_URL .= "/<yyyy-mm-dd>/<yyyy-mm-dd>";
                $API_URL .= "/(xml|json|csv)";
                $ROW = $this->_add_api_url($ROW, $API_URL);*/
                
            # ~~~~~~~~~~ NEW - Adding url-to-be-called part to the ResultSet [End] ~~~~~~~~~~
            
            $this->response($ROW, 200); // 200 being the HTTP response code
        }
        else
        {
            $err_response_arr = array('error_code'=>404,
                                      'error_msg'=>'No data found');
            $this->response($err_response_arr, 200);
        }
    }
    
}
