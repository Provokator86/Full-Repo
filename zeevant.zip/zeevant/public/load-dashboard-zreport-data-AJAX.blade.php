<!-- ////////////// DASHBOARD Z-REPORT SECTION - AJAX CONTENT [BEGIN] ////////////// -->
@if( !empty($data_tbl_arr) )
	<table class="table table-bordered table-striped table-condensed">
	  <thead>
		<tr>
		  <th class="reg">Description</th>
		  <th class="reg">Amount</th>
		</tr>
	  </thead>
	  <tbody>
		@forelse ($data_tbl_arr as $arr)
			{{--*/ $INDENT = ($arr['s_instruction']=='T')? '&nbsp;&nbsp;&nbsp;&nbsp;': '' /*--}}
			{{--*/ $BOLD_FLAG = ($arr['s_instruction']=='H' || $arr['s_instruction']=='B')? true: false /*--}}
			{{--*/ $DESC_VALUE = ($BOLD_FLAG)? '<b>'. $arr['s_description'] .'</b>': $arr['s_description'] /*--}}
			{{--*/ $NUMBER_VALUE = ( !empty($arr['d_value']) )? (($BOLD_FLAG)? '<b>$ '. number_format($arr['d_value'], 2) .'</b>': '$ '. number_format($arr['d_value'], 2)): ( ($arr['s_instruction']=='H')? '': '0.00' ) /*--}}
			<tr>
				<td>{{ $INDENT }} {!! $DESC_VALUE !!}</td>
				<td class="num-only"> {!! $NUMBER_VALUE !!}</td>
			</tr>
		@empty
			<tr>
				<td colspan="2" style="min-height: 50px;">No Data</td>
			</tr>
		@endforelse
	  </tbody>
	</table>
@else
	@include('userend.dashboard.ajax-parts.load-dashboard-zreport-empty-AJAX')
@endif
<!-- ////////////// DASHBOARD Z-REPORT SECTION - AJAX CONTENT [END] ////////////// -->

<script type="text/javascript">
<!--
	hideAJAXLoader('unseen', 'section');	// hiding the Z-Report loader section...
//-->
</script>