// JS for user-end login page

/////////////// AJAX "UserEnd Login" [BEGIN] //////////////

//// ~~~~ Settings for drop-down select
$(document).ready(function(arg) {	
	
	// for AJAX page-submission...
    optionsArr = { 
        beforeSubmit:  showBusyScreen,  // pre-submit callback 
        success:       validateFrm, // post-submit callback 
		url:		   base_url + "login/authenticate-AJAX"
    }; 
 
	
	
})

function login_AJAX()
{
	if(window.location.hash!='') {
		$('#frmLogin').append('<input type="hidden" name="hash" value="'+window.location.hash + '" />');
	}
	
	$('#frmLogin').ajaxSubmit(optionsArr);
	
	return false;
}


// validate ajax-submission...
function validateFrm(data)
{
	//console.log(data);
	var data = JSON.parse(data);

	if(data.result=='success') {
		
		// show message...
		showUIMsg(data.msg);
		
		// redirect to page...
		window.location.href = data.redirect_url;
	}


	if(data.result=='error') {
	
		//_alert_box(data.alert_type, data.msg);
		showUIMsg(data.msg);
		
	}
	
	// hide busy-screen...
	hideBusyScreen();
}

// 	
/////////////// AJAX "UserEnd Login" [END] //////////////


function _alert_box(css_class, alert_msg)
{
	var alert_css = "alert alert-"+ css_class;
	
	$('#div_login_alert').empty();
	$('#div_login_alert').removeClass();
	
	$('#div_login_alert').addClass(alert_css);
	$('#div_login_alert').html(alert_msg);
	
}