// ================== Script(s) for Product-Mix Page ==================

	var today = new Date();
	var prev_dt = null;
	
	$(function() {
		
		// I: get current date & date of 1 month earlier (i.e. -30 days)...
		prev_dt = new Date(today.getFullYear(), today.getMonth(), today.getDate()-30);
		
		// II: putting from-date(30 days back from to-date) & to-date in proper <span>s...
			$('#lbl_from_dt').html( $.datepicker.formatDate('d M yy', prev_dt) );	// from-date
			$('#lbl_to_dt').html( $.datepicker.formatDate('d M yy', today) );	// from-date
		
		
				
		// bootstrap3 datepicker(s)...
		
		//// III: from-date-icon click...
		$('#from_dt_icon').datepicker({
			format: 'd M yy',
			todayHighlight: true,
			autoclose: true
		}).on('changeDate', function(e){
			
			$('#lbl_from_dt').html( e.format($('#from_dt_icon div').datepicker('getFormattedDate')) );
			
		});
		$('#from_dt_icon').datepicker('setDate', prev_dt);	// set date as from-date...
		
		//// IV: to-date-icon click...
		$('#to_dt_icon').datepicker({
			format: 'd M yy',
			todayHighlight: true,
			autoclose: true
		}).on('changeDate', function(e){
			
			$('#lbl_to_dt').html( e.format($('#to_dt_icon div').datepicker('getFormattedDate')) );
			
		});
		$('#to_dt_icon').datepicker('setDate', today);	// set date as from-date...


	});