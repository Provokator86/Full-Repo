// ================== Script(s) for Daily-Scoop-Time-of-Day Page ==================

	var today = new Date();
	var prev_dt = null;
	
	$(function() {
		
		// I: get current date & date of 1 month earlier (i.e. -30 days)...
		prev_dt = new Date(today.getFullYear(), today.getMonth(), today.getDate()-30);
		
		// II: putting from-date(30 days back from to-date) & to-date in proper <span>s...
			$('#lbl_from_dt').html( $.datepicker.formatDate('d M yy', prev_dt) );	// from-date
			$('#lbl_to_dt').html( $.datepicker.formatDate('d M yy', today) );	// from-date
		
		
				
		// bootstrap3 datepicker(s)...
		
		//// III: from-date-icon click...
		$('#from_dt_icon').datepicker({
			format: 'd M yy',
			todayHighlight: true,
			autoclose: true
		}).on('changeDate', function(e){
			
			$('#lbl_from_dt').html( e.format($('#from_dt_icon div').datepicker('getFormattedDate')) );
			
		});
		$('#from_dt_icon').datepicker('setDate', prev_dt);	// set date as from-date...
		
		//// IV: to-date-icon click...
		$('#to_dt_icon').datepicker({
			format: 'd M yy',
			todayHighlight: true,
			autoclose: true
		}).on('changeDate', function(e){
			
			$('#lbl_to_dt').html( e.format($('#to_dt_icon div').datepicker('getFormattedDate')) );
			
		});
		$('#to_dt_icon').datepicker('setDate', today);	// set date as from-date...


	});

	
	
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 					Helper Functions [Begin]
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		// function to check if entered value is >100...
		function checkForVal(input_obj) {
			
			var entered_val = parseInt($(input_obj).val());
			
			if( entered_val>100 ) {
				showUIMsg("You can't put values greater than 100(>100).");
				$('input[name^="days"]:eq('+ selected_fld_index +')').val('');
				$('input[name^="days"]:eq('+ selected_fld_index +')').select();
			}
				
		}
		
		
		// function to check if total value doesn't exceed 100...
		function verifyTotal() {
			
			var total_val = 0;
			$('input[name^="days"]').each(function() {
				
				if( $(this).val().length !== 0 ) {
					total_val += parseFloat( $(this).val() );
				}
				
			});
			
			if( total_val>100 ) {
				showUIMsg("Sorry, the total exceeds 100%. Please recheck it.");
				$('input[name^="days"]:eq(0)').select();
			}
			
		}
		
		
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 					Helper Functions [End]
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	