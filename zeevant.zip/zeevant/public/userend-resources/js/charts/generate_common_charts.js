google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawNDCharts);

// Function to draw Bell-Curve(s)...
function drawNDCharts() {
	
	// Benchmark Revenue Charts...
	drawRAllStoresChart();
	drawRTop10StoresChart();
	drawRTop10RevenueStoresChart();
	drawRTop5StoresChart();
	drawRTop5RevenueStoresChart();
	
	
	// One fixed chart...
	drawRAnalysisChart();
	
}

// Function to draw Column-Chart(s)...
function drawColumnCharts() {
	
	// for Histogram/Column-Charts...
	drawCAllStoresChart();
	drawCTop10StoresChart();
	drawCTop10RevenueStoresChart();
	drawCTop5StoresChart();
	drawCTop5RevenueStoresChart();
	
	// One fixed chart...
	drawCAnalysisChart();
	
}



// window resize
$(window).resize(function(){
    //drawCharts();
	if( $('#chart_grap_one').is(':visible') )
		drawNDCharts();
	else
		drawColumnCharts();
});