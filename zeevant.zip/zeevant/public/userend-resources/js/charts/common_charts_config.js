/* ========= Charting Function(s) [Begin] ========= */

// Draw Revenue Chart (My Store vs Average of All Store KPI Stores)
function drawRAllStoresChart() {
	
	var data = google.visualization.arrayToDataTable([
	  ['Year', {role: 'annotation'}, 'Sales', {role: 'style'}, {role: 'tooltip'}],
	  [25, null, 0.00041, '#DAAEAF', 'Store 1: 25'],
	  [74, null, 0.00053, '#DAAEAF', 'Store 2: 74'],
	  [125, null, 0.00067, '#DAAEAF', 'Store 3: 125'],
	  [170, null, 0.00081, '#DAAEAF', 'Store 4: 170'],
	  [219, null, 0.00096, '#DAAEAF', 'Store 5: 219'],
	  [231, null, 0.00099, '#DAAEAF', 'Store 6: 231'],
	  [300, null, 0.00119, '#CC7878', 'Store 7: 300'],
	  [349, null, 0.0013, '#CC7878', 'Store 8: 349'],
	  [430, null, 0.00141, '#CC7878', 'Store 9: 430'],
	  [470, null, 0.00143, '#CC7878', 'Store 10: 470'],
	  [475, null, 0.00143, '#CC7878', 'Store 11: 475'],
	  [539, 'actual', 0.00138, '#CC7878', 'Store 12: 539'],
	  [555, null, 0.00136, '#CC7878', 'Store 13: 555'],
	  [600, null, 0.00128, '#CC7878', 'Store 14: 600'],
	  [625, null, 0.00122, '#A00000', 'Store 15: 625'],
	  [771, null, 0.00079, '#A00000', 'Store 16: 771'],
	  [800, 'plan', 0.00071, '#A00000', 'Store 17: 800'],
	  [891, null, 0.00046, '#A00000', 'Store 18: 891'],
	  [900, null, 0.00043, '#A00000', 'Store 19: 900'],
	  [990, null, 0.00025, '#A00000', 'Store 20: 990']
	]);
	

	var options = {
	  curveType: 'function',
	  areaOpacity: 1.0,
	  annotations: {
			stemColor: 'blue'
	  },
	  annotation: {
		1: {
			style: 'line'
		}
	  },
		vAxis: {
				minValue: 0,
				textPosition: 'none',
				//format: '0',
				gridlines: {color: 'transparent'}
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  //textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
    };
	
	var chart = new google.visualization.AreaChart(document.getElementById('bm_ar'));
	
	chart.draw(data, options);
}

// Draw Revenue Chart - (My Store vs Top 10 KPI Stores)
function drawRTop10StoresChart() {
	
	var data = google.visualization.arrayToDataTable([
	  ['Year', {role: 'annotation'}, 'Sales', {role: 'style'}, {role: 'tooltip'}],
	  [31, null, 0.00647, '#DAAEAF', 'Store 1: 31'],
	  [38, null, 0.01042, '#DAAEAF', 'Store 2: 38'],
	  [46, null, 0.01535, '#DAAEAF', 'Store 3: 46'],
	  [51, null, 0.01798, '#CC7878', 'Store 4: 51'],
	  [55, null, 0.01948, '#CC7878', 'Store 5: 55'],
	  [63, 'actual', 0.02017, '#CC7878', 'Store 6: 63'],
	  [71, null, 0.0177, '#CC7878', 'Store 7: 71'],
	  [72, null, 0.01721, '#A00000', 'Store 8: 72'],
	  [81, 'plan', 0.01191, '#A00000', 'Store 9: 81'],
	  [99, null, 0.00303, '#A00000', 'Store 10: 99'],
	]);

	var options = {
		curveType: 'function',
		areaOpacity: 1.0,
		annotations: {
			stemColor: 'blue'
		},
	    annotation: {
			1: {
				style: 'line'
			}
	    },
		vAxis: {
				minValue: 0,
				textPosition: 'none',
				gridlines: {color: 'transparent'}
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  //textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '85%',
		  height: '75%'
		},
		legend: { position: 'none' }
    };
	
	var chart = new google.visualization.AreaChart(document.getElementById('bm_rtop10'));
	
	chart.draw(data, options);
}

// Draw Chart - (My Store vs Top 10 Revenue Stores)
function drawRTop10RevenueStoresChart() {
	
	var data = google.visualization.arrayToDataTable([
	  ['Year', {role: 'annotation'}, 'Sales', {role: 'style'}, {role: 'tooltip'}],
	  [31, null, 0.00647, '#DAAEAF', 'Store 1: 31'],
	  [38, null, 0.01042, '#DAAEAF', 'Store 2: 38'],
	  [46, null, 0.01535, '#DAAEAF', 'Store 3: 46'],
	  [51, null, 0.01798, '#CC7878', 'Store 4: 51'],
	  [55, null, 0.01948, '#CC7878', 'Store 5: 55'],
	  [63, 'actual', 0.02017, '#CC7878', 'Store 6: 63'],
	  [71, null, 0.0177, '#CC7878', 'Store 7: 71'],
	  [72, null, 0.01721, '#A00000', 'Store 8: 72'],
	  [81, 'plan', 0.01191, '#A00000', 'Store 9: 81'],
	  [99, null, 0.00303, '#A00000', 'Store 10: 99'],
	]);

	var options = {
		curveType: 'function',
		areaOpacity: 1.0,
		annotations: {
			stemColor: 'blue'
		},
	    annotation: {
			1: {
				style: 'line'
			}
	    },
		vAxis: {
				minValue: 0,
				textPosition: 'none',
				gridlines: {color: 'transparent'}
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  //textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '85%',
		  height: '75%'
		},
		legend: { position: 'none' }
    };
	
	var chart = new google.visualization.AreaChart(document.getElementById('bm_r_revenuetop10'));
	
	chart.draw(data, options);
}

// Draw Revenue Chart - (My Store vs Top 5 KPI Stores)
function drawRTop5StoresChart() {
	
	var data = google.visualization.arrayToDataTable([
	  ['Year', {role: 'annotation'}, 'Sales', {role: 'style'}, {role: 'tooltip'}],
	  [7, null, 0.0058, '#DAAEAF', 'Store 1: 7'],
	  [21, 'actual', 0.00971, '#DAAEAF', 'Store 2: 21'],
	  [29, null, 0.01176, '#A00000', 'Store 3: 29'],
	  [55, null, 0.01296, '#A00000', 'Store 4: 55'],
	  [67, 'plan', 0.01035, '#CC7878', 'Store 5: 67'],
	  [92, null, 0.00375, '#CC7878', 'Store 5: 92']
	]);

	var options = {
		curveType: 'function',
		areaOpacity: 1.0,
		annotations: {
			stemColor: 'blue'
		},
		annotation: {
			1: {
				style: 'line'
			}
		},
		vAxis: {
				minValue: 0,
				textPosition: 'none',
				gridlines: {color: 'transparent'}
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  //textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '85%',
		  height: '75%'
		},
		legend: { position: 'none' }
    };
	
	var chart = new google.visualization.AreaChart(document.getElementById('bm_rtop5'));
	
	chart.draw(data, options);
}

// Draw Revenue Chart - (My Store vs Top 5 Revenue Stores)
function drawRTop5RevenueStoresChart() {
	
	var data = google.visualization.arrayToDataTable([
	  ['Year', {role: 'annotation'}, 'Sales', {role: 'style'}, {role: 'tooltip'}],
	  [7, null, 0.0058, '#DAAEAF', 'Store 1: 7'],
	  [21, 'actual', 0.00971, '#DAAEAF', 'Store 2: 21'],
	  [29, null, 0.01176, '#A00000', 'Store 3: 29'],
	  [55, null, 0.01296, '#A00000', 'Store 4: 55'],
	  [67, 'plan', 0.01035, '#CC7878', 'Store 5: 67'],
	  [92, null, 0.00375, '#CC7878', 'Store 5: 92']
	]);

	var options = {
		curveType: 'function',
		areaOpacity: 1.0,
		annotations: {
			stemColor: 'blue'
		},
		annotation: {
			1: {
				style: 'line'
			}
		},
		vAxis: {
				minValue: 0,
				textPosition: 'none',
				gridlines: {color: 'transparent'}
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  //textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '85%',
		  height: '75%'
		},
		legend: { position: 'none' }
    };
	
	var chart = new google.visualization.AreaChart(document.getElementById('bm_r_revenuetop5'));
	
	chart.draw(data, options);
}


// fixed chart - Last 12 Months Revenue Analysis
function drawRAnalysisChart() {
	
	var HTML = '<div class="img_brd"> <img src="img/brd2.jpg"> </div>';
	$('#bm_last_rev_analysis').html(HTML);
	
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



//// Draw Column Charts...
// I: Draw Column-Chart - (My Store vs Average of All Store KPI Stores)
function drawCAllStoresChart() {
	var data = google.visualization.arrayToDataTable([
	  ['Shop', 'Revenue', { role: 'style' }],
	  ['Shop 1', 990, '#CC7878'],
	  ['Shop 2', 900, '#CC7878'],
	  ['Shop 3', 891, '#CC7878'],
	  ['Shop 4', 800, '#CC7878'],
	  ['Shop 5', 771, '#CC7878'],
	  ['Shop 6', 625, '#CC7878'],
	  ['Shop 7', 600, '#CC7878'],
	  ['Shop 8', 555, '#CC7878'],
	  ['Shop 9', 539, '#CC7878'],
	  ['Shop 10', 475, '#CC7878'],
	  ['Shop 11', 470, '#CC7878'],
	  ['Shop 12', 430, '#CC7878'],
	  ['My Store', 409, '#A00000'],
	  ['Shop 13', 349, '#CC7878'],
	  ['Shop 14', 300, '#CC7878'],
	  ['Shop 15', 231, '#CC7878'],
	  ['Shop 16', 219, '#CC7878'],
	  ['Shop 17', 170, '#CC7878'],
	  ['Shop 18', 125, '#CC7878'],
	  ['Shop 19', 74, '#CC7878'],
	  ['Shop 20', 25, '#CC7878']
	]);

	var options = {
	    //bar: {groupWidth: "95%"},
		//colors: ['#1790E1'],
		vAxis: {
				//title: 'Ticket $',
				minValue: 0,
				//textPosition: 'none'
			 },
		hAxis: {
			  //title: 'Day of Month',	
			  gridlines: {color: 'transparent'},
			  textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
	};

	var chart = new google.visualization.ColumnChart(document.getElementById('hst_ar'));

	chart.draw(data, options);
}

// II: Draw Column-Chart - (My Store vs Top 10 KPI Stores)
function drawCTop10StoresChart() {
	var data = google.visualization.arrayToDataTable([
	  ['Store(s)', 'Revenue', { role: 'style' }],
	  ['Store 1', 99, '#CC7878'],
	  ['Store 2', 81, '#CC7878'],
	  ['Store 3', 72, '#CC7878'],
	  ['Store 4', 71, '#CC7878'],
	  ['Store 5', 63, '#CC7878'],
	  ['Store 6', 55, '#CC7878'],
	  ['Store 7', 51, '#CC7878'],
	  ['Store 8', 46, '#CC7878'],
	  ['Store 9', 38, '#CC7878'],
	  ['Store 10', 31, '#CC7878'],
	  ['My Store', 47, '#A00000']
	]);

	var options = {
	    bar: {groupWidth: "95%"},
		vAxis: {
				minValue: 0,
				//textPosition: 'none'
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
	};

	var chart = new google.visualization.ColumnChart(document.getElementById('hst_rtop10'));

	chart.draw(data, options);
}

// III: Draw Column-Chart - (My Store vs Top 10 Revenue Stores)
function drawCTop10RevenueStoresChart() {
	var data = google.visualization.arrayToDataTable([
	  ['Store(s)', 'Revenue', { role: 'style' }],
	  ['Store 1', 99, '#CC7878'],
	  ['Store 2', 81, '#CC7878'],
	  ['Store 3', 72, '#CC7878'],
	  ['Store 4', 71, '#CC7878'],
	  ['Store 5', 63, '#CC7878'],
	  ['Store 6', 55, '#CC7878'],
	  ['Store 7', 51, '#CC7878'],
	  ['Store 8', 46, '#CC7878'],
	  ['Store 9', 38, '#CC7878'],
	  ['Store 10', 31, '#CC7878'],
	  ['My Store', 47, '#A00000']
	]);

	var options = {
	    bar: {groupWidth: "95%"},
		vAxis: {
				minValue: 0,
				//textPosition: 'none'
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
	};

	var chart = new google.visualization.ColumnChart(document.getElementById('hst_r_revenuetop10'));

	chart.draw(data, options);
}

// IV: Draw Column-Chart - (My Store vs Top 5 KPI Stores)
function drawCTop5StoresChart() {
	var data = google.visualization.arrayToDataTable([
	  ['Store(s)', 'Revenue', { role: 'style' }],
	  ['Store 1', 92, '#CC7878'],
	  ['Store 2', 67, '#CC7878'],
	  ['Store 3', 55, '#CC7878'],
	  ['Store 4', 29, '#CC7878'],
	  ['Store 5', 21, '#CC7878'],
	  ['Store 6', 51, '#A00000']
	]);

	var options = {
	    bar: {groupWidth: "95%"},
		vAxis: {
				minValue: 0,
				//textPosition: 'none'
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
	};

	var chart = new google.visualization.ColumnChart(document.getElementById('hst_rtop5'));

	chart.draw(data, options);
}

// IV: Draw Column-Chart - (My Store vs Top 5 Revenue Stores)
function drawCTop5RevenueStoresChart() {
	var data = google.visualization.arrayToDataTable([
	  ['Store(s)', 'Revenue', { role: 'style' }],
	  ['Store 1', 92, '#CC7878'],
	  ['Store 2', 67, '#CC7878'],
	  ['Store 3', 55, '#CC7878'],
	  ['Store 4', 29, '#CC7878'],
	  ['Store 5', 21, '#CC7878'],
	  ['Store 6', 51, '#A00000']
	]);

	var options = {
	    bar: {groupWidth: "95%"},
		vAxis: {
				minValue: 0,
				//textPosition: 'none'
			 },
		hAxis: {
			  gridlines: {color: 'transparent'},
			  textPosition: 'none'
		},
		chartArea: {
		  backgroundColor: {
			  stroke: '#000000',
			  strokeWidth: 0.1
		  },
		  width: '90%',
		  height: '80%'
		},
		legend: { position: 'none' }
	};

	var chart = new google.visualization.ColumnChart(document.getElementById('hst_r_revenuetop5'));

	chart.draw(data, options);
}

// fixed chart - Last 12 Months Revenue Analysis
function drawCAnalysisChart() {
	
	var HTML = '<div class="img_brd"> <img src="img/brd2.jpg"> </div>';
	$('#hst_analysis').html(HTML);
	
}

/* ========= Charting Function(s) [End] ========= */