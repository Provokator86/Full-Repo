//// Miscellaneous Function(s) for Chart Utilities...

var powN;

// function to get the charting scale...
function getChartScale(arr_param) {
	
	
	// 1: extract the value(s) array from chart-data-array...
	var number_arr = fetchScaleData(arr_param);
	
	// I: get the max-val...
	var max_val = Math.max.apply(null, number_arr);
	
	// II: get itz scale of 10...
	/*powN = 1;
	getPowerOf10(max_val);
	
	var scale_value = Math.pow(10, powN);*/
	var scale_value = parseFloat(max_val) + 10;
	
	return scale_value;
}

// function to form an array of numeric (i.e. chart-data) values...
function fetchScaleData(arr_param) {
	
	var return_arr = [];
	
	var loop_index = 0;
	for (var i = 1; i < arr_param.length; i++) {
		
		if( arr_param[i]!='' ) {
			
			return_arr[loop_index] = arr_param[i][1];
			
			loop_index++;			
		}
	}
	
	// console.log(return_arr);
	
	return return_arr;
}



// calculate the power of 10...
function getPowerOf10(num) {
	
	var x = parseInt(num/10);
	
	if( x>10 ) {
		powN++;
		getPowerOf10(x);
	} else {
		powN++;
		return powN;
	}

	
}