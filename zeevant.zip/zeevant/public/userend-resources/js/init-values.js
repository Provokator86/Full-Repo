//// NEW - "wow" init flag...
WOW_INIT_FLAG = true;

	
if(window.location.href.indexOf("benchmark") > -1) {
   WOW_INIT_FLAG = false;
}
