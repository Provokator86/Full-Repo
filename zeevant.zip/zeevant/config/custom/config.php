<?php
# page for site-wide custom configuration value(s)...
return [

    // site Default title...
    'default_site_title' => ':: Welcome to Zeevant ::',

    // valid image-type(s)...
    'valid_img_ext' => array('gif', 'png', 'jpg', 'jpeg'),

    // Franchisor Logo Dimensions...
    'logo_width'  => '90',
    'logo_height' => '80',

    'test' => 'Managing',

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //          Frontend/Userend Menu Link(s) - Begin
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        'sidebar_arr' => array('dashboard' => '/',
                               'benchmark' => array(
                                                    'revenue' => '/benchmark/revenue-distribution',
                                                    'gross-margin' => '/benchmark/gross-margin',
                                                    'internet-sales' => '/benchmark/internet-sales',
                                                    'average-ticket' => '/benchmark/avg-ticket',
                                                    'marketing-%-of-sales' => '/benchmark/percentage-sales',
                                                    'labor-efficiency' => '/benchmark/labor-efficiency',
                                                    'inventory-turns' => '/benchmark/inventory-turns',
                                                    'conversion-ratio' => '/benchmark/conversion-ratio',
                                                    'store-visitations' => '/benchmark/store-visitation',
                                                    'average-discount' => '/benchmark/avg-discount'
                                              ),
                               'daily-scoop' => array(
                                                    'cumulative-revenue' => '/daily-scoop/cumulative-revenue',
                                                    'ticket' => '/daily-scoop/ticket',
                                                    'gross-margin' => '/daily-scoop/gross-margin',
                                                    'discount' => '/daily-scoop/discount',
                                                    'time-of-day' => '/daily-scoop/time-of-day',
                                                    'z-report' => '/daily-scoop/zreport',
                                                    'top-10-sellers' => '/daily-scoop/top-10-sellers',
                                                    //'product-mix' => '/daily-scoop/product-mix',
                                                    'mix-and-shelf-space-optimizer' => '/daily-scoop/product-mix',
                                                    'visitations' => '/daily-scoop/visitations',
                                                    //'pricing-tool' => '/daily-scoop/pricing-tool',
                                                    'conversion-rate' => '#'
                                               ),
                               'my-inputs' => array(
                                                    'configuration-inputs' => '/my-inputs/configuration-inputs',
                                                    'monthly-KPI-plan' => '/my-inputs/monthly-KPI-plan',
                                                    'monthly-financials' => '/my-inputs/monthly-financials',
                                                    'labor-floor-hours' => '/my-inputs/labor-floor-hours'
                                               ),
                               'contribution-and-pricing-tools' => '/pricing-tool',
                               'settings' => '#',
                               'franchisee' => array(
                                                    'manage-franchisees' => '/franchisee/manage-franchisees',
                                                    'franchisee-users' => '/franchisee/franchisee-users'
                                               )
        ),

        'sidebar_icons_arr' => array(
                                        'dashboard' => 'dashboard',
                                        'benchmark' => 'television',
                                        'daily-scoop' => 'shopping-cart',
                                        'my-inputs' => 'book',
                                        'my-accounting' => 'calculator',
                                        'my-results' => 'search',
                                        'contribution-and-pricing-tools' => 'line-chart',
                                        'settings' => 'cog',
                                        'franchisee' => 'user-plus'
                                     ),
                                     
        //// NEW - for sidebar option view/hide...
        'sidebar_acl_arr' =>  array(
                                        'dashboard' => [1,2,3,4],
                                        'benchmark' => [2,3,4],
                                        'daily-scoop' => [2,3,4],
                                        'my-inputs' => [2,3,4],
                                        'my-accounting' => [2,3,4],
                                        'my-results' => [2,3,4],
                                        'contribution-and-pricing-tools' => [2,3,4],
                                        'settings' => [2,3,4],
                                        'franchisee' => [2]
                                    ),
                                    
                                    
       //// NEW - for sidebar multiple/single store-owner access...
		'sidebar_store_wise_access_arr' =>  array(
													'dashboard' => [0],
													'benchmark' => array(
						                                                    'revenue' => 0,
						                                                    'gross-margin' => 0,
						                                                    'internet-sales' => 0,
						                                                    'average-ticket' => 0,
						                                                    'marketing-%-of-sales' => 0,
						                                                    'labor-efficiency' => 0,
						                                                    'inventory-turns' => 0,
						                                                    'conversion-ratio' => 0,
						                                                    'store-visitations' => 0,
						                                                    'average-discount' => 0
						                                                ),
													'daily-scoop' => array(
						                                                    'cumulative-revenue' => 0,
						                                                    'ticket' => 0,
						                                                    'gross-margin' => 0,
						                                                    'discount' => 0,
						                                                    'time-of-day' => 0,
						                                                    'z-report' => 0,
						                                                    'top-10-sellers' => 0,
						                                                    'mix-and-shelf-space-optimizer' => 0,
						                                                    'visitations' => 0,
						                                                    'conversion-rate' => 0
						                                                 ),
													'my-inputs' => array(
						                                                    'configuration-inputs' => 0,
						                                                    'monthly-KPI-plan' => 0,
						                                                    'monthly-financials' => 0,
						                                                    'labor-floor-hours' => 0
						                                                ),
												    'my-results' => array(
																		'multistore-view' => 1,
																		'singlestore-view' => 0
																	),
						                            'contribution-and-pricing-tools' => 0,
													'settings' => 0,
													'franchisee' => array(
						                                                    'manage-franchisees' => 0,
						                                                    'franchisee-users' => 0
						                                                 )
												),
		                                    

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //          Frontend/Userend Menu Link(s) - End
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




    // ===================================================================
    //       ACL Controls (Resources, Previleges etc [Begin]
    // ===================================================================

        'acl_master' => array('general'=>array('site_settings', 'dashboard'),
                              'users'=>array('manage_user_types', 'manage_companies')),
        'roles_arr' => array('site_settings'=>array('edit'),
                             'dashboard'=>array('view'),
                             'manage_user_types'=>array('view', 'add', 'edit', 'delete', 'access_control'),
                             'manage_companies'=>array('view', 'add', 'edit', 'delete')),

    // ===================================================================
    //       ACL Controls (Resources, Previleges etc [End]
    // ===================================================================
    
												
	// NEW - Default TimeZone
		'default_timezone' => 'America/New_York',

];
