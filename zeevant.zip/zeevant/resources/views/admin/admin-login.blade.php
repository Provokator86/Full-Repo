<!DOCTYPE html>
<html>
  <head>
    @include('layouts.admin.partials.head-meta-section')
	
    @include('layouts.admin.partials.head-login-scripts-section')
	
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
        <!-- <a href="{{ url() }}"><b>Admin</b>LTE</a> -->
		<a class="login-logo2" href="{{ url() }}"><img src="{{ asset('admin-resources/dist/img/logo/logo-full.png') }}" alt="Zeevant" /></a>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>
        <form id="frmAdminLogin" action="" method="post" onsubmit="return admin_login_AJAX()">
          <div class="form-group has-feedback">
            <input type="name" class="form-control" placeholder="Username" name="username" />
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="passwd" />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">
              <div class="checkbox icheck">
                <label>
                  <input type="checkbox" name="chkRem" /> Remember Me
                </label>
              </div>
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
            </div><!-- /.col -->
          </div>
        </form>

      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    @include('layouts.admin.partials.footer-login-scripts-section')
	{{-- //////////////// For Page-Specific JS File(s) [Begin] //////////////// --}}
		{!! Html::script('admin-resources/dist/js/custom-scripts/admin-login.js') !!}
	{{-- //////////////// For Page-Specific JS File(s) [End] //////////////// --}}
	

	<!-- ############ Loading Section [Start] ########### -->
		<div id="loading_dialog" class="modal_dialog" style="width:auto;padding:20px; background:transparent;border:none; display:none;"> <img src="{{ asset('admin-resources/dist/img/loaders/loading_big.gif') }}" width="50"/> </div>
	<!-- ############ Loading Section [End] ########### -->

  </body>
</html>