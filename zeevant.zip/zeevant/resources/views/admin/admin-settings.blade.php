@extends('layouts.admin.admin-layout')

@section('breadcrumb')
	{!! Breadcrumbs::render('settings') !!}
@stop

@section('content')
	<div class="row">			
		<div class="col-md-12">
			<div class="box box-info">    
			{{-- Show Messages --}}
				<div class="box-header">
					<i class="fa fa-edit"></i>
					<h3 class="box-title">Site Settings</h3>
				</div><!-- /.box-header -->

					   
					<form role="form" id="frmAdminSettings" action="" method="post" onsubmit="return update_account_settings_AJAX()">
					<input type="hidden" id="h_id" name="h_id" value="{{ $settings_info->i_id }}"> 
						<div class="box-body">   
						
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_admin_mail_lbl" for="s_admin_mail">Admin Email</label>
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
											<input type="email" class="form-control" name="s_admin_mail" id="s_admin_mail" placeholder="Email" value="{{ $settings_info->s_admin_mail }}">
											<span class="text-danger"></span>
										</div>
									</div>
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="s_contact_mail_lbl" for="s_contact_mail">Contact Email</label>
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
											<input type="text" class="form-control" id="s_contact_mail" name="s_contact_mail" placeholder="Contact Email" value="{{ $settings_info->s_contact_mail }}">
											<span class="text-danger"></span>
										</div>
									</div> 
								</div>
							</div>                         
							
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_site_phone_lbl" for="s_site_phone">Site Phone</label>
										<div class="input-group">
											<div class="input-group-addon">
												<i class="fa fa-phone"></i>
											</div>
											<input type="text" class="form-control" id="s_site_phone" name="s_site_phone" placeholder="Site Phone" class="form-control" value="{{ $settings_info->s_site_phone }}" data-inputmask='"mask": "(999) 999-9999"' data-mask>
											<span class="text-danger"></span>
										</div>
									</div>
								</div>                                     
								<div class="col-md-5 col-md-offset-1"> 
									<div class="form-group">
										<label id="i_items_per_page_lbl">Item(s) Per Page</label>
										<input type="text" class="form-control" id="i_items_per_page" name="i_items_per_page" placeholder="Item Per Page" value="{{ $settings_info->i_items_per_page }}" />
										<span class="text-danger"></span>
									</div>                                   
								</div>
							</div>                       
							
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_site_title">Site Title</label>
										<input type="text" class="form-control" id="s_site_title" name="s_site_title" placeholder="Site Title" value="{{ $settings_info->s_site_title }}" />
										<span class="text-danger"></span>
									</div>
								</div>                                     
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label>Google Plus URL</label>
										<input type="text" class="form-control" id="s_g_plus_url" name="s_g_plus_url" placeholder="Google Plus URL" value="{{-- s_g_plus_url --}}" disabled />
										<span class="text-danger"></span>
									</div>                                    
								</div>
							</div>  
							
							<div class="row">
								<div class="col-md-5"> 
									<div class="form-group">
										<label>Youtube URL</label>
										<input type="text" class="form-control" id="s_youtube_url" name="s_youtube_url" placeholder="Youtube URL" value="{{-- s_youtube_url --}}" disabled />
										<span class="text-danger"></span>
									</div>                                    
								</div>                                     
								<div class="col-md-5 col-md-offset-1">   
									<div class="form-group">
										<label>Default Listing Expiry Days</label>
										<input type="text" class="form-control" id="i_listing_exp_no" name="i_listing_exp_no" placeholder="Default Listing Expiry Number" value="{{-- i_listing_exp_no --}}" disabled />
										<span class="text-danger"></span>
									</div>                           
									
								</div>
							</div>                     
							
							<div class="row">
								<div class="col-md-5"> 
									<div class="form-group">
										<label>Footer Text</label>
										<textarea class="form-control" id="s_footer_text" name="s_footer_text" placeholder="Footer Text" disabled>{{-- s_footer_text --}}</textarea>
										<span class="text-danger"></span>
									</div>                                    
								</div>                                     
								<div class="col-md-5 col-md-offset-1"> 
									<div class="form-group">
										<label>Linked In URL</label>
										<input type="text" class="form-control" id="s_linked_in_url" name="s_linked_in_url" placeholder="Linked In URL" value="{{-- s_linked_in_url --}}" disabled />
										<span class="text-danger"></span>
									</div>                                   
								</div>
							</div>
						
						</div>

						<div class="box-footer">
							<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save Changes">
						</div>
					</form>
			
			</div>
		</div>
	</div>
@endsection

@section('page-specific-scripts')
	{!! Html::script('admin-resources/plugins/input-mask/jquery.inputmask.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/settings-page.js') !!}
@stop