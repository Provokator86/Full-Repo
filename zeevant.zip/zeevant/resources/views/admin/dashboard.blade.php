@extends('layouts.admin.admin-layout')

@section('breadcrumb')
	{!! Breadcrumbs::render('home') !!}
@stop

@section('content')

<!-- Script to load fusion chart -->

<script type="text/javascript">
    
FusionCharts.ready(function(){
   
      
  
  
   /*var visitChart = new FusionCharts({
        type: 'mssplinearea',
        renderAt: 'chartContainer',
        width: '500',
        height: '350',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Normal Distrition",
                "subCaption": "Normal Distrition Chart",
                "xAxisName": "Value",
                "yAxisName": "Deviation",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "baseFontColor" : "#333333",
                "baseFont" : "Helvetica Neue,Arial",                        
                "subcaptionFontBold": "0",
                "paletteColors" : "#6baa01,#008ee4",
                "usePlotGradientColor": "0",
                "bgColor" : "#ffffff",
                "showBorder" : "0",
                "showPlotBorder": "0",
                "showValues": "0",                 
                "showShadow" : "0",
                "showAlternateHGridColor" : "0",
                "showCanvasBorder": "0",
                "showXAxisLine": "1",
                "xAxisLineThickness": "1",
                "xAxisLineColor": "#999999",
                "canvasBgColor" : "#ffffff",
                "divlineAlpha" : "100",
                "divlineColor" : "#999999",
                "divlineThickness" : "1",
                "divLineIsDashed" : "1",
                "divLineDashLen" : "1",
                "divLineGapLen" : "1",
                "legendBorderAlpha": "0",
                "legendShadow": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5"
            },
            
            "categories": [
                {
                    "category": 
                                <?php echo json_encode($jsonEncodedData[0]);?>
                    
                }
            ],
            "dataset": [
                {
                    "seriesname": "ND",
                    "data": 
                                <?php echo json_encode($jsonEncodedData[1]);?> 
                    
                }, 
               
            ]
        }
    }).render();*/
  
}); 
</script>

<div class="row">
    <div class="col-md-12">
        <div class="box box-info">
            <div class="box-header">
                <i class="fa fa-dashboard"></i>
                <h3 class="box-title">Welcome</h3>  
            </div>

            <div class="box-body">
                <div class="col-xs-12 connectedSortable">
                    <h3>Hello <span class="text-green">Super Admin</span>, welcome to Zeevant</h3>
                </div>
                
                    <!-- chart container starts-->
                    <!-- <div id="chartContainer">FusionCharts XT will load here!</div> -->
                   
                    <!-- <div id="chartlineContainer">FusionCharts XT will load here!</div> -->
                    <!-- chart container ends-->
                
            </div> 
            
            
               
        </div>
        <!-- content ends -->
    </div>
</div>

@endsection