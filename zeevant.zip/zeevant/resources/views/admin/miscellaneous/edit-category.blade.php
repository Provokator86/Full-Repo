@extends('layouts.admin.admin-layout')

@section('page-specific-css')
    <!-- jquery-color-picker -->
    {!! Html::style('admin-resources/dist/js/colorpicker/css/colorpicker.css') !!}
    <!-- jquery-selectize -->
    {!! Html::style('admin-resources/dist/js/selectize/css/selectize.css') !!}
    {!! Html::style('admin-resources/dist/js/selectize/css/selectize.bootstrap3.css') !!}
@endsection

@section('breadcrumb')
	{!! Breadcrumbs::render('manage-categories') !!}
@stop

@section('content')
	<div class="row">			
		<div class="col-md-12">
			<div class="box box-info">    
				<div class="box-header">
					<i class="fa fa-edit"></i>
					<h3 class="box-title">Edit Screen</h3>
				</div><!-- /.box-header -->

					   
					<form role="form" id="frmEditCategory" action="" method="post" onsubmit="return edit_category_AJAX()">
						<div class="box-body">   
						
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label id="product_group_lbl" for="product_group">POS Category</label>
                                        
                                        {{--*/ $SELECT_FLDS_ARR = array('i_id', 'product_group') /*--}}
                                        {{--*/ $WHERE_COND = " `subgroup` IS NULL " /*--}}
                                        {{--*/ $SELECTED_COND = ($category_info->product_group)?$category_info->product_group:'' /*--}}
                                        <select class="form-control" id="product_group" name="product_group">
                                            <option value="">-- Select POS Category --</option>
                                            {!! \App\Helpers\optionHelper::makeOptionCategory($SELECT_FLDS_ARR, $WHERE_COND, $SELECTED_COND) !!}  
                                        </select>
                                        
                                        <span class="text-danger"></span>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label id="subgroup_lbl" for="subgroup">POS Sub-Category</label>
                                        <input type="text" class="form-control" name="subgroup" id="subgroup" placeholder="POS Sub-Category" value="{{ ($category_info->subgroup)? $category_info->subgroup: '' }}" />
                                        <span class="text-danger"></span>
                                    </div>
                                </div> 
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label id="product_group_new_lbl" for="product_group_new">Zeevant Category</label>
                                        
                                        {{--*/ $SELECT_FLDS_ARR = array('i_id', 'product_group_new') /*--}}
                                        {{--*/ $WHERE_COND = " `subgroup` IS NULL " /*--}}
                                        {{--*/ $SELECTED_COND = ($category_info->product_group_new)?$category_info->product_group_new:'' /*--}}
                                        <select class="form-control" id="product_group_new" name="product_group_new">
                                            <option value="">-- Select Zeevant Category --</option>
                                            {!! \App\Helpers\optionHelper::makeOptionCategory($SELECT_FLDS_ARR, $WHERE_COND, $SELECTED_COND) !!}  
                                        </select>
                                        
                                        <span class="text-danger"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label id="subgroup_new_lbl" for="subgroup_new">Zeevant Sub-Category</label>
                                        
                                        <div id="div_zeevant_sub_cat">
                                            {{--*/ $SELECT_FLDS_ARR = array('i_id', 'subgroup_new') /*--}}
                                            {{--*/ $ZEEVANT_SUBCATEGORY_NAME = $category_info->product_group_new /*--}}
                                            {{--*/ $WHERE_COND = " `product_group_new`='$ZEEVANT_SUBCATEGORY_NAME' " /*--}}
                                            {{--*/ $SELECTED_COND = ($category_info->subgroup_new)?$category_info->subgroup_new:'' /*--}}
                                            <select class="form-control" id="subgroup_new" name="subgroup_new">
                                                <option value="">-- Select Zeevant Sub-Category --</option>
                                                {!! \App\Helpers\optionHelper::makeOptionCategory($SELECT_FLDS_ARR, $WHERE_COND, $SELECTED_COND) !!}  
                                            </select>
                                        </div>
                                        
                                        <span class="text-danger"></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                            
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label id="i_franchisor_id_lbl" for="i_franchisor_id">Franchisors</label>
                                        <select class="form-control" id="i_franchisor_id" name="i_franchisor_id">
                                            <option value="">-- Select Franchisors --</option>
                                            {!! \App\Helpers\optionHelper::makeOptionFranchisors('', $category_info->i_franchisor_id) !!}  
                                        </select>
                                        
                                        <span class="text-danger"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    {{--*/ $COLOR_CODE = ($category_info->color_code)?$category_info->color_code:'' /*--}}
                                    <div class="col-md-10">
                                        <div class="form-group">
                                            <label id="color_code_lbl" for="color_code">Color-Code</label>
                                            <input type="text" class="form-control" name="color_code" id="color_code" placeholder="Color-Code" value="{{ $COLOR_CODE }}" />
                                            <span class="text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>&nbsp;</label>
                                            <div id="customWidget">
                                                <div id="colorSelector2"><div style="background-color: {{ $COLOR_CODE }}"></div></div>
                                                <div id="colorpickerHolder2"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                                                                              
                            </div>                         
                            
						</div>

						<div class="box-footer">
							<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save Changes">
							<button type="button" class="btn btn-primary btn-danger" id="cancelbttn">Cancel</button>
                            <input type="hidden" class="form-control" id="category_id" name="category_id" value="{{ $category_info->i_id }}" />
							<input type="hidden" class="form-control" id="category_name" name="category_name" value="{{ $category_info->product_group }}" />
						</div>
					</form>
			
			</div>
		</div>
	</div>
@endsection

@section('page-specific-scripts')
    <!-- jquery-color-picker -->
    {!! Html::script('admin-resources/dist/js/colorpicker/js/colorpicker.js') !!}
    <!-- jquery-selectize -->
    {!! Html::script('admin-resources/dist/js/selectize/js/selectize.js') !!}
	{!! Html::script('admin-resources/plugins/input-mask/jquery.inputmask.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/miscellaneous/edit-category.js') !!}
@stop