@extends('layouts.admin.admin-layout')

@section('breadcrumb')
	{!! Breadcrumbs::render('manage-usr-types') !!}
@stop

@section('content')
	<div class="row">			
		<div class="col-md-12">
			<div class="box box-info">    
				<div class="box-header">
					<i class="fa fa-edit"></i>
					<h3 class="box-title">Create New</h3>
				</div><!-- /.box-header -->

					   
					<form role="form" id="frmAddUserType" action="" method="post" onsubmit="return add_user_type_AJAX()">
						<div class="box-body">   
						
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label id="s_user_type_lbl" for="s_user_type">User Type</label>
										<input type="text" class="form-control" name="s_user_type" id="s_user_type" placeholder="User Type" value="">
										<span class="text-danger"></span>
									</div>
								</div>                                       
							</div>                         
							
						</div>

						<div class="box-footer">
							<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save Changes">
							<button type="button" class="btn btn-primary btn-danger" id="cancelbttn">Cancel</button>
						</div>
					</form>
			
			</div>
		</div>
	</div>
@endsection

@section('page-specific-scripts')
	{!! Html::script('admin-resources/plugins/input-mask/jquery.inputmask.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/users/add-user-type.js') !!}
@stop