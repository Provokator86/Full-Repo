@extends('layouts.admin.admin-layout')

@section('breadcrumb')
	{!! Breadcrumbs::render('manage-companies') !!}
@stop

@section('content')
	<div class="row">			
		<div class="col-md-12">
			<div class="box box-info">    
				<div class="box-header">
					<i class="fa fa-edit"></i>
					<h3 class="box-title">Edit Screen</h3>
				</div><!-- /.box-header -->

					   
					<form role="form" id="frmEditCompany" action="" method="post" onsubmit="return edit_company_AJAX()">
						<div class="box-body">   
						
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_company_name_lbl" for="s_company_name">Company Name</label>
										<input type="text" class="form-control" name="s_company_name" id="s_company_name" placeholder="Company Name" value="{{ $company_info->s_company_name }}">
										<span class="text-danger"></span>
									</div>
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="s_email_lbl" for="s_email">Company Email</label>
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
											<input type="email" class="form-control" id="s_email" name="s_email" placeholder="Company Email" value="{{ $company_info->s_email }}">
											<span class="text-danger"></span>
										</div>
									</div> 
								</div>
							</div>                         
							
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_phone_lbl" for="s_phone">Company Phone-Number</label>
										<div class="input-group">
											<div class="input-group-addon">
												<i class="fa fa-phone"></i>
											</div>
											<input type="text" class="form-control" id="s_phone" name="s_phone" placeholder="Company Phone" class="form-control" value="{{ $company_info->s_phone }}" data-inputmask='"mask": "(999) 999-9999"' data-mask>
											<span class="text-danger"></span>
										</div>
									</div>
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="i_no_employees_lbl" for="i_no_employees">Number of Employee(s)</label>
										<input type="text" class="form-control" id="i_no_employees" name="i_no_employees" placeholder="Number of Employee(s)" value="{{ $company_info->i_no_employees }}">
										<span class="text-danger"></span>
									</div> 
								</div>
							</div>                         
						
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="i_corporate_users_lbl" for="i_corporate_users">Number of Corporate User(s)</label>
										<input type="text" class="form-control" id="i_corporate_users" name="i_corporate_users" placeholder="Number of Corporate User(s)" value="{{ $company_info->i_corporate_users or '' }}" />
										<span class="text-danger"></span>
									</div> 
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="i_field_executives_lbl" for="i_field_executives">Number of Field Executive(s)</label>
										<input type="text" class="form-control" id="i_field_executives" name="i_field_executives" placeholder="Number of Field Executive(s)" value="{{ $company_info->i_field_executives or '' }}" />
										<span class="text-danger"></span>
									</div> 
								</div>
							</div>                         
						
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="i_no_stores_lbl" for="i_no_stores">Number of Store(s) *</label>
										<input type="text" class="form-control" id="i_no_stores" name="i_no_stores" placeholder="Number of Store(s)" value="{{ $company_info->i_no_stores }}" />
										<span class="text-danger"></span>
									</div> 
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="s_address_1_lbl" for="s_address_1">Address 1 *</label>
										<input type="text" class="form-control" id="s_address_1" name="s_address_1" placeholder="Address 1" value="{{ $company_info->s_address_1 }}" />
										<span class="text-danger"></span>
									</div> 
								</div>
							</div>                         

							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_address_2_lbl" for="s_address_2">Address 2</label>
										<input type="text" class="form-control" id="s_address_2" name="s_address_2" placeholder="Address 2" value="{{ $company_info->s_address_2 }}" />
										<span class="text-danger"></span>
									</div> 
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="s_city_lbl" for="s_city">City *</label>
										<input type="text" class="form-control" id="s_city" name="s_city" placeholder="City" value="{{ $company_info->s_city }}" />
										<span class="text-danger"></span>
									</div> 
								</div>
							</div>                         
							
							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_state_lbl" for="s_state">State *</label>
										<select class="form-control" id="s_state" name="s_state">
											<option value="">-- Select State --</option>
											{!! \App\Helpers\optionHelper::makeOptionState('', $company_info->s_state) !!}
										</select>
										<span class="text-danger"></span>
									</div> 
								</div>                                       
								<div class="col-md-5 col-md-offset-1">  
									<div class="form-group">
										<label id="s_zipcode_lbl" for="s_zipcode">Zipcode *</label>
										<input type="text" class="form-control" id="s_zipcode" name="s_zipcode" placeholder="Zipcode" value="{{ $company_info->s_zipcode }}" />
										<span class="text-danger"></span>
									</div> 
								</div>
							</div>                         

							<div class="row">
								<div class="col-md-5">
									<div class="form-group">
										<label id="s_authorized_person_lbl" for="s_authorized_person">Authorized Person</label>
										<input type="text" class="form-control" id="s_authorized_person" name="s_authorized_person" placeholder="Authorized Person" value="{{ $company_info->s_authorized_person }}" />
										<span class="text-danger"></span>
									</div> 
								</div>                                       
							</div>
							

						</div>

						<div class="box-footer">
							<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save Changes">
							<button type="button" class="btn btn-primary btn-danger" id="cancelbttn">Cancel</button>
							<input type="hidden" class="form-control" id="company_id" name="company_id" value="{{ $company_info->i_id }}" />
						</div>
					</form>
			
			</div>
		</div>
	</div>
@endsection

@section('page-specific-scripts')
	{!! Html::script('admin-resources/plugins/input-mask/jquery.inputmask.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/users/edit-company.js') !!}
@stop