@extends('layouts.admin.admin-layout')
 
@section('page-specific-css')
    <!-- DataTables -->
	{!! Html::style('admin-resources/plugins/datatables/dataTables.bootstrap.css') !!}
    <!-- jquery-confirm -->
	{!! Html::style('admin-resources/dist/js/jquery-confirm/jquery.confirm.css') !!}
	{!! Html::style('http://fonts.googleapis.com/css?family=Cuprum&subset=latin') !!}
@endsection

@section('breadcrumb')
	{!! Breadcrumbs::render('manage-usr-types') !!}
@stop

@section('content')
<div class="row">
	<div class="col-xs-12">
	  <div class="box">
		<div class="box-header">
		  <h3 class="box-title">User Type(s)</h3>
		  <div class="align-right">
			  <a class="btn btn-block btn-social btn-bitbucket" href="{{ urlHelper::admin_base_url() }}add-user-type">
				  <i class="fa fa-plus-square-o"></i>
				  Add Record
			  </a>
		  </div>
		</div><!-- /.box-header -->
		<div class="box-body">
		  <div id="div_no_of_jobs_list" class="dataTables_wrapper form-inline" role="grid">
			  @include('admin.users.ajax-parts.usertype-listing-ajax')
		  </div>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->

	</div><!-- /.col -->
</div><!-- /.row -->
@endsection

@section('page-specific-scripts')
	<!-- DataTables -->
	{!! Html::script('admin-resources/plugins/datatables/jquery.dataTables.min.js') !!}
	{!! Html::script('admin-resources/plugins/datatables/dataTables.bootstrap.min.js') !!}
    <!-- jquery-confirm -->
	{!! Html::script('admin-resources/dist/js/jquery-confirm/jquery.confirm.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/users/manage-user-types.js') !!}
@stop