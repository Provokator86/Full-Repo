@extends('layouts.admin.admin-layout')
 
@section('page-specific-css')
    <!-- DataTables -->
	{!! Html::style('admin-resources/plugins/datatables/dataTables.bootstrap.css') !!}
    <!-- jquery-confirm -->
	{!! Html::style('admin-resources/dist/js/jquery-confirm/jquery.confirm.css') !!}
	{!! Html::style('http://fonts.googleapis.com/css?family=Cuprum&subset=latin') !!}
@endsection

@section('breadcrumb')
	{{-- Breadcrumbs::render('manage-usr-types') --}}
@stop

@section('content')
	<div class="row">
        <div class="col-md-12">
            <div class="box box-info">
                <div class="box-header">
                    <i class="fa fa-unlock-alt"></i>
                    <h3 class="box-title">Manage Access Control(s) {{ config('custom.test.test') }}</h3>
                    <a class="btn btn-sm btn-warning pull-right" id="back" href="javascript:;" style="margin-left: 10px;">Back</a>
                    <a class="btn btn-sm btn-success pull-right" id="save" href="javascript:;">Save</a>
                </div>
            
                <?php 
                if(!empty($menu_action))
                {
                    foreach($menu_action as $key => $val)
                    {
                        if($val['first_label_id'] != 8 && $val['first_label_id'] != 11)
                            $menu[$val['first_label_id']][] = $val;
                    }
                ?>
                <form action="" method="post" name="frm_actions" id="frm_actions" role="form">
                <input type="hidden" name="user_type_id" value="<?php echo encrypt($user_type_id)?>">
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover table-bordered">
                        <tbody>
                            <tr>
                                <th>Menu List</th>
                                <?php 
                                    for($i = 0; $i <count($action_list); $i++)
                                        echo '<th class="center">'.$action_list[$i].'</th>';
                                ?>
                            </tr>
                            <?php 
                            foreach($menu as $key => $val)
                            {
                                echo '<tr>
                                            <td colspan="'.(count($action_list)+1).'">
                                                <span class="text-orange">'.$val[0]['first_label_menu'].'</span>
                                                <input type="hidden" name="h_first_label_menu_id[]" value="'.$val[0]['first_label_id'].'">
                                                <input type="hidden" name="access_type" value="'.$user_info[0]["e_access_type"].'">
                                            </td>
                                        </tr>';
                                for($i = 0; $i < count($val); $i++)
                                {
                                    echo '<tr>
                                            <th><span class="light-font">'.$val[$i]['second_label_menu'].'</span>
                                                <input type="hidden" name="first_label_menu_id['.$val[$i]['second_label_id'].'][]" value="'.$val[0]['first_label_id'].'" />
                                                <input type="hidden" value="'.$val[$i]['second_label_id'].'" name="h_action_permit[]">
                                            </th>';
                                    for($j = 0; $j <count($action_list); $j++)
                                    {
                                        $selected_action = explode('##', $val[$i]['actions']);
                                        $checked = in_array($action_list[$j], $selected_action) ? 'checked="checked"' : '';
                                        
                                        $arr_action = explode('||',$val[$i]['s_action_permit']);
                                        //$disabled = in_array($action_list[$j], $arr_action) ? '' : 'disabled="disabled"';
                                        if(in_array($action_list[$j], $arr_action))
                                                                                {
                                            echo '<th class="center" title="'.$action_list[$j].'">
                                                    <input  type="checkbox" id="select_'.$val[$i]['first_label_id'].'_'.$val[$i]['second_label_id'].'" name="opt_actions['.$val[$i]['second_label_id'].'][]" value="'.$action_list[$j].'" '.$checked.'>
                                                  </th>';
                                        }
                                        else
                                        {
                                            echo '<th class="center">&nbsp;</th>';
                                        }
                                    }
                                    echo '</tr>';
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
		        <div class="box-footer">
                    <a class="btn btn-sm btn-success pull-left" id="save2" href="javascript:;" style="margin-right: 10px;">Save</a>
                    <a class="btn btn-sm btn-warning pull-left" id="back2" href="javascript:;" >Back</a>
                    
                </div>
                </form>
                <?php 
                }
                ?>
            </div>
        </div>
    </div><!-- row ends -->
@endsection

@section('page-specific-scripts')
	<!-- DataTables -->
	{!! Html::script('admin-resources/plugins/datatables/jquery.dataTables.min.js') !!}
	{!! Html::script('admin-resources/plugins/datatables/dataTables.bootstrap.min.js') !!}
    <!-- jquery-confirm -->
	{!! Html::script('admin-resources/dist/js/jquery-confirm/jquery.confirm.js') !!}
	{!! Html::script('admin-resources/dist/js/custom-scripts/users/manage-user-types.js') !!}
@stop