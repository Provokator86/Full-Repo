<!-- Stored in resources/views/layouts/child.blade.php -->

@extends('layouts.master')

@section('title', 'Page Title')

@section('sidebar')
    @parent

    <p>This is appended to the master sidebar.</p>
@endsection

@section('content')
    <p>This is my body content.</p>
    
    <?php //echo $user; 
    
    test();
    
    //var_dump($user);
    
    /*foreach ($user as $user) {
    echo $user->name;
    }*/    
    ?>
    <?php
    /*if(count($user) > 0):
    ?>
    
    <?php foreach ($user as $ind=>$val): ?>
        <?php echo $val->user_name; ?>
    <?php endforeach; ?>
    
    <?php echo $user->render(); ?>
    
    <?php endif;*/?>
    <a href="{{ url('user/add') }}">Add</a>
    
    @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
    @endif
    
    @if (count($user) > 0)
    <div class="alert">
             <ul>
                <li>ID</li>
                <li>USER NAME</li>
                <li>IMAGE</li>
                <li>STATE</li>
                <li>ACTIION</li>
             </ul>
                
            @foreach ($user->all() as $usr)
            <ul>
                <li>{{ $usr->id }}</li>
                <li>{{ $usr->user_name }}</li>
                <li>@if( $usr->user_image != '')  <img src="{{ url() }}/img/{{ $usr->user_image }}" width="100" height="100"> @else {{ 'No Image'}} @endif</li>
                <li>@if( $usr->state_name != '') {{ $usr->state_name }}  @else {{ 'No State'}} @endif</li>
                <li><a href="{{ url('user/edit')}}/{{ $usr->id }}">Edit</a> | <a href="{{ url('user/del')}}/{{ $usr->id }}" onclick="javascript:return confirm('Are you sure?');">Delete</a></li>
            </ul>
            @endforeach
        
        
        {!! $user->render() !!}
    </div>
    @endif
    
    
    

@endsection