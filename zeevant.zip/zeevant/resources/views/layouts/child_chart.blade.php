<!-- Stored in resources/views/layouts/child.blade.php -->

@extends('layouts.master')

@section('title', 'Page Title')


@section('sidebar')
    @parent

    <p>This is appended to the master sidebar.</p>
@endsection

@section('content')
    <p>This is my body content.</p>
    

    
<script type="text/javascript">
    
FusionCharts.ready(function(){
   
      var revenueChart = new FusionCharts({
      type: "pie3d",
      renderAt: "chartContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
       "chart": {
          "caption": "Monthly revenue for last year",
          "subCaption": "Harry's SuperMart",
          "captionFontSize":"14",
          "subcaptionFontSize":"14",
          "subcaptionFontBold":"0",
          "xAxisName": "Month",
          "yAxisName": "Revenues (In USD)",
          "theme": "zune",
          "toolTipColor":"#ffffff",
          "toolTipBorderThickness":"0",
          "toolTipBgColor":"#000000",
          "toolTipBgAlpha":"80",
          "toolTipBorderRadius":"2",
          "toolTipPadding":"5",
          "showHoverEffect":"1",
          "showLegend":"1",
          "legendBgColor":"#ffffff",
          "legendBorderAlpha":"0",
          "legendShadow":"0",
          "legendItemFontSize":"10",
          "legendItemFontColor":"#666666",
          "useDataPlotColorForLabels":"1"
       },
       "data":<?php echo html_entity_decode($data);?>,
       
      }
 
  });
  revenueChart.render("chartContainer");
/*}); 



FusionCharts.ready(function(){
      var revenueChart = new FusionCharts({
      type: "bar2d",
      renderAt: "chartContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
      "chart": {
        "caption": "Top 10 Most Popular Sports in the World",
        "subcaption": "Based on number of viewers",
        "yaxisname": "Number of Viewers",
        "plotgradientcolor": "",
        "bgcolor": "FFFFFF",
        "showplotborder": "0",
        "divlinecolor": "CCCCCC",
        "showvalues": "1",
        "showcanvasborder": "0",
        "canvasbordercolor": "CCCCCC",
        "canvasborderthickness": "1",
        "showyaxisvalues": "0",
        "showlegend": "1",
        "showshadow": "0",
        "labelsepchar": ": ",
        "basefontcolor": "000000",
        "labeldisplay": "AUTO",
        "numberscalevalue": "1000,1000,1000",
        "numberscaleunit": "K,M,B",
        "palettecolors": "#008ee4,#9b59b6,#6baa01,#e44a00,#f8bd19,#d35400,#bdc3c7,#95a5a6,#34495e,#1abc9c",
        "showborder": "0"
    },
    "data": [
        {
            "label": "Football",
            "value": "3500000000",
            "tooltext": "Popular in: {br}Europe{br}Africa{br}Asia{br}Americas"
        },
        {
            "label": "Cricket",
            "value": "3000000000",
            "tooltext": "Popular in: {br}India{br}UK{br}Pakistan{br}Australia"
        },
        {
            "label": "Field Hockey",
            "value": "2200000000",
            "tooltext": "Popular in: {br}Asia{br}Europe{br}Africa{br}Australia"
        },
        {
            "label": "Tennis",
            "value": "1000000000",
            "color": "e44a00",
            "tooltext": "Popular in: {br}Europe{br}Americas{br}Asia"
        },
        {
            "label": "Volleyball",
            "value": "900000000",
            "tooltext": "Popular in: {br}Asia{br}Europe{br}Americas{br}Australia"
        },
        {
            "label": "Table Tennis",
            "value": "900000000",
            "tooltext": "Popular in: {br}Asia{br}Europe{br}Africa{br}Americas"
        },
        {
            "label": "Baseball",
            "value": "500000000",
            "tooltext": "Popular in: {br}US{br}Japan{br}Cuba{br}Dominican Republic"
        },
        {
            "label": "Golf",
            "value": "400000000",
            "tooltext": "Popular in: {br}US{br}Canada{br}Europe"
        },
        {
            "label": "Basketball",
            "value": "400000000",
            "tooltext": "Popular in: {br}US{br}Canada"
        },
        {
            "label": "American football",
            "value": "390000000",
            "tooltext": "Popular in:{br}US"
        }
    ]
});
  revenueChart.render("chartContainer");
}); */


var revenuebarChart = new FusionCharts({
      type: "bar2d",
      renderAt: "chartbarContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
       "chart": {
        "caption": "Top 5 Sellers - Revenue",
        //"subcaption": "U.S Bureau of Labor (Survey 2013)",
        "canvasborderthickness": "1",
        "canvasbordercolor": "CDCDCD",
        "xaxisname": "Visitaion",
        "numbersuffix": "%",
        "showvalues": "1",
        "plotgradientcolor": "",
        "plotborderalpha": "0",
        "alternatevgridalpha": "0",
        "divlinealpha": "0",
        "canvasborderalpha": "0",
        "bgcolor": "#FFFFFF",
        "basefontsize": "12",
        "basefontcolor": "#194920",
        "palettecolors": "#3A803D",
        "showyaxisvalues": "0",
        "showborder": "0"
    },
    "data": [
        {
            "label": "Product A",
            "value": "12.00"
        },
        {
            "label": "Product B",
            "value": "10.12"
        },
        {
            "label": "Product C",
            "value": "8.29"
        },
        {
            "label": "Product D",
            "value": "3.29"
        },
        {
            "label": "Product E",
            "value": "2.29"
        }        
        ]
       
      }
 
  });
  revenuebarChart.render("chartbarContainer");
  
  
  var revenuestepChart = new FusionCharts({
      type: "msstepline",
      renderAt: "chartstepContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
      
      "chart": {
        "caption": "Time Of Day",
        "xAxisName": "Time Of Day In Hours",
        "showYAxisValues":'0',
        "showXAxisValues":'0',
        //"yaxisname": "Sales",
        "showvalues": "0",
        "showalternatevgridcolor": "1",
        "bgalpha": "45",
        "bgcolor": "DFDFDF",
        "numdivlines": "4",
        "showalternatehgridcolor": "1",
        "outcnvbasefont": "Verdana",
        "outcnvbasefontsize": "12",
        "canvasborderthickness": "1",
        "canvasbordercolor": "CDCDCD",
        "anchorradius": "4",
        "anchorsides": "16",
        "anchorbgcolor": "FFFFFF",
        "anchorbordercolor": "6F6F6F",
        "alternatevgridalpha": "10",
        "alternatehgridcolor": "FAE4E9",
        "alternatehgridalpha": "40",
        "alternatevgridcolor": "CFCFCF",
        "linethickness": "2",
        "anchorborderthickness": "2",
        "linedashgap": "5",
        "divlinealpha": "5",
        "canvasborderalpha": "60",
        "outcnvbasefontcolor": "43302E",
        "legendbordercolor": "6C1121",
        "legendborderalpha": "40",
        "legendborderthickness": "2",
        "bordercolor": "CDCDCD",
        "borderalpha": "70",
        "showborder": "0"
    },
    "categories": [
        {
            "category": [
                {
                    "label": "06 am",                   
                },
                {
                    "label": "07 am"
                },
                {
                    "label": "08 am"
                },
                {
                    "label": "09 am"
                },
                {
                    "label": "10 am"
                },
                {
                    "label": "11 am"
                },
                {
                    "label": "12 am"
                },
                {
                    "label": "13 pm"
                },
                {
                    "label": "14 pm"
                },
                {
                    "label": "15 pm"
                },
                {
                    "label": "16 pm"
                },
                {
                    "label": "17 pm"
                },
                {
                    "label": "18 pm"
                },
                {
                    "label": "19 pm"
                },
                {
                    "label": "20 pm"
                }
            ]
        }
    ],
    "dataset": [
        {
            "seriesname": "Hourly Revenue",
            "anchorbordercolor": "B50F27",
            "color": "BB2644",
            "data": [
                {
                    "value": "22000"
                },
                
                {
                    "value": "28000"
                },
                {
                    "value": "21000"
                },
                {
                    "value": "26000"
                },
                {
                    "value": "20000"
                },
                {
                    "value": "25000"
                },
                {
                    "value": "27000"
                },
                {
                    "value": "32000"
                },
                {
                    "value": "24000"
                },
                {
                    "value": "29000"
                },
                {
                    "value": "31000"
                },
                {
                    "value": "30000"
                },
                {
                    "value": "33000"
                },
                {
                    "value": "23000"
                },
                {
                    "value": "34000"
                }
            ]
        },
        {
            "seriesname": "Employees Checked In",
            "color": "515151",
            "data": [
                {
                    "value": "12000"
                },
                
                {
                    "value": "18000"
                },
                {
                    "value": "11000"
                },
                {
                    "value": "16000"
                },
                {
                    "value": "10000"
                },
                {
                    "value": "15000"
                },
                {
                    "value": "17000"
                },
                {
                    "value": "22000"
                },
                {
                    "value": "14000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "21000"
                },
                {
                    "value": "20000"
                },
                {
                    "value": "23000"
                },
                {
                    "value": "13000"
                },
                {
                    "value": "24000"
                }
            ]
        }
    ]
       
      }
 
  });
  revenuestepChart.render("chartstepContainer");
  
  var revenuecolumnChart = new FusionCharts({
      type: "column2D",
      renderAt: "chartcolumnContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
      
     "chart": {
        "caption": "Ticket",
        //"subcaption": "23/12/2013 - 29/12/2013",
        "yaxisname": " ",
        "xAxisName": " ",
        "yaxismaxvalue": "10",
        "showvalues": "0",
        "showXAxisValues":'1',
        "labelDisplay": "none",
        "canvasbgalpha": "0",
        "bgalpha": "0",
        "plotborderalpha": "0",
        "showborder": "0",
        "showalternatehgridcolor": "0",
        "plotgradientcolor": "",
        "showplotborder": "0",
        "numdivlines": "5",
        "showyaxisvalues": "0",
        "palettecolors": "#1790E1 ",
        "canvasborderthickness": "1",
        "canvasbordercolor": "#074868",
        "canvasborderalpha": "30",
        "basefontcolor": "#074868",
        "divlinecolor": "#074868",
        "divlinealpha": "10",
        "tooltipborderalpha": "0"
    },
    "data": [
        {
            "label": "Mon",
            "value": "2"
        },
        {
            "label": "Tue",
            "value": "4"
        },
        {
            "label": "Wed",
            "value": "6"
        },
        {
            "label": "Thu",
            "value": "7"
        },
        {
            "label": "Fri",
            "value": "6"
        },
        {
            "label": "Sat",
            "value": "4"
        },
        {
            "label": "Sun",
            "value": "3"
        }
    ],
    "trendlines": [
        {
            "line": [
                {
                    "startvalue": "7",
                    "endvalue": "",
                    "istrendzone": "",
                    "valueonright": "1",
                    "color": "fda813",
                    "displayvalue": " ",
                    "showontop": "1",
                    "thickness": "2"
                },
                {
                    "startvalue": "8",
                    "endvalue": "",
                    "istrendzone": "",
                    "valueonright": "1",
                    "color": "f77027",
                    "displayvalue": " ",
                    "showontop": "1",
                    "thickness": "2"
                }
            ]
        }
    ]
       
      }
 
  });
  revenuecolumnChart.render("chartcolumnContainer");
  
  
  var revenuelineChart = new FusionCharts({
      type: "msline",
      renderAt: "chartlineContainer",
      width: "500",
      height: "300",
      dataFormat: "json",
      dataSource: {
    "chart": {
        "caption": "Weather Report",
        "subcaption": "Temperature",
        "xaxisname": "Month",
        "yaxisname": "Degree  (in Fahrenheit)",
        "palette": "3",
        "bgcolor": "FFFFFF",
        "canvasbgcolor": "66D6FF",
        "canvasbgalpha": "5",
        "canvasborderthickness": "1",
        "canvasborderalpha": "20",
        "legendshadow": "0",
        "numbersuffix": "�",
        "showvalues": "0",
        "alternatehgridcolor": "ffffff",
        "alternatehgridalpha": "100",
        "showborder": "0",
        "legendborderalpha": "0",
        "legendiconscale": "1.5",
        "drawAnchors":"0", 
        "divlineisdashed": "1"
    },
    "categories": [
        {
            "category": [
                {
                    "label": "Jan"
                },
                {
                    "label": "Feb"
                },
                {
                    "label": "Mar"
                },
                {
                    "label": "Apr"
                },
                {
                    "label": "May"
                },
                {
                    "label": "Jun"
                },
                {
                    "label": "Jul"
                },
                {
                    "label": "Aug"
                },
                {
                    "label": "Sep"
                },
                {
                    "label": "Oct"
                },
                {
                    "label": "Nov"
                },
                {
                    "label": "Dec"
                }
            ]
        }
    ],
    "dataset": [
        {
            "seriesname": "New York",
            "color": "F97D10",
            "data": [
                {
                    "value": "-6"
                },
                {
                    "value": "-15"
                },
                {
                    "value": "3"
                },
                {
                    "value": "12"
                },
                {
                    "value": "32"
                },
                {
                    "value": "44"
                },
                {
                    "value": "52"
                },
                {
                    "value": "50"
                },
                {
                    "value": "39"
                },
                {
                    "value": "28"
                },
                {
                    "value": "5"
                },
                {
                    "value": "-13"
                }
            ]
        },
        {
            "seriesname": "Chicago",
            "data": [
                {
                    "value": "-27"
                },
                {
                    "value": "-19"
                },
                {
                    "value": "-8"
                },
                {
                    "value": "7"
                },
                {
                    "value": "24"
                },
                {
                    "value": "36"
                },
                {
                    "value": "40"
                },
                {
                    "value": "41"
                },
                {
                    "value": "28"
                },
                {
                    "value": "17"
                },
                {
                    "value": "1"
                },
                {
                    "value": "-25"
                }
            ]
        },
        {
            "seriesname": "Bismarck",
            "color": "3994F9",
            "data": [
                {
                    "value": "-44"
                },
                {
                    "value": "-43"
                },
                {
                    "value": "-31"
                },
                {
                    "value": "-12"
                },
                {
                    "value": "15"
                },
                {
                    "value": "30"
                },
                {
                    "value": "35"
                },
                {
                    "value": "33"
                },
                {
                    "value": "11"
                },
                {
                    "value": "-10"
                },
                {
                    "value": "-30"
                },
                {
                    "value": "-43"
                }
            ]
        }
    ],
    "styles": {
        "definition": [
            {
                "name": "captionFont",
                "type": "font",
                "size": "15"
            }
        ],
        "application": [
            {
                "toobject": "caption",
                "styles": "captionfont"
            }
        ]
    }
} 
  });
  revenuelineChart.render("chartlineContainer");
 
}); 
</script>
    
    
    
    
    <div id="chartContainer">FusionCharts XT will load here!</div>
    <div id="chartbarContainer">FusionCharts XT will load here!</div>
    <div id="chartstepContainer">FusionCharts XT will load here!</div>
    <div id="chartcolumnContainer">FusionCharts XT will load here!</div>
    <div id="chartlineContainer">FusionCharts XT will load here!</div>
    
    
@endsection