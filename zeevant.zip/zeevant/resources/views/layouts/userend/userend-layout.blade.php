<!DOCTYPE html>
<html lang="en">
<head>
	@include('layouts.userend.partials.head-meta-section')
	
	@include('layouts.userend.partials.head-scripts-section')
</head>
<body>
	<section id="container">
		{{-- Header [Begin] --}}
			@include('layouts.userend.partials.header')
		{{-- Header [End] --}}
		
		{{-- Left Menu/SideBar [Begin] --}}
			@include('layouts.userend.partials.sidebar-menu')
		{{-- Left Menu/SideBar [End] --}}
		
		{{-- Page Content [Begin] --}}
			<section id="main-content">
				<section class="wrapper">
					@yield('content')
					
					@include('layouts.userend.partials.footer')
				</section>
			</section>
		{{-- Page Content [End] --}}
	</section>
	
	{{-- Footer META Section (if any) [Begin] --}}
		@include('layouts.userend.partials.footer-meta-section')
	{{-- Footer META Section (if any) [End] --}}
	
	
	{{-- Footer Scripts Section [Begin] --}}
		@include('layouts.userend.partials.footer-scripts-section')
		
		@yield('inline-footer-js')		
	{{-- Footer Scripts Section [End] --}}
</body>
</html>
