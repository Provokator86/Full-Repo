<!DOCTYPE html>
<html>
  <head>

	@include('layouts.admin.partials.head-meta-section')
	
	@include('layouts.admin.partials.head-scripts-section')
	
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

	  @include('layouts.admin.partials.header')
	  
	  @if( \Session::get('loggedin') )
		@include('layouts.admin.partials.sidebar')
	  @endif	
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>
				{{ $page_header_BIG or '' }}
				<small>{{ $page_header_SMALL or '' }}</small>
			</h1>
			@yield('breadcrumb')
		</section>

		<section class="content">
			@yield('content')
		</section>
	  </div><!-- /.content-wrapper -->
      
	  
	  @include('layouts.admin.partials.footer')

	  {{-- @include('layouts.admin.partials.right-sidebar') --}}
	  
    </div><!-- ./wrapper -->

	@include('layouts.admin.partials.footer-scripts-section')
  </body>
</html>