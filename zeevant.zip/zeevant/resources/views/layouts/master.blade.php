<html>
    <head>
        <title>Zeevant - @yield('title')</title>
        
        <link rel="stylesheet" href="{{ URL::asset('resources/assets/css/style.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('resources/assets/css/bootstrap-simplex.css') }}">
        
        <link rel="stylesheet" href="{{ URL::asset('resources/assets/css/bootstrap-responsive.css') }}">

        <link rel="stylesheet" href="{{ URL::asset('resources/assets/css/shield.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('resources/assets/css/charisma-app.css') }}">
        
        <script language="javascript" type="text/javascript" src="{{ URL::asset('resources/assets/js/jquery-1.11.3.min.js') }}"></script>
        <script language="javascript" type="text/javascript" src="{{ URL::asset('resources/assets/js/fusioncharts.js') }}"></script>
        <script language="javascript" type="text/javascript" src="{{ URL::asset('resources/assets/js/fusioncharts.jqueryplugin.js') }}"></script>
        
        
        
       
               
    </head>
    <body>
    <!-- topbar starts -->
    <div class="navbar">
        <div class="navbar-inner">
            <div class="container-fluid">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                
                <a class="brand" href="{{ url() }}">
                    <img alt="zeevant" src="{{ URL::asset('resources/assets/img/logo.png') }}"/>
                </a>                
                
                 <!-- user dropdown starts -->
                <div class="btn-group pull-right" >
                    <a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="icon-user"></i><span class="hidden-phone">{{ trans('messages.user') }}</span>
                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="{{ url() }}/my_account/">{{ trans('messages.profile') }}</a></li>
                        <li class="divider"></li>
                        <li><a href="{{ url() }}/logout/">{{ trans('messages.logout') }}</a></li>
                        <?php //if(decrypt($admin_loggedin['user_type_id'])==0 && !SITE_FOR_LIVE){ ?>
                        <?php
                        /*<li class="divider"></li>
                        <li><a href="<?php echo admin_base_url().'menu_setting/show_list'; ?>"><?php echo  addslashes(custom_lang_display("Menu Setting"))?></a></li>
                        */?>
                        <?php //} ?>
                    </ul>
                </div>
                <!-- user dropdown ends -->
         </div>
        </div>
    </div>
    <!-- topbar ends -->
    
    
    <div class="container-fluid">
            <div class="row-fluid">

            <!-- left menu starts -->
            <div class="span2 main-menu-span">
                <div class="well nav-collapse sidebar-nav">
                    <ul class="nav nav-tabs nav-stacked main-menu">
                        
                        @section('sidebar')
                        
                        <?php //create_left_menus();
                       // {{ create_left_menus() }} ?>
                        
                        <?php /*This is the master sidebar.            
                        @include('layouts.test')*/?>  
                        @show 
                           
                    </ul>
                </div><!--/.well -->
            </div><!--/span-->
            <!-- left menu ends -->

            <noscript>
                <div class="alert alert-block span10">
                    <h4 class="alert-heading">Warning!</h4>
                    <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
                </div>
            </noscript>


            
            @yield('content')
            
        <hr>

        <footer>
            <p class="pull-left">&copy; <a href="http://www.zeevant.com" target="_blank">www.zeevant.com</a> <?php echo date('Y');?></p>
            <p class="pull-right">{{ trans('messages.powered_by') }}: <a href="http://shieldwatch.com/" target="blank">Shield Watch IT</a></p>
        </footer>

    </div>
        </div><!--/.fluid-container-->
        
      
        
        
    </body>
</html>