@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- Bootstrap Date-Picker -->
    {!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
	 <!--Start Cumulative-Revenue Part-->
     
		<!-- ************** Store(s) Selection [Begin] ************** -->
		<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel" id="select-store">
						<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
							<label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
							<select class="form-control pm" id="i_store" name="i_store" onchange="load_data_AJAX()">
								{!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
							</select>
						</div>
					</section>
				</div>
			</div>						
		<!-- ************** Store(s) Selection [End] ************** -->
	
		<div class="row">
			<!--Full Width Part Start-->
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				<div class="margin_btntwenty">
				  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="row">
					  <h1 class="bench_h1">Daily Scoop -  Time Of Day [Based on {{ $total_no_of_shops }} store(s) data]</h1>
					</div>
				  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                        <div class="col-md-4"></div>
                            <div class="col-md-2 icheck">
                                <div class="row right_fltmargin">
                                    <div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio" value="1" id="radio_day">
                                        <label>Day</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3 icheck">
                                <div class="row right_fltmargin">
                                    <div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio" value="2" id="radio_range" checked="checked">
                                        <label>Range</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3 icheck">
                                <div class="row right_fltmargin">
                                    <div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio" value="3" id="radio_special">
                                        <label>Special</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row"> 
                            
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topfive_margin">
                                    <div class="lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">{{ $prev_month_scroller_dt }}</span> <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a> <span id="text_to">to&nbsp;&nbsp;</span> <span id="lbl_to_dt" class="lbl_dt_marker_long">{{ $next_month_scroller_dt }}</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a> 
                                        <select class="form-control pm" id="select_special" style="display: none; width: auto; float:right; margin-bottom:5px;">
                                                <option value="1">All Sunday</option>
                                                <option value="2">All Monday</option>
                                                <option value="3">All Tuesday</option>
                                                <option value="4">All Wednesday</option>
                                                <option value="5">All Thursday</option>
                                                <option value="6">All Friday</option>
                                                <option value="7">All Saturday</option>
                                            </select>
                                            </div>
                                             </div>
                                
                                
                                                                
                                <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
                                        <input type="hidden" name="i_prev_date" id="i_prev_date" value="" />
                                        <input type="hidden" name="i_prev_month" id="i_prev_month" value="" />
                                        <input type="hidden" name="i_prev_year" id="i_prev_year" value="" />
                                        
                                        <input type="hidden" name="i_week_day" id="i_week_day" value="" />
                                        
                                        <input type="hidden" name="i_current_date" id="i_current_date" value="" />
                                        <input type="hidden" name="i_current_month" id="i_current_month" value="" />
                                        <input type="hidden" name="i_current_year" id="i_current_year" value="" />
                                        <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
                            
                        </div>
                    </div>
                </div>
            </div>
                                 
                
                <div id="DS_cumulative_marching_charts">                
               
				<div class="clearfix"></div>
				
				<div class="row twenty_margin">						  

                        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                            <section class="panel round_border">
                                <header class="panel-heading">Time Of Day<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                                <div class="panel-body">
                                <div id="hst_mp" loader-class="preloader_allR" class="img_brd" style="width: 100%; margin: 0 auto;">
                                    <div class="preloader_allR">&nbsp;</div>
                                <!-- <div class="daly_rev"> <img src="img/dally_rev.jpg"> </div> -->
                                </div>
                                
                                <div class="col-md-8">
                                <div class="col-md-3 col-md-offset-1"><span class="deep-blue-block"></span>Employee Clock In</div>
                                <div class="col-md-4"><span class="deep-red-block"></span>Hourly Revenue</div>                               
                                </div>
                                <div class="col-md-4">                                
                                </div>
                                
                                </div>
                                <!-- <div class="panel-body">
                                <div class="daly_rev"> <img src="{{ asset('userend-resources/img/dally_rev.jpg') }}"> </div>
                                </div> -->
                            </section>
                        </div>
				</div>
                
                <div class="clearfix"></div>
                
                <!--Table Section start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel plan_border">
            <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" onclick="hide(this)" class="fa fa-times"></a> </span> </header>
            <div class="panel-body">
              <section id="unseen_tebl">
              <?php 
              if(!empty($all_CR_table_data_arr)){
              ?>
              
             
              
                <table class="table table-bordered table-striped table-condensed">
                  <thead>
                    <tr>
                      <th>Time Of Day</th>
                      <th class="num">Total Revenue ($)</th>
                      <th class="num">Total Employee Clocked in</th>
                      <th class="num">Revenue /  Employee ($)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach($all_CR_table_data_arr as $ind=>$val){
                    ?>
                    <tr>
                      <td><p><?php echo $val->clock_in;?></p></td>
                      <td class="num"><p><?php echo $val->total_sales;?></p></td>
                      <td class="num"><p><?php echo $val->emp_clock_in;?></p></td>
                      <td class="num"><p><?php echo $val->rev_per_emp;?></p></td>
                    </tr>
                    <?php
                    }
                    ?>
                  </tbody>
                </table>
                <?php 
                }
                ?>
              </section>
              </div>
          </section>
        </div>
        <!--Table Section end-->
                </div>
			  </section>
			  <!--End Product Mix Top Part-->
			</div>
			<!--End Left Part-->

		
		</div>
	    <!--End Cumulative-Revenue Part-->
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
	{!! Html::script('https://www.google.com/jsapi') !!}
	{!! Html::script('userend-resources/js/charts/DS/timeofday/generate_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/DS/timeofday/revenue_charts.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/daily-scoop/daily_scoop_timeofday.js') !!}
@stop


@section('inline-footer-js')
<script type="text/javascript">
<!--
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - Begin
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		var all_CR_data = {!! $all_CR_data_arr !!};
       
		
	
		


		
		//// For  Chart(s) [Begin]
			drawMPChart(all_CR_data);
            
		//// For Chart(s) [End]
		
		
		
		
	
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - End
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
//-->
</script>
@stop
