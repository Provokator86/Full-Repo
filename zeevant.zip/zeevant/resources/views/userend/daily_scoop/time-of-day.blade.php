@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!--Start Time-of-Day Part-->
      <div class="row">
        <!--Full Width Part Start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
            <div class="margin_btntwenty">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                  <h1 class="bench_h1">Daily Scoop -  Time Of Day</h1>
                </div>
              </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    	<div class="row">
                        <div class="col-md-4"></div>
                        	<div class="col-md-2 icheck">
                            	<div class="row right_fltmargin">
                            		<div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio">
                                        <label>Day</label>
                                    </div>
                            	</div>
                                </div>
                        	</div>
                            <div class="col-md-3 icheck">
                            	<div class="row right_fltmargin">
                            		<div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio">
                                        <label>Range</label>
                                    </div>
                            	</div>
                                </div>
                        	</div>
                            <div class="col-md-3 icheck">
                            	<div class="row right_fltmargin">
                            		<div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio">
                                        <label>Special</label>
                                    </div>
                            	</div>
                                </div>
                        	</div>
                        </div>
                        
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    	<div class="row"> 
                            <form class="form-horizontal bucket-form" method="get">
                                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 topfive_margin">
                                    <div class="row lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">July 14 2015</span> <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a>to   <span id="lbl_to_dt" class="lbl_dt_marker_long">Aug 13 2015</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                    <div class="row">
                                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                        <div class="row">
                                            <select class="form-control pm">
                                                <option>All Saturday</option>
                                                <option>Option 2</option>
                                                <option>Option 3</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                        <button class="btn btn-primary" type="button">Go</button>
                                     </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border">
                  <header class="panel-heading">Time Of Day<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div class="daly_shop"> <img src="{{ asset('userend-resources/img/daly_shop1.jpg') }}"> </div>
                  </div>
                </section>
              </div>
            </div>
          </section>
          <!--End Product Mix Top Part-->
        </div>
        <!--End Left Part-->
        <!--Table Section start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel plan_border">
            <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
            <div class="panel-body">
              <section id="unseen_tebl">
                <table class="table table-bordered table-striped table-condensed">
                  <thead>
                    <tr>
                      <th>Time Of Day</th>
                      <th class="num">Total Revenue ($)</th>
                      <th class="num">Total Employee Clocked in</th>
                      <th class="num">Revenue /  Employee ($)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p>08.00</p></td>
                      <td class="num"><p>100.00</p></td>
                      <td class="num"><p>2</p></td>
                      <td class="num"><p>50.00</p></td>
                    </tr>
                    <tr>
                      <td><p>08.30</p></td>
                      <td class="num"><p>100.00</p></td>
                      <td class="num"><p>2</p></td>
                      <td class="num"><p>20.00</p></td>
                    </tr>
                    <tr>
                      <td><p>09.00</p></td>
                      <td class="num"><p>200.00</p></td>
                      <td class="num"><p>8</p></td>
                      <td class="num"><p>25.00</p></td>
                    </tr>
                    <tr>
                      <td><p>09.30</p></td>
                      <td class="num"><p>400.00</p></td>
                      <td class="num"><p>8</p></td>
                      <td class="num"><p>50.00</p></td>
                    </tr>
                    <tr>
                      <td><p>10.00</p></td>
                      <td class="num"><p>400.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    <tr>
                      <td><p>10.30</p></td>
                      <td class="num"><p>600.00</p></td>
                      <td class="num"><p>15</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    <tr>
                      <td><p>11.00</p></td>
                      <td class="num"><p>600.00</p></td>
                      <td class="num"><p>15</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    <tr>
                      <td><p>11.30</p></td>
                      <td class="num"><p>700.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>70.00</p></td>
                    </tr>
                    <tr>
                      <td><p>12.00</p></td>
                      <td class="num"><p>400.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    <tr>
                      <td><p>12.30</p></td>
                      <td class="num"><p>600.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>60.00</p></td>
                    </tr>
                    <tr>
                      <td><p>13.00</p></td>
                      <td class="num"><p>700.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>70.00</p></td>
                    </tr>
                    <tr>
                      <td><p>13.30</p></td>
                      <td class="num"><p>400.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    
                    
                    <tr>
                      <td><p>14.00</p></td>
                      <td class="num"><p>350.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>35.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>14.30</p></td>
                      <td class="num"><p>500.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>50.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>15.00</p></td>
                      <td class="num"><p>1200.00</p></td>
                      <td class="num"><p>12</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>15.30</p></td>
                      <td class="num"><p>1200.00</p></td>
                      <td class="num"><p>12</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>16.00</p></td>
                      <td class="num"><p>1400.00</p></td>
                      <td class="num"><p>14</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>16.30</p></td>
                      <td class="num"><p>350.00</p></td>
                      <td class="num"><p>7</p></td>
                      <td class="num"><p>50.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>17.00</p></td>
                      <td class="num"><p>700.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>70.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>17.30</p></td>
                      <td class="num"><p>1200.00</p></td>
                      <td class="num"><p>12</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>18.00</p></td>
                      <td class="num"><p>1100.00</p></td>
                      <td class="num"><p>11</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>18.30</p></td>
                      <td class="num"><p>1400.00</p></td>
                      <td class="num"><p>14</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>19.00</p></td>
                      <td class="num"><p>1600.00</p></td>
                      <td class="num"><p>16</p></td>
                      <td class="num"><p>100.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>19.30</p></td>
                      <td class="num"><p>600.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>60.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>20.00</p></td>
                      <td class="num"><p>900.00</p></td>
                      <td class="num"><p>15</p></td>
                      <td class="num"><p>60.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>20.30</p></td>
                      <td class="num"><p>600.00</p></td>
                      <td class="num"><p>15</p></td>
                      <td class="num"><p>40.00</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>21.00</p></td>
                      <td class="num"><p>700.00</p></td>
                      <td class="num"><p>15</p></td>
                      <td class="num"><p>16.66</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>21.30</p></td>
                      <td class="num"><p>800.00</p></td>
                      <td class="num"><p>18</p></td>
                      <td class="num"><p>44.44</p></td>
                    </tr>
                    
                    <tr>
                      <td><p>22.00</p></td>
                      <td class="num"><p>500.00</p></td>
                      <td class="num"><p>10</p></td>
                      <td class="num"><p>50.00</p></td>
                    </tr>
                  </tbody>
                </table>
              </section>
            </div>
          </section>
        </div>
        <!--Table Section end-->
      </div>
      <!--End Time-of-Day Part-->
@endsection

@section('page-specific-scripts')
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/daily-scoop/time_of_day.js') !!}
@stop