@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- Bootstrap Date-Picker -->
    {!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
	 <!--Start Cumulative-Revenue Part-->
     
		<!-- ************** Store(s) Selection [Begin] ************** -->
		<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel" id="select-store">
						<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
							<label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
							<select class="form-control pm" id="i_store" name="i_store" onchange="load_data_AJAX()">
								{!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
							</select>
						</div>
					</section>
				</div>
			</div>						
		<!-- ************** Store(s) Selection [End] ************** -->
	
		<div class="row">
			<!--Full Width Part Start-->
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				<div class="margin_btntwenty">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="row">
					  <h1 class="bench_h1">Daily Scoop -  Discount [Based on {{ $total_no_of_shops }} store(s) data]</h1>
					</div>
				  </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                     <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row"> 
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topfive_margin">
                                    <div class="row lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">{{ $prev_month_scroller_dt }}</span> <!-- <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a>-->to   <span id="lbl_to_dt" class="lbl_dt_marker_long">{{ $next_month_scroller_dt }}</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a>
                                    </div>
                                        <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
                                        <input type="hidden" name="i_prev_date" id="i_prev_date" value="" />
                                        <input type="hidden" name="i_prev_month" id="i_prev_month" value="" />
                                        <input type="hidden" name="i_prev_year" id="i_prev_year" value="" />
                                        
                                        <input type="hidden" name="i_current_date" id="i_current_date" value="" />
                                        <input type="hidden" name="i_current_month" id="i_current_month" value="" />
                                        <input type="hidden" name="i_current_year" id="i_current_year" value="" />
                                        <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
                                    
                                </div>
                        </div>
                    </div>
                </div>
                </div>
                 
                
                <div id="DS_cumulative_marching_charts">                
               
				<div class="clearfix"></div>
				
				<div class="row twenty_margin">						  

                        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                            <section class="panel round_border">
                                <header class="panel-heading">Marching Progress<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                                <div class="panel-body">
                                <div id="hst_mp" loader-class="preloader_allR" class="img_brd" style="width: 100%; margin: 0 auto;">
                                    <div class="preloader_allR">&nbsp;</div>
                                <!-- <div class="daly_rev"> <img src="img/dally_rev.jpg"> </div> -->
                                </div>
                                
                                <div class="col-md-8">
                                <div class="col-md-3 col-md-offset-1"><span class="blue-block"></span>Discount Last Year</div>
                                <div class="col-md-4"><span class="brown-block"></span>Plan Discount This Year</div>
                                <div class="col-md-4"><span class="purple-block"></span>Discount This Year</div>
                                </div>
                                <div class="col-md-4">
                                
                                </div>
                                
                                </div>
                                <!-- <div class="panel-body">
                                <div class="daly_rev"> <img src="{{ asset('userend-resources/img/dally_rev.jpg') }}"> </div>
                                </div> -->
                            </section>
                        </div>
              
                        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                            <section class="panel round_border">
                                <header class="panel-heading">Deviation From Plan<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                                <div class="panel-body">
                                <div id="hst_dv" loader-class="preloader_allR" class="img_brd" style="width: 100%; margin: 0 auto;">
                                <div class="preloader_allR">&nbsp;</div>
                                <!-- <div class="daly_rev2"> <img src="img/dally_rev2.jpg"> </div> -->
                                </div>
                                <div id="hst_dv_legend"></div>
                                </div>
                                <!-- <div class="panel-body">
                                <div class="daly_rev2"> <img src="{{ asset('userend-resources/img/dally_rev2.jpg') }}"> </div>
                                </div> -->
                            </section>
                        </div>
              
                        
						
                        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                            <section class="panel round_border">
                                <header class="panel-heading">Snapshot<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                                <div class="panel-body">
                                <div id="hst_ss" loader-class="preloader_allR" class="img_brd" style="width: 100%; margin: 0 auto;">
                                <div class="preloader_allR">&nbsp;</div>
                                <!-- <div class="daly_rev4"> <img src="img/dally_rev4.jpg"> </div> -->
                                </div>
                                
                                <div class="col-md-6">
                                <div class="col-md-11 col-md-offset-1"><span class="blue-block"></span>Discount This Month to Date</div>
                                <div class="col-md-11 col-md-offset-1"><span class="brown-block"></span>Plan Discount This Month to Date</div>
                                <div class="col-md-11 col-md-offset-1"><span class="saffron-block"></span>Last Year Discount This Month to Date</div>
                                <div class="col-md-11 col-md-offset-1"><span class="green-block"></span>System Average Discount This Month to Date</div>
                                </div>
                                
                                <div class="col-md-6">
                                <div class="col-md-11 col-md-offset-1"><span class="yellow-block"></span>+ or - Plan vs. Actual</div>
                                <div class="col-md-11 col-md-offset-1"><span class="dark-green-block"></span>+ or - Plan vs. Last Year</div>
                                <div class="col-md-11 col-md-offset-1"><span class="light-yellow-block"></span>+ or - Plan vs. System Average</div>                              
                                </div>
                                
                                </div>
                                <!-- <div class="panel-body">
                                <div class="daly_rev4"> <img src="{{ asset('userend-resources/img/dally_rev4.jpg') }}"> </div>
                                </div> -->
                            </section>
                        </div>					
				</div>
                
                <div class="clearfix"></div>
                
                <!--Table Section start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel plan_border">
            <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" onclick="hide(this)" class="fa fa-chevron-down"></a> <a href="javascript:;" onclick="close_section(this)" class="fa fa-times"></a> </span> </header>
            <div class="panel-body">
              <section id="unseen_tebl">
                <!-- <div id="hst_tab" loader-class="preloader_allR">
                <div class="preloader_allR">&nbsp;</div>                
                </div> -->
                <?php
                if(!empty($all_CR_table_data_arr)){
                ?>
                <table class="table table-bordered table-striped table-condensed">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th class="num">Actual ($)</th>
                      <th class="num">Plan ($)</th>
                      <th class="num">Last Year ($)</th>
                      <th class="num">System Average ($)</th>
                      <th class="num">+/-vs. Plan</th>
                      <th class="num">+/-vs.Last Year</th>
                      <th class="num">+/-vs. System Average</th>
                    </tr>
                  </thead>
                  <tbody>
                  
                <?php
    
        
                foreach($all_CR_table_data_arr as $ind=>$val){
            
                ?>
                <tr>
                <td><p><?php echo date('m/d/Y',strtotime($val->erplytrans_date));?></p></td>
                <td class="rev"><p class='<?php echo ($val->discount) <0?"red_text":"";?>' ><?php echo $val->discount;?><span class='<?php echo ($val->cum_discount) <0?"red_text":"";?>'><?php echo $val->cum_discount;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->plan_discount) <0?"red_text":"";?>'><?php echo $val->plan_discount;?><span class='<?php echo ($val->cum_plan_discount) <0?"red_text":"";?>'><?php echo $val->cum_plan_discount;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->last_year_discount) <0?"red_text":"";?>'><?php echo $val->last_year_discount;?><span class='<?php echo ($val->cum_last_year_discount) <0?"red_text":"";?>'><?php echo $val->cum_last_year_discount;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->system_avg_discount) <0?"red_text":"";?>'><?php echo $val->system_avg_discount;?><span class='<?php echo ($val->cum_sys_avg_discount) <0?"red_text":"";?>'><?php echo $val->cum_sys_avg_discount;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->deviation_from_plan) <0?"red_text":"";?>'><?php echo $val->deviation_from_plan;?><span class='<?php echo ($val->cum_deviation_from_plan) <0?"red_text":"";?>'><?php echo $val->cum_deviation_from_plan;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->deviation_from_last_year) <0?"red_text":"";?>'><?php echo $val->deviation_from_last_year;?><span class='<?php echo ($val->cum_deviation_from_last_year) <0?"red_text":"";?>'><?php echo $val->cum_deviation_from_last_year;?></span></p></td>
                <td class="rev"><p class='<?php echo ($val->deviation_from_sys_avg) <0?"red_text":"";?>'><?php echo $val->deviation_from_sys_avg;?><span class='<?php echo ($val->cum_deviation_from_sys_avg) <0?"red_text":"";?>'><?php echo $val->cum_deviation_from_sys_avg;?></span></p></td>
                </tr>
                <?php
            
                }
   
                ?>
                   
                    
                  </tbody>
                </table>
                 <?php
                 }
                 ?>
              </section>
            </div>
          </section>
        </div>
        <!--Table Section end-->
                </div>
			  </section>
			  <!--End Product Mix Top Part-->
			</div>
			<!--End Left Part-->

		
		</div>
	    <!--End Cumulative-Revenue Part-->
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
	{!! Html::script('https://www.google.com/jsapi') !!}
	{!! Html::script('userend-resources/js/charts/DS/discount/generate_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/DS/discount/revenue_charts.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/daily-scoop/daily_scoop_discount.js') !!}
@stop


@section('inline-footer-js')
<script type="text/javascript">
<!--
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - Begin
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		var all_CR_data = {!! $all_CR_data_arr !!};
        var all_CR_revised_data = {!! $all_CR_revised_data_arr !!};        
        var all_CR_snapshot_data_arr = {!! $all_CR_snapshot_data_arr !!}
		
	
		


		
		//// For "Normally-Distributed" Chart(s) [Begin]
			drawMPChart(all_CR_data);
			drawDVChart(all_CR_revised_data);			
			drawSSChart(all_CR_snapshot_data_arr);
            
		//// For "Normally-Distributed" Chart(s) [End]
		
		
		
		
	
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - End
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
//-->
</script>
@stop
