<?php

namespace App\Http\Controllers\userend\daily_scoop;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\CumulativeModel as model_Curv;


class CumulativeRevenueController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Daily Scoop - Cumulative Revenue ::';

        # for menu selection...
        $this->data['selected_menu'] = 'daily-scoop';
        $this->data['selected_sub_menu'] = 'cumulative-revenue';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        #$data = $this->data;

        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        # 1: getting concerned Franchisor-Admin ID...
            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                   : $LOGGED_USR_ID;

        # 2: total no. of Store(s) available...
            $this->data['total_no_of_shops'] = usr_Helper::getAllStoreCount($FRANCHISOR_ADMIN_ID);

        
        
        # 3: Total Statistics :
        
        $TABLE_DATA_ARR = $this->loadAllStoresTableData();
        
         # Total Statistics Data:
        if(!empty($TABLE_DATA_ARR['ret_yesterday']))    
        $this->data['sum_yesterday'] = number_format($TABLE_DATA_ARR['ret_yesterday'],2,'.',',');
        else
        $this->data['sum_yesterday'] = 0;
        
        if(!empty($TABLE_DATA_ARR['ret_achievement']))    
        $this->data['sum_achievement'] = number_format($TABLE_DATA_ARR['ret_achievement'],2,'.',',');
        else
        $this->data['sum_achievement'] = 0;
        
        if(!empty($TABLE_DATA_ARR['ret_target']))    
        $this->data['sum_target'] = number_format($TABLE_DATA_ARR['ret_target'],2,'.',',');
        else
        $this->data['sum_target'] = 0;
        
        if(!empty($TABLE_DATA_ARR['ret_goal']))    
        $this->data['sum_goal'] = number_format($TABLE_DATA_ARR['ret_goal'],2,'.',',');
        else
        $this->data['sum_goal'] = 0;
        
        if(!empty($TABLE_DATA_ARR['ret_planned']))    
        $this->data['sum_planned'] = number_format($TABLE_DATA_ARR['ret_planned'],2,'.',',');
        else
        $this->data['sum_planned'] = 0;
        
        if(!empty($TABLE_DATA_ARR['revisted_target']))    
        $this->data['sum_revised'] = number_format($TABLE_DATA_ARR['revisted_target'],2,'.',',');
        else
        $this->data['sum_revised'] = 0;

        
        
        # 4: loading chart-data...
            $ALL_DATA_ARR = $this->loadAllStoresChartData();   
            $ALL_REVISED_ARR = $this->loadAllStoresRevisedData();    
            $ALL_BASELINE_ARR = $this->loadAllStoresBaselineData();        
            $ALL_SNAPSHOT_ARR = $this->loadAllStoresSnapshotData();
            $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableData();
            
       
        
        

        # ===========================================================================
        #       For Column Graph(s) - Begin
        # ===========================================================================

            
            $CR_ALL_DATA_ARR = $this->prepareGChartAllArray($ALL_DATA_ARR);
            $this->data['all_CR_data_arr'] = json_encode($CR_ALL_DATA_ARR);
            
            $CR_ALL_REVISED_DATA_ARR = $this->prepareGChartRevisedArray($ALL_REVISED_ARR);
            $this->data['all_CR_revised_data_arr'] = json_encode($CR_ALL_REVISED_DATA_ARR);            
            
            $CR_ALL_BASELINE_DATA_ARR = $this->prepareGChartBaselineArray($ALL_BASELINE_ARR);            
            $this->data['all_CR_baseline_data_arr'] = json_encode($CR_ALL_BASELINE_DATA_ARR);
            
            $CR_ALL_SNAPSHOT_DATA_ARR = $this->prepareGChartSnapshotArray($ALL_SNAPSHOT_ARR);
            $this->data['all_CR_snapshot_data_arr'] = json_encode($CR_ALL_SNAPSHOT_DATA_ARR);
            
            
            $this->data['all_CR_table_data_arr'] = $ALL_TABLE_ARR;

        # ===========================================================================
        #      For Column Graph(s) -  End
        # ===========================================================================


        # Default Load "Month-Scroller"...
        $this->data['default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));
        #utils::dump($data);
        
        $this->data['prev_month_scroller_dt'] = date('d M y', strtotime("-30 days"));
        $this->data['next_month_scroller_dt'] = date('d M y'); 
        
        $this->data['display_month_year'] = date('M/Y');        
        
        
        # show view part...
        return view('userend.daily_scoop.cumulative-revenue', $this->data);
    }


    // AJAX Call - load Chart data based on selected store(s), month & year...
    public function loadCumulativeRevenueDataAJAX(Request $request) {

        try {

            # 1: loading chart-data...
            $ALL_DATA_ARR = $this->loadAllStoresChartDataAJAX($request);            
            $TABLE_DATA_ARR = $this->loadAllStoresTableDataAJAX($request);          
            
            $ALL_REVISED_ARR = $this->loadAllStoresRevisedDataAJAX($request);
            $ALL_BASELINE_ARR = $this->loadAllStoresBaselineDataAJAX($request);
           
            $ALL_SNAPSHOT_ARR = $this->loadAllStoresSnaphotDataAJAX($request);
            $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableDataAJAX($request);

            # ===========================================================================
            #       For Column Graph(s) - Begin
            # ===========================================================================

                //$chart_type = 'ND';
                $CR_ALL_DATA_ARR = $this->prepareGChartAllArray($ALL_DATA_ARR);
                $this->data['all_CR_data_arr'] = json_encode($CR_ALL_DATA_ARR);

                $CR_ALL_REVISED_DATA_ARR = $this->prepareGChartRevisedArray($ALL_REVISED_ARR);
                $this->data['all_CR_revised_data_arr'] = json_encode($CR_ALL_REVISED_DATA_ARR);
                #print_r($ALL_BASELINE_ARR);
                $CR_ALL_BASELINE_DATA_ARR = $this->prepareGChartBaselineArray($ALL_BASELINE_ARR);
                #print_r($CR_ALL_BASELINE_DATA_ARR);
                $this->data['all_CR_baseline_data_arr'] = json_encode($CR_ALL_BASELINE_DATA_ARR);
                
                $CR_ALL_SNAPSHOT_DATA_ARR = $this->prepareGChartSnapshotArray($ALL_SNAPSHOT_ARR);
                $this->data['all_CR_snapshot_data_arr'] = json_encode($CR_ALL_SNAPSHOT_DATA_ARR); 
                
                $this->data['all_CR_table_data_arr'] = $ALL_TABLE_ARR;            
                

            # ===========================================================================
            #       For Column Graph(s) - End
            # ===========================================================================
            


            # Total Statistics :
            if(!empty($TABLE_DATA_ARR['ret_yesterday']))    
            $this->data['sum_yesterday'] = number_format($TABLE_DATA_ARR['ret_yesterday'],2,'.',',');
            else
            $this->data['sum_yesterday'] = 0;

            if(!empty($TABLE_DATA_ARR['ret_achievement']))    
            $this->data['sum_achievement'] = number_format($TABLE_DATA_ARR['ret_achievement'],2,'.',',');
            else
            $this->data['sum_achievement'] = 0;

            if(!empty($TABLE_DATA_ARR['ret_target']))    
            $this->data['sum_target'] = number_format($TABLE_DATA_ARR['ret_target'],2,'.',',');
            else
            $this->data['sum_target'] = 0;

            if(!empty($TABLE_DATA_ARR['ret_goal']))    
            $this->data['sum_goal'] = number_format($TABLE_DATA_ARR['ret_goal'],2,'.',',');
            else
            $this->data['sum_goal'] = 0;
            
            if(!empty($TABLE_DATA_ARR['ret_planned']))    
            $this->data['sum_planned'] = number_format($TABLE_DATA_ARR['ret_planned'],2,'.',',');
            else
            $this->data['sum_planned'] = 0;            
            
            if(!empty($TABLE_DATA_ARR['revisted_target']))    
            $this->data['sum_revised'] = number_format($TABLE_DATA_ARR['revisted_target'],2,'.',',');
            else
            $this->data['sum_revised'] = 0;
            
        
            # load view part...
            $HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-cumulative-revenue-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

    # =============================================================
    #           Generate Chart(s) - Begin
    # =============================================================

        # I: INITIAL LOAD
            //// 1st Chart: My Store VS All Store(s)...
            public function loadAllStoresChartData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                    

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);
                        
                        


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

            
            ###2
            public function loadAllStoresRevisedData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresRevisedDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###3
            public function loadAllStoresBaselineData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresBaselineDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
             public function loadAllStoresCumulativeTableData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);

                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            ###4
            ###3
            public function loadAllStoresSnapshotData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresSnapshotDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s)...
            

            //// 3rd Chart: Last 12 month(s) Analysis...
            

            public function loadAllStoresTableData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresTableDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

        # I: AJAX LOAD
            //// 1st Chart: My Store VS All Store(s)...
            public function loadAllStoresChartDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

            
            public function loadAllStoresRevisedDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresRevisedDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s)...
            

            public function loadAllStoresBaselineDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresBaselineDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            //// 3rd Chart: Last 12 month(s) Analysis [AJAX Call]...
            
            //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s)...
            

            public function loadAllStoresSnaphotDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresSnapshotDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ///4

            public function loadAllStoresTableDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    //$arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);
                    $arr = $this->formStoresTableDataArray($all_store_ids, $dt_time_arr, $store_ids);

                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            
            public function loadAllStoresCumulativeTableDataAjax(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $dt_time_arr = array();

                        $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                        $dt_time_arr['prev_month'] = $request->input('prev_month');
                        $dt_time_arr['prev_year'] = $request->input('prev_yr');

                        $dt_time_arr['current_date'] = $request->input('current_date');                    
                        $dt_time_arr['current_month'] = $request->input('current_month');
                        $dt_time_arr['current_year'] = $request->input('current_yr');
                        
                       

                        $store_ids = $request->input('store_id');
                        if( $store_ids==-1 )
                            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
    # =============================================================
    #           Generate Chart(s) - End
    # =============================================================




        # function to get ALL-STORES-DATA...
        public function formStoresDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $return_arr = array();
                $ret_previous_arr = array(); 
                $ret_target_arr = array();                
                $new_array = array();
                
                $last_cumulative = 0;
                $cumulative_previous_val = 0;
                $cumulative_target_val = 0;
                $cumulative_previous =0;
                
                $model_Curv = new model_Curv();
                $return_arr = $model_Curv->getCumRevDetailsData($selected_stores_arr, $dt_time_arr);
                
                
                $ret_current = $return_arr['ret_current'];
                $ret_previous = $return_arr['ret_previous'];
                $ret_target = $return_arr['ret_target'];
                
               
                
                if(!empty($ret_target)){
                    foreach($ret_target as $val){
                        
                        
                        $ret_target_arr[$val->erplytrans_date] = (object)array('target_val'=>$val->target_sales);
                    }
                }               
                
                
                if(!empty($ret_previous)){
                    foreach($ret_previous as $val){
                        $ret_previous_arr[$val->erplytrans_date] = $val;
                    }
                }
                
              
                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/
                
                
                if(!empty($ret_current)){
                    
                    $array_length = count($ret_current);
                    if($array_length >0){
                        $prev_month = date('m',strtotime($ret_current[0]->erplytrans_date));
                    }
                    
                    foreach($ret_current as $ind=>$val){
                        
                        
                        /*$cur_month = date('m',strtotime($val->erplytrans_date));
                        if($prev_month != $cur_month){
                        $new_array[] = (object)array('erplytrans_date'=>0,'cumulative_current'=>0);
                        $prev_month = date('m',strtotime($RETURN_ARR[$ind]->erplytrans_date));
                        }                        
                        $new_array[] = $val;
                        */
                       
                        $previous_year_date =  date('Y-m-d', strtotime('-1 year', strtotime($val->erplytrans_date)));
                        
                        $cur_month = date('m',strtotime($val->erplytrans_date));
                        //$cur_date = date('N',strtotime($val->erplytrans_date));
                        $cumulative_previous += (!(empty($ret_previous_arr)) && array_key_exists($previous_year_date,$ret_previous_arr))?
                                                $ret_previous_arr[$previous_year_date]->cumulative_previous :
                                                $cumulative_previous_val;
                                                
                        $cumulative_target_val =  (!(empty($ret_target_arr)) && array_key_exists($val->erplytrans_date,$ret_target_arr))?
                                                $ret_target_arr[$val->erplytrans_date]->target_val : $cumulative_target_val;
                                                
                        $cumulative_default_val =  (!(empty($ret_target_arr)) && array_key_exists($val->erplytrans_date,$ret_target_arr))?
                                                $ret_target_arr[$val->erplytrans_date]->target_val : 0;                                               
                        
                        
                        if($prev_month != $cur_month){
                            $new_array[] = (object)array('erplytrans_date'=>null,'cumulative_current'=>null,'cumulative_previous'=>null,'cumulative_target'=>null);
                            $prev_month = date('m',strtotime($ret_current[$ind]->erplytrans_date));
                            $prev_index = $ind-1;
                            $last_cumulative = $ret_current[$prev_index]->cumulative_current;
                            $cumulative_target_val =$cumulative_default_val;
                            $new_array[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current-$last_cumulative), 'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                        elseif($cur_month !=date('m',strtotime($ret_current[0]->erplytrans_date)) && $prev_month == $cur_month){
                            $new_array[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current-$last_cumulative),
                            'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                        else{
                            $new_array[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current),
                            'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                    }
                }
                else{
                    $new_array[] = (object)array('erplytrans_date'=>null,'cumulative_current'=>0,'cumulative_previous'=>$cumulative_previous_val,'cumulative_target'=>$cumulative_target_val);
                }
                
                //print_r($new_array);exit;

                return $new_array;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        ##
        # function to get ALL-STORES-DATA...
        public function formStoresRevisedDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumRevisedDetailsData($selected_stores_arr, $dt_time_arr);
               
                $new_array = array();
                if(!empty($RETURN_ARR)){
                    
                    $array_length = count($RETURN_ARR);
                    if($array_length >0){
                        $prev_month = date('m',strtotime($RETURN_ARR[0]->erplytrans_date));
                    }
                    
                    foreach($RETURN_ARR as $ind=>$val){
                        
                        
                        $cur_month = date('m',strtotime($val->erplytrans_date));
                        if($prev_month != $cur_month){
                        $new_array[] = (object)array('erplytrans_date'=>null,'dev'=>null);
                        $prev_month = date('m',strtotime($RETURN_ARR[$ind]->erplytrans_date));
                        }
                        
                        $new_array[] = $val;
                    }
                }
                else{
                    $new_array[] = (object)array('erplytrans_date'=>null,'dev'=>0);
                }                

                return $new_array;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        ##3
        # function to get ALL-STORES-DATA...
        public function formStoresBaselineDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumBaselineDetailsData($selected_stores_arr, $dt_time_arr);
               //print_r($RETURN_ARR);
                $new_array = array();
                if(!empty($RETURN_ARR)){
                    
                    $array_length = count($RETURN_ARR);
                    if($array_length >0){
                        $prev_month = date('m',strtotime($RETURN_ARR[0]->erplytrans_date));
                    }
                    
                    foreach($RETURN_ARR as $ind=>$val){
                        
                        
                        $cur_month = date('m',strtotime($val->erplytrans_date));
                        if($prev_month != $cur_month){
                        $new_array[] = (object)array('erplytrans_date'=>null,'actual_sales'=>null,'target_sales'=>null,'revisted_target'=>null);
                        $prev_month = date('m',strtotime($RETURN_ARR[$ind]->erplytrans_date));
                        }
                        
                        $new_array[] = $val;
                    }
                }
                else{
                    $new_array[] = (object)array('erplytrans_date'=>null,'actual_sales'=>0,'target_sales'=>0,'revisted_target'=>0);
                }                

                return $new_array;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        public function formStoresCumulativeDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumulativeTableData($selected_stores_arr, $dt_time_arr);
                //print_r($RETURN_ARR);
               
                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
         # function to get ALL-STORES-DATA...
        public function formStoresSnapshotDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $return_arr = array();
                
                $model_Curv = new model_Curv();
                $return_arr = $model_Curv->getCumSnapshotDetailsData($stores_arr,$selected_stores_arr, $dt_time_arr);              

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        # function to get Table-DATA...
        public function formStoresTableDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumRevTableData($selected_stores_arr, $dt_time_arr);

                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


        # function to get TOP 10/5 STORES DATA...
        


        # function to prepare return-array format form db-results...
        

        # prepare chart for Google-Graph...
        public function prepareGChartAllArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                if( !empty($arr) ) {
                    
                
                    
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Date', 'Previous Revenues', 'Targetted Revenues', 'Revenues',  array('role' => 'style')]]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                          
                            //$TOOLTIP = $sorted_arr->erplytrans_date ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#CC7878';
                            $cumulative_previous = is_null($sorted_arr->cumulative_previous)?null:floatval($sorted_arr->cumulative_previous);
                            $cumulative_target = is_null($sorted_arr->cumulative_target)?null:floatval($sorted_arr->cumulative_target);
                            $cumulative_current = is_null($sorted_arr->cumulative_current)?null:floatval($sorted_arr->cumulative_current);

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,                                                    
                                                    1 => $cumulative_previous,
                                                    2 => $cumulative_target,
                                                    3 => $cumulative_current,
                                                    4 => $CHART_COLOR
                                                 );
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

        # prepare chart for Google-Graph...
        public function prepareGChartRevisedArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                if( !empty($arr) ) {
                    
                    
                    
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Date', 'Deviation', array('role' => 'style')]]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                          
                            //$TOOLTIP = $sorted_arr->erplytrans_date ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#1897BA';
                            $dev = is_null($sorted_arr->dev)?null:floatval($sorted_arr->dev);

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => $dev,
                                                    2 => $CHART_COLOR
                                                 );
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        
        # prepare chart for Google-Graph...
        public function prepareGChartBaselineArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                if( !empty($arr) ) {
                    
                   
                    
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Date', 'Baseline Plan', 'Actual', 'Revised Plan', array('role' => 'style')]]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                          
                            //$TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            /*$TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $target_sales = is_null($sorted_arr->target_sales)?null:floatval($sorted_arr->target_sales);
                            $actual_sales = is_null($sorted_arr->actual_sales)?null:floatval($sorted_arr->actual_sales);
                            $revisted_target = is_null($sorted_arr->revisted_target)?null:floatval($sorted_arr->revisted_target);
                            $CHART_COLOR =  '#1897BA';

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => $target_sales,
                                                    2 => $actual_sales,
                                                    3 => $revisted_target,
                                                    4 => $CHART_COLOR
                                                 );*/
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        # prepare chart for Google-Graph...
        public function prepareGChartSnapshotArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                if( !empty($arr) ) {
                    
                    
                    
                        //// For "Column" Chart(s) [Begin]
                        //$return_arr = [['Date', 'Baseline Plan', 'Actual', 'Revised Plan', array('role' => 'style')]]; // for Header Array...
                        
                        $return_arr = [['Type', 'Value', array('role' => 'style')]]; // for Header Array...

                        foreach($arr as $ind=>$sorted_arr) {
                          
                            
                            
                            if($ind==0){
                            $CHART_COLOR ='#4F9BEF';
                            $TOOLTIP = 'Revenue This Month';
                            }
                            elseif($ind==1){
                            $CHART_COLOR ='#9F0100';
                            $TOOLTIP = 'Plan Revenue For This Month';
                            }
                            elseif($ind==2){
                            $CHART_COLOR ='#A6A435';
                            $TOOLTIP = 'Last Year Revenue To Month This Date';
                            }
                            elseif($ind==3){
                            $CHART_COLOR ='#E2B220';
                            $TOOLTIP = 'System Average Revenue To Month This Date';
                            }
                            elseif($ind==4){
                            $CHART_COLOR ='';
                            $TOOLTIP = '';
                            }
                            elseif($ind==5){
                            $CHART_COLOR ='#E2B220';
                            $TOOLTIP = '+ Or - Plan VS Actual';
                            }
                            elseif($ind==6){
                            $CHART_COLOR ='#A88310';
                            $TOOLTIP = '+ Or - Plan VS Last Year';
                            }
                            elseif($ind==7){
                            $CHART_COLOR ='#E7C86E';
                            $TOOLTIP = '+ Or - Plan VS System Average';
                            }
                            
                            

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => floatval($sorted_arr),                                                  
                                                    2 => $CHART_COLOR
                                                 );
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    

                }   // end - if
                
                //print_r($return_arr);exit;

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        # prepare chart for Google-Graph...

        
}
