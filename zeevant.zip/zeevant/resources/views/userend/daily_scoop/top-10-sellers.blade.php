@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- Bootstrap Date-Picker -->
    {!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
    <!-- ************** Store(s) Selection [Begin] ************** -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel" id="select-store">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
                        <label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <select class="form-control pm" id="i_store" name="i_store" onchange="load_data_AJAX()">
                            {!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
                        </select>
                    </div>
                </section>
            </div>
        </div>                        
    <!-- ************** Store(s) Selection [End] ************** -->
                            
                            
      <!--Start Top-10-Sellers Part-->
      <div class="row">
        <!--Full Width Part Start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
            <div class="margin_btntwenty">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                  <h1 class="bench_h1">Daily Scoop - Top 10 Sellers - <span id="lbl_main_heading">All Store(s)</span></h1>
                </div>
              </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                        <div class="col-md-6"></div>
                            
                            <div class="col-md-3 icheck">
                                <div class="row right_fltmargin">
                                    <div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio"  name="demo-radio" checked="checked" value="1" >
                                        <label>All Store</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-3 icheck">
                                <div class="row right_fltmargin">
                                    <div class="minimal-blue single-row">
                                    <div class="radio no_padd_left">
                                        <input tabindex="3" type="radio" value="2" name="demo-radio" >
                                        <label>My Store</label>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row"> 
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topfive_margin">
                                <div class="row lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">{{ $prev_month_scroller_dt }}</span> <!-- <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a>-->to <span id="lbl_to_dt" class="lbl_dt_marker_long">{{ $next_month_scroller_dt }}</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a>
                                </div>
                                    <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
                                    <input type="hidden" name="i_prev_date" id="i_prev_date" value="" />
                                    <input type="hidden" name="i_prev_month" id="i_prev_month" value="" />
                                    <input type="hidden" name="i_prev_year" id="i_prev_year" value="" />
                                    
                                    <input type="hidden" name="i_current_date" id="i_current_date" value="" />
                                    <input type="hidden" name="i_current_month" id="i_current_month" value="" />
                                    <input type="hidden" name="i_current_year" id="i_current_year" value="" />
                                    <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border" id="graph_top_10_sellers">
                  <header class="panel-heading">Top 10 Sellers Revenue - <span id="lbl_sub_heading">All Store(s)</span><span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div id="ds_top_10_stores" loader-class="preloader_top10DS" class="daly_shop" style="width: 100%; margin: 0 auto;">
                        <div class="preloader_top10DS">&nbsp;</div>
                    </div>
                    <div id="hst_mp_legend">
                        <img src="{{ asset('userend-resources/img/legend_top_10_sellers.png') }}" height="25px" />
                    </div>                        
                  </div>
                </section>
              </div>
            </div>
            
          </section>
          <!--End Product Mix Top Part-->
        </div>
        <!--End Left Part-->
        <!--Table Section start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel plan_border">
            <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
            <div class="panel-body">
              <section id="unseen_tebl">
                <table class="table table-bordered table-striped table-condensed">
                  <thead>
                    <tr>
                      <th class="center_text">Product</th>
                      <th class="center_text">Top 10 Average Selling Product’s Revenue ($) </th>
                      <th class="center_text">% Top 10 Average Selling Product’s Revenue ($) </th>
                      <th class="center_text">My Store Top 10 Selling Product’s Revenue ($) </th>
                      <th class="center_text">% Of My Store Top 10 Selling Product’s Revenue ($) </th>
                    </tr>
                  </thead>
                  <tbody>
                    @if( !empty($data_tbl_arr) )
                        @foreach($data_tbl_arr as $arr)
                            <tr>
                              <td class="center_text"><p>{{ $arr['product_name'] }}</p></td>
                              <td class="center_text"><p>{{ $arr['top_sellers_amount'] }}</p></td>
                              <td class="center_text"><p>{{ $arr['top_seller_percentage'] }}%</p></td>
                              <td class="center_text"><p>{{ $arr['my_store_product'] }}</p></td>
                              <td class="center_text"><p>{{ $arr['my_store_percentage'] }}%</p></td>
                            </tr>
                        @endforeach
                    @else
                            <tr>
                                <td colspan="5" style="min-height:50px;"><p>No Data</p></td>
                            </tr>
                    @endif
                  </tbody>
                </table>
              </section>
            </div>
          </section>
        </div>
        <!--Table Section end-->
      </div>
      <!--End Top-10-Sellers Part-->
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
    {!! Html::script('https://www.google.com/jsapi') !!}
    {{-- Html::script('https://www.gstatic.com/charts/loader.js') --}}
    {!! Html::script('userend-resources/js/charts/DS/top-10-sellers/generate_charts.js') !!}
    {!! Html::script('userend-resources/js/charts/DS/top-10-sellers/common_charts_config.js') !!}
    <!-- Page Specific -->
    {!! Html::script('userend-resources/js/custom-scripts/daily-scoop/top_10_sellers.js') !!}
@stop

@section('inline-footer-js')
<script type="text/javascript">
<!--
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - Begin
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
        var all_BAR_data = {!! $all_BAR_data_arr !!};        
        
        //// For "Top-10-Sellers" Chart(s) [Begin]
            //drawTop10StoresChart(all_BAR_data);
            drawCharts();
        //// For "Top-10-Sellers" Chart(s) [End]
        
    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - End
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
//-->
</script>
@stop
