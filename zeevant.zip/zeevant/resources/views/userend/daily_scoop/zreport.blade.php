@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- Bootstrap Date-Picker -->
    {!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
    <!-- ************** Store(s) Selection [Begin] ************** -->
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel" id="select-store">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
                        <label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <select class="form-control pm" id="i_store" name="i_store" onchange="">
                            {!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
                        </select>
                    </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<div class="row lft_arrow"><span id="lbl_dt" class="lbl_dt_marker_long">{{ $default_month_scroller_dt }}</span> <a id="dt_icon" href="#"><i class="fa fa-calendar"></i></a></div>
							<!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
							<input type="hidden" name="i_date" id="i_date" value="" />
							<input type="hidden" name="i_month" id="i_month" value="" />
							<input type="hidden" name="i_year" id="i_year" value="" />
							<!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
					</div>
                </section>
            </div>
        </div>                        
    <!-- ************** Store(s) Selection [End] ************** -->
                            
                            
      <!--Start Z-Report Part-->
		<div class="row">
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel">
				<header class="panel-heading"> Z-Report <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				<div class="panel-body">
				  <section id="unseen" class="z_report font18">
                    <table class="table table-bordered table-striped table-condensed">
                      <thead>
                        <tr>
                          <th class="reg">Description</th>
                          <th class="reg">Amount</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                            <td> <b>Register</b></td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Opening Amount in Register</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Day Cash Income</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Sum of Cash In / Cash Out</td>
                            <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Cash Count in Register End of Day</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Amount for Bank Deposit End of Day</td>
                            <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Over/Under</td>
                            <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                        </tr>
                        <tr>
                            <td> Cash Transactions</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Transactions by Check</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> <b>Credit Card Transactions</b></td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;&nbsp;&nbsp; Mastercard</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Visa</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Discover</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Other Credit Cards</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> <b>Total Credit Cards</b></td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> <b>Total Debit Cards</b></td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> <b>Total American Express</b></td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Other Payment Types</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Gift Cards Sold</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Gift Cards Redeemed</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Store Credits Issued/Redeemed</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Invoice-Waybills Issued/Redeemed</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Gross Revenue</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Taxable Sales</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Tax Exempt Sales</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Taxes </td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Visits</td>
                            <td class=""> </td>
                        </tr>
                        <tr>
                            <td> Returns </td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Discounts</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> Discounts %</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> # Tickets </td>
                            <td class=""> --</td>
                        </tr>
                      </tbody>
                    </table>                  
				  </section>
				</div>
			  </section>
			</div>
		</div>	  
      <!--End Z-Report Part-->

      <!--Start Z-Report-Attendance Part-->
        <div class="row">
            <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
              <section class="panel">
                <header class="panel-heading"> Employee Attendance Details <span id="dt_header"></span> <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                <div class="panel-body">
                  <section id="unseen_attendance" class="z_report font18">
                    <table class="table table-bordered table-striped table-condensed">
                      <thead>
                        <tr>
                          <th class="reg">Employee Name</th>
                          <th class="reg">Clock-In</th>
                          <th class="reg">Clock-Out</th>
                          <th class="reg">Total Working Hours</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                            <td> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                        </tr>
                        <tr>
                            <td> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                            <td class=""> --</td>
                        </tr>
                      </tbody>
                    </table>                  
                  </section>
                </div>
              </section>
            </div>
        </div>      
      <!--End Z-Report-Attendance Part-->
      
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Page Specific -->
    {!! Html::script('userend-resources/js/custom-scripts/daily-scoop/zreport.js') !!}
@stop
