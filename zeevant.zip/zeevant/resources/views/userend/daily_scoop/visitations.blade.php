@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!--Start Visitations Part-->
      <div class="row">
        <!--Full Width Part Start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
            <div class="margin_btntwenty">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                  <h1 class="bench_h1">Daily Scoop -  Visitation</h1>
                </div>
              </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    	<div class="row"> 
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 topfive_margin">
                                    <div class="row lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">July 14 2015</span> <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a>to   <span id="lbl_to_dt" class="lbl_dt_marker_long">Aug 13 2015</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a>
                                    </div>									
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 twenty_margin">
            	<div class="row">
                	<h2 class="bench_h2 wow fadeInUp" data-wow-duration="2s">Monthly Statics</h2>
                    <div class="rev_border">
                    <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                      <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Targeted Visitation:</span> <span>8500</span></p>
                      <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Achievement to Date:</span>  <span>9500</span></p>
                      <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Amount to Goal:</span> <span> 6500</span></p>
                    </div>
                     <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                       <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Yesterday's Planned Visitation:</span> <span>8500</span></p>
                       <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Today's Planned Visitation:</span>  <span>200</span></p>
                       <p class="dally_rev wow fadeInUp" data-wow-duration="2s"><span>Today's Revised Plan Visitation:</span> <span> 400</span></p>
                    </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="clearfix"></div>
            <div class="row twenty_margin">
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border">
                  <header class="panel-heading">Marching Progress<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div class="daly_rev"> <img src="{{ asset('userend-resources/img/dally_rev.jpg') }}"> </div>
                  </div>
                </section>
              </div>
              
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border">
                  <header class="panel-heading">Deviation From Plan<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div class="daly_rev2"> <img src="{{ asset('userend-resources/img/dally_rev2.jpg') }}"> </div>
                  </div>
                </section>
              </div>
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border">
                  <header class="panel-heading">Baseline And Revised Plan<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div class="daly_rev3"> <img src="{{ asset('userend-resources/img/dally_rev3.jpg') }}"> </div>
                  </div>
                </section>
              </div>
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel round_border">
                  <header class="panel-heading">Snapshot<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div class="daly_rev4"> <img src="{{ asset('userend-resources/img/dally_rev4.jpg') }}"> </div>
                  </div>
                </section>
              </div>
            </div>
          </section>
          <!--End Product Mix Top Part-->
        </div>
        <!--End Left Part-->
        <!--Table Section start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel plan_border">
            <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
            <div class="panel-body">
              <section id="unseen_tebl">
                <table class="table table-bordered table-striped table-condensed">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th class="num">Actual ($)</th>
                      <th class="num">Plan ($)</th>
                      <th class="num">Last Year ($)</th>
                      <th class="num">System Average ($)</th>
                      <th class="num">+/-vs. Plan</th>
                      <th class="num">+/-vs.Last Year</th>
                      <th class="num">+/-vs. System Average</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                   
                   <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p class="red_text">+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                    
                    <tr>
                      <td><p>09/19/2015</p></td>
                      <td class="rev"><p>12,000<span>38,000</span></p></td>
                      <td class="rev"><p>1,600<span>36,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>2,000<span>38,000</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                      <td class="rev"><p>+20.00%<span>+6.19%</span></p></td>
                    </tr>
                  </tbody>
                </table>
              </section>
            </div>
          </section>
        </div>
        <!--Table Section end-->
      </div>
      <!--End Visitations Part-->
@endsection

@section('page-specific-scripts')
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/daily-scoop/visitations.js') !!}
@stop