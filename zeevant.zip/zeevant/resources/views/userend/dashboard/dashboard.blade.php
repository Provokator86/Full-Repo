@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
	<!--Start Benchmark Top Part-->
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel" id="select-store">
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
						<label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<select class="form-control pm" id="i_store" name="i_store" onchange="load_dashboard_data_AJAX()">
							{!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
						</select>
					</div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <a href="#" class="fa fa-print fa-lg pull-right">&nbsp;</a>
                    </div>
				</section>
			</div>
		</div>						
							
							
	
	
		<div class="row">
			<!--Left Part Start-->
			<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
			  <!--Start Benchmark left Top Part-->
			  <div class="col-md-12">
				<div class="row">
				  <section class="panel" id="bench">
					<div class="row margin_btntwenty">
						<div class="col-md-6">
						  <h1 class="bench_h1">Benchmark</h1>
						</div>
						<div class="col-md-6">
						  <div class="lft_arrow"> <a id="prev_BM_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_BM_dt">{{ $BM_default_month_scroller_dt }}</span> <a id="next_BM_dt" href="#"><i class="fa fa-angle-right"></i></a> </div>
						  <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
							<input type="hidden" name="i_BM_month" id="i_BM_month" value="" />
							<input type="hidden" name="i_BM_year" id="i_BM_year" value="" />
						  <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
						</div>
					  </div>
					  <div class="clearfix"></div>
					  <!-- *************** Benchmark Chart(s) - AJAX PART [Begin] *************** -->
						  <div class="row" id="div_BM_charts">
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Revenue<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_r" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						  
							</div>
							
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Gross Margin<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_gm" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
							
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Internet Sales<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_is" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
							
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Average Ticket<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_at" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						   
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
							<section class="panel round_border">
								<header class="panel-heading">Mktg. (%  of Sales)<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_ms" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						  
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						   
							<section class="panel round_border">
								<header class="panel-heading">Labor Efficiency<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_le" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						  
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						   
							<section class="panel round_border">
								<header class="panel-heading">Inventory Turns<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_it" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						  
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Conversion Ratio<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_cr" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
							
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						  
							<section class="panel round_border">
								<header class="panel-heading">Store Visitation<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_sv" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
							
							</div>
							<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						  
							<section class="panel round_border">
								<header class="panel-heading">Average Discount<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div id="bm_ad" class="img_part" style="width: 100%; margin: 0 auto;">
										<div class="preloader_BM">&nbsp;</div>
									</div>
								</div>
							</section>
						 
							</div>
						</div>
					  <!-- *************** Benchmark Chart(s) - AJAX PART [End] *************** -->
				   </section>
				</div>
			  </div>
			  <!--End Benchmark Left Top Part-->
			  <!--notification start-->
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				<div class="row">
				  <section class="panel">
					<header class="panel-heading"> Z-Report (<span id="dt_zreport">Today</span>) <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span>
						  <div class="lft_arrow" style=" float: right; margin-right: 5px; margin-top: 6px; width: 90px;"> <a id="prev_ZR_dt" href="javascript:void(0)"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_ZR_dt">{{ $ZR_default_month_scroller_dt }}</span> <a id="next_ZR_dt" href="javascript:void(0)"><i class="fa fa-angle-right"></i></a> </div>
						  <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
							<input type="hidden" name="i_ZR_date" id="i_ZR_date" value="" />
							<input type="hidden" name="i_ZR_month" id="i_ZR_month" value="" />
							<input type="hidden" name="i_ZR_year" id="i_ZR_year" value="" />
						  <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
					
					</header>
					<div class="panel-body">
					  <section id="unseen" class="z_report">
                        <table class="table table-bordered table-striped table-condensed">
                          <thead>
                            <tr>
                              <th class="reg">Description</th>
                              <th class="reg">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                                <td> <b>Register</b></td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Opening Amount in Register</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; --</td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Day Cash Income</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; --</td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Sum of Cash In / Cash Out</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Cash Count in Register End of Day</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; --</td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Amount for Bank Deposit End of Day</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Over/Under</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; </td>
                            </tr>
                            <tr>
                                <td> Cash Transactions</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Transactions by Check</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> <b>Credit Card Transactions</b></td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td>&nbsp;&nbsp;&nbsp;&nbsp; Mastercard</td>
                                <td class="">&nbsp;&nbsp;&nbsp;&nbsp; --</td>
                            </tr>
                            <tr>
                                <td> Visa</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Discover</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Other Credit Cards</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> <b>Total Credit Cards</b></td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> <b>Total Debit Cards</b></td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> <b>Total American Express</b></td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Other Payment Types</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Gift Cards Sold</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Gift Cards Redeemed</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Store Credits Issued/Redeemed</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Invoice-Waybills Issued/Redeemed</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Gross Revenue</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Taxable Sales</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Tax Exempt Sales</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Taxes </td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Visits</td>
                                <td class=""> </td>
                            </tr>
                            <tr>
                                <td> Returns </td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Discounts</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> Discounts %</td>
                                <td class=""> --</td>
                            </tr>
                            <tr>
                                <td> # Tickets </td>
                                <td class=""> --</td>
                            </tr>
                          </tbody>
                        </table>                  
					  </section>
					</div>
				  </section>
				</div>
			  </div>
			  <!--notification end-->
			</div>
			<!--End Left Part-->
			<!--Start Benchmark Right Top Part-->
			<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
			  <!--Start Daily Scoop left Top Part-->
			  
			  <div class="col-md-12">
				<div class="row">
				  <section class="panel" id="bench">
					<div class="row margin_btntwenty">
						<div class="col-md-6">
						  <h1 class="bench_h1">Daily Scoop</h1>
						</div>
						<div class="col-md-6">
						  <div class="lft_arrow"> <a id="prev_DS_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_DS_dt">{{ $DS_default_month_scroller_dt }}</span> <a id="next_DS_dt" href="#"><i class="fa fa-angle-right"></i></a> </div>
						  <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
                            <input type="hidden" name="i_DS_date" id="i_DS_date" value="" />
							<input type="hidden" name="i_DS_month" id="i_DS_month" value="" />
							<input type="hidden" name="i_DS_year" id="i_DS_year" value="" />
						  <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
						</div>

					  </div>
					  <div class="clearfix"></div>
					  <!-- *************** Daily-Scoop Chart(s) - AJAX PART [Begin] *************** -->
					  <div class="row" id="div_DS_charts">
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
						<section class="panel round_border">
							<header class="panel-heading">Cumulative Revenue<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
							<div id="ds_cr" class="" style="width: 100%; margin: 0 auto;">
								<div class="preloader_DS">&nbsp;</div>
							</div>
							</div>
						</section>
					  
						</div>
						
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
						<section class="panel round_border">
							<header class="panel-heading">Ticket<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div id="ds_ticket" class="" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
						
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
						<section class="panel round_border">
							<header class="panel-heading">Gross Margin<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_gmargin" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
						
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
						<section class="panel round_border">
							<header class="panel-heading">Discount<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_discount" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
					   
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					
						<section class="panel round_border">
							<header class="panel-heading">Time of Day<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_tod" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
					  
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					   
						<section class="panel round_border">
							<header class="panel-heading">Conv. Rate - Future<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_ccf" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
					  
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					   
						<section class="panel round_border">
							<header class="panel-heading">Store Visit - Future<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_sv" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
					  
						</div>
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
						
						<section class="panel round_border">
							<header class="panel-heading">Top 5 Sellers<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
							<div class="panel-body">
								<div class="daily_part" id="ds_top5" style="width: 100%; margin: 0 auto;">
									<div class="preloader_DS">&nbsp;</div>
								</div>
							</div>
						</section>
						
						</div>
					
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Product Mix - Revenue %<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div class="daily_part" id="ds_pmr" style="width: 100%; margin: 0 auto;">
										<div class="preloader_DS">&nbsp;</div>
									</div>
								</div>
							</section>
						  
						</div>
						
						<div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
							
							<section class="panel round_border">
								<header class="panel-heading">Product Mix - Contribution %<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
								<div class="panel-body">
									<div class="daily_part" id="ds_pmc" style="width: 100%; margin: 0 auto;">
										<div class="preloader_DS">&nbsp;</div>
									</div>
								</div>
							</section>
							
						</div>
					
					</div>
					  <!-- *************** Daily-Scoop Chart(s) - AJAX PART [End] *************** -->
				   </section>
				</div>
			  </div>
			  
			  <!--End Daily Scoop Left Top Part-->
			  <!--End Benchmark Right Top Part-->
			  <!--notification start-->
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s" >
				<div class="row">
				  <section class="panel">
					<header class="panel-heading"> Notification <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					<div class="panel-body">
					  <div class="alert alert-info clearfix"> <span class="alert-icon"><i class="fa fa-envelope-o"></i></span>
						<div class="notification-info">
						  <ul class="clearfix notification-meta">
							<li class="pull-left notification-sender"><span><a href="#">Jonathan Smith</a></span> send you a mail </li>
							<li class="pull-right notification-time">1 min ago</li>
						  </ul>
						  <p> Urgent meeting for next proposal </p>
						</div>
					  </div>
					  <div class="alert alert-danger"> <span class="alert-icon"><i class="fa fa-facebook"></i></span>
						<div class="notification-info">
						  <ul class="clearfix notification-meta">
							<li class="pull-left notification-sender"><span><a href="#">Jonathan Smith</a></span> mentioned you in a post </li>
							<li class="pull-right notification-time">7 Hours Ago</li>
						  </ul>
						  <p> Very cool photo jack </p>
						</div>
					  </div>
					  <div class="alert alert-success "> <span class="alert-icon"><i class="fa fa-comments-o"></i></span>
						<div class="notification-info">
						  <ul class="clearfix notification-meta">
							<li class="pull-left notification-sender">You have 5 message unread</li>
							<li class="pull-right notification-time">1 min ago</li>
						  </ul>
						  <p> <a href="#">Anjelina Mewlo, Jack Flip</a> and <a href="#">3 others</a> </p>
						</div>
					  </div>
					</div>
				  </section>
				</div>
			  </div>
			  <!--notification end-->
			</div>
			<!--End Benchmark Right Top Part-->
		</div>
	<!--End Benchmark Top Part-->
@endsection

@section('page-specific-scripts')
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
	{!! Html::script('https://www.google.com/jsapi') !!}
	{!! Html::script('userend-resources/js/charts/chart_utils.js') !!}
	{!! Html::script('userend-resources/js/charts/dashboard/dashboard_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/dashboard/benchmark_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/dashboard/daily_scoop_charts.js') !!}
	<!-- Dashboard Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/dashboard/dashboard.js') !!}
@stop

@section('inline-footer-js')
<script type="text/javascript">
<!--
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - Begin
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		
		// chart data-array(s)...
			var revenue_sales_arr = {!! $js_arr_revenue !!};
			var gross_margin_arr = {!! $js_arr_gross_margin !!};
			var internet_sales_arr = {!! $js_arr_internet_sales !!};
			var avg_tk_arr = {!! $js_arr_average_tkt !!};
			var mktg_percent_arr = {!! $js_arr_mktg_percent !!};
			var labor_efficiency_arr = {!! $js_arr_labor_efficiency !!};
			var inventory_turns_arr = {!! $js_arr_inventory_turns !!};
			var discounts_percent_arr = {!! $js_arr_discounts_percent !!};
            
            var ds_cu_data_arr = {!! $ds_js_cu_data !!};
            var ds_ti_data_arr = {!! $ds_js_ti_data !!};
            var ds_gm_data_arr = {!! $ds_js_gm_data !!};
            var ds_dt_data_arr = {!! $ds_js_dt_data !!};
            var ds_tod_data_arr = {!! $ds_js_tod_data !!};            
            
            var ds_js_tf_data = {!! $ds_js_tf_data !!};
            
            var ds_pmr_data_arr = {!! $ds_js_pmr_data !!};
            var ds_pmr_color_arr = {!! $ds_js_pmr_color !!};
            
            var ds_pmc_data_arr = {!! $ds_js_pmc_data !!};
            var ds_pmc_color_arr = {!! $ds_js_pmc_color !!};    	
	
				// Daily-Scoop Charts...
				drawCRevenueChart(ds_cu_data_arr);
				drawTicketChart(ds_ti_data_arr);
				drawGMarginChart(ds_gm_data_arr);
				drawDiscountChart(ds_dt_data_arr);
				drawTODChart(ds_tod_data_arr);
				drawFConversionChart();
				drawFStoreVisitChart();
				drawTop5SellersChart(ds_js_tf_data);
				drawPMRevenueChart(ds_pmr_data_arr,ds_pmr_color_arr);
                drawPMContributionChart(ds_pmc_data_arr,ds_pmc_color_arr);
                
				
				// Benchmark Charts...
				drawBRevenueChart(revenue_sales_arr);
				drawBGMarginChart(gross_margin_arr);
				drawBISalesChart(internet_sales_arr);
				drawBATicketsChart(avg_tk_arr);
				drawBMSalesPercentChart(mktg_percent_arr);
				drawBLEfficiencyChart(labor_efficiency_arr);
				drawBITurnsChart(inventory_turns_arr);
				drawBCRatioChart();
				drawBSVisitChart();
				drawBADiscountChart(discounts_percent_arr);
	
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 				Chart Related Function(s) - End
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~	
//-->
</script>
@stop
