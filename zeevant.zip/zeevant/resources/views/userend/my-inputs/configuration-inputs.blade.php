@extends('layouts.userend.userend-layout')

@section('content')
     <!-- Fixed-Variables Start-->
		<div class="row">
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				<div class="row margin_btntwenty">
					<div class="col-md-4">
					  <h1 class="bench_h1">Configuration Inputs</h1>
					</div>
				    {{-- //////////// NEW HTML FIELD(S) [BEGIN] //////////// --}}
                        <form id="frmAddCongigVariable" action="" class="form-horizontal bucket-form" method="post" onsubmit="return add_congig_variable_AJAX()">
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                              <div class="row">
                                <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                                  <div class="row">
                                    <label class="control-label font-size-sisteen" for="inputSuccess">Select Store</label>
                                  </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                  <div class="row">
                                    <select name="i_store" id="i_store" class="form-control pm" onchange="load_congig_data_AJAX()">
                                        <option value="">-- Select --</option>
                                        {!! \App\Helpers\optionHelper::showOptionFranchisees(null, null, null, false) !!}
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                             {{-- //////////// NEW HTML FIELD(S) [END] //////////// --}}
                              <div class="clearfix"></div>
                              
                    
				  <div class="clearfix"></div>
				  
				  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel border_btn">
					 <div id="fixed" class="tab-pane active">
							  <div class="row">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								 
								  <div id="div_config_inputs" class="main_bord">
								  <h4>Variable Costs(%)</h4>
								     
                                     @foreach($config_variable_arr as $config_variable_info)
									      <div class="form-group">
										    
                                            
                                            <label class="col-lg-12" id="s_config_plan" for="s_config_variable_plan">{{ $config_variable_info->s_name }}</label>									      
                                            <input type="text" class="form-control" name="config_variable_marks[]" placeholder="{{ $config_variable_info->s_name }}" value="" />
                                            <span class="text-danger"></span>
                                            <span class="lftflot"></span>
                                              
                                             
									      </div>
                                     @endforeach     
								     
								  </div>
								  
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									
								  <div class="main_bord">
								  <h4>Day-wise Weighted Plan Input(%)</h4>
									
                                     @foreach($config_weighted_arr as $Config_weighted_info)
                                          <div class="form-group">
                                            <label class="col-lg-12" id="s_config_plan" for="s_config_weighted_plan">{{ $Config_weighted_info->s_name }}</label>
                                            
                                              <input type="text" class="form-control" name="config_weighted_marks[]" placeholder="{{ $Config_weighted_info->s_name }}" value="" />
                                              <span class="text-danger"></span>
                                              <span class="lftflot"></span>
                                            
                                          </div>
                                     @endforeach     
                                     
								  </div>
								  
								</div>
								<div class="clearfix"></div>
                                
                                
                               
                                
                                
                                
                                
                                
                                
								<div class="col-lg-12">
									<div class="inner_catgory wow fadeInUp" data-wow-duration="2s">
									<h1 class="bench_h1">Shelf Space Inputs (Area in sq cm)</h1>
										<ul>
										<!-- ////////// Looping Through Parent-Categories [Begin] /////////// -->
										@foreach($categories_arr as $ind=>$parent_category)
											
                                            @if( empty($parent_category['product_sub_group']) )
                                            <li class="margin_btninn">{{ $parent_category['product_group'] }} <span id="totalP_{{ $parent_category['i_id'] }}">&nbsp;</span></li>
											<!-- ======= Looping Through Sub-Categories [If Any] - Begin ======= -->
											@endif
                                            
                                            @if( !empty($parent_category['product_sub_group']) )
												<li>
                                                
												    <div class="form-group">
                                                    <label class="col-lg-6 col-md-6 col-sm-6 col-xs-12">{{ $parent_category['product_sub_group'] }}</label>
													
                                                   <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
														<input type="text" class="form-control" placeholder=" " id="wt_{{ $parent_category['i_id'] }}" name="wt_{{ $parent_category['i_id'] }}" value="">
                                                    <span class="text-danger"></span>
                                                    </div>
                                                    </div>
												</li>
											@endif	
										<!-- ////////// Looping Through Parent-Categories [End] /////////// -->
										@endforeach
										</ul>
									</div>
								</div>
								<div class="clearfix"></div>
								<div class="col-lg-12 text-center">
									<input type="submit" class="btn btn-primary" value="Submit" />
								</div>
							  </div>
							</div>
				  </section>
				  </div>
				  </form>
				</div>
				<div class="clearfix"></div>
			  </section>
			  <!--End Product Mix Top Part-->
			</div>
        </div>
     <!-- Fixed-Variables Part-->
@endsection

@section('page-specific-scripts')
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/my-inputs/my_inputs.js') !!}
    <!-- Page Specific -->
    {!! Html::script('userend-resources/js/custom-scripts/my-inputs/config_variable_plan.js') !!}
@stop
