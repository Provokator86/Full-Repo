@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!-- Monthly-KPI-Plan Part-->
		  <div class="row">
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				<div class="row margin_btntwenty">
					<div class="col-md-4">
						<h1 class="bench_h1">Monthly KPI Plan</h1>
					</div>
					{{-- //////////// NEW HTML FIELD(S) [BEGIN] //////////// --}}
						<form id="frmAddKPIPlan" action="" class="form-horizontal bucket-form" method="post" onsubmit="return add_KPI_plan_AJAX()">
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
							  <div class="row">
								<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
								  <div class="row">
									<label class="control-label font-size-sisteen" for="inputSuccess">Select Store</label>
								  </div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								  <div class="row">
									<select name="i_store" id="i_store" class="form-control pm" onchange="load_KPI_plan_data_AJAX()">
										<option value="">-- Select --</option>
										{{--*/ $selected_store = ( !empty($selected_store) )? $selected_store: ''  /*--}}
										{!! \App\Helpers\optionHelper::showOptionFranchisees(null, null, null, false) !!}
									</select>
								  </div>
								</div>
							  </div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="lft_arrow">Select Month<a id="calendar_icon" href="#"><i class="fa fa-calendar"></i></a> <span class="lbl_dt_marker_small" id="lbl_dt">Aug 15</span> </div>
							</div>
					{{-- //////////// NEW HTML FIELD(S) [END] //////////// --}}
							  <div class="clearfix"></div>
							  
							  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
								<section class="panel border_btn">
								  <div id="monthly" class="tab-pane ">
									<div id="div_kpi_plans" class="main_bord ">
										<div class="row">
										{{--*/ $column_index = 1 /*--}}
										{{--*/ $sub_column_index = 1 /*--}}
										{{--*/ $CSS_CLASS = "" /*--}}
										@foreach($KPI_arr as $KPI_info)
											@if($column_index==2)
												{{--*/ $CSS_CLASS = "col-md-offset-1" /*--}}
												{{--*/ $column_index = 1 /*--}}
											@else
												{{ $CSS_CLASS = "" }}
												{{--*/ $column_index++ /*--}}
											@endif
											{{--*/ $KPI_VAL = ( !empty($KPI_info['kpi_plan_val']) )? $KPI_info['kpi_plan_val']: ''  /*--}}
											{{--*/ $FLAG = ( !empty($KPI_info['e_flag']) )? TRUE: FALSE  /*--}}
											@if($sub_column_index==1)
											<div class="col-md-5 {{ $CSS_CLASS }}">
											@endif
												@if( $FLAG )
													@if($sub_column_index==2)
														{{--*/ $SUB_CSS_CLASS = "col-md-offset-1" /*--}}
														{{--*/ $column_index = 1 /*--}}
														{{--*/ $sub_column_index = 1 /*--}}
													@else
														{{ $SUB_CSS_CLASS = "" }}
														{{--*/ $sub_column_index++ /*--}}
													@endif
													<div class="col-md-5 {{ $SUB_CSS_CLASS }}">
														<div class="form-group">
															<label id="s_kpi_plan_lbl" for="s_kpi_plan">{{ $KPI_info['s_name'] }}</label>
															<input type="text" class="form-control" name="kpi_marks[]" placeholder="{{ $KPI_info['s_placeholder'] }}" min-range="{{ $KPI_info['d_range_min_val'] }}" max-range="{{ $KPI_info['d_range_max_val'] }}" value="{{ $KPI_VAL }}" />
															<span class="text-danger"></span>
														</div>
													</div>
												@else
													<div class="form-group">
														<label id="s_kpi_plan_lbl" for="s_kpi_plan">{{ $KPI_info['s_name'] }}</label>
														<input type="text" class="form-control" name="kpi_marks[]" placeholder="{{ $KPI_info['s_placeholder'] }}" min-range="{{ $KPI_info['d_range_min_val'] }}" max-range="{{ $KPI_info['d_range_max_val'] }}" value="{{ $KPI_VAL }}" />
														<span class="text-danger"></span>
													</div>
												
												@endif
											@if($sub_column_index==1)
											</div>
											@endif                                     
										@endforeach
										</div>
									</div>
									<div class="clearfix"></div>
									<div class="col-lg-12 text-center twenty_margin">
										<input type="submit" class="btn btn-primary" value="Submit" />
									</div>
									
								  </div>
							  </section>
							  </div>
							  <input type="hidden" name="i_month" id="i_month" />
							  <input type="hidden" name="i_year" id="i_year" />
							</form>
				</div>
				<div class="clearfix"></div>
			  </section>
			  <!--End Product Mix Top Part-->
			</div>
		  </div>
	  <!-- Monthly-KPI-Plan Part-->
@endsection

@section('page-specific-scripts')
	<!-- jQuery jStepper -->
	{!! Html::script('userend-resources/js/jquery.jstepper.min.js') !!}
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/my-inputs/KPI_plan.js') !!}
@stop
