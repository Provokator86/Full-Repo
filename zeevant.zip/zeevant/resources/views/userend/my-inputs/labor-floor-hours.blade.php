@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!-- Start Labor-Floor-Hours Part-->
		  <div class="row"> 
			<!--Full Width Part Start-->
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				  <form id="frmLaborFloorHours" method="post" onsubmit="return validate_form_AJAX()">

					<div class="row margin_btntwenty">
					  <div class="col-md-3">
						<h1 class="bench_h1">Labor Floor Hours</h1>
					  </div>
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						  <div class="row">
							<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
							  <div class="row">
								<label class="control-label font-size-sisteen" for="inputSuccess">Select Store</label>
							  </div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							  <div class="row">
								<select name="i_store" id="i_store" class="form-control pm" onchange="load_floor_hours_data_AJAX()">
									<option value="">-- Select --</option>
									{!! \App\Helpers\optionHelper::showOptionFranchisees(null, null, null, false) !!}
								</select>
							  </div>
							</div>
						  </div>
						</div>
					  <div class="col-md-5">
							<div class="lft_arrow"><strong>Select from an year and month </strong><a id="calendar_icon" href="#"><i class="fa fa-calendar"></i></a> <a id="prev_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_dt">Aug 15</span> <a id="next_dt" href="#"><i id="nxt_month" class="fa fa-angle-right"></i></a> </div>
					  </div>
					  <div class="clearfix"></div>
					  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
						<section class="panel border_btn">
						  <div id="standard" class="tab-pane ">
							<section id="stander">
							  <div class="container">
								<div class="row">
								  <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
									<div class="form-group" id="div_labor_hrs">
									  <label class="col-lg-3 lab_lin">Floor Labor Hours (actual)</label>
									  <div class="col-lg-6 box_part_flo act-lb-hr" id="input_labor_hrs">
										<input type="text" placeholder=" " id="d_labor_hours" name="d_labor_hours" class="form-control inp_flo" value="" />
									  </div>
									  <label class="col-lg-3 lab_lin"> (in hours)</label>

										<div class="clearfix"></div>
										<div class="col-lg-12 text-center twenty_margin">
											<p align="center">
												<input type="hidden" name="i_month" id="i_month" value="" />
												<input type="hidden" name="i_year" id="i_year" value="" />
												<input id="btn_submit" type="submit" class="btn btn-primary" value="Submit" />
											</p>
										</div>

									</div>
								  </div>
								</div>
							  </div>
							  
							</section>
						  </div>
						</section>
					  </div>
					</div>
					<div class="clearfix"></div>
				  </form>
			  </section>
			  <!--End Product Mix Top Part--> 
			</div>
			<!--End Left Part--> 
		  </div>
      <!-- End Labor-Floor-Hours Part-->
    
    <!-- ========= Modal Message Div [Begin] ========= -->
		<div id="question" style="display:none;cursor:default;"> 
			<h1 id="modal_msg"></h1> 
			<input type="button" id="ok" value="OK" class="btn btn-primary"/> 
		</div>
    <!-- ========= Modal Message Div [End] ========= -->
    
@endsection

@section('page-specific-scripts')
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/my-inputs/labor_floor_hours.js') !!}
@stop
