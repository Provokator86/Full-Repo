@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!-- Start Monthly-Financials Part-->
		  <div class="row"> 
			<!--Full Width Part Start-->
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				  <form id="frmMonthlyFinancials" method="post" onsubmit="return validate_form_AJAX()">

					<div class="row margin_btntwenty">
					  <div class="col-md-3">
						<h1 class="bench_h1">Monthly Financials</h1>
					  </div>
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						  <div class="row">
							<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
							  <div class="row">
								<label class="control-label font-size-sisteen" for="inputSuccess">Select Store</label>
							  </div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							  <div class="row">
								<select name="i_store" id="i_store" class="form-control pm" onchange="load_monthly_financials_data_AJAX()">
									<option value="">-- Select --</option>
									{!! \App\Helpers\optionHelper::showOptionFranchisees(null, null, null, false) !!}
								</select>
							  </div>
							</div>
						  </div>
						</div>
					  <div class="col-md-5">
							<div class="lft_arrow"><strong>Select from an year and month </strong><a id="calendar_icon" href="#"><i class="fa fa-calendar"></i></a> <a id="prev_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_dt">Aug 15</span> <a id="next_dt" href="#"><i id="nxt_month" class="fa fa-angle-right"></i></a> </div>
					  </div>
					  <div class="clearfix"></div>
					  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
						<section class="panel border_btn">
						  <div id="standard" class="tab-pane ">
							<section id="stander">
							  
						  <section class="panel border_btn">
							<header class="panel-heading tab-bg-dark-navy-blue" id="my_input">
							  <ul class="nav nav-tabs nav-justified ">
								<li class="active"> <a data-toggle="tab" href="#fixed">Standardized Balance Sheet</a> </li>
								<li> <a data-toggle="tab" href="#monthly">Standardized Income Statement</a> </li>
							  </ul>
							</header>
							<div class="panel-body">
							  <div id="div_monthly_financials" class="tab-content tasi-tab">
									<!-- ************* Balance-Sheet [Begin] ************* -->
										<div id="fixed" class="tab-pane active">
										  <p id="lbl_bsheet_modified" align="right">&nbsp;</p>
										  <div>									  
											<table class="table table-bordered table-striped table-condensed" align="center">
											  <thead>
												<tr>
												  <th colspan="4">Account #</th>
												  <th>&nbsp;</th>
												  <th>Amount</th>
												</tr>
											  </thead>
											  <tbody>
												<tr>
												  <td>10000</td>
												  <td colspan="4" align="left">Assets</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>11000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Current Assets</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>11100</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Cash & Investments</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>11101</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td>Cash Drawer</td>
												  <td class="col-xs-2">
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11101: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="cash-N-investment" name="d_bs_11101" id="d_bs_11101" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>11102</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td>Additional Cash & Investments</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11102: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="cash-N-investment" name="d_bs_11102" id="d_bs_11102" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="3" width="160">&nbsp;</td>
												  <td class="bg_color" colspan="2"><strong>TOTAL CASH & INVESTMENTS</strong></td>
												  <td class="bg_color" id="lbl_total_cash_N_investments">
												  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_11100 .'</lbl>': '' /*--}}
												  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>11200</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Account Receivable</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11200: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-current-assets" name="d_bs_11200" id="d_bs_11200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>11300</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Inventory</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11300: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-current-assets" name="d_bs_11300" id="d_bs_11300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>11400</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Other Current Assets</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>11401</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td>Undeposited Funds</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11401: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-current-assets" name="d_bs_11401" id="d_bs_11401" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>11402</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td>&nbsp;</td>
												  <td>Additional Other Current Assets</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_11402: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-current-assets" name="d_bs_11402" id="d_bs_11402" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="3" width="160">&nbsp;</td>
												  <td class="bg_color" colspan="2"><strong>TOTAL Other Current Assets</strong></td>
												  <td class="bg_color" id="lbl_total_other_current_assets">
													  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_11400 .' </lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr style="border-top:1px solid #ddd;">
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>TOTAL Current Assets</strong></td>
												  <td class="bg_color" id="lbl_total_current_assets">
													  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_11000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>12000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Fixed Assets</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_12000: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-assets" name="d_bs_12000" id="d_bs_12000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>13000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other Assets</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_13000: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-assets" name="d_bs_13000" id="d_bs_13000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td width="80">&nbsp;</td>
												  <td colspan="4" class="bg_color "><strong>TOTAL Assets</strong></td>
												  <td class="bg_color" id="lbl_total_assets">
													  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_10000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>20000</td>
												  <td colspan="4">Liabilities &amp; Equity</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>21000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Current Liabilities</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>21101</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Accounts Payable</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_21101: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="current-liabilities" name="d_bs_21101" id="d_bs_21101" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>21102</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Gift Card Liabilities</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_21102: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="current-liabilities" name="d_bs_21102" id="d_bs_21102" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>21104</td>
												  <td width="40">&nbsp;</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="2">Other Current Liabilities</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_21104: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="current-liabilities" name="d_bs_21104" id="d_bs_21104" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="2" width="120">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>TOTAL Current Liabilities</strong></td>
												  <td class="bg_color" id="lbl_total_current_liabilities">
													  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_21000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>22000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Long Term Liabilities</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_22000: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-liabilities" name="d_bs_22000" id="d_bs_22000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>30000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Equity</td>
												  <td>
													{{--*/ $VAL = ( !empty($bsheet_arr) )? $bsheet_arr->d_bs_30000: '' /*--}}
													@if( $bsheet_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-liabilities" name="d_bs_30000" id="d_bs_30000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td width="80">&nbsp;</td>
												  <td class="bg_color" colspan="4"><strong>TOTAL Liabilities AND Equity</strong></td>
												  <td class="bg_color" id="lbl_total_liabilities_N_equity">
													  {{--*/ $VAL = ( !empty($bsheet_arr) )? '$ <lbl>'. $bsheet_arr->d_bs_20000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
											  </tbody>
											</table>									  
										  </div>
										
										<!-- ///////////// "Lock It" Part [Begin] ///////////// -->
											<div class="clearfix"></div>
											<div class="text-center twenty_margin">
												
												  @if ( $logged_usr_type==2 )
													{{--*/ $CHKBOX_STATUS = '' /*--}}
													@if( !empty($istmt_arr) )
														{{--*/ $CHKBOX_STATUS = ( $bsheet_arr->i_locked )? 'checked': '' /*--}}
													@endif
														<p class="tbl-para-class">
															<input type="checkbox" name="i_bsheet_locked" id="i_bsheet_locked" value="1" {{ $CHKBOX_STATUS }} />&nbsp;Lock It
														</p>
												  @endif
													
														<p class="tbl-para-class">
															<span id="bsheet_certify_msg"><input type="checkbox" name="i_bsheet_agree" id="i_bsheet_agree" value="1" />&nbsp;I certify this Balance-Sheet data is true &amp; accurate</span>
															<input type="hidden" name="bsheet_mode" id="bsheet_mode" value="{{ $bsheet_mode }}" />
														</p>
													 
											
											</div>
										<!-- ///////////// "Lock It" Part [End] ///////////// -->
										
										</div>
									<!-- ************* Balance-Sheet [End] ************* -->
											

									<!-- ************* Income-Statement [Begin] ************* -->
										<div id="monthly" class="tab-pane ">
										  <p id="lbl_istmt_modified" align="right">&nbsp;</p>
										  <div>
											<table class="table table-bordered table-striped table-condensed" align="center">
											  <thead>
												<tr>
												  <th colspan="4">Account #</th>
												  <th>&nbsp;</th>
												  <th>Amount</th>
												</tr>
											  </thead>
											  <tbody>
												<tr>
												  <td>40000</td>
												  <td colspan="4" align="left">Revenue</td>
												  <td>&nbsp;</td>
												</tr>
												
												<tr>
												  <td>40100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Merchandise Sales</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_40100: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="revenue" name="d_is_40100" id="d_is_40100" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>40200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Online Sales</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_40200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="revenue" name="d_is_40200" id="d_is_40200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>40300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other Income</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_40300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="revenue" name="d_is_40300" id="d_is_40300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>TOTAL REVENUE</strong></td>
												  <td class="bg_color" id="lbl_total_revenue">
													  {{--*/ $VAL = ( !empty($istmt_arr) )? '$ <lbl>'. $istmt_arr->d_is_40000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>50000</td>
												  <td colspan="4" align="left">Cost of Goods Sold</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>50100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Products Purchased (Stocked)</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50100: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50100" id="d_is_50100" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>50200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Products Purchased (Non-Stocked) </td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50200" id="d_is_50200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>50300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">POS Inventory Adjustments</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50300" id="d_is_50300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>50400</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Freight In - Inventory Purchases</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50400: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50400" id="d_is_50400" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>50500</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Merchant Account Fees</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50500: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50500" id="d_is_50500" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>50600</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other COGS</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_50600: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="COGS" name="d_is_50600" id="d_is_50600" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>TOTAL COST OF GOODS SOLD</strong></td>
												  <td class="bg_color" id="lbl_total_cost_of_goods_sold">
													  {{--*/ $VAL = ( !empty($istmt_arr) )? '$ <lbl>'. $istmt_arr->d_is_50000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>60000</td>
												  <td colspan="4" align="left">Expenses</td>
												  <td>&nbsp;</td>
												</tr>
												<tr>
												  <td>60100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Advertising & Promotion</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_advt_N_promotion: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60100" id="d_advt_N_promotion" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Amoritization</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60200" id="d_is_60200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Bank Service Charges</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60300" id="d_is_60300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60400</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Business Licenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60400: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60400" id="d_is_60400" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60500</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Charitable Contributions</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60500: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60500" id="d_is_60500" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60600</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Computer SW, Supplies & Services</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60600: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60600" id="d_is_60600" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60700</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Depreciation</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60700: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60700" id="d_is_60700" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60800</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Displays, Decor, Furn, Eqt.</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60800: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60800" id="d_is_60800" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>60900</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Dues & Subscriptions</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_60900: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_60900" id="d_is_60900" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Franchise Royalties</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61000: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61000" id="d_is_61000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Franchise SDF</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61100: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61100" id="d_is_61100" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">HR/Recruiting Expenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61200" id="d_is_61200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Insurance Expense</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61300" id="d_is_61300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61400</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Interest Expense</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61400: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61400" id="d_is_61400" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61500</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Janitorial Expense</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61500: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61500" id="d_is_61500" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61600</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Meals and Entertainment</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61600: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61600" id="d_is_61600" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61700</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Office Supplies</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61700: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61700" id="d_is_61700" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61800</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Payroll Expenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61800: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61800" id="d_is_61800" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>61900</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Postage & Delivery</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_61900: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_61900" id="d_is_61900" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62000</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Professional Expenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62000: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62000" id="d_is_62000" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Rent Expense</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62100: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62100" id="d_is_62100" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Repairs & Mainteance</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62200" id="d_is_62200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Training & Education</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62300" id="d_is_62300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62400</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Travel & Entertainment</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62400: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62400" id="d_is_62400" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62500</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Uniforms</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62500: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62500" id="d_is_62500" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62600</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Utilities</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62600: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62600" id="d_is_62600" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>62700</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other Expenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_62700: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="expenses" name="d_is_62700" id="d_is_62700" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>TOTAL EXPENSES</strong></td>
												  <td class="bg_color" id="lbl_total_expenses">
													  {{--*/ $VAL = ( !empty($istmt_arr) )? '$ <lbl>'. $istmt_arr->d_is_60000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												<tr>
												  <td>80000</td>
												  <td colspan="4" align="left">Other Income/Expense</td>
												  <td>&nbsp;</td>
												</tr>
												
												<tr>
												  <td>80100</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Ask My Accountant</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_80100: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-income" name="d_is_80100" id="d_is_80100" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>80200</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other Income</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_80200: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-income" name="d_is_80200" id="d_is_80200" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td>80300</td>
												  <td width="40">&nbsp;</td>
												  <td colspan="3">Other Expenses</td>
												  <td>
													{{--*/ $VAL = ( !empty($istmt_arr) )? $istmt_arr->d_is_80300: '' /*--}}
													@if( $istmt_mode=='view-only' )
														@if( !empty($VAL) )
															$ <span>{{ $VAL }}</span>
														@endif
													@else
														$ <input type="text" class="txtbox-small" sum-group="other-income" name="d_is_80300" id="d_is_80300" value="{{ $VAL }}" />
													@endif
												  </td>
												</tr>
												<tr>
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color"><strong>TOTAL OTHER INCOME/EXPENSES</strong></td>
												  <td class="bg_color" id="lbl_total_other_income_N_expenses">
													  {{--*/ $VAL = ( !empty($istmt_arr) )? '$ <lbl>'. $istmt_arr->d_is_80000 .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
												
												<tr>
												  <td colspan="6">&nbsp;</td>
												</tr>
												<tr>
												  <td colspan="2" width="80">&nbsp;</td>
												  <td colspan="3" class="bg_color "><strong>NET INCOME</strong></td>
												  <td class="bg_color" id="lbl_net_income">
													  {{--*/ $VAL = ( !empty($istmt_arr) )? '$ <lbl>'. $istmt_arr->d_net_income .'</lbl>': '' /*--}}
													  <strong>{!! $VAL !!}</strong>
												  </td>
												</tr>
											  </tbody>
											</table>							  
										  </div>
										
										<!-- ///////////// "Lock It" Part [Begin] ///////////// -->
											<div class="clearfix"></div>
											<div class="col-lg-12 text-center twenty_margin">

												  @if ( $logged_usr_type==2 )
													{{--*/ $CHKBOX_STATUS = '' /*--}}
													@if( !empty($istmt_arr) )
														{{--*/ $CHKBOX_STATUS = ( $istmt_arr->i_locked )? 'checked': '' /*--}}
													
													@endif

														<p class="tbl-para-class">
															<input type="checkbox" name="i_istmt_locked" id="i_istmt_locked" value="1" {{ $CHKBOX_STATUS }} />&nbsp;Lock It
														</p>

												  @endif

														<p class="tbl-para-class">
															<span id="istmt_certify_msg"><input type="checkbox" name="i_istmt_agree" id="i_istmt_agree" value="1" />&nbsp;I certify this Income-Statement data is true &amp; accurate</span>
															<input type="hidden" name="istmt_mode" id="istmt_mode" value="{{ $istmt_mode }}" />
														</p>
												
											</div>
										<!-- ///////////// "Lock It" Part [End] ///////////// -->
										
										</div>
									<!-- ************* Income-Statement [End] ************* -->	
									
											
								</div>
								
								<div class="clearfix"></div>
								<div class="col-lg-12 text-center twenty_margin">
									<p align="center">
										<input type="hidden" name="i_month" id="i_month" value="" />
										<input type="hidden" name="i_year" id="i_year" value="" />
										<input id="btn_submit" type="submit" class="btn btn-primary" value="Submit" />
									</p>
							    </div>
							</div>
						  </section>
							  
							</section>
						  </div>
						</section>
					  </div>
					</div>
					<div class="clearfix"></div>
				  </form>
			  </section>
			  <!--End Product Mix Top Part--> 
			</div>
			<!--End Left Part--> 
		  </div>
      <!-- End Monthly-Financials Part-->
    
    <!-- ========= Modal Message Div [Begin] ========= -->
		<div id="question" style="display:none;cursor:default;"> 
			<h1 id="modal_msg"></h1> 
			<input type="button" id="ok" value="OK" class="btn btn-primary"/> 
		</div>
    <!-- ========= Modal Message Div [End] ========= -->
    
@endsection

@section('page-specific-scripts')
	<!-- Bootstrap Date-Picker -->
	{!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/my-inputs/monthly_financials.js') !!}
	{!! Html::script('userend-resources/js/custom-scripts/my-inputs/monthly_financials_calculate_sum.js') !!}
@stop
