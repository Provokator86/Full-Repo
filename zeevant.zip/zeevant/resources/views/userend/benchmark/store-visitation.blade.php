@extends('layouts.userend.userend-layout')

@section('content')
      <!--Start Store-Visitation Part-->
		  <div class="row">
			<!--Full Width Part Start-->
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel" id="bench">
				<div class="margin_btntwenty">
				  <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<div class="row">
					  <h1 class="bench_h1">Benchmark Drill Down - Store Visitations [Based on 50 stores data]</h1>
					</div>
				  </div>
				  <div class="col-md-4">
						  <div class="lft_arrow"> <a id="prev_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_dt">Aug 15</span> <a id="next_dt" href="#"><i class="fa fa-angle-right"></i></a>  <a class="grap_two" href="#">&nbsp;
	</a><a class="grap_one active" href="#">&nbsp;</a> </div>
						</div>
				</div>
				<div class="clearfix"></div>
				<!-- ///////////// PANEL I ///////////// -->
				<div class="row" id="chart_grap_one">
				  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Average of All Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_ar" loader-class="preloader_allR" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_allR">&nbsp;</div>
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 10 (in Store Visitations) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_rtop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top10">&nbsp;</div>
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 10 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_r_revenuetop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top10">&nbsp;</div>
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 5 (in Store Visitations) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_rtop5" loader-class="preloader_top5" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top5">&nbsp;</div>
					  </div>
					</section>
				  </div>
				  
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 5 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_r_revenuetop5" loader-class="preloader_top5" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top5">&nbsp;</div>
					  </div>
					</section>
				  </div>
				  
				  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - Last 12 Months Analysys<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="bm_last_rev_analysis" class="panel-body" loader-class="preloader_allR">
						<div class="img_brd"> <img src="{{ asset('userend-resources/img/brd2.jpg') }}"> </div>
					  </div>
					</section>
				  </div>
				  
				</div>
			  
			  
				<!-- ///////////// PANEL II ///////////// -->
				<div class="row" id="chart_grap_two" style="display:none;">
				  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Average of All Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_ar" class="panel-body" loader-class="preloader_allR" style="width: 100%; margin: 0 auto;">
						<div class="preloader_allR">&nbsp;</div>
						<!--<div class="img_brd"> <img src="img/brd1.jpg"> </div>-->
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 10 (in Store Visitations) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_rtop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top10">&nbsp;</div>
						<!--<div class="img_brd1"> <img src="img/brd1_1.jpg"> </div>-->
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 10 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_r_revenuetop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top10">&nbsp;</div>
						<!--<div class="img_brd1"> <img src="img/brd1_2.jpg"> </div>-->
					  </div>
					</section>
				  </div>
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 5 (in Store Visitations) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_rtop5" class="panel-body" loader-class="preloader_top5" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top5">&nbsp;</div>
						<!--<div class="img_brd1"> <img src="img/brd1_3.jpg"> </div>-->
					  </div>
					</section>
				  </div>
				  
				  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - My Store vs Top 5 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_r_revenuetop5" class="panel-body" loader-class="preloader_top5" style="width: 100%; margin: 0 auto;">
						<div class="preloader_top5">&nbsp;</div>
						<!--<div class="img_brd1"> <img src="img/brd1_4.jpg"> </div>-->
					  </div>
					</section>
				  </div>
				  
				  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					<section class="panel round_border">
					  <header class="panel-heading">Visitations - Last 12 Months Analysys<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					  <div id="hst_analysis" class="panel-body" loader-class="preloader_allR">
						<div class="img_brd"> <img src="{{ asset('userend-resources/img/brd2.jpg') }}"> </div>
					  </div>
					</section>
				  </div>
				  
				</div>
			  
			  </section>
			  <!--End Product Mix Top Part-->
			</div>
			<!--End Left Part-->
			
			
			<!--Table Section start-->
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				 <section class="panel plan_border">
					<header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
					<div class="panel-body">
							<section id="unseen_tebl">
								<table class="table table-bordered table-striped table-condensed">
								   
									<thead>
									<tr>
										<th>Month</th>
										<th class="num">Revenue ($)</th>
										<th class="num">Actual Plan ($)</th>
										<th class="num">(+/-) in percentage</th>
									  </tr>
									</thead>
									
									<tbody>
									
									<tr>
										<td><p>Oct'14</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+3%</p></td>
									</tr>
									
									<tr>
										<td><p>Nov'14</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4900.00</p></td>
										<td class="num"><p>+1.25%</p></td>
									</tr>
									
									<tr>
										<td><p>Dec'14</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+3%</p></td>
									</tr>
									
									<tr>
										<td><p>Jan'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,9800.00</p></td>
										<td class="num"><p>+1.55%</p></td>
									</tr>
									
									<tr>
										<td><p>Feb'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+3%</p></td>
									</tr>
									
									<tr>
										<td><p>Mar'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,3800.00</p></td>
										<td class="num"><p>+1.75%</p></td>
									</tr>
									
									<tr>
										<td><p>Apr'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,3000.00</p></td>
										<td class="num"><p>+3%</p></td>
									</tr>
									
									<tr>
										<td><p>May'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+1.30%</p></td>
									</tr>
									
									<tr>
										<td><p>Jun'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+1.75%</p></td>
									</tr>
									
									<tr>
										<td><p>July'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+1.75%</p></td>
									</tr>
									
									<tr>
										<td><p>Aug'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+1.75%</p></td>
									</tr>
									
									<tr>
										<td><p>Sep'15</p></td>
										<td class="num"><p>79,4800.00</p></td>
										<td class="num"><p>78,4800.00</p></td>
										<td class="num"><p>+3%</p></td>
									</tr>
									
								   </tbody>
								</table>
							</section>
						</div>
				  </section>
			 </div>
			  <!--Table Section end-->
		  </div>
      <!--End Store-Visitation Part-->
@endsection

@section('page-specific-scripts')
    <!-- Chart Related -->
	{!! Html::script('https://www.google.com/jsapi') !!}
	{!! Html::script('userend-resources/js/charts/visitations/generate_common_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/visitations/common_charts_config.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/benchmark/benchmark_store_visitation.js') !!}
@stop