@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- Bootstrap Date-Picker -->
    {!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
  <!--Start Percentage-Sales Part-->
	
	<!-- ************** Store(s) Selection [Begin] ************** -->
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel" id="select-store">
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
						<label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<select class="form-control pm" id="i_store" name="i_store" onchange="load_data_AJAX()">
							{!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
						</select>
					</div>
				</section>
			</div>
		</div>                        
	<!-- ************** Store(s) Selection [End] ************** -->
	

	<div class="row">
		<!--Full Width Part Start-->
		<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
		  <section class="panel" id="bench">
			<div class="margin_btntwenty">
			  <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<div class="row">
				  <h1 class="bench_h1">Benchmark Drill Down - Percentage Sales [Based on {{$total_no_of_shops}} stores data]</h1>
				</div>
			  </div>
			  <div class="col-md-4">
					  <div class="lft_arrow"> <a id="prev_dt" href="#"><i class="fa fa-angle-left"></i></a><span class="lbl_dt_marker_small" id="lbl_dt">{{ $default_month_scroller_dt }}</span> <a id="next_dt" href="#"><i class="fa fa-angle-right"></i></a>  <a class="grap_two" href="#">&nbsp;
		</a><a class="grap_one active" href="#">&nbsp;</a></div>
					  <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
						<input type="hidden" name="i_month" id="i_month" value="" />
						<input type="hidden" name="i_year" id="i_year" value="" />
					  <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
					</div>
			</div>
			<div class="clearfix"></div>
			
			<div id="BM_percentage_sales_dist_charts">
			<!-- ///////////// PANEL I ///////////// -->
			<div class="row" id="chart_grap_one">
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Average of All Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_ar" loader-class="preloader_allR" class="panel-body" style="width: 100%; margin: 0 auto;">
					 <div class="preloader_allR">&nbsp;</div>
					<!--<div class="img_brd"> <img src="img/brd1.jpg"> </div>-->
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 10 (in Margin) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_rtop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top10">&nbsp;</div>
					<!--<div class="img_brd1"> <img src="img/brd1_1.jpg"> </div>-->
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 10 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_r_revenuetop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top10">&nbsp;</div>
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 5 (in Margin) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_rtop5" loader-class="preloader_top5" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top5">&nbsp;</div>
				  </div>
				</section>
			  </div>
			  
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 5 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_r_revenuetop5" loader-class="preloader_top5" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top5">&nbsp;</div>
				  </div>
				</section>
			  </div>
			  
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - Last 12 Months Analysys<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="bm_last_rev_analysis" class="panel-body" loader-class="preloader_allR">
					<div class="img_brd"> <img src="{{ asset('userend-resources/img/brd2.jpg') }}"> </div>
				  </div>
				</section>
			  </div>
			  
			</div>
		  
		  
			<!-- ///////////// PANEL II ///////////// -->
			<div class="row" id="chart_grap_two" style="display:none;">
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Average of All Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_ar" class="panel-body" loader-class="preloader_allR" style="width: 100%; margin: 0 auto;">
					<div class="preloader_allR">&nbsp;</div>
					<!--<div class="img_brd"> <img src="img/brd1.jpg"> </div>-->
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 10 (in Margin) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_rtop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top10">&nbsp;</div>
					<!--<div class="img_brd1"> <img src="img/brd1_1.jpg"> </div>-->
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 10 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_r_revenuetop10" loader-class="preloader_top10" class="panel-body" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top10">&nbsp;</div>
					<!--<div class="img_brd1"> <img src="img/brd1_2.jpg"> </div>-->
				  </div>
				</section>
			  </div>
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 5 (in Margin) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_rtop5" class="panel-body" loader-class="preloader_top5" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top5">&nbsp;</div>
				  </div>
				</section>
			  </div>
			  
			  <div class="col-md-6 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - My Store vs Top 5 (In Revenue) Stores<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_r_revenuetop5" class="panel-body" loader-class="preloader_top5" style="width: 100%; margin: 0 auto;">
					<div class="preloader_top5">&nbsp;</div>
				  </div>
				</section>
			  </div>
			  
			  <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
				<section class="panel round_border">
				  <header class="panel-heading">Percentage Sales - Last 12 Months Analysys<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
				  <div id="hst_analysis" class="panel-body" loader-class="preloader_allR">
					<div class="img_brd"> <img src="{{ asset('userend-resources/img/brd2.jpg') }}"> </div>
				  </div>
				</section>
			  </div>
			  
			</div>
			</div>
		  </section>
		  <!--End Product Mix Top Part-->
		</div>
		<!--End Left Part-->

		
	</div>
  
  <!--End Percentage-Sales Part-->
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
	{!! Html::script('https://www.google.com/jsapi') !!}
	{!! Html::script('userend-resources/js/charts/BM/percent-sales/generate_common_charts.js') !!}
	{!! Html::script('userend-resources/js/charts/BM/percent-sales/common_charts_config.js') !!}
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/benchmark/benchmark_percentage_sales.js') !!}
@stop


@section('inline-footer-js')
<script type="text/javascript">
<!--
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - Begin
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        var all_ND_data = {!! $all_ND_data_arr !!};
        var top_10_ND_data = {!! $top_10_ND_data_arr !!};
        var top_5_ND_data = {!! $top_5_ND_data_arr !!};
        var top_10_ND_revenue_data = {!! $top_10_ND_revenue_data_arr !!};
        var top_5_ND_revenue_data = {!! $top_5_ND_revenue_data_arr !!};
        
        var last_12_months_data = {!! $last_12_months_data_arr !!};
    
        var all_column_data = {!! $all_column_data_arr !!};
        var top_10_column_data = {!! $top_10_column_data_arr !!};
        var top_5_column_data = {!! $top_5_column_data_arr !!};
        var top_10_revenue_column_data = {!! $top_10_revenue_column_data_arr !!};
        var top_5_revenue_column_data = {!! $top_5_revenue_column_data_arr !!};

        //// For "Normally-Distributed" Chart(s) [Begin]
        drawRAllStoresChart(all_ND_data);
        drawRTop10StoresChart(top_10_ND_data);
        drawRTop5StoresChart(top_5_ND_data);
        drawRTop10RevenueStoresChart(top_10_ND_revenue_data);
        drawRTop5RevenueStoresChart(top_5_ND_revenue_data);
        
        // One fixed chart...
        drawRAnalysisChart(last_12_months_data);
        //// For "Normally-Distributed" Chart(s) [End]
        
        
        
        //// For "Column" Chart(s) [Begin]
        drawCAllStoresChart(all_column_data);
        drawCTop10StoresChart(top_10_column_data);
        drawCTop5StoresChart(top_5_column_data);
        drawCTop10RevenueStoresChart(top_10_revenue_column_data);
        drawCTop5RevenueStoresChart(top_5_revenue_column_data);
    
        // One fixed chart...
        drawCAnalysisChart(last_12_months_data);
            
        //// For "Column" Chart(s) [End]
        
    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - End
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
//-->
</script>
@stop