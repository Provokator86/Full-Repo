@extends('layouts.userend.userend-layout')

@section('page-specific-css')
    <!-- jquery-confirm -->
	{!! Html::style('admin-resources/dist/js/jquery-confirm/jquery.confirm.css') !!}
	{!! Html::style('http://fonts.googleapis.com/css?family=Cuprum&subset=latin') !!}
@endsection

@section('content')
	<div class="row">
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
            <div class="margin_btntwenty">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="row">
						<h1 class="bench_h1">Manage Field-Consultant(s)</h1>
					</div>
				</div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  <div class="row lft_arrow">
					<button id="back_btn" class="btn btn-warning" type="button">
						<i class="fa fa-fw fa-angle-double-left"></i>Back
					</button>
					<button id="add-franchisee-user" class="btn btn-primary" type="button">Add Field-Consultant</button>
				  </div>
                </div>
            </div>
            <div class="clearfix"></div>
			
			<!-- ///////////// TABLE LISTING [START] ///////////// -->
				<div class="row">
					<section class="panel plan_border">
						<header class="panel-heading">&nbsp;<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
						<div class="panel-body">
							<section id="unseen_tebl">
								@include('userend.franchisee.ajax-parts.field-executives-listing-ajax')
							</section>
						</div>
					</section>
				</div>
			<!-- ///////////// TABLE LISTING [END] ///////////// -->

		  </section>
          <!--End Table Part-->
        </div>	
	</div><!-- /.row -->
@endsection

@section('page-specific-scripts')
    <!-- jquery-confirm -->
	{!! Html::script('admin-resources/dist/js/jquery-confirm/jquery.confirm.js') !!}
    <!-- Custom-Scripts -->
	{!! Html::script('userend-resources/js/custom-scripts/franchisee/manage-field-executives.js') !!}
@stop
