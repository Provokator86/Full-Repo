@extends('layouts.userend.userend-layout')

@section('content')
	<div class="row">
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <!--Begin Franchisee-Users Part-->
          <section class="panel" id="bench">
          	<div class="row margin_btntwenty">
				<div class="col-md-6">
				  <h1 class="bench_h1">Add New Field-Consultant</h1>
				</div>
				<div class="col-md-6">
				  <span class="error-msg pull-right">* marked fields are mandatory</span>
				</div>
             
              <div class="clearfix"></div>
              
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel border_btn">
					<div id="monthly" class="tab-pane ">
                        <div class="row">
							<form class="frm-franchisee" role="form" id="frmAddFieldExecutive" action="" method="post" onsubmit="return add_field_executive_AJAX()">
								
								<!-- ///////////// FIELD-EXECUTIVE [BEGIN] ///////////// -->
									<div id="usr-type-3" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<div class="main_bord inner_catgory">
										
											<div class="row">
												<div class="form-group">
												&nbsp;<label id="i_fld_franchisee_id_lbl" for="i_fld_franchisee_id">Select Franchisee(s) *</label>
												</div>
												<div class="form-group">													
													<div class="col-md-4">
														{{--*/ $COUNTER = 0 /*--}}
														@foreach ($franchisee_arr as $franchisee)
															@if( !empty($COUNTER) && $COUNTER%3==0 )
																</div><div class="col-md-4">
															@endif
																<span class="label-space">
																	<input type="checkbox" name="i_fld_franchisee_id[]" id="i_fld_franchisee_id" value="{{ $franchisee->i_id }}" />
																	<label class="label-normal">{{ ucwords($franchisee->s_name) }}</label>
																</span>
															{{--*/ $COUNTER = $COUNTER+1 /*--}}
														@endforeach
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-5">
													<div class="form-group">
														<label id="s_fld_username_lbl" for="s_fld_username">Username *</label>
														<input type="text" class="form-control" name="s_fld_username" id="s_fld_username" placeholder="Login Username" value="">
														<span class="text-danger"></span>
													</div>
												</div>                                       
												<div class="col-md-5 col-md-offset-1">  
													<div class="form-group">
														<label id="s_fld_passwd_lbl" for="s_fld_passwd">Password *</label>
														<input type="password" class="form-control" name="s_fld_passwd" id="s_fld_passwd" placeholder="Login Password" value="">
														<span class="text-danger"></span>
													</div> 
												</div>
											</div>

											<div class="row">
												<div class="col-md-5">
													<div class="form-group">
														<label id="s_fld_first_name_lbl" for="s_fld_first_name">First Name *</label>
														<input type="text" class="form-control" name="s_fld_first_name" id="s_fld_first_name" placeholder="First Name" value="" />
														<span class="text-danger"></span>
													</div>
												</div>                                       
												<div class="col-md-5 col-md-offset-1">
													<div class="form-group">
														<label>Last Name</label>
														<input type="text" class="form-control" name="s_fld_last_name" id="s_fld_last_name" placeholder="Last Name" value="" />
													</div>
												</div>                                       
											</div>

											<div class="row">
												<div class="col-md-5">  
													<div class="form-group">
														<label id="s_fld_email_lbl" for="s_fld_email">Email *</label>
														<div class="input-group">
															<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
															<input type="email" class="form-control" id="s_fld_email" name="s_fld_email" placeholder="Email" value="" />
															<span class="text-danger"></span>
														</div>
													</div> 
												</div>
											</div>

										</div>
									</div>
								<!-- ///////////// FIELD EXECUTIVE [END] ///////////// -->
																
								<div class="clearfix"></div>
								<div class="col-lg-12 text-center twenty_margin">
									<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save New" />
									<button type="button" class="btn btn-primary btn-danger" id="cancel_btn">Cancel</button>
								</div>
							</form>
						</div>
                    </div>
				</section>
              </div>
              
            </div>
            <div class="clearfix"></div>
          </section>
          <!--End Franchisee-Users Part-->
        </div>
	</div>
@endsection

@section('page-specific-scripts')
	{!! Html::script('userend-resources/js/custom-scripts/franchisee/add-field-executive.js') !!}
@stop
