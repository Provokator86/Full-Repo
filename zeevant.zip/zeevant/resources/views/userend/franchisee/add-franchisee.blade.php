@extends('layouts.userend.userend-layout')

@section('content')
	<div class="row">
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
          	<div class="row margin_btntwenty">
                    <div class="col-md-6">
                      <h1 class="bench_h1">Add New Franchisee</h1>
                    </div>
                    <div class="col-md-6">
                      <span class="error-msg pull-right">* marked fields are mandatory</span>
                    </div>
             
              <div class="clearfix"></div>
              
              <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                <section class="panel border_btn">
					<div id="monthly" class="tab-pane ">
                        <div class="row">
							<form role="form" id="frmAddFranchisee" action="" method="post" onsubmit="return add_franchisee_AJAX()">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="main_bord ">
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_name_lbl" for="s_name">Store/Franchisee Name *</label>
													<input type="text" class="form-control" name="s_name" id="s_name" placeholder="Store Name" value="" />
													<span class="text-danger"></span>
												</div>
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_passwd_lbl" for="s_passwd">Account Number&nbsp;<i data-toggle="tooltip" title="(Optional) One needs to put the concerned 'ERPLY-ACCOUNT-NUMBER' here" class="fa fa-info-circle"></i></label>
													<input type="text" class="form-control" name="s_account_number" id="s_account_number" placeholder="Account Number" value="" />
												</div> 
											</div>
										</div>
											
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_email_lbl" for="s_email">Email *</label>
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
														<input type="email" class="form-control" id="s_email" name="s_email" placeholder="Franchisee Email" value="" />
														<span class="text-danger"></span>
													</div>
												</div> 
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_phone_lbl" for="s_phone">Phone-Number</label>
													<div class="input-group">
														<div class="input-group-addon">
															<i class="fa fa-phone"></i>
														</div>
														<input type="text" class="form-control" id="s_phone_number" name="s_phone_number" placeholder="Phone Number" class="form-control" value="" data-inputmask='"mask": "(999) 999-9999"' data-mask>
														<span class="text-danger"></span>
													</div>
												</div>
											</div>
										</div>                         
										
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_address_1_lbl" for="s_address_1">Address 1 *</label>
													<input type="text" class="form-control" id="s_address_1" name="s_address_1" placeholder="Address 1" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_address_2_lbl" for="s_address_2">Address 2</label>
													<input type="text" class="form-control" id="s_address_2" name="s_address_2" placeholder="Address 2" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>
										</div>                         
									
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_city_lbl" for="s_city">City *</label>
													<input type="text" class="form-control" id="s_city" name="s_city" placeholder="City" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_state_lbl" for="s_state">State *</label>
													<select class="form-control" id="s_state" name="s_state">
														<option value="">-- Select State --</option>
														{!! \App\Helpers\optionHelper::makeOptionState() !!}
													</select>
													<span class="text-danger"></span>
												</div> 
											</div>
										</div>                         

										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_zipcode_lbl" for="s_zipcode">Zipcode *</label>
													<input type="text" class="form-control" id="s_zipcode" name="s_zipcode" placeholder="Zipcode" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_state_lbl" for="s_timezone">TimeZone *</label>
													<select class="form-control" id="s_timezone" name="s_timezone">
														<option value="">-- Select TimeZone --</option>
														{!! \App\Helpers\optionHelper::makeOptionTimezones() !!}
													</select>
													<span class="text-danger"></span>
												</div> 
											</div>
										</div>                         
										
									<!-- ////// New Field(s) for Door-Counter [Begin] ////// -->
									
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_device_id_lbl" for="s_device_id">Device-ID </label>
													<input type="text" class="form-control" id="s_device_id" name="s_device_id" placeholder="Device ID" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>                                       
											<div class="col-md-5 col-md-offset-1">  
												<div class="form-group">
													<label id="s_api_key_lbl" for="s_api_key">API Key </label>
													<input type="text" class="form-control" id="s_api_key" name="s_api_key" placeholder="API Key" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>
										</div>                         
										<div class="row">
											<div class="col-md-5">
												<div class="form-group">
													<label id="s_ip_lbl" for="s_ip">IP Address </label>
													<input type="text" class="form-control" id="s_ip" name="s_ip" placeholder="IP Address" value="" />
													<span class="text-danger"></span>
												</div> 
											</div>                                       
										</div>                         
									
									<!-- ////// New Field(s) for Door-Counter [End] ////// -->
									
										
									</div>
								</div>
								<div class="clearfix"></div>
								<div class="col-lg-12 text-center twenty_margin">
									<input type="submit" id="btn_save" name="btn_save" class="btn btn-primary" value="Save New" />
									<button type="button" class="btn btn-primary btn-danger" id="cancel_btn">Cancel</button>
								</div>
							</form>
						</div>
                    </div>
				</section>
              </div>
              
            </div>
            <div class="clearfix"></div>
          </section>
          <!--End Product Mix Top Part-->
        </div>
	</div>
@endsection

@section('page-specific-scripts')
	{!! Html::script('userend-resources/js/utils/input-mask/jquery.inputmask.js') !!}
	{!! Html::script('userend-resources/js/custom-scripts/franchisee/add-franchisee.js') !!}
@stop
