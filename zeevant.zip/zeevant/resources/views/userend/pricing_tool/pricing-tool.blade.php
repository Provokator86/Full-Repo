@extends('layouts.userend.userend-layout')

@section('page-specific-css')
	<!-- Bootstrap Date-Picker -->
	{!! Html::style('userend-resources/js/datepicker/css/bootstrap-datepicker.css') !!}
@endsection

@section('content')
      <!--Start Pricing Tool Top Part-->
      
      <!-- ************** Store(s) Selection [Begin] ************** -->
        <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="2s">
                    <section class="panel" id="select-store">
                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 col-lg-offset-4 col-md-offset-4 col-sm-offset-4">
                            <label for="inputSuccess" class="control-label font-size-sisteen">Select Store</label>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <select class="form-control pm" id="i_store" name="i_store">
                                {!! \App\Helpers\optionHelper::showOptionFranchisees() !!}
                            </select>
                        </div>
                    </section>
                </div>
            </div>                        
        <!-- ************** Store(s) Selection [End] ************** -->
        
        
      <div class="row">
        <!--Full Width Part Start-->
        <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
          <section class="panel" id="bench">
            <div class="margin_btntwenty">
              <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
                <div class="row">
                  <h1 class="bench_h1">Contribution and Pricing Tools [Based on {{ $total_no_of_shops }} store(s) data]</h1>
                </div>
              </div>
              <form class="form-horizontal bucket-form" method="get">
                <div class="col-lg-1 col-md-1 col-sm-6 col-xs-12">
                      <div class="row">
                        <input type="radio" class="radio_btn" name="group_name" checked="checked" value="0">
                        <label class="control-label font-size-sisteen" for="inputSuccess">POS Group</label>
                      </div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-6 col-xs-12">
                      <div class="row">
                        <input type="radio" class="radio_btn" name="group_name" value="1"> 
                        <label class="control-label font-size-sisteen" for="inputSuccess">Zeevant Group</label>
                      </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                  <div class="row lft_arrow"><span id="lbl_from_dt" class="lbl_dt_marker_long">{{ $prev_month_scroller_dt }}</span> <!-- <a id="from_dt_icon" href="#"> <i class="fa fa-calendar"></i></a>-->  to   <span id="lbl_to_dt" class="lbl_dt_marker_long">{{ $next_month_scroller_dt }}</span> <a id="to_dt_icon" href="#"><i class="fa fa-calendar"></i></a>
                    <button class="btn btn-primary" type="button" onclick="load_table_data_AJAX()">Go</button>
                  </div>
                  
                  
                  <!-- //////////////// HIDDEN FIELD(S) [BEGIN] //////////////// -->
                                        <input type="hidden" name="i_prev_date" id="i_prev_date" value="" />
                                        <input type="hidden" name="i_prev_month" id="i_prev_month" value="" />
                                        <input type="hidden" name="i_prev_year" id="i_prev_year" value="" />
                                        
                                        <input type="hidden" name="item_code_val" id="item_code_val" value="" />
                                        
                                        <input type="hidden" name="i_current_date" id="i_current_date" value="" />
                                        <input type="hidden" name="i_current_month" id="i_current_month" value="" />
                                        <input type="hidden" name="i_current_year" id="i_current_year" value="" />
                                        <!-- //////////////// HIDDEN FIELD(S) [END] //////////////// -->
                                        
                </div>
              </form>
            
            <div class="clearfix">&nbsp;</div>
            
             <div class="col-lg-3 col-md-5 col-sm-0 col-xs-0">
                <div class="row">
                </div>
            </div>
             <div class="col-lg-9 col-md-7 col-sm-12 col-xs-12">
                <div class="row">
                    <form class="form-horizontal bucket-form odd" method="get">
                    
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                          <div class="row">
                                <label class="control-label font-size-sisteen" for="inputSuccess">Select Category</label>
                                <select class="form-control pm odd" id="default_option_value_1">
                                <option value="">Select A Category</option>
                                <?php
                                foreach($all_pos_categories_arr as $ind=>$val){
                                ?>
                                <option value="<?php echo $val->product_group;?>"><?php echo $val->product_group;?></option>
                                <?php }
                                ?>                              
                                </select>
                                
                                <select class="form-control pm odd" id="default_option_value_2" style="display: none;">
                                <option value="">Select A Category</option>
                                <?php
                                foreach($all_categories_arr as $ind=>$val){
                                ?>
                                <option value="<?php echo $val->product_group_new;?>"><?php echo $val->product_group_new;?></option>
                                <?php }
                                ?>                              
                                </select>
                                
                          </div>
                        </div>
                        
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                          <div class="row" id="display_sub_category">
                                
                          </div>
                        </div>
                        
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                          <div class="row">
                                <label class="control-label font-size-sisteen" for="inputSuccess">Find Product</label>
                                <input type="search" class="find_pro" name="search_product" id="search_product">
                          </div>
                        </div>
                        
                      </form>
                </div>
            </div>
           
          <!--End Product Mix Top Part-->
         
        <!--End Left Part-->
        
        
        <!--Table Section start-->
          <div class="col-md-12 wow fadeInUp twenty_margin" data-wow-duration="2s">
             <section class="panel plan_border">
                <header class="panel-heading"> &nbsp; <span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                <div class="panel-body" id="table_data">
                        <section id="unseen_tebl">
                        <?php 
                        if(!empty($all_PT_table_data_arr)){
                        ?>
                            <table class="table table-bordered table-striped table-condensed">
                                <thead valign="top">
                                    <tr>
                                        <th>Index</th>
                                        <th>Code</th>
                                        <th>Product Name</th>
                                        <th>POS Group</th>
                                        <th>Zeevant Group</th>
                                        <th>POS List Price</th>
                                        <th>POS Average Price</th>
                                        <th>Discounted POS Price</th>
                                        <th>New Price</th>
                                        <th>Price Reflects Discounting</th>
                                        <th>POS Cost</th>
                                        <th>Variable Cost</th>
                                        <th>Item Contribution Margin</th>
                                        <th>Unit Sales</th>
                                        <th>Contribution</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                <?php
                                foreach($all_PT_table_data_arr as $ind=>$val){
                                ?>
                                    <tr>
                                        <td align="center"><input type="radio" class="radio_btn" value="<?php echo $val->item_code;?>" name="item_code"></td>
                                        <td><?php echo $val->item_code;?></td>
                                        <td><?php echo $val->item_name;?></td>
                                        <td><?php echo $val->item_pos_group;?></td>
                                        <td><?php echo $val->item_new_group;?></td>
                                        <td><?php echo $val->pos_list_price;?></td>
                                        <td><?php echo $val->pos_avg_price;?></td>
                                        <td><?php echo $val->discounted_pos_price;?></td>
                                        <td></td>
                                        <td><?php echo $val->price_reflects_discounting;?></td>
                                        <td><?php echo $val->pos_cost;?></td>
                                        <td><?php echo $val->variable_cost;?></td>
                                        <td><?php echo $val->item_contribution_margin;?></td>
                                        <td><?php echo $val->unit_sold;?></td>
                                        <td><?php echo $val->contribution;?></td>
                                        
                                    </tr>                                    
                                <?php
                                }
                                ?>   
                                </tbody>
                            </table>
                        <?php
                        }
                        ?>
                        </section>
                    </div>
              </section>
         </div>
          <!--Table Section end-->
          <div class="clearfix"></div>
          
            <div class="row" id="chart_data">                
                <div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
                                         
                <section class="panel round_border">
                  <header class="panel-heading">Price and Unit Salesover Time Period<span class="tools pull-right"> <a href="javascript:;" class="fa fa-chevron-down"></a> <a href="javascript:;" class="fa fa-times"></a> </span> </header>
                  <div class="panel-body">
                    <div id="hst_mp" loader-class="preloader_allR" class="img_brd" style="width: 100%; margin: 0 auto;">
                                    <div class="preloader_allR">&nbsp;</div>
                                <!-- <div class="daly_rev"> <img src="img/dally_rev.jpg"> </div> -->
                                </div>
                  </div>
                </section>
                </div>
             </div>
              </div>   
          </section>
        </div>
      </div>
      <!--End Pricing Tool Top Part-->
@endsection

@section('page-specific-scripts')
    <!-- Bootstrap Date-Picker -->
    {!! Html::script('userend-resources/js/datepicker/js/bootstrap-datepicker.js') !!}
    <!-- Chart Related -->
    {!! Html::script('https://www.google.com/jsapi') !!}
    {!! Html::script('userend-resources/js/charts/pricing_tool/generate_charts.js') !!}
    {!! Html::script('userend-resources/js/charts/pricing_tool/revenue_charts.js') !!}
    <!-- Page Specific -->
    {!! Html::script('userend-resources/js/custom-scripts/pricing_tool/pricing_tool.js') !!}
@stop

<?php /*
@section('inline-footer-js')
<script type="text/javascript">
<!--
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - Begin
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        var all_CR_data = {!! $all_CR_data_arr !!};
       
        
    
        


        
        //// For  Chart(s) [Begin]
            //drawMPChart(all_CR_data);
            
        //// For Chart(s) [End]
        
        
        
        
    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //                 Chart Related Function(s) - End
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~    
//-->
</script>
@stop
*/ ?>
