<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- ////////// Required Blade Template(s) [Begin] ////////// -->
		@include('layouts.userend.partials.login-page.head-meta-section')
		
		@include('layouts.userend.partials.login-page.head-scripts-section')
		<!-- ////////// Required Blade Template(s) [End] ////////// -->
	</head>
	<body class="login-body">
		<div class="container">
		  <form method="get" class="form-signin" action="">
			<h2 class="form-signin-heading wow fadeInUp" data-wow-duration="2s">registration now</h2>
			<div class="login-wrap wow fadeInUp" data-wow-duration="2s">
			  <p>Enter your personal details below</p>
			  <input type="text" class="form-control" placeholder="Full Name" autofocus>
			  <input type="text" class="form-control" placeholder="Address" autofocus>
			  <input type="text" class="form-control" placeholder="Email" autofocus>
			  <input type="text" class="form-control" placeholder="City/Town" autofocus>
			  <div class="radios wow fadeInUp" data-wow-duration="2s">
				<label class="label_radio col-lg-6 col-sm-6" for="radio-01">
				<input name="sample-radio" id="radio-01" value="1" type="radio" checked />
				Male </label>
				<label class="label_radio col-lg-6 col-sm-6" for="radio-02">
				<input name="sample-radio" id="radio-02" value="1" type="radio" />
				Female </label>
			  </div>
			  <p> Enter your account details below</p>
			  <input type="text" class="form-control" placeholder="User Name" autofocus>
			  <input type="password" class="form-control" placeholder="Password">
			  <input type="password" class="form-control" placeholder="Re-type Password">
			  <label class="checkbox wow fadeInUp" data-wow-duration="2s">
			  <input type="checkbox" value="agree this condition">
			  I agree to the Terms of Service and Privacy Policy </label>
			  <button class="btn btn-lg btn-login btn-block" type="submit">Submit</button>
			  <div class="registration wow fadeInUp" data-wow-duration="2s"> Already Registered. <a class="" href="{{ url() }}/login"> Login </a> </div>
			</div>
		  </form>
	  
		  @include('layouts.userend.partials.footer')
		</div>
		<!-- ********** Footer Script(s) - Begin ********** -->
			@include('layouts.userend.partials.login-page.footer-scripts-section')
			
			{{-- //////////////// For Page-Specific JS File(s) [Begin] //////////////// --}}
				{!! Html::script('userend-resources/js/custom-scripts/registration.js') !!}
			{{-- //////////////// For Page-Specific JS File(s) [End] //////////////// --}}
		<!-- ********** Footer Script(s) - End ********** -->
	</body>
</html>