@extends('layouts.userend.userend-layout')

@section('content')
      <!-- user-profile page start-->
		  <div class="row">
			<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
			  <section class="panel">
				<div class="panel-body profile-information">
                <h4>Edit Profile</h4> 
				  <div class="col-md-2">
					<div class="profile-pic text-center"> <img src="{{ asset($site_logo) }}" alt=""/> </div> 
				  </div>
				  {{-- ######### Profile Info(s) [Begin] ######### --}}
					 {{--*/ $FNAME = ( !is_array($user_info) )? $user_info->s_first_name: $user_info['s_first_name'] /*--}}
					 {{--*/ $LNAME = ( !is_array($user_info) )? $user_info->s_last_name: $user_info['s_last_name'] /*--}}
					 {{--*/ $EMAIL = ( !is_array($user_info) )? $user_info->s_email: $user_info['s_email'] /*--}}
					  <div class="col-md-5 stroke-right">
						<div class="">
						  <form method="post" id="frmProfileInfo" role="form" class="form-horizontal" onsubmit="return update_profile_info_AJAX()">
							  <div class="form-group">
								<label id="s_first_name_lbl" for="s_first_name" class="col-lg-2 control-label">First Name *</label>
								<div class="col-lg-6">
								  <input type="text" placeholder="First Name" id="s_first_name" name="s_first_name" class="form-control" value="{{ $FNAME }}" />
								</div>
							  </div>
							  <div class="form-group">
								<label id="s_last_name_lbl" for="s_last_name" class="col-lg-2 control-label">Last Name *</label>
								<div class="col-lg-6">
								  <input type="text" placeholder="Last Name" id="s_last_name" name="s_last_name" class="form-control" value="{{ $LNAME }}" />
								</div>
							  </div>                         
							  <div class="form-group">
								<label id="s_email_lbl" for="s_email" class="col-lg-2 control-label">Email *</label>
								<div class="col-lg-6">
								  <input type="text" placeholder="Email" id="s_email" name="s_email" class="form-control" value="{{ $EMAIL }}" />
								</div>
							  </div>
							  <div class="form-group">&nbsp;</div>
							  <div class="form-group">
								<div class="col-lg-offset-2 col-lg-10">
								  <button class="btn btn-primary" type="submit">Save</button>
								  <button class="btn btn-default" type="button">Cancel</button>
								</div>
							  </div>
						  </form>
						</div>
					  </div>
				  {{-- ######### Profile Info(s) [End] ######### --}}
				  
				  
				  {{-- ========= Password Info [Begin] ========= --}}
					  <div class="col-md-5">
						<form method="post" id="frmPasswd" role="form" class="form-horizontal" onsubmit="return update_password_AJAX()">
						  <div class="form-group">
							<label id="old_passwd_lbl" for="old_passwd" class="col-lg-2 control-label">Old Password</label>
							<div class="col-lg-6">
							  <input type="password" id="old_passwd" name="old_passwd" class="form-control" />
							</div>
						  </div>
						  <div class="form-group">
							<label id="new_passwd_lbl" for="new_passwd" class="col-lg-2 control-label">New Password</label>
							<div class="col-lg-6">
							  <input type="password" id="new_passwd" name="new_passwd" class="form-control" />
							</div>
						  </div>
						  <div class="form-group">
							<label id="conf_new_passwd_lbl" for="conf_new_passwd" class="col-lg-2 control-label">Confirm New Password</label>
							<div class="col-lg-6">
							  <input type="password" id="conf_new_passwd" name="conf_new_passwd" class="form-control" />
							</div>
						  </div>
						  <div class="form-group">&nbsp;</div>
						  <div class="form-group">
							<div class="col-lg-offset-2 col-lg-10">
							  <button class="btn btn-primary" type="submit">Update</button>
							  <button class="btn btn-default" type="button">Cancel</button>
							</div>
						  </div>
					   </form>
					  </div>
				  {{-- ========= Password Info [End] ========= --}}
				</div>
			  </section>
			</div>
			
			@if( \Session::get('user_type')!=2 )
				@if( !empty($store_arr) )
					<div class="col-md-12 wow fadeInUp" data-wow-duration="2s">
					  <section class="panel">
						<header class="tab-bg-dark-navy-blue">
						  <ul class="nav nav-tabs nav-justified ">
							<li class="active"> <a data-toggle="tab" href="#overview"> Your Store Details </a> </li>
							<li class="border-right-none"> </li>
							<li class="border-right-none"> </li>
							<li class="border-right-none"> </li>
						  </ul>
						</header>
						<div class="panel-body">
						  <div class="tab-content tasi-tab">
							<div id="overview" class="tab-pane active">
							  <div class="row">
								<div class="col-md-12">
								  <div class="recent-act">
								  
									@foreach ($store_arr as $store_info)
										<div class="activity-desk space-bottom">
										  <div class="form-group">  
											  <label class="col-md-2">Company Name:</label> <div class="col-md-10">{{ $store_info->s_name }}</div>
										  </div>
										  <div class="form-group">
											  <label class="col-md-2">Email:</label> <div class="col-md-10">{{ $store_info->s_email }}</div>
										  </div>
										  <div class="form-group">
											  <label class="col-md-2">Phone:</label> <div class="col-md-10">{{ $store_info->s_phone_number }}</div>
										  </div>
										  <div class="form-group">
											  {{--*/ $ADDRESS1 = $store_info->s_address_1 /*--}}
											  {{--*/ $ADDRESS2 = $store_info->s_address_2 /*--}}
											  {{--*/ $ADDRESS = ( !empty($ADDRESS2) )? $ADDRESS1 .", ". $ADDRESS2: $ADDRESS1  /*--}}
											  <label class="col-md-2">Address:</label> <div class="col-md-10">{{ $ADDRESS }}</div>
										  </div>
										  <div class="form-group">
											  <label class="col-md-2">City:</label> <div class="col-md-10">{{ $store_info->s_city }}</div>
										  </div>
										  <div class="form-group">
											  <label class="col-md-2">State:</label> <div class="col-md-10">{{ $store_info->state_name }}</div>
										  </div>
										  <div class="form-group">
											  <label class="col-md-2">Zipcode:</label> <div class="col-md-10">{{ $store_info->s_zipcode }}</div>
										  </div>
										</div>
									@endforeach

								  </div>
								</div>
								
							  </div>
							</div>
						  </div>
						</div>
					  </section>
					</div> 
				@endif
			@endif
		  </div>
      <!-- user-profile page end-->
@endsection

@section('page-specific-scripts')
	<!-- Page Specific -->
	{!! Html::script('userend-resources/js/custom-scripts/profile-page/profile.js') !!}
@stop
