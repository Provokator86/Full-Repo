<!DOCTYPE html>
<html lang="en">
<head>
	<!-- ////////// Required Blade Template(s) [Begin] ////////// -->
    @include('layouts.userend.partials.login-page.head-meta-section')
	
    @include('layouts.userend.partials.login-page.head-scripts-section')
	<!-- ////////// Required Blade Template(s) [End] ////////// -->
</head>
<body class="login-body">
<div class="container">
  <form id="frmLogin" class="form-signin" action="" method="post" onsubmit="return login_AJAX()">
    <h2 class="form-signin-heading wow fadeInUp" data-wow-duration="3s">Login now</h2>
    <div class="login-wrap wow fadeInUp" data-wow-duration="4s">
      <div class="user-login-info">
        <input type="text" id="user_id" name="user_id" class="form-control wow fadeInUp" data-wow-duration="2s" placeholder="User ID" autofocus />
        <input type="password" id="passwd" name="passwd" data-wow-duration="2s" class="form-control wow fadeInUp" placeholder="Password" />
      </div>
      <label class="checkbox wow fadeInUp" data-wow-duration="2s">
      <input type="checkbox" name="chkRem" id="chkRem" value="remember-me" />
      Remember me <span class="pull-right"> <a data-toggle="modal" href="#myModal"> Forgot Password?</a> </span> </label>
      <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>
      <div class="registration"> Don't have an account yet? <a class="" href="{{ url() }}/registration"> Create an account </a> </div>
    </div>
    <!-- ************* "Forgot Password" Modal [Begin] ************* -->
		<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Forgot Password ?</h4>
			  </div>
			  <div class="modal-body">
				<p>Enter your e-mail address below to reset your password.</p>
				<input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">
			  </div>
			  <div class="modal-footer">
				<button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
				<button class="btn btn-success" type="button">Submit</button>
			  </div>
			</div>
		  </div>
		</div>
    <!-- ************* "Forgot Password" Modal [End] ************* -->
  </form>
  
  @include('layouts.userend.partials.footer')
</div>
<!-- ********** Footer Script(s) - Begin ********** -->
	@include('layouts.userend.partials.login-page.footer-scripts-section')
	
	{{-- //////////////// For Page-Specific JS File(s) [Begin] //////////////// --}}
		{!! Html::script('userend-resources/js/custom-scripts/login.js') !!}
	{{-- //////////////// For Page-Specific JS File(s) [End] //////////////// --}}
<!-- ********** Footer Script(s) - End ********** -->
</body>
</html>