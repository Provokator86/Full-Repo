<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
class Device {
    private $config;
    private $url_base;
            
    public $page = 1;
    public $pageSize = 96;
    public $curl; 
    public $timeZone = 'EST5EDT'; 
    
    // tmp
    public $date;
    
    private $db_host, $db_name, $db_user, $db_password, $con;
    
    protected $previous_count1 = 0,$previous_count2 = 0;


    public function __construct() {
        $this->config = array(
            'id' => 'N520030', // Device number
            'apiKey' => 'f5311b3f-a5c2-4921-a8ab-042414b0c72f', // Api Key
            'name' => 'SWTAMPA', // Device name
            'siteId' => 'ShieldWatch1', // Site Id
        );
        
        $this->db_host = '192.168.1.39';
        $this->db_name = 'test';
        $this->db_user = 'root';
        $this->db_password = 'shld123';
        
        $this->db_host = '209.133.221.163';
        $this->db_name = 'zeevant_dev_db';
        $this->db_user = 'zeevant';
        $this->db_password = 'g(oEROlGwr}*';
        
        
        $this->con = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);
        
        if (!$this->con) {
            echo "Error: Unable to connect to MySQL." . PHP_EOL;
            echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
            echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
            exit;
        }
        
        // Set URL
        $this->url_base = 'https://209.133.221.162/api/v1/device/';
        
        // Set default timezone
        date_default_timezone_set($this->timeZone);
    }
    
    protected function get_franchisee_details($id)
    {
        $id = intval($id) > 0 ? $id : 19;
        
        $res = $this->con->query("SELECT s_ip, s_device, s_api_key, s_time_zone FROM zeevant_franchisee_master WHERE i_id = '{$id}'");
        
        /*$res = mysqli_query($this->con, "SEELCT s_ip, s_device, s_api_key, s_time_zone FROM zeevant_franchisee_master WHERE i_id = '{$id}'");*/
        
    }


    protected function set_curl_init($url = '')
    {
        if($url != '')
        {
            $headers = array();
            $headers[] = 'Content-length: 0';
            $headers[] = 'Content-type: application/json';
            
            $this->curl = curl_init($url);
            curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($this->curl, CURLOPT_HTTPHEADER, $headers);
            $curl_response = curl_exec($this->curl);
            if ($curl_response === false) {
                curl_close($this->curl);
                return '';
            }
            curl_close($this->curl);
            return json_decode($curl_response, true);
        }
    }


    public function test()
    {
        $service_url = $this->url_base.'get/' . $this->config['id'] . '?apikey='.$this->config['apiKey'];
        
        
        /* 
         * Using File Get Content
         * Working
        $arrContextOptions=array(
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        );  
        echo '<pre>';
        $response = file_get_contents($service_url, false, stream_context_create($arrContextOptions));
        var_dump($response); */
         
        // Using CURL
        $curl = curl_init($service_url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        /*curl_setopt($curl,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.52 Safari/537.17');*/
        
        $headers = array();
        $headers[] = 'Content-length: 0';
        $headers[] = 'Content-type: application/json';
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $curl_response = curl_exec($curl);
        
        
        /*$info = curl_getinfo($curl);
        $this->pr($info);*/
        
        $decoded = json_decode($curl_response);
        $this->pr($decoded);
        
        if ($curl_response === false) {
            $info = curl_getinfo($curl);
            curl_close($curl);
            die('Error occured during curl exec. Additioanl info: ' . var_export($info));
        }
        curl_close($curl);
        
        /* Not necessary
        if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
            die('error occured: ' . $decoded->response->errormessage);
        }*/
        
    }
    
    // Get device information
    public function get_device()
    {
        $service_url = $this->url_base.'get/' . $this->config['id'] . '?apikey='.$this->config['apiKey'];
        $tmp = $this->set_curl_init($service_url);
        $this->pr($tmp);
    }
    
    // Get count logs inclusive date time
    public function get_count_logs_per_day($from, $to)
    {
        $service_url = $this->url_base.'CountLogs/' . $this->config['id'] . '?from='.$from.'&to='.$to.'&page='.$this->page.'&pageSize='.$this->pageSize.'&apikey='.$this->config['apiKey'];
        $count_logs = $this->set_curl_init($service_url);
        if(!empty($count_logs))
        {
            echo '<table border="0" width="500">';
            echo '<tr><th>Log Entry Id</th><th>Register Count Logs</th><th>Line</th><th>Time</th></tr>';
            foreach($count_logs as $key=>$val)
            {
                echo '<tr>'
                    .'<td>'.$val['LogEntryId'].'</td>'
                    .'<td>'.($val['RegisterCountLogs'][0]['Index'] > 0 || $val['RegisterCountLogs'][1]['Index'] > 0  ? 'Yes': '-').'</td>'
                    .'<td>'.($val['RegisterCountLogs'][0]['Index'] > 0 ? $val['RegisterCountLogs'][0]['Name'] : $val['RegisterCountLogs'][1]['Name']).'</td>'
                    .'<td>'.date('M d, Y h:i:s a', strtotime($val['Timestamp'])).'</td>'
                . '</tr>';
            }
            echo '</table>';
        }
    }
    
    // Get count logs inclusive date time
    public function get_count_logs($from, $to)
    {
        $service_url = $this->url_base.'CountLogs/' . $this->config['id'] . '?from='.$from.'&to='.$to.'&page='.$this->page.'&pageSize='.$this->pageSize.'&apikey='.$this->config['apiKey'];
        $count_logs = $this->set_curl_init($service_url);
        
        return $count_logs;
        
        //echo '<br>---------------------------'.$from.' :: '.$to.'---------------------------';
        //$this->pr($count_logs);
    }
    
    // Calculate the actual door counter
    protected function calculate_door_count($count = 0, $flag = 1)
    {
				if($flag == 1)
        {
            $actual_count = $count-$this->previous_count1;
            $this->previous_count1 = $this->previous_count1 + $actual_count;
            return $actual_count;
        }
        else if($flag == 2)
        {
            $actual_count = $count-$this->previous_count2;
            $this->previous_count2 = $this->previous_count2 + $actual_count;
            return $actual_count;
        }
    }
    
    // Interval
    public function get_count_per_interval($id)
    {
        
        $date = date('Y-m-d', strtotime('-1 day'));
        /*if($this->date != '')
					$date = $this->date;
				else
					$date = '2016-07-04';*/
        
        $start = 8;
        $end = 22;
        
        // Set default door count
        $tmp = $this->get_count_logs($date.'T'.sprintf("%02d",($start-1)).':45:00Z',$date.'T'.sprintf("%02d",($start-1)).':59:59Z');
        if(!empty($tmp))
        {
            $this->previous_count1 = $tmp[0]['RegisterCountLogs'][0]['Value'];
            $this->previous_count2 = $tmp[0]['RegisterCountLogs'][1]['Value'];
        }
        
        $id = intval($id) > 0 ? $id : 19;
         
        for($i = $start; $i<$end; $i++)
        {
            //$time_zone = 'EST5EDT';
            date_default_timezone_set($this->timeZone);
            // First Interval
            $first_start_interval = $date."T".sprintf("%02d", $i).":00:00Z";
            $first_end_interval = $date."T".sprintf("%02d", $i).":29:00Z";
            $tmp1 = $this->get_count_logs($first_start_interval,$first_end_interval);
            
            if($tmp1[0]['LogEntryId'] > 0 || $tmp1[1]['LogEntryId'] > 0)
            {
								$count1 = $this->calculate_door_count($tmp1[0]['RegisterCountLogs'][0]['Value'],1)+$this->calculate_door_count($tmp1[1]['RegisterCountLogs'][0]['Value'],1);
                
                $count2 = $this->calculate_door_count($tmp1[0]['RegisterCountLogs'][1]['Value'],2)+$this->calculate_door_count($tmp1[1]['RegisterCountLogs'][1]['Value'],2);
                
                // Sum up
                $update = array(
                    'count1' => $count1,
                    'count2' => $count2,
                    'LogEntryId' => $tmp1[0]['LogEntryId'].','.$tmp1[1]['LogEntryId'],
                    'start_time' => str_replace(array('T','Z'),array(' '.''),$first_start_interval),
                    'end_time' => str_replace(array('T','Z'),array(' '.''),$first_end_interval),
                    'franchise_id' => $id
                );
                // End
                /*$sql = "REPLACE INTO `count_log`(count1,count2,LogEntryId,start_time,end_time,franchise_id) VALUES({$update['count1']}, {$update['count2']}, {$update['LogEntryId']}, {$update['start_time']}, {$update['end_time']}, {$update['franchise_id']})";*/

                // Local Server
                /*$sql = "INSERT INTO `count_log`(count1,count2,LogEntryId,start_time,end_time,franchise_id) VALUES({$update['count1']}, {$update['count2']}, '{$update['LogEntryId']}', '{$update['start_time']}', '{$update['end_time']}', {$update['franchise_id']}) ON DUPLICATE KEY UPDATE count1={$update['count1']}, count2={$update['count2']}";*/

                // Zeevant Server
                $sql = "INSERT INTO `zeevant_visitor_count`(line1,line2,LogEntryId,start_time,end_time,franchisee_id) VALUES({$update['count1']}, {$update['count2']}, '{$update['LogEntryId']}', '{$update['start_time']}', '{$update['end_time']}', {$update['franchise_id']}) ON DUPLICATE KEY UPDATE line1= {$update['count1']}, line2={$update['count2']}";

                // Update
                mysqli_query($this->con, $sql) or die(mysqli_error($this->con));
                unset($update);
            }
            
            // Second Interval
            $second_start_interval = $date."T".sprintf("%02d", $i).":30:00Z";
            $second_end_interval = $date."T".sprintf("%02d", $i).":59:00Z";
            $tmp2 =$this->get_count_logs($second_start_interval,$second_end_interval);
            
            if(intval($tmp2[0]['LogEntryId']) > 0 || intval($tmp2[1]['LogEntryId']) > 0)
            {
								// Sum up
                $count1 = $this->calculate_door_count($tmp2[0]['RegisterCountLogs'][0]['Value'],1)+$this->calculate_door_count($tmp2[1]['RegisterCountLogs'][0]['Value'],1);
                
                $count2 = $this->calculate_door_count($tmp2[0]['RegisterCountLogs'][1]['Value'],2)+$this->calculate_door_count($tmp2[1]['RegisterCountLogs'][1]['Value'],2);
                
                $update = array(
                    'count1' => $count1,
                    'count2' => $count2,
                    'LogEntryId' => $tmp2[0]['LogEntryId'].','.$tmp2[1]['LogEntryId'],
                    'start_time' => str_replace(array('T','Z'),array(' '.''),$second_start_interval),
                    'end_time' => str_replace(array('T','Z'),array(' '.''),$second_end_interval),
                    'franchise_id' => $id
                );
                // Local Server
                /*$sql = "INSERT INTO `count_log`(count1,count2,LogEntryId,start_time,end_time,franchise_id) VALUES({$update['count1']}, {$update['count2']}, '{$update['LogEntryId']}', '{$update['start_time']}', '{$update['end_time']}', {$update['franchise_id']}) ON DUPLICATE KEY UPDATE count1={$update['count1']}, count2={$update['count2']}";*/

                // Zeevant Server
                $sql = "INSERT INTO `zeevant_visitor_count`(line1,line2,LogEntryId,start_time,end_time,franchisee_id) VALUES({$update['count1']}, {$update['count2']}, '{$update['LogEntryId']}', '{$update['start_time']}', '{$update['end_time']}', {$update['franchise_id']}) ON DUPLICATE KEY UPDATE line1={$update['count1']}, line2={$update['count2']}";

                // Update
                mysqli_query($this->con, $sql);
                unset($update);
            }
        }
    }
    
    public function get_visitor_count()
    {
        // Fetch all the visitor with device
        $res = $this->con->query("SELECT i_id, s_ip, s_device_id, s_api_key, s_time_zone FROM zeevant_franchisee_master WHERE s_device_id != ''") or die(mysqli_error($this->con));
        
        while($row = $res->fetch_object())
        {
            // Change main setting for this franchise
            $this->config['apiKey'] = $row->s_api_key;
            $this->config['id'] = $row->s_device_id;
            $this->url_base = "https://{$row->s_ip}/api/v1/device/";
            $this->timeZone = $row->s_time_zone;
            
            // Continue
            $this->get_count_per_interval($row->i_id);
        }
    }
    
   
    
    // Helper
    public function pr($arr, $exit = 0)
    {
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
        if($exit == 1) exit;
    }
    public function vr($arr, $exit = 0)
    {
        echo '<pre>';
        var_dump($arr);
        echo '</pre>';
        if($exit == 1) exit;
    }
    
    protected function display_count($count_logs)
    {
        if(!empty($count_logs))
        {
            echo '<table border="0" width="500">';
            echo '<tr><th>Log Entry Id</th><th>Register Count Logs</th><th>Line</th><th>Time</th></tr>';
            foreach($count_logs as $key=>$val)
            {
                echo '<tr>'
                    .'<td>'.$val['LogEntryId'].'</td>'
                    .'<td>'.($val['RegisterCountLogs'][0]['Index'] > 0 || $val['RegisterCountLogs'][1]['Index'] > 0  ? 'Yes': '-').($val['RegisterCountLogs'][0]['Value'].'<>'.$val['RegisterCountLogs'][1]['Value']).'</td>'
                    .'<td>'.($val['RegisterCountLogs'][0]['Index'] > 0 ? $val['RegisterCountLogs'][0]['Name'] : $val['RegisterCountLogs'][1]['Name']).'</td>'
                    .'<td>'.date('M d, Y h:i:s a', strtotime($val['Timestamp'])).'</td>'
                . '</tr>';
            }
            echo '</table>';
        }
    }
    
    public function __destruct() {
        $this->con->close();
    }
}

/*-----------------------------------------------*/

$date = $_REQUEST['date'];

$obj = new Device();

$obj->date = $date;

$time_zone = 'Asia/Calcutta';
$time_zone = 'EST5EDT';
date_default_timezone_set($obj->timeZone);


//$obj->get_device(); // Working

$from = '2016-05-16T02:50:42.139Z'; // UTC format
$to = date("Y-m-d\TH:i:s\Z", time());//'2016-05-18T02:50:42.139Z'; // UTC format // gmdate()


$from = '2016-05-07T01:50:42.139Z'; // UTC format
$to = '2016-05-07T23:50:42.139Z'; // UTC format
//$obj->get_count_logs($from,$to);
//$obj->get_count_per_interval();



$obj->get_visitor_count();// Current working

?>

<style type="text/css">
    table {
        border-collapse: collapse;
        width: 80%;
        margin: 0 auto;
        font-family: Arial, sans-serif;
        font-size:13px;
        border: 1px solid #ddd;
    }
    
    th {
        height: 40px;
        text-align: left;
        background-color: #4CAF50;
        color: white;
    }
    
    table, th, td {
        border-bottom: 1px solid #ddd;
    }
    td {
        height: 40px;
        vertical-align: bottom;
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    tr:hover {background-color: #f5f5f5}
    tr:nth-child(even) {background-color: #f2f2f2}
</style>
    
