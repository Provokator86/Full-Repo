<?php

namespace App\Helpers;
use DB;

class ChartHelper {

    /**
     * Function to generate random numbers array
     *
     * @return Array (sorted array of randomly generated numbers)
     */
    public static function generate_numbers($num=50, $min_range=1, $max_range=10000) {
        try
        {
            $num_arr = [];
            for($i=1; $i<=$num; $i++) {

                $random_num = rand($min_range, $max_range);
                $random_num = ChartHelper::recursive_gen_call($random_num,
                                                              $num_arr,
                                                              $min_range,
                                                              $max_range);

                $num_arr[] = $random_num;
            }

            asort($num_arr);

            return $num_arr;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Function: Recursive call to fetch distinct number(s) for the array
     *
     * @return num
     */
    public static function recursive_gen_call($rand_num, $arr, $min, $max) {

        try {

            if( !in_array($rand_num, $arr) )
                return $rand_num;
            else {
                $rand = rand($min, $max);
                ChartHelper::recursive_gen_call($rand, $arr, $min, $max);
            }


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }


}