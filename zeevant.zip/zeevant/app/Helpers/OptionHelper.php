<?php

namespace App\Helpers;
use DB;
use DateTime;
use DateTimeZone;

class OptionHelper {

    /**
    * Returns state drop-down option(s)
    *
    * @return HTML (<option> tag)
    */
    public static function makeOptionState($param_where=null, $param_selected=null)
    {
        try
        {
            $STATES_TBL = getenv('DB_PREFIX') ."states";

            $cond = (trim($param_where)) ? " WHERE {$param_where} " : '';
            $sql = sprintf("SELECT `i_id`, `s_code`, `s_name` FROM %s %s ORDER BY `s_name` ",
                            $STATES_TBL, $cond);

            $states_arr = DB::select( DB::raw($sql) );
            $s_option = '';
            if($states_arr)
            {
                foreach ($states_arr as $state)
                {
                    $s_select = '';
                    if( $state->s_code==$param_selected )
                        $s_select = " selected ";
                    $s_option .= "<option {$s_select} value='". $state->s_code ."' >". $state->s_name ."</option>";
                }
            }

            unset($states_arr, $sql, $param_where, $param_selected);

            return $s_option;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns Franchisor(s) drop-down option(s)
     *
     * @return HTML (<option> tag)
     */
    public static function makeOptionFranchisors($param_where=null, $param_selected=null)
    {
        try
        {
            $TBL = getenv('DB_PREFIX') ."franchisor_details";

            $cond = (trim($param_where)) ? " WHERE {$param_where} " : '';
            $sql = sprintf("SELECT `i_id`, `s_company_name` FROM %s %s ORDER BY `s_company_name` ",
                            $TBL, $cond);

            $franchisor_arr = DB::select( DB::raw($sql) );
            $s_option = '';
            if($franchisor_arr)
            {
                foreach ($franchisor_arr as $franchisor)
                {
                    $s_select = '';
                    if( $franchisor->i_id==$param_selected )
                        $s_select = " selected ";
                    $s_option .= "<option {$s_select} value='". $franchisor->i_id ."' >". $franchisor->s_company_name ."</option>";
                }
            }

            unset($franchisor_arr, $sql, $param_where, $param_selected);

            return $s_option;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns Franchisee(s) drop-down option(s)
     *
     * @return HTML (<option> tag)
     */
    public static function makeOptionFranchisees($param_where=null, $param_selected=null, $param_order_by=null)
    {
        try
        {
            $TBL = getenv('DB_PREFIX') ."franchisee_master";

            $cond = (trim($param_where)) ? " WHERE {$param_where} " : '';
            $order_by = (trim($param_order_by)) ? " {$param_order_by} " : " `s_name` ";
            $sql = sprintf("SELECT `i_id`, `s_name` FROM %s %s ORDER BY %s ",
                            $TBL, $cond, $order_by);

            $franchisee_arr = DB::select( DB::raw($sql) );
            $s_option = '';
            if($franchisee_arr)
            {
                foreach ($franchisee_arr as $franchisee)
                {
                    $s_select = '';
                    if( $franchisee->i_id==$param_selected )
                        $s_select = " selected='selected' ";
                    $s_option .= "<option {$s_select} value='". $franchisee->i_id ."' >". $franchisee->s_name ."</option>";
                }
            }

            unset($franchisee_arr, $sql, $param_where, $param_selected);

            return $s_option;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns Franchisee(s) drop-down option(s)
     * based on logged-in user(s)
     *
     * @return HTML (<option> tag)
     */
    public static function showOptionFranchisees($param_where=null, $param_selected=null, $param_order_by=null, $flag_all=true)
    {
        try
        {
            $MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
            $USERS_TBL  = getenv('DB_PREFIX') ."franchisee_users";

            $LOGGED_USR_TYPE = \Session::get('user_type');
            $LOGGED_USR_ID = \Session::get('user_id');

            # I: if "Franchisor"...
            if( $LOGGED_USR_TYPE==2 ) {
                $SQL = sprintf("SELECT * FROM %s WHERE `i_franchisor_id`=%d ORDER BY `s_name` ",
                                $MASTER_TBL, $LOGGED_USR_ID);
            } elseif( $LOGGED_USR_TYPE==3 || $LOGGED_USR_TYPE==4 ) { // Field-Consultant OR Franchisee-User
                $SQL = sprintf("SELECT
                                    A.*
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`i_id`=B.`i_franchisee_id`
                                WHERE B.`i_user_id`=%d
                                ORDER BY A.`s_name` ",
                                $MASTER_TBL, $USERS_TBL, $LOGGED_USR_ID);
            } else {    // Super-Admin
                $SQL = sprintf("SELECT * FROM %s WHERE 1 ORDER BY `s_name` ", $MASTER_TBL);
            }

            $franchisee_arr = DB::select( DB::raw($SQL) );
            $s_option = '';
            if($franchisee_arr)
            {
                # NEW - for "All Store(s)" option [Begin]
                if( $flag_all ) {
                    $s_select = " selected='selected' ";
                    $s_option .= "<option {$s_select} value='-1' >All Store(s)</option>";
                }
                # NEW - for "All Store(s)" option [End]

                foreach ($franchisee_arr as $franchisee)
                {
                    $s_select = '';
                    if( $franchisee->i_id==$param_selected )
                        $s_select = " selected='selected' ";
                    $s_option .= "<option {$s_select} value='". $franchisee->i_id ."' >". $franchisee->s_name ."</option>";
                }
            }

            unset($franchisee_arr, $sql, $param_where, $param_selected);

            return $s_option;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
    
    /**
    * Returns root category drop-down option(s)
    *
    * @return HTML (<option> tag)
    */
    public static function makeOptionRootCategory($param_where=null, $param_selected=null)
    {
        try
        {
            $STATES_TBL = getenv('DB_PREFIX') ."franchisor_categogy_map";

            $cond = (trim($param_where)) ? " WHERE {$param_where} " : '';
            $sql = sprintf("SELECT `i_id`, `s_product_group` FROM %s %s ORDER BY `s_product_group` ",
                            $STATES_TBL, $cond);
            
            $states_arr = DB::select( DB::raw($sql) );
            $s_option = '';
            if($states_arr)
            {
                foreach ($states_arr as $state)
                {
                    $s_select = '';
                    if( $state->s_product_group==$param_selected )
                        $s_select = " selected ";
                    $s_option .= "<option {$s_select} value='". $state->s_product_group ."' >". $state->s_product_group ."</option>";
                }
            }

            unset($states_arr, $sql, $param_where, $param_selected);

            return $s_option;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
    
    
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              NEW FUNCTION(S) - BEGIN
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        /**
        * Returns Category drop-down option(s)
        *
        * @return HTML (<option> tag)
        */
        public static function makeOptionCategory($flds_arr=null, $param_where=null, $param_selected=null)
        {
            try
            {
                $CATEGORY_MAP_TBL = getenv('DB_PREFIX') ."category_map";

                if( !empty($flds_arr) )
                    list($FLD1, $FLD2) = $flds_arr;
                else {
                    $FLD1 = 'i_id';
                    $FLD2 = 'product_group_new';
                }
                    
                $cond = (trim($param_where)) ? " WHERE {$param_where} " : '';
                $sql = sprintf("SELECT DISTINCT {$FLD1} AS `id`, {$FLD2} AS `name` FROM %s %s ORDER BY `name` ",
                                $CATEGORY_MAP_TBL, $cond);
                
                $row_arr = DB::select( DB::raw($sql) );
                $s_option = '';
                if($row_arr)
                {
                    foreach ($row_arr as $row)
                    {
                        $s_select = '';
                        
                        if( $row->name==$param_selected )
                            $s_select = " selected='selected' ";
                        $s_option .= "<option {$s_select} value='". $row->name ."' >". $row->name ."</option>";
                    }
                }

                unset($states_arr, $sql, $param_where, $param_selected);

                return $s_option;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }
        }
        
        
        // ***** TIMEZONE RELATED [BEGIN]
        
        /**
         * Returns TimeZone drop-down option(s)
         *
         * @return HTML (<option> tag)
         */
        public static function makeOptionTimezones($param_selected=null)
        {
        	try
        	{
        		
			    // ========================================================
			    	$timezone_list = $timezone_offset_list = array();
			    	$timezones = timezone_identifiers_list();
			    	foreach($timezones as $key=>$timezone) {
			    		
			    		# I: get time-offset...
				    		$tz = new DateTimeZone($timezone);
				    		$tz_offset = $tz->getOffset(new DateTime());
				    		
				    	# II: process timezone-offset...
				    		$formattedTZ = self::_formatTimezoneOffset($tz_offset);
				    			
				    		$pretty_offset = "UTC{$formattedTZ}";
				    		$arr_key = "{$formattedTZ}";
				    		
				    	# III: forming the array...
				    		$timezone_offset_list[] = $arr_key;
				    		$timezone_list[] = "(${pretty_offset}) {$timezone}";
					}
				// ========================================================
				
				
				// ********************************************************
					$s_option = '';
					
					foreach($timezone_list as $key=>$tzone) {
						
						$option_value = $timezone_offset_list[$key] ." ". self::_splitStr($tzone);
						$chk_value = self::_splitStr($tzone);
						$option_txt = \App\Helpers\Utility::get_proper_word($tzone, true);
						$s_select = '';
						
						if( $param_selected!= '' ) {
							
							if( strcmp( $chk_value, $param_selected)==0 )
								$s_select = " selected='selected' ";
							
						} else {
							$default_offset_val = self::_getDefaultESTOffset();
							
							if( strcmp( $chk_value, $default_offset_val)==0 )
								$s_select = " selected='selected' ";
						}
						
						$s_option .= "<option {$s_select} value='{$option_value}' >{$option_txt}</option>";
						
					}
					
				// ********************************************************
				
			    #\App\Helpers\Utility::dump($timezone_offset_list);
						
			    return $s_option;
        	}
        	catch(Exception $err_obj)
        	{
        		show_error($err_obj->getMessage());
        	}
        }
        
        
        
        # function to format timezone-offset...
        public static function _formatTimezoneOffset($timezone_offset) {
        	
        	try {
        		
        		# process timezone-offset...
        		$offset_prefix = $timezone_offset < 0 ? '-' : '+';
        		$offset_formatted = gmdate( 'H:i', abs($timezone_offset) );
        		 
        		$return_format = "{$offset_prefix}{$offset_formatted}";
        		
        		return $return_format;
        		
        	} catch(Exception $err_obj) {
        		show_error($err_obj->getMessage());
        	}
        	
        }
        
        
        
        # function to have default UTC time-zone offset...
        public static function _getDefaultESTOffset() {
        	
        	try {
        		
        		# I: getting default timezone offset...
        		$default_timezone = config('custom.config.default_timezone');
        		$tz = new DateTimeZone($default_timezone);
	    		$tz_offset = $tz->getOffset(new DateTime());
	    		
	    		# II: process timezone-offset...
	    		/*$defaultTZ = self::_formatTimezoneOffset($tz_offset);
	    		$defaultTZ .= " ". self::_splitStr("# {$default_timezone}");*/
	    		$defaultTZ = self::_splitStr("# {$default_timezone}");
				
	    		return $defaultTZ;
        		
        	} catch (Exception $err_obj) {
        		show_error($err_obj->getMessage());
        	}
        	
        }
        
        
        # split string based on regular-expression...
        public static function _splitStr($str, $separator=null, $flag=true) {
        	
        	try {
        		$pattern = ( !empty($separator) )
        				   ? '/[{$separator]/': '/\\s/';
        		
        		$arr = preg_split($pattern, $str);
        		$arr_index = ( $flag )? count($arr)-1: 0;
        		
        		return strtolower($arr[$arr_index]);
        		
        	} catch(Exception $err_obj) {
        		show_error($err_obj->getMessage());
        	}
        	
        }
        
        // ***** TIMEZONE RELATED [END]
        
        
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //              NEW FUNCTION(S) - END
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}