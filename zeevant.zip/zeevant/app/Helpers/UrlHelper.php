<?php

namespace App\Helpers;

class UrlHelper {

    /**
    * Returns admin-base-url
    *
    * @return string
    */
    public static function admin_base_url()
    {
        $ADMIN_URL = url() ."/admin/";

        return $ADMIN_URL;
    }


}