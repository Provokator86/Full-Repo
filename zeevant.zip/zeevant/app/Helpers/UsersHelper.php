<?php

namespace App\Helpers;
use DB;

class UsersHelper {

    /**
    * Returns user-role
    *
    * @return string
    */
    public static function getUserRole($param_user_type)
    {
        try
        {
            $USR_TYPE_TBL = getenv('DB_PREFIX') ."user_types";

            $sql = sprintf("SELECT
                                LOWER(`s_user_type`) AS `user_role`
                            FROM
                                %s
                            WHERE `i_id`=%d ",
                            $USR_TYPE_TBL, $param_user_type);

            $row = DB::select( DB::raw($sql) );
            $return_usr_role = $row[0]->user_role;

            unset($row, $sql, $param_user_type);

            return $return_usr_role;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns ACL Resource & Privileges
     *
     * @return array
     */
    public static function getResourceNAction($param_arr) {

        $return_arr = array();
        foreach($param_arr as $posted) {

            $arr = explode('-', $posted);
            $resource = trim($arr[0]);
            $action = trim($arr[1]);

            $return_arr[$resource][] = $action;
        }

        return $return_arr;
    }


    # function to form array of action-resources-roles...
    public static function formACLArray($data_arr=null) {

        $return_arr = array();
        if( !empty($data_arr) ) {

            $usr_type = null;
            $resource_type = null;
            foreach($data_arr as $rowObj) {

                if( $rowObj->i_usr_type_id!=$usr_type )
                    $usr_type = $rowObj->i_usr_type_id;

                if( $rowObj->s_resource!=$resource_type )
                    $resource_type = $rowObj->s_resource;

                $actions_arr = explode(',', $rowObj->actions);
                if( is_array($actions_arr) ) {
                    foreach($actions_arr as $key=>$val)
                        $return_arr[$usr_type][$resource_type][] = $val;
                } else
                    $return_arr[$usr_type][$resource_type][] = $rowObj->actions;

            }   // End - foreach

        }   // End - if

        return $return_arr;

    }


    /**
     * Returns LOGO resource path
     * Input param(s): logged-user-franchisor-ID
     * Output param: logo-path (based on logged-in user-type)
     *
     * @return string
     */
    public static function getUserLogo($logged_usr_franchisor_ID) {

        try
        {
            # I: required table(s)
            $USR_TBL = getenv('DB_PREFIX') ."users";
            $FRANCHISOR_DETAILS_TBL = getenv('DB_PREFIX') ."franchisor_details";


            # II: Find Logo
            $sql = sprintf("SELECT
                                A.`s_logo`
                            FROM
                                %s A LEFT JOIN %s B
                                ON A.`i_franchisor_id`=B.`i_id`
                            WHERE
                                A.`i_franchisor_id`=%d ",
                            $USR_TBL, $FRANCHISOR_DETAILS_TBL, $logged_usr_franchisor_ID);

            $row = DB::select( DB::raw($sql) );
            $return_usr_role = $row[0]->s_logo;

            unset($row, $sql, $param_user_type);

            return $return_usr_role;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }

    }


    /**
     * Returns concerned Franchisor/Company ID
     * based on logged-in franchisor-admin
     *
     * param IN: user-data array
     *
     * @return string
     */
    public static function getFranchisorID($param_franchisor_admin)
    {
        try
        {
            # I: DB Table Name(s)...
            $USR_TBL = getenv('DB_PREFIX') ."users";


            # II: just find the related franchisor
            $sql = sprintf("SELECT `i_franchisor_id` FROM %s
                            WHERE `i_id`=%d ", $USR_TBL, $param_franchisor_admin);

            $row = DB::select( DB::raw($sql) );
            $return_franchisor_ID = $row[0]->i_franchisor_id;

            unset($row, $sql, $param_franchisor_admin);

            return $return_franchisor_ID;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns concerned Parent-Franchisor-AdminID
     * based on logged-in field-consultant/franchisee-user
     *
     * param IN: logged-user-id
     *
     * @return franchisor-admin-id
     */
    public static function getParentFranchisorAdminID($param_usr_id)
    {
        try
        {
            # I: DB Table Name(s)...
            $USR_TBL = getenv('DB_PREFIX') ."users";


            # II: just find the related franchisor
            $sql = sprintf("SELECT `i_parent_userid` FROM %s
                            WHERE `i_id`=%d ", $USR_TBL, $param_usr_id);

            $row = DB::select( DB::raw($sql) );
            if( !is_null($row) )
                $return_parent_usr_ID = $row[0]->i_parent_userid;
            else
                $return_parent_usr_ID = null;

            unset($row, $sql, $param_usr_id);

            return $return_parent_usr_ID;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * OLD FUNCTION - Returns concerned Franchisee(s)/Store(s)
     * based on logged-in franchisor-admin/field-consultant/franchisee-user &
     * his/her user-type
     *
     * param IN: logged-in userID, logged-user-type
     * param OUT: concerned store-id(s)
     *
     * @return array
     */
    public static function getFranchiseesByUserOld($param_user_id, $param_user_type, $flag_multiple=false)
    {
        try
        {
            $return_arr = array();

            # I: DB Table Name(s)...
            $FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
            $FRANCHISEE_USERS_TBL = getenv('DB_PREFIX') ."franchisee_users";


            # II: preparing query based on user-type...
            if( $param_user_type==2 ) { // i.e. Franchisor-Admin
                $FLDs = ( $flag_multiple )? " `i_id`, `s_name` ": " `i_id` AS `franchisee_id` ";
                $sql = sprintf("SELECT %s FROM %s
                                WHERE `i_franchisor_id`=%d ",
                    $FLDs, $FRANCHISEE_MASTER_TBL, $param_user_id);
            } else {    // either Field-Consultant OR Franchisee-User
                if( $flag_multiple ) {
                    $FLDs = " A.`i_id`, B.`s_name` ";
                    $FROM_CLAUSE = " {$FRANCHISEE_USERS_TBL} A LEFT JOIN {$FRANCHISEE_MASTER_TBL}  B
                                     ON A.`i_income_stmt_id`=B.`i_id` ";
                    $WHERE_COND = " A.`i_user_id`={$param_user_id} ";
                } else {
                    $FLDs = "`i_id` AS `franchisee_id` ";
                    $FROM_CLAUSE = " {$FRANCHISEE_USERS_TBL} ";
                    $WHERE_COND = " `i_user_id`={$param_user_id} ";
                }
                $sql = sprintf("SELECT %s FROM %s WHERE %s ",
                    $FLDs, $FROM_CLAUSE, $WHERE_COND);
            }

            $rows = DB::select( DB::raw($sql) );

            if( $flag_multiple ) {
                $loop_index = 0;
                foreach($rows as $row) {
                    $return_arr[$loop_index]['i_id'] = $row->i_id;
                    $return_arr[$loop_index]['s_name'] = $row->s_name;

                    $loop_index++;
                }
            } else {
                foreach($rows as $row)
                    $return_arr[] = $row->franchisee_id;
            }

            unset($rows, $sql);

            return $return_arr;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }




    /**
     * Returns concerned Franchisee(s)/Store(s)
     * based on logged-in franchisor-admin/field-consultant/franchisee-user &
     * his/her user-type
     *
     * param IN: logged-in userID, logged-user-type
     * param OUT: concerned store-id(s)
     *
     * @return array
     */
    public static function getFranchiseesByUser($param_user_id, $param_user_type)
    {
        try
        {
            $return_arr = array();

            # I: DB Table Name(s)...
            $FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
            $FRANCHISEE_USERS_TBL = getenv('DB_PREFIX') ."franchisee_users";


            # II: preparing query based on user-type...
            if( $param_user_type==2 ) { // i.e. Franchisor-Admin
                $sql = sprintf("SELECT `i_id` AS `franchisee_id` FROM %s
                                WHERE `i_franchisor_id`=%d ",
                                $FRANCHISEE_MASTER_TBL, $param_user_id);
            } else {    // either Field-Consultant OR Franchisee-User
                $WHERE_COND = " `i_user_id`={$param_user_id} ";
                $sql = sprintf("SELECT `i_franchisee_id` AS `franchisee_id` FROM %s WHERE %s ",
                                $FRANCHISEE_USERS_TBL, $WHERE_COND);
            }

            $rows = DB::select( DB::raw($sql) );

            foreach($rows as $row)
                $return_arr[] = $row->franchisee_id;

            unset($rows, $sql);

            return $return_arr;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns Total Number of Store(s) under the
     * concerned Franchisor-Admin
     *
     * param IN: franchisor-admin ID
     * param OUT: store-count
     *
     * @return integer
     */
    public static function getAllStoreCount($param_user_id)
    {
        try
        {
            $return_val = null;

            # I: DB Table Name(s)...
            $FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";


            # II: preparing query based on user-type...
            $sql = sprintf("SELECT COUNT(*) AS `no_of_shops` FROM %s
                            WHERE `i_franchisor_id`=%d ",
                $FRANCHISEE_MASTER_TBL, $param_user_id);

            $rows = DB::select( DB::raw($sql) );
            if( !empty($rows) )
                $return_val = $rows[0]->no_of_shops;

            unset($rows, $sql);

            return $return_val;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns Imploded string of Concerned Store-ID(s)
     *
     * param IN: store-info array
     * param OUT: imploded string of store-id(s) [for IN clause]
     *
     * @return string
     */
    public static function formIDstr($param_store_arr=null)
    {
        try
        {
            $return_val = null;

            if( !empty($param_store_arr) ) {

                $ID_arr = array();
                foreach($param_store_arr as $key=>$row)
                    $ID_arr[] = $row['i_id'];

                if( !empty($ID_arr) )
                    $return_val = implode(',', $ID_arr);
            }

            return $return_val;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns Profit/Loss percentage
     *
     * param IN: actual revenue, planned revenue
     * param OUT: Profit/Loss float/decimal
     *
     * @return float/decimal
     */
    public static function calculateProfitLossPercent($rev_actual=0, $rev_planned=0)
    {
        try
        {
            $rev_actual = ( !empty($rev_actual) )? floatval($rev_actual): 0;
            $rev_planned = ( !empty($rev_planned) )? floatval($rev_planned): 0;

            $profit_OR_loss_val = ($rev_actual-$rev_planned);
            $profit_OR_loss_percent = ( !empty($rev_actual) )
                                      ? number_format((($profit_OR_loss_val*100)/$rev_actual), 2)
                                      : 0;

            return $profit_OR_loss_percent;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns Ticket(s) Count
     * concerned table "erply-daysales"
     *
     * param IN: store-id(s)
     * param OUT: ticket count for that month & year
     *
     * @return integer
     */
    public static function getDaysalesTicketCount($store_ids, $dt_time_arr)
    {
        try
        {
            $return_val = null;

            # I: DB Table Name(s)...
            $FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
            $ERPLY_DAYSALES_TBL = getenv('DB_PREFIX') ."erply_daysales";

            # regarding date(s)...
            $month = $dt_time_arr['month'];
            $year  = $dt_time_arr['year'];


            # II: preparing query based on user-type...
            if( is_array($store_ids) ) {    // multiple-store(s)

                # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_ids);

                $sql = sprintf("SELECT
                                    SUM(B.`tickets`) AS `ticket_count`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`s_account_number`=B.`erply_account_number`
                                WHERE
                                    A.`i_id` IN (%s) AND
                                    MONTH(DATE(B.`erplytrans_date`))=%d AND
                                    YEAR(DATE(B.`erplytrans_date`))=%d ",
                                $FRANCHISEE_MASTER_TBL, $ERPLY_DAYSALES_TBL,
                                $stores, $month, $year);
            } else {    // particular store
                $sql = sprintf("SELECT
                                    SUM(B.`tickets`) AS `ticket_count`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`s_account_number`=B.`erply_account_number`
                                WHERE
                                    A.`i_id`=%d AND
                                    MONTH(DATE(B.`erplytrans_date`))=%d AND
                                    YEAR(DATE(B.`erplytrans_date`))=%d ",
                                $FRANCHISEE_MASTER_TBL, $ERPLY_DAYSALES_TBL,
                                $store_ids, $month, $year);
            }


            $rows = DB::select( DB::raw($sql) );
            if( !empty($rows) )
                $return_val = $rows[0]->ticket_count;

            unset($rows, $sql);

            return $return_val;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns Summed Discount
     * concerned table "erply-daysales"
     *
     * param IN: store-id(s)
     * param OUT: discount summed across month
     *
     * @return integer
     */
    public static function getSummedDiscount($store_ids, $dt_time_arr)
    {
        try
        {
            $return_val = null;

            # I: DB Table Name(s)...
            $FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
            $ERPLY_DAYSALES_TBL = getenv('DB_PREFIX') ."erply_daysales";

            # regarding date(s)...
            $month = $dt_time_arr['month'];
            $year  = $dt_time_arr['year'];


            # II: preparing query based on user-type...
            if( is_array($store_ids) ) {    // multiple-store(s)

                # IA: preparing for MySQL IN clause...
                $stores = implode(',', $store_ids);

                $sql = sprintf("SELECT
                                    SUM(B.`discount`) AS `total_discount`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`s_account_number`=B.`erply_account_number`
                                WHERE
                                    A.`i_id` IN (%s) AND
                                    MONTH(DATE(B.`erplytrans_date`))=%d AND
                                    YEAR(DATE(B.`erplytrans_date`))=%d ",
                                $FRANCHISEE_MASTER_TBL, $ERPLY_DAYSALES_TBL,
                                $stores, $month, $year);
            } else {    // particular store
                $sql = sprintf("SELECT
                                    SUM(B.`discount`) AS `total_discount`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`s_account_number`=B.`erply_account_number`
                                WHERE
                                    A.`i_id`=%d AND
                                    MONTH(DATE(B.`erplytrans_date`))=%d AND
                                    YEAR(DATE(B.`erplytrans_date`))=%d ",
                                $FRANCHISEE_MASTER_TBL, $ERPLY_DAYSALES_TBL,
                                $store_ids, $month, $year);
            }


            $rows = DB::select( DB::raw($sql) );
            if( !empty($rows) )
                $return_val = $rows[0]->total_discount;

            unset($rows, $sql);

            return $return_val;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Returns Hour(s)
     * concerned table "erply-daysales"
     *
     * param IN: store-id(s)
     * param OUT: hour(s) count for that month & year
     *
     * @return integer
     */
    public static function getMyInputsHourCount($store_ids, $dt_time_arr)
    {
        try
        {
            $return_val = null;

            # I: DB Table Name(s)...
            $BSHEET_MASTER_TBL = getenv('DB_PREFIX') .'balance_sheet_master';
            $BSHEET_INPUTS_TBL = getenv('DB_PREFIX') ."balance_sheet_inputs";

            # regarding date(s)...
            $month = $dt_time_arr['month'];
            $year  = $dt_time_arr['year'];

            # II: preparing query based on user-type...
            if( is_array($store_ids) ) {    // multiple-store(s)

                # IA: preparing for MySQL IN clause...
                $stores = implode(',', $store_ids);

                $sql = sprintf("SELECT
                                    IFNULL(SUM(B.`d_labor_hours`), 0) AS `labor_hours`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`i_id`=B.`i_balance_sheet_id`
                                WHERE
                                    A.`i_id` IN (%s) AND
                                    A.`i_month`=%d AND
                                    A.`i_year`=%d ",
                                $BSHEET_MASTER_TBL, $BSHEET_INPUTS_TBL,
                                $stores, $month, $year);
            } else {    // particular store
                $sql = sprintf("SELECT
                                    IFNULL(SUM(B.`d_labor_hours`), 0) AS `labor_hours`
                                FROM
                                    %s A LEFT JOIN %s B
                                    ON A.`i_id`=B.`i_balance_sheet_id`
                                WHERE
                                    A.`i_id`=%d AND
                                    A.`i_month`=%d AND
                                    A.`i_year`=%d ",
                                $BSHEET_MASTER_TBL, $BSHEET_INPUTS_TBL,
                                $store_ids, $month, $year);
            }


            $rows = DB::select( DB::raw($sql) );
            if( !empty($rows) )
                $return_val = $rows[0]->labor_hours;

            unset($rows, $sql);

            return $return_val;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Returns Mean & Std-Dev
     *
     * param IN: db row(s)
     * param OUT: return array mean & std-dev
     *
     * @return integer
     */
    public static function getMeanNStdDev($row_obj)
    {
        try
        {
            $return_arr = array();

            if( !empty($row_obj) ) :
                
                foreach($row_obj as $row) {

                    if( !empty($row->my_store_name) ) :
                        
                        if( $row->my_store_name=='avg' )
                            $return_arr['mean_val'] = $row->dv;

                        if( $row->my_store_name=='sd' )
                            $return_arr['sd_val'] = $row->dv;

                    endif;
                    
                }
            endif;

            return $return_arr;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
    

    /**
     * Returns Mean, Std-Dev & Average
     *
     * param IN: db row(s)
     * param OUT: return array mean, std-dev & average
     *
     * @return integer
     */
    public static function getMeanStdDevNAvg($row_obj)
    {
    	try
    	{
    		$return_arr = array();
    
    		if( !empty($row_obj) ) :
    
    		foreach($row_obj as $row) {
    
    			if( !empty($row->my_store_name) ) :
    
	    			if( $row->my_store_name=='avg' )
	    				$return_arr['mean_val'] = $row->dv;
	    
	    			if( $row->my_store_name=='sd' )
	    				$return_arr['sd_val'] = $row->dv;

    				if( $row->my_store_name=='Average' )
    					$return_arr['avg_val'] = $row->dv;
	    					 
    			endif;
    
    		}
    		endif;
    
    		return $return_arr;
    	}
    	catch(Exception $err_obj)
    	{
    		show_error($err_obj->getMessage());
    	}
    }
    
    
    
    

    /**
     * Returns Array based on chart-mode
     * i.e. either "Normal-Distribution" OR "Column"
     *
     * param IN: array, key
     * param OUT: return array
     *
     * @return array
     */
    public static function getArrayByMode($arr, $mode)
    {
        try
        {
            $return_arr = array();

            if( !empty($arr) ) :
                
                $arr_index = 0;
                foreach($arr as $key=>$row_arr) {
                    
                    if( $key==$mode ) :
                        
                        foreach($row_arr as $sub_arr) :
                            
                            if( is_array($sub_arr) ) :
                                if( array_key_exists("store_id", $sub_arr) ) {
                                    
                                    $return_arr[$arr_index]['store_id'] = $sub_arr['store_id'];
                                    $return_arr[$arr_index]['store_name'] = $sub_arr['store_name'];
                                    $return_arr[$arr_index]['revenue'] = $sub_arr['revenue'];
                                    $return_arr[$arr_index]['ND'] = $sub_arr['ND'];
                                    $return_arr[$arr_index]['region_color'] = $sub_arr['region_color'];
                                    $return_arr[$arr_index]['line_marker'] = $sub_arr['line_marker'];
                                    
                                    $arr_index++;
                                        
                                }
                            endif;
                            
                        endforeach;
                        

                    endif;
                    
                }
            endif;

            return $return_arr;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }

    
    /**
     * return user-type
     *
     * param IN: user-type int
     * param OUT: user-type string
     *
     * @return string
     */
    public static function getUserTypeName($usr_type)
    {
        try
        {
            $str_user_type = "Site Administrator";
            
            switch ($usr_type) {
            	case 1: $str_user_type = "Site Administrator";
            			break;
            	case 2: $str_user_type = "Franchisor Admin";
            			break;
            	case 3: $str_user_type = "Field Consultant";
            			break;
            	case 4: $str_user_type = "Franchisee User";
            			break;
            	default: $str_user_type = "Site Administrator";
            			break;
            }

            return $str_user_type;
        }
        catch(Exception $err_obj)
        {
            show_error($err_obj->getMessage());
        }
    }
    
    
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # 			NEW FUNCTION(S) - BEGIN
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	    
	    /**
	     * Returns Last 12 Month(s) KPI-specific Data
	     * based on logged-in user-type & selected-store
	     *
	     * param IN: KPI, logged-user-type, month, year, selected-store
	     * param OUT: last 12 month(s) Planned, Actual & System-Avg Data
	     *
	     * @return array
	     */
	    public static function getLast12MonthsData($param_KPI, $param_user_type, $param_month, $param_year, $param_selected_store)
	    {
	    	try
	    	{
	    		$return_arr = array();
	    
	    		# I: preparing query based on param_in(s)...
    			$sql = sprintf("CALL zev_bm_last_12_month_analysys('%s', %d, %d, %d, %d) ",
    							$param_KPI, $param_user_type, $param_month, $param_year, $param_selected_store);
	    
	    		$rows = DB::select( DB::raw($sql) );
	    
	    		$return_arr = json_decode(json_encode((array) $rows), true);
	    
    			unset($rows, $sql);
    
    			return $return_arr;
	    	}
	    	catch(Exception $err_obj)
	    	{
	    		show_error($err_obj->getMessage());
	    	}
	    }
	    
	    
	    
	    /**
	     * Returns Number of Store(s) who
	     * submitted for that month's
	     *
	     * param IN: month, year, franchisor-admin-ID
	     * param OUT: store-count
	     *
	     * @return integer
	     */
	    public static function getStoreCount($param_user_id, $param_month, $param_year)
	    {
	    	try
	    	{
	    		$return_val = null;
	    
	    		# I: INCOME-STATEMENT DB Table...
	    		$INCOME_STMT_TBL = getenv('DB_PREFIX') ."income_stmt_master";
	    
	    
	    		# II: preparing query based on user-type, month & year...
	    		$sql = sprintf("SELECT COUNT(DISTINCT(`i_store_id`)) AS `no_of_shops` FROM %s
                            	WHERE
	    							`i_user_id`=%d AND
	    							`i_month`=%d AND
	    							`i_year`=%d ",
	                                $INCOME_STMT_TBL, $param_user_id,
	                                $param_month, $param_year);
	    
	    		$rows = DB::select( DB::raw($sql) );
	    		if( !empty($rows) )
	    			$return_val = $rows[0]->no_of_shops;
	    
	    			unset($rows, $sql);
	    
	    			return $return_val;
	    	}
	    	catch(Exception $err_obj)
	    	{
	    		show_error($err_obj->getMessage());
	    	}
	    }
	     

	    

	    /**
	     * Returns Number of Store(s) who
	     * submitted for that month's
	     * into DaySales table
	     *
	     * param IN: month, year, franchisor-admin-ID
	     * param OUT: store-count
	     *
	     * @return integer
	     */
	    public static function getDaySalesStoreCount($param_user_id, $param_month, $param_year)
	    {
	    	try
	    	{
	    		$return_val = null;
	    	  
	    		# I: DAY-SALES & FRANCHISEE-MASTER DB Table...
	    		$FRANCHISEE_MASTER_TBL = getenv('DB_PREFIX') ."franchisee_master";
	    		$DAYSALES_TBL = getenv('DB_PREFIX') ."erply_daysales";
	    	  
	    	  
	    		# II: preparing query based on user-type, month & year...
	    		$sql = sprintf("SELECT COUNT(DISTINCT(B.`erply_account_number`)) AS `no_of_shops`
	    						FROM
	    							%s A LEFT JOIN %s B
	    							ON A.`s_account_number`=B.`erply_account_number`
                            	WHERE
	    							A.`i_franchisor_id`=%d AND
	    							MONTH(B.`erplytrans_date`)=%d AND
	    							YEAR(B.`erplytrans_date`)=%d ",
    	    					$FRANCHISEE_MASTER_TBL, $DAYSALES_TBL,
    	    					$param_user_id, $param_month, $param_year);
	    	  
	    		$rows = DB::select( DB::raw($sql) );
	    		if( !empty($rows) )
	    			$return_val = $rows[0]->no_of_shops;
	    			 
    			unset($rows, $sql);
    			 
    			return $return_val;
	    	}
	    	catch(Exception $err_obj)
	    	{
	    		show_error($err_obj->getMessage());
	    	}
	    }
	    
	     
	    
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # 			NEW FUNCTION(S) - END
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}