<?php

namespace App\Helpers;
use DB;

class Utility {

    /**
    * Returns salted encrypted password
    *
    * @param $string
    * @return string
    */
    public static function get_salted_password($password)
    {
        $salt = config('app.salt');
    	//$salt = 'iws_app';

        return sha1($salt.$password);
    }


    /**
     * Function to format input string
     *
     * @param $string
     * @return string
     */
    public static function get_formatted_string($str)
    {
        try
        {
            return htmlspecialchars(trim($str),ENT_QUOTES, 'UTF-8');
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }


    /**
     * Function to fetch unformatted string
     *
     * @param $string
     * @return string
     */
    public static function get_unformatted_string($str)
    {
        try
        {
            return trim($str);
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }




    /**
     * Misc: Function to get last executed query
     *
     * @return string
     */
    public static function get_last_query() {
        $queries = DB::getQueryLog();
        $sql = end($queries);

        if( ! empty($sql['bindings']))
        {
            $pdo = DB::getPdo();
            foreach($sql['bindings'] as $binding)
            {
                $sql['query'] =
                    preg_replace('/\?/', $pdo->quote($binding),
                        $sql['query'], 1);
            }
        }

        return $sql['query'];
    }


    /**
     * Misc: Function to get current date-time
     *
     * @return in datetime format
     */
    public static function get_db_datetime() {
        try
        {
            return date('Y-m-d H:i:s');

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }



    /**
     * Misc: Function to get random datetime
     *
     * @return in datetime format
     */
    public static function generate_rand_datetime($min_date, $max_date, $dt_format=null) {
        /* Gets 2 dates as string, earlier and later date.
           Returns date in between them.
        */

        $FORMAT = ( empty($dt_format) )? 'Y-m-d H:i:s': $dt_format;
        $min_epoch = strtotime($min_date);
        $max_epoch = strtotime($max_date);

        $rand_epoch = rand($min_epoch, $max_epoch);
        
        return date($FORMAT, $rand_epoch);
    }


    /**
     * Misc: Function to print array OR object
     *
     * print array
     */
    public static function dump($obj) {
        echo '<pre>';
            print_r($obj);
        echo '</pre>';
    }


    /**
     * Misc: Function to make readable word(s)
     * from hyphenated word(s)
     *
     * @return String
     */
    public static function get_proper_word($str, $flag=false) {
        try
        {
        	#$return_str = preg_replace('/-/', ' ', $str);
        	$return_str = ($flag)
        				  ? preg_replace('/_/', '-', $str)
        				  : ucwords(preg_replace('/-/', ' ', $str));
        				  

            return $return_str;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }


    # function to get file-extensions
    public static function get_extension($filename) {
        $x = explode('.', $filename);
        return '.'.end($x);
    }


    /**
     * Misc: Function to make hyphenated
     * Image Name
     *
     * @return String
     */
    public static function createImageName($str) {
        return trim( preg_replace('/[^\da-zA-Z\-]+/', '-', $str), '-' );
    }


    /**
     * Misc: Function to check if
     * the concerned file physically exists
     * OR not
     *
     * @return String
     */
    public static function test_file($file) {

        if( file_exists($file) ) {
            if( is_file($file) )
                return true;
            else
                return false;
        }
        else
            return false;
    }


    /**
     * Misc: Function to calculate the
     * Array Offset
     * i.e. Where to start
     *
     * @return String
     */
    public static function getArrOffset($arr, $top=null) {

        $arr_offset = 0;


        if( !empty($top) && count($arr)>$top ) {
            $extraa = count($arr)-$top;
            $arr_offset = ( $extraa>0 )? $extraa--: 0;
        }

        return $arr_offset;
    }


    /**
     * Misc: Function to format number
     *
     * param IN: number, decimal-separator, thousand-separator
     *
     * @return String
     */
    public static function formatNum($number, $dec_separator='.', $thousand_separator='') {

        return number_format($number, 2, $dec_separator, $thousand_separator);

    }


    /**
     * Misc: function to check whether the "Planned" data
     * falls within the data-range (here 2nd parameter)
     *
     * param IN: param1 - Array/Number, param2 - Array
     * param OUT: true OR false
     *
     * @return boolean
     */
    public static function ifWithinActualDataRange($param1, $param2) {

        $val_to_check = ( !empty($param1) )
                        ? ( (!is_array($param1))? $param1: $param1[0]['revenue'] )
                        : 0;

        $lower_limit = PHP_INT_MAX;
        $upper_limit = 0;
        foreach ($param2 as $arr) {
            $lower_limit = min($lower_limit, $arr['revenue']);
            $upper_limit = max($upper_limit, $arr['revenue']);
        }

        $returnVal = false;
        if( $val_to_check>=$lower_limit && $val_to_check<=$upper_limit )
            $returnVal = true;

        return $returnVal;
    }


	//// NEW
		# function to get "Monthly KPI Plan" range(s)...
		public static function getMonthlyKpiPlanRanges($order_by=null) {
			
			try {
				
				$RETURN_ARR = array();
				
				$KPI_MASTER_TBL = getenv('DB_PREFIX') ."kpi_master";
				
				$sql = sprintf("SELECT `d_range_min_val`, `d_range_max_val` FROM %s ",
								$KPI_MASTER_TBL);
				$sql .= ( !empty($order_by) )? " ORDER BY {$order_by} ": ' ORDER BY `i_id` ';
				
				$KPI_arr = DB::select( DB::raw($sql) );
				if($KPI_arr)
				{
					foreach ($KPI_arr as $kpi_info)
						$RETURN_ARR[] = array('min'=>$kpi_info->d_range_min_val,
											  'max'=>$kpi_info->d_range_max_val);
				}
				
				unset($KPI_arr, $sql);
				
				return $RETURN_ARR;
				
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
			
		}



}