<?php
namespace App\Services;
namespace App\Libraries;

use Illuminate\Support\Collection;
use Illuminate\Pagination\BootstrapThreePresenter;
use Illuminate\Pagination\LengthAwarePaginator as BasePaginator;

class MyPaginator extends BasePaginator{


    /**
     * Create a new paginator instance.
     *
     * @param  mixed  $items
     * @param  int  $perPage
     * @param  string $path Base path
     * @param  int $page
     * @return void
     */
    /*public function __construct($items, $perPage, $path, $page){
        // Set the "real" items that will appear here
        $trueItems = [];

        // That is, add the correct items
        for ( $i = $perPage*($page-1) ; $i < min(count($items),$perPage*$page) ; $i++ ){
            $trueItems[] = $items[$i];
        }

        // Set path as provided
        $this->path = $path;

        // Call parent
        parent::__construct($trueItems,count($items),$perPage);

        // Override "guessing" of page
        $this->currentPage = $page;
    }*/
    public function __construct($items, $total_items, $perPage, $path, $page){
        // Set path as provided
        $this->path = $path;

        // Call parent
        parent::__construct($items, $total_items,$perPage);

        // Override "guessing" of page
        $this->currentPage = $page;
    }

    /**
     * Get a URL for a given page number.
     *
     * @param  int  $page
     * @return string
     */
    public function url($page){
        if ($page <= 0) $page = 1;

        return $this->path."/".$page;
    }
}
