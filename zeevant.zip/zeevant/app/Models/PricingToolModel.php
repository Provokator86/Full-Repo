<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class PricingToolModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'erply_daysales';        
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
        $this->franchisee_tbl  = getenv('DB_PREFIX') .'franchisee_master';
        $this->kpi_tbl  = getenv('DB_PREFIX') .'kpi_details';
        $this->config_tbl  = getenv('DB_PREFIX') .'config_details';
        $this->cat_tbl = getenv('DB_PREFIX') .'category_map';       
    }

    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================        
        
        
        
         public function category_group(){
            
            
        $sql ="select distinct(`product_group_new`) from ".$this->cat_tbl; 

        $ret = DB::select(DB::raw($sql)); 
        
        return $ret;
                                
        }
        
        public function sub_category_group($cat_name){
            
            
        $sql ="select distinct(`subgroup_new`) as sub from ".$this->cat_tbl." Where product_group_new='".$cat_name."' and subgroup_new <>''"; 

        $ret = DB::select(DB::raw($sql)); 
        
        return $ret;
                                
        }
        
         public function pos_category_group(){
            
            
        $sql ="select distinct(`product_group`) from ".$this->cat_tbl; 

        $ret = DB::select(DB::raw($sql)); 
        
        return $ret;
                                
        }
        
        public function pos_sub_category_group($cat_name){
            
            
        $sql ="select distinct(`subgroup`) as sub from ".$this->cat_tbl." Where product_group='".$cat_name."' and subgroup_new <>''"; 

        $ret = DB::select(DB::raw($sql)); 
        
        return $ret;
                                
        }
        
        // chart 1
        public function getCumRevDetailsData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = array_key_exists('prev_date',$dt_time_arr)?$dt_time_arr['prev_date']:$dt_time_arr['current_date'];
                $prev_month = array_key_exists('prev_month',$dt_time_arr)?$dt_time_arr['prev_month']:$dt_time_arr['current_month'];
                $prev_year  =  array_key_exists('prev_year',$dt_time_arr)?$dt_time_arr['prev_year']:$dt_time_arr['current_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $item_code = array_key_exists('item_code',$dt_time_arr)?$dt_time_arr['item_code']:''; 
                /*$bi_group = array_key_exists('bi_group',$dt_time_arr)?$dt_time_arr['bi_group']:'';
                $category = array_key_exists('category',$dt_time_arr)?$dt_time_arr['category']:'';
                $sub_category = array_key_exists('sub_category',$dt_time_arr)?$dt_time_arr['sub_category']:'0';
                $product = array_key_exists('product',$dt_time_arr)?$dt_time_arr['product']:'';*/
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                
                
                $prev_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                //$prev_date = date('Y-m-d', strtotime('-1 day', strtotime($prev_date)));
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                
                                 $sql_tool =" call zev_pricing_tool_graph('".$stores."','".$prev_date."','".$req_date."','".$item_code."')";
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                
                                 $sql_tool =" call zev_pricing_tool_graph('".$store_id."','".$prev_date."','".$req_date."','".$item_code."')";
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_tool));  
               
                unset($sql_tod);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        
        // tabular data
        public function getCumulativeTableData($store_id, $dt_time_arr) {

            try
            {
               
                
                $prev_date = array_key_exists('prev_date',$dt_time_arr)?$dt_time_arr['prev_date']:$dt_time_arr['current_date'];
                $prev_month = array_key_exists('prev_month',$dt_time_arr)?$dt_time_arr['prev_month']:$dt_time_arr['current_month'];
                $prev_year  =  array_key_exists('prev_year',$dt_time_arr)?$dt_time_arr['prev_year']:$dt_time_arr['current_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $week_of_day = array_key_exists('week_of_day',$dt_time_arr)?$dt_time_arr['week_of_day']:0; 
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $prev_date = $prev_year.'-'.$prev_month.'-'.$prev_date;                  
                
                $category = array_key_exists('category',$dt_time_arr)?$dt_time_arr['category']:'';
                $subcategory = array_key_exists('subcategory',$dt_time_arr)?$dt_time_arr['subcategory']:'0';
                $product = array_key_exists('product',$dt_time_arr)?$dt_time_arr['product']:''; 
                $group = array_key_exists('group',$dt_time_arr)?$dt_time_arr['group']:'';
                $orderby = array_key_exists('orderby',$dt_time_arr)?$dt_time_arr['orderby']:'';       
                
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year                               
                                
                                
                                 $sql_tool =" call zev_pricing_tool_table('".$stores."','".$prev_date."','".$req_date."','".$category."','".$subcategory."','".$product."','".$group."','".$orderby."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                $sql_tool =" call zev_pricing_tool_table('".$store_id."','".$prev_date."','".$req_date."','".$category."','".$subcategory."','".$product."','".$group."','".$orderby."')";
                               
                                
                               
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_tool));  
              
               //print_r($ret_);exit;
               unset($sql_tod);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}
