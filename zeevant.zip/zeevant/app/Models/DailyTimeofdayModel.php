<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class DailyTimeofdayModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'erply_daysales';        
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
        $this->franchisee_tbl  = getenv('DB_PREFIX') .'franchisee_master';
        $this->kpi_tbl  = getenv('DB_PREFIX') .'kpi_details';
        $this->config_tbl  = getenv('DB_PREFIX') .'config_details';
    }

    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================        
        
        
        // chart 1
        public function getCumRevDetailsData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = array_key_exists('prev_date',$dt_time_arr)?$dt_time_arr['prev_date']:$dt_time_arr['current_date'];
                $prev_month = array_key_exists('prev_month',$dt_time_arr)?$dt_time_arr['prev_month']:$dt_time_arr['current_month'];
                $prev_year  =  array_key_exists('prev_year',$dt_time_arr)?$dt_time_arr['prev_year']:$dt_time_arr['current_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $week_of_day = array_key_exists('week_of_day',$dt_time_arr)?$dt_time_arr['week_of_day']:0; 
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                
                
                $prev_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                //$prev_date = date('Y-m-d', strtotime('-1 day', strtotime($prev_date)));
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                
                                 $sql_tod =" call zev_ds_time_of_day('".$stores."','".$prev_date."','".$req_date."','".$week_of_day."')";
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                
                                 $sql_tod =" call zev_ds_time_of_day('".$store_id."','".$prev_date."','".$req_date."','".$week_of_day."')";
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_tod));  
               
                unset($sql_tod);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        
        // tabular data
        public function getCumulativeTableData($store_id, $dt_time_arr) {

            try
            {
               
                
                $prev_date = array_key_exists('prev_date',$dt_time_arr)?$dt_time_arr['prev_date']:$dt_time_arr['current_date'];
                $prev_month = array_key_exists('prev_month',$dt_time_arr)?$dt_time_arr['prev_month']:$dt_time_arr['current_month'];
                $prev_year  =  array_key_exists('prev_year',$dt_time_arr)?$dt_time_arr['prev_year']:$dt_time_arr['current_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $week_of_day = array_key_exists('week_of_day',$dt_time_arr)?$dt_time_arr['week_of_day']:0; 
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $prev_date = $prev_year.'-'.$prev_month.'-'.$prev_date;                
                
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year                               
                                
                                
                                 $sql_tod =" call zev_ds_time_of_day('".$stores."','".$prev_date."','".$req_date."','".$week_of_day."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                $sql_tod =" call zev_ds_time_of_day('".$store_id."','".$prev_date."','".$req_date."','".$week_of_day."')";
                               
                                
                               
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_tod));  
              
               //print_r($ret_);exit;
               unset($sql_tod);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // top info
        public function getCumRevTableData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                $sql_yesterday ="SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date = '".$yesterday."' 
                                group BY a.erplytrans_date  "; 
                                
                                $sql_achievement ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_current FROM 
                                (SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date BETWEEN '".$previ_date."'  AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";
                                
                                $sql_target ="select ROUND(sum(get_company_target_day_revenue('".$stores."',erplytrans_date))) as tr from  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN ('".$stores."') and a.erplytrans_date between DATE_SUB('".$req_date."', INTERVAL 1 MONTH) AND '".$req_date."'
                                and  a.company_id IS NOT NULL";
                               
                                 
                                $sql_planned ="select ROUND((d_monthly_plan_mark/".$today_day_no."),2) as planned_val from ".$this->kpi_tbl." where i_kpi_id = '1'
                                and i_store_id IN (".$stores.") 
                                and (i_month = '".$current_month."' and i_year = '".$current_year."')";
                               
                                                             

                } else {    // i.e. for a particular-store

                                # IIA: preparing SQL...fetching planned KPI val of selected store...
                                $sql_yesterday ="SELECT erplytrans_date, ROUND(SUM(a.gross_sales),2) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id ='".$store_id."' AND erplytrans_date = '".$yesterday."' 
                                group BY a.erplytrans_date  "; 
                               
                                $sql_achievement ="SELECT erplytrans_date,ROUND((@s := @s + sum_sales),2) as cumulative_current FROM 
                                (SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM zeevant_erply_daysales a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id ='".$store_id."' AND erplytrans_date BETWEEN '".$previ_date."'  AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";
                                
                                $sql_target ="select ROUND(sum(get_company_target_day_revenue('".$store_id."',erplytrans_date))) as tr from  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id = '".$store_id."' and a.erplytrans_date between DATE_SUB('".$req_date."', INTERVAL 1 MONTH) AND '".$req_date."'
                                and  a.company_id IS NOT NULL";
                                
                                $sql_planned ="select ROUND((d_monthly_plan_mark/".$current_day_no."),2) as planned_val from ".$this->kpi_tbl." where i_kpi_id = '1'
                                and i_store_id ='".$store_id."'
                                and (i_month = '".$current_month."' and i_year = '".$current_year."')";;
                                
                                
                }
                
                $ret_yesterday = DB::select(DB::raw($sql_yesterday));
                $ret_achievement = DB::select(DB::raw($sql_achievement));
                $ret_target = DB::select(DB::raw($sql_target));  
                $ret_planned = DB::select(DB::raw($sql_planned));
                
                if(!empty($ret_yesterday)){
                $ret_yesterday = $ret_yesterday[0]->sum_sales;
                }
                else{
                $ret_yesterday = 0;    
                }
                
                if(!empty($ret_achievement)){
                $ret_achievement = array_reverse($ret_achievement);    
                $ret_achievement = $ret_achievement[0]->cumulative_current/2;
                }
                else{
                $ret_achievement = 0;    
                }
                
                if(!empty($ret_target)){
                $ret_target = $ret_target[0]->tr;
                }
                else{
                $ret_target = 0;    
                }
                
                if(!empty($ret_planned)){
                $ret_planned = $ret_planned[0]->planned_val;
                }
                else{
                $ret_planned = 0;    
                }
                
                $ret_goal =  $ret_target - $ret_achievement;  
               
                
                
               $ret_ = array('ret_yesterday'=>$ret_yesterday,'ret_achievement'=>$ret_achievement,'ret_target'=>$ret_target,'ret_goal'=>$ret_goal,'ret_planned'=>$ret_planned);
               
               
                /*$return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2);*/

                unset($sql_yesterday,$sql_achievement);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}
