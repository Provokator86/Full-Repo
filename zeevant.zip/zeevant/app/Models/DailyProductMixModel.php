<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class DailyProductMixModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl,$cat_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'erply_daysales';       
        $this->cat_tbl = getenv('DB_PREFIX') .'franchisor_categogy_map';       
        
    }

    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================
        
        public function category_group(){
            
            
        $sql ="select distinct(`s_product_group`) from ".$this->cat_tbl; 

        $ret = DB::select(DB::raw($sql)); 
        
        return $ret;
                                
        }
        
        
        // chart 1
        public function getRevenueData($store_id, $dt_time_arr) {

            try
            {
               
               
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
               
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                $sql_marching =" CALL zev_ds_product_mix_revenue_my_store('".$stores."','".$default_option_value."','".$req_date."','".$default_type_value."')"; 
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                //$sql_marching =" CALL zev_ds_discount('".$store_id."','".$req_date."')"; 
                                $sql_marching =" CALL zev_ds_product_mix_revenue_my_store('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_marching));  
               
                unset($sql_marching);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        // chart 2
        public function getSystemRevenueData($store_id, $dt_time_arr) {

            try
            {
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                
                                $sql_deviation =" CALL zev_ds_product_mix_revenue_my_system('".$stores."','".$default_option_value."','".$req_date."','".$default_type_value."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                                $sql_deviation =" CALL zev_ds_product_mix_revenue_my_system('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 3
        public function getContributionData($store_id, $dt_time_arr) {

            try
            {
               
               
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                 
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                $sql_marching =" CALL zev_ds_product_mix_contribution_my_store('".$stores."','".$default_option_value."','".$req_date."','".$default_type_value."')"; 
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                //$sql_marching =" CALL zev_ds_discount('".$store_id."','".$req_date."')"; 
                                $sql_marching =" CALL zev_ds_product_mix_contribution_my_store('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_marching));  
               
                unset($sql_marching);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 4        
        public function getSystemContributionData($store_id, $dt_time_arr) {

            try
            {
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                
                                $sql_deviation =" CALL zev_ds_product_mix_contribution_my_system('".$stores."','".$default_option_value."','".$req_date."','".                $default_type_value."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                                $sql_deviation =" CALL zev_ds_product_mix_contribution_my_system('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 5
        public function getShelfData($store_id, $dt_time_arr) {

            try
            {
               
               
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                 
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                $sql_marching =" CALL zev_ds_product_mix_contribution_my_store_shelf_area('".$stores."','".$default_option_value."','".$req_date."','".$default_type_value."')"; 
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                //$sql_marching =" CALL zev_ds_discount('".$store_id."','".$req_date."')"; 
                                $sql_marching =" CALL zev_ds_product_mix_contribution_my_store_shelf_area('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_marching));  
               
                unset($sql_marching);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 4        
        public function getSystemShelfData($store_id, $dt_time_arr) {

            try
            {
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                
                                $sql_deviation =" CALL zev_ds_product_mix_contribution_my_system_shelf_area('".$stores."','".$default_option_value."','".$req_date."','".                $default_type_value."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                               $sql_deviation =" CALL zev_ds_product_mix_contribution_my_system_shelf_area('".$store_id."','".$default_option_value."','".$req_date."','".$default_type_value."')";   
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // table
        
        // tabular data
        public function getCumulativeTableData($store_id, $dt_time_arr) {

            try
            {
               
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                $default_option_value = array_key_exists('default_option_value',$dt_time_arr)?$dt_time_arr['default_option_value']:'';
                $default_type_value = array_key_exists('default_type_value',$dt_time_arr)?$dt_time_arr['default_type_value']:0;
                
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year                               
                                
                                
                                 $sql_tod =" call zev_ds_product_mix_table('".$stores."','".$default_option_value."','".$req_date."')";                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                $sql_tod =" call zev_ds_product_mix_table('".$store_id."','".$default_option_value."','".$req_date."')";                                   
                               
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_tod));  
              
               //print_r($ret_);exit;
               unset($sql_tod);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // For dashboard top 5 Product chart 
        public function getTop10ProductData($store_id, $dt_time_arr) {

            try
            {
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                
                                $sql_deviation =" CALL zev_ds_top10_sellers_all_store('".$stores."','".$req_date."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                               $sql_deviation =" CALL zev_ds_top10_sellers_all_store('".$store_id."','".$req_date."')";
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        
        
    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}
