<?php

namespace App\models;

use App\Helpers\Utility;
use Illuminate\Database\Eloquent\Model;

use DB;

class IncomeStmtModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'income_stmt_master';
        $this->inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
    }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to fetch Income-Statement info...
        public function fetchIncomeStmtInfo($s_where=null)
        {

            try {
                $ret_ = null;
                $sql = sprintf("SELECT
                                    A.`i_id` `i_master_id`, A.`i_user_id`, A.`i_locked`,
                                    A.`i_month`, A.`i_year`,
                                    IFNULL(A.`dt_updated`, A.`dt_added`) `dt_last_modified`,
                                    B.`i_id` `i_details_id`, B.*,
                                    CONCAT_WS(' ', C.`s_first_name`, C.`s_last_name`) `s_last_modified_by`
                                FROM
                                    %s A LEFT JOIN %s B
                                      ON A.`i_id`=B.`i_income_stmt_id`
                                    LEFT JOIN %s C
                                      ON A.`i_user_id`=C.`i_id`
                                WHERE %s ",
                                $this->master_tbl, $this->inputs_tbl, $this->users_tbl, $s_where);
                $ret_ = DB::select(DB::raw($sql));

                return $ret_;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }


        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================

        // function to calculate Net-Income from "_income_stmt_master" &
        // "_income_stmt_inputs" table(s)...
        public function getIncomeStmtData($store_id, $dt_time_arr) {

            try
            {
                $month = $dt_time_arr['month'];
                $year  = $dt_time_arr['year'];

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT
                                        AVG(B.`d_net_income`) `net_income`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                        A.`i_month`=%d AND A.`i_year`=%d AND
                                        A.`i_store_id` IN (%s) ",
                                    $this->master_tbl, $this->inputs_tbl, $month, $year, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching Income-Statement of a selected store...
                    $sql = sprintf("SELECT
                                        B.`d_net_income` AS `net_income`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                       A.`i_month`=%d AND A.`i_year`=%d AND
                                       A.`i_store_id`=%d ",
                                    $this->master_tbl, $this->inputs_tbl, $month, $year, $store_id);
                }


                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2, '.', '');

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // for last 12 month(s) data...
        public function getLast12MonthsIncomeStmtData($store_id, $selected_dt=null) {

            try
            {
                $DT_SELECTED = ( !empty($selected_dt) )
                               ? $selected_dt
                               : date('Y-m-d', mktime(0, 0, 0, date('m')-1, date('d'), date('Y')));

                $DT_BETWEEN_CLAUSE = " BETWEEN DATE('{$DT_SELECTED}') - INTERVAL 12 MONTH AND DATE('{$DT_SELECTED}') ";

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT
                                        AVG(B.`d_net_income`) `kpi_val`,
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', A.`i_month`, '/', A.`i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) AS `rcvd_dt`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                        A.`i_store_id` IN (%s) AND
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', A.`i_month`, '/', A.`i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) %s
                                    GROUP BY `rcvd_dt` ",
                                    $this->master_tbl, $this->inputs_tbl, $stores, $DT_BETWEEN_CLAUSE);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching Income-Statement of selected store...
                    $sql = sprintf("SELECT
                                        B.`d_net_income` AS `kpi_val`,
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', A.`i_month`, '/', A.`i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) AS `rcvd_dt`                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                         A.`i_store_id` = %d AND
                                         STR_TO_DATE(
                                              CONCAT( DAY(NOW()), '/', A.`i_month`, '/', A.`i_year` ),
                                                '%%d/%%m/%%Y'
                                         ) %s ",
                                    $this->master_tbl, $this->inputs_tbl, $store_id, $DT_BETWEEN_CLAUSE);
                }


                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = $ret_;

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to get different field(s) of "income-statement" table...
        public function getFieldData($columnID, $columnAlias=null, $stores, $arr_dt_time, $sql_mode="SUM") {

            try {
                $month = $arr_dt_time['month'];
                $year  = $arr_dt_time['year'];

                $ALIAS_FLD = ( !empty($columnAlias) )? $columnAlias: $columnID;

                if( is_array($stores) ) {   // i.e. Multiple Store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $stores);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT
                                        IFNULL(AVG(B.`%s`), 0) `%s`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                        A.`i_month`=%d AND A.`i_year`=%d AND
                                        A.`i_store_id` IN (%s) ",
                                    $columnID, $ALIAS_FLD,
                                    $this->master_tbl, $this->inputs_tbl,
                                    $month, $year, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching concerned data of the selected store...
                    $sql = sprintf("SELECT
                                        IFNULL(B.`%s`, 0) AS `%s`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                       A.`i_month`=%d AND A.`i_year`=%d AND
                                       A.`i_store_id`=%d ",
                                    $columnID, $ALIAS_FLD,
                                    $this->master_tbl, $this->inputs_tbl,
                                    $month, $year, $stores);
                }


                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->{$ALIAS_FLD}, 2, '.', '');

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}