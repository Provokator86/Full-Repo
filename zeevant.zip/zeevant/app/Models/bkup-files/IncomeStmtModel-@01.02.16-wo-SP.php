<?php

namespace App\models;

use App\Helpers\Utility;
use Illuminate\Database\Eloquent\Model;

use DB;
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

class IncomeStmtModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'income_stmt_master';
        $this->inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
    }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to fetch Income-Statement info...
        public function fetchIncomeStmtInfo($s_where=null)
        {

            try {
                $ret_ = null;
                $sql = sprintf("SELECT
                                    A.`i_id` `i_master_id`, A.`i_user_id`, A.`i_locked`,
                                    A.`i_month`, A.`i_year`,
                                    IFNULL(A.`dt_updated`, A.`dt_added`) `dt_last_modified`,
                                    B.`i_id` `i_details_id`, B.*,
                                    CONCAT_WS(' ', C.`s_first_name`, C.`s_last_name`) `s_last_modified_by`
                                FROM
                                    %s A LEFT JOIN %s B
                                      ON A.`i_id`=B.`i_income_stmt_id`
                                    LEFT JOIN %s C
                                      ON A.`i_user_id`=C.`i_id`
                                WHERE %s ",
                                $this->master_tbl, $this->inputs_tbl, $this->users_tbl, $s_where);
                $ret_ = DB::select(DB::raw($sql));

                return $ret_;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }


        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================

        // function to calculate Net-Income from "_income_stmt_master" &
        // "_income_stmt_inputs" table(s)...
        public function getIncomeStmtData($store_id, $dt_time_arr) {

            try
            {
                $month = $dt_time_arr['month'];
                $year  = $dt_time_arr['year'];

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT
                                        AVG(B.`d_net_income`) `net_income`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                        A.`i_month`=%d AND A.`i_year`=%d AND
                                        A.`i_store_id` IN (%s) ",
                                    $this->master_tbl, $this->inputs_tbl, $month, $year, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching Income-Statement of a selected store...
                    $sql = sprintf("SELECT
                                        B.`d_net_income` AS `net_income`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                       A.`i_month`=%d AND A.`i_year`=%d AND
                                       A.`i_store_id`=%d ",
                                    $this->master_tbl, $this->inputs_tbl, $month, $year, $store_id);
                }


                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2, '.', '');

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // for last 12 month(s) data...
        public function getLast12MonthsIncomeStmtData($store_id, $kpi_id=null, $selected_dt=null) {

            try
            {
                $DT_SELECTED = ( !empty($selected_dt) )
                               ? $selected_dt
                               : date('Y-m-d', mktime(0, 0, 0, date('m')-1, date('d'), date('Y')));

                $DT_BETWEEN_CLAUSE = " BETWEEN DATE('{$DT_SELECTED}') - INTERVAL 12 MONTH AND DATE('{$DT_SELECTED}') ";
                
                # for date-time array...
                $DT_TIME_ARR = array('month'=>date('m', strtotime($DT_SELECTED)),
                                     'year' =>date('Y', strtotime($DT_SELECTED)));
                $PARAM_STORE = ( is_array($store_id) )? 0: $store_id;
                
                //// NEW - MySQL Expression...
                $FLD = ( !empty($kpi_id) )? $this->getSQLExpression($kpi_id, $DT_TIME_ARR, $PARAM_STORE): B.`d_net_income`;

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT DATE_FORMAT(rcvd_dt,'%%Y-%%m') AS rcvd_dt, SUM(kpi_val) AS kpi_val FROM

                                        (SELECT
                                            STR_TO_DATE( CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ), '%%d/%%m/%%Y' ) AS `rcvd_dt`,
                                            %2\$s `kpi_val`
                                        FROM
                                            %3\$s A LEFT JOIN %4\$s B
                                            ON A.`i_id`=B.`i_income_stmt_id`
                                        WHERE
                                            A.`i_store_id` IN (%5\$s) AND
                                            STR_TO_DATE( CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ), '%%d/%%m/%%Y' ) BETWEEN DATE('%1\$s') - INTERVAL 12 MONTH AND DATE('%1\$s')
                                        GROUP BY `rcvd_dt`

                                        UNION

                                        (SELECT
                                            DISTINCT DATE_FORMAT((SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY,'%%Y-%%m-01') erplytrans_date,0 val 
                                        FROM 
                                         (SELECT 0 a UNION SELECT 1 a UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 
                                          UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d, 
                                        (SELECT 0 b UNION SELECT 10 UNION SELECT 20 UNION SELECT 30 UNION SELECT 40 UNION SELECT 50 
                                             UNION SELECT 60 UNION SELECT 70 UNION SELECT 80 UNION SELECT 90) m,
                                        (SELECT 0 c UNION SELECT 100 UNION SELECT 200 UNION SELECT 300 UNION SELECT 400) y 
                                        WHERE (SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY < (select date('2015-12-29')) 
                                        ORDER BY a + b +c)) T

                                        GROUP BY DATE_FORMAT(rcvd_dt,'%%Y-%%m') ",
                                    $DT_SELECTED, $FLD, $this->master_tbl, $this->inputs_tbl, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching Income-Statement of selected store...
                    $sql = sprintf("SELECT DATE_FORMAT(rcvd_dt,'%%Y-%%m') AS rcvd_dt, SUM(kpi_val) AS kpi_val FROM

                                        (SELECT
                                            STR_TO_DATE( CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ), '%%d/%%m/%%Y' ) AS `rcvd_dt`,
                                            %2\$s `kpi_val`
                                        FROM
                                            %3\$s A LEFT JOIN %4\$s B
                                            ON A.`i_id`=B.`i_income_stmt_id`
                                        WHERE
                                            A.`i_store_id`=%5\$d AND
                                            STR_TO_DATE( CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ), '%%d/%%m/%%Y' ) BETWEEN DATE('%1\$s') - INTERVAL 12 MONTH AND DATE('%1\$s')
                                        GROUP BY `rcvd_dt`

                                        UNION

                                        (SELECT
                                            DISTINCT DATE_FORMAT((SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY,'%%Y-%%m-01') erplytrans_date,0 val 
                                        FROM 
                                         (SELECT 0 a UNION SELECT 1 a UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 
                                          UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d, 
                                        (SELECT 0 b UNION SELECT 10 UNION SELECT 20 UNION SELECT 30 UNION SELECT 40 UNION SELECT 50 
                                             UNION SELECT 60 UNION SELECT 70 UNION SELECT 80 UNION SELECT 90) m,
                                        (SELECT 0 c UNION SELECT 100 UNION SELECT 200 UNION SELECT 300 UNION SELECT 400) y 
                                        WHERE (SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY < (select date('2015-12-29')) 
                                        ORDER BY a + b +c)) T

                                        GROUP BY DATE_FORMAT(rcvd_dt,'%%Y-%%m') ",
                                    $DT_SELECTED, $FLD, $this->master_tbl, $this->inputs_tbl, $store_id);
                }

                # echo $sql ."<br />==============<br />";
                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) ) {
                    $start_index = ( count($ret_)>12 )? (count($ret_)-12): 0;
                    $ret_ = array_slice($ret_, $start_index);
                    
                    # utils::dump($ret_);
                    $return_val = $ret_;
                }

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to get different field(s) of "income-statement" table...
        public function getFieldData($columnID, $columnAlias=null, $stores, $arr_dt_time, $sql_mode="SUM") {

            try {
                $month = $arr_dt_time['month'];
                $year  = $arr_dt_time['year'];

                $ALIAS_FLD = ( !empty($columnAlias) )? $columnAlias: $columnID;

                if( is_array($stores) ) {   // i.e. Multiple Store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $stores);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    $sql = sprintf("SELECT
                                        IFNULL(AVG(B.`%s`), 0) `%s`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                        A.`i_month`=%d AND A.`i_year`=%d AND
                                        A.`i_store_id` IN (%s) ",
                                    $columnID, $ALIAS_FLD,
                                    $this->master_tbl, $this->inputs_tbl,
                                    $month, $year, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching concerned data of the selected store...
                    $sql = sprintf("SELECT
                                        IFNULL(B.`%s`, 0) AS `%s`
                                    FROM
                                        %s A LEFT JOIN %s B
                                        ON A.`i_id`=B.`i_income_stmt_id`
                                    WHERE
                                       A.`i_month`=%d AND A.`i_year`=%d AND
                                       A.`i_store_id`=%d ",
                                    $columnID, $ALIAS_FLD,
                                    $this->master_tbl, $this->inputs_tbl,
                                    $month, $year, $stores);
                }


                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->{$ALIAS_FLD}, 2, '.', '');

                unset($sql, $ret_);

                # dd($ret_);
                return $return_val;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

        
        // function to get actual MySQL expression for selected KPI...
        public function getSQLExpression($kpi_index, $dt_time_arr=null, $store_id=null) {
            
            try {
                
                $EXPRESSION = null;
                
                switch($kpi_index) {
                    
                    case 1: $EXPRESSION = ' B.`d_is_40000` ';   // Revenue
                            break;
                    case 2: $EXPRESSION = ' (1 - (B.`d_is_50000`/B.`d_is_40100`))*100 ';    // Gross Margin
                            break;
                    case 3: $EXPRESSION = ' B.`d_is_40200` ';   // Internet Sales
                            break;
                    case 4: $MONTH = $dt_time_arr['month']; $YR  = $dt_time_arr['year'];
                            $EXPRESSION = " (B.`d_is_40100`/get_store_ticket_month({$MONTH}, {$YR}, {$store_id})) "; // Average Ticket
                            break;
                    case 5: $EXPRESSION = ' (B.`d_is_60100`/B.`d_is_40000`)*100 ';  // Marketing % of Sales
                            break;
                    case 6: $MONTH = $dt_time_arr['month']; $YR  = $dt_time_arr['year'];
                            $EXPRESSION = " (B.`d_is_40100`/get_store_labor_hour_month({$MONTH}, {$YR}, {$store_id})) "; // Labor Efficiency
                            break;
                    case 7: $MONTH = $dt_time_arr['month']; $YR  = $dt_time_arr['year'];
                            $EXPRESSION = " (B.`d_is_50000`*12/get_store_inventory_month({$MONTH}, {$YR}, {$store_id})) ";   // Inventory Turns
                            break;
                    case 10: $MONTH = $dt_time_arr['month']; $YR  = $dt_time_arr['year'];   // Average Discount
                             $EXPRESSION = " (get_store_discount_month({$MONTH}, {$YR}, {$store_id})/(B.`d_is_40100`+get_store_discount_month({$MONTH}, {$YR}, {$store_id})))*100 ";
                             break;
                    default: $EXPRESSION = ' B.`d_is_40000` ';
                            break;
                }
                
                return $EXPRESSION;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }

    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}