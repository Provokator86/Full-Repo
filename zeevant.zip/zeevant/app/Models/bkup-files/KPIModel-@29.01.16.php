<?php

namespace App\models;

use App\Helpers\Utility;
use Illuminate\Database\Eloquent\Model;

use DB;

class KPIModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $details_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'kpi_master';
        $this->details_tbl = getenv('DB_PREFIX') .'kpi_details';
    }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        //// From Master-Table
        // function to fetch master-record(s) based on limit, offset...
        public function fetchRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry = "SELECT * FROM ". $this->master_tbl;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch master-record(s) based on limit, offset...
        public function fetchRecordsArr($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry = "SELECT * FROM ". $this->master_tbl;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                $return_arr = array();
                $count = 0;

                # II: fetching associated franchisee(s)...
                foreach($ret_ as $KPI_plan) {
                    $return_arr[$count]['i_id'] = $KPI_plan->i_id;
                    $return_arr[$count]['s_name'] = $KPI_plan->s_name;
                    $return_arr[$count]['d_range_min_val'] = $KPI_plan->d_range_min_val;
                    $return_arr[$count]['d_range_max_val'] = $KPI_plan->d_range_max_val;
                    $return_arr[$count]['kpi_plan_val'] = '';

                    $count++;
                }

                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of master-record(s)...
        public function getTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->master_tbl, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        //// From Child-Details Table
        // function to fetch details-record(s) based on limit, offset...
        public function fetchKPIDetailRecords($s_where=null, $s_sub_where=null, $s_order_by=null) {

            try
            {
                $s_qry= sprintf("SELECT * FROM %s ", $this->master_tbl);
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                $ret_ = DB::select(DB::raw($s_qry));

                $return_arr = array();
                $count = 0;

                # II: fetching associated franchisee(s)...
                foreach($ret_ as $KPI_plan) {
                    $return_arr[$count]['i_id'] = $KPI_plan->i_id;
                    $return_arr[$count]['s_name'] = $KPI_plan->s_name;
                    $return_arr[$count]['d_range_min_val'] = $KPI_plan->d_range_min_val;
                    $return_arr[$count]['d_range_max_val'] = $KPI_plan->d_range_max_val;

                    $s_sub_qry= sprintf("SELECT `d_monthly_plan_mark`  FROM %s
                                         WHERE
                                             `i_kpi_id`=%d AND %s ",
                                         $this->details_tbl, $KPI_plan->i_id, $s_sub_where);
                    $sub_ret_ = DB::select(DB::raw($s_sub_qry));

                    if( !empty($sub_ret_) )
                        $return_arr[$count]['kpi_plan_val'] = $sub_ret_[0]->d_monthly_plan_mark;
                    else
                        $return_arr[$count]['kpi_plan_val'] = '';


                    $count++;
                }

                unset($s_qry,$rs,$s_where,$s_sub_where, $i_start,$i_limit);

                # dd($return_arr);
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of details-record(s)...
        public function getKPIDetailTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->details_tbl, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================

        // function to calculate KPI value(s) from "_kpi-details" table...
        public function getKPIPlanData($kpi_id, $store_id, $dt_time_arr) {

            try
            {
                $month = $dt_time_arr['month'];
                $year  = $dt_time_arr['year'];

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                        $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                        $sql = sprintf("SELECT
                                            IFNULL(AVG(`d_monthly_plan_mark`), 0) `planned_KPI_val`
                                        FROM %s
                                        WHERE
                                           `i_month`=%d AND `i_year`=%d AND
                                           `i_kpi_id`=%d AND
                                           `i_store_id` IN (%s) ",
                                        $this->details_tbl, $month, $year, $kpi_id, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching planned KPI val of selected store...
                    $sql = sprintf("SELECT
                                        IFNULL(`d_monthly_plan_mark`, 0) AS `planned_KPI_val`
                                    FROM %s
                                    WHERE
                                       `i_month`=%d AND `i_year`=%d AND
                                       `i_kpi_id`=%d AND
                                       `i_store_id`=%d ",
                                    $this->details_tbl, $month, $year, $kpi_id, $store_id);
                }

                # echo $sql;
                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->planned_KPI_val, 2, '.', '');

                unset($sql, $ret_);
                # dd($ret_);
                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // for last 12 month(s) data...
        public function getLast12MonthsKPIPlanData($kpi_id, $store_id, $selected_dt=null) {

            try
            {
                $DT_SELECTED = ( !empty($selected_dt) )
                               ? $selected_dt
                               : date('Y-m-d', mktime(0, 0, 0, date('m')-1, date('d'), date('Y')));

                $DT_BETWEEN_CLAUSE = " BETWEEN DATE('{$DT_SELECTED}') - INTERVAL 12 MONTH AND DATE('{$DT_SELECTED}') ";

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                    /*$sql = sprintf("SELECT
                                        AVG(`d_monthly_plan_mark`) `kpi_val`,
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', `i_month`, '/', `i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) AS `rcvd_dt`
                                    FROM %s
                                    WHERE
                                        `i_kpi_id`=%d AND
                                        `i_store_id` IN (%s) AND
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', `i_month`, '/', `i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) %s
                                    GROUP BY `rcvd_dt` ",
                                    $this->details_tbl, $kpi_id, $stores, $DT_BETWEEN_CLAUSE);*/
                    $sql = sprintf("SELECT DATE_FORMAT(rcvd_dt,'%%Y-%%m') `rcvd_dt`, SUM(kpi_val) `kpi_val` FROM
                                        (SELECT
                                                STR_TO_DATE(
                                                        CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ),
                                                        '%%d/%%m/%%Y'
                                                ) AS `rcvd_dt`,
                                            A.`d_monthly_plan_mark` AS `kpi_val`
                                        FROM
                                            %2\$s A 
                                        WHERE
                                             A.`i_kpi_id`=%3\$d AND
                                             A.`i_store_id` IN (%4\$s) AND
                                             STR_TO_DATE(
                                                        CONCAT( DAY(DATE('%1\$s')), '/', A.i_month, '/', A.i_year ),
                                                        '%%d/%%m/%%Y'
                                             )  BETWEEN DATE('%1\$s') - INTERVAL 12 MONTH AND DATE('%s')
                                    UNION
                                    (SELECT DISTINCT DATE_FORMAT((SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY,'%%Y-%%m-01') erplytrans_date,0 val 
                                    FROM 
                                     (SELECT 0 a UNION SELECT 1 a UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 
                                      UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d, 
                                    (SELECT 0 b UNION SELECT 10 UNION SELECT 20 UNION SELECT 30 UNION SELECT 40 UNION SELECT 50 
                                         UNION SELECT 60 UNION SELECT 70 UNION SELECT 80 UNION SELECT 90) m,
                                    (SELECT 0 c UNION SELECT 100 UNION SELECT 200 UNION SELECT 300 UNION SELECT 400) y 
                                    WHERE (SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY < (select date('%1\$s')) 
                                    ORDER BY a + b +c)) T
                                    GROUP BY DATE_FORMAT(rcvd_dt,'%%Y-%%m') ",
                                    $DT_SELECTED, $this->details_tbl, $kpi_id, $stores);

                } else {    // i.e. for a particular-store

                    # IIA: preparing SQL...fetching planned KPI val of selected store...
                    /*$sql = sprintf("SELECT
                                        `d_monthly_plan_mark` AS `kpi_val`,
                                        STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', `i_month`, '/', `i_year` ),
                                            '%%d/%%m/%%Y'
                                        ) AS `rcvd_dt`
                                    FROM %s
                                    WHERE
                                       `i_kpi_id`=%d AND
                                       `i_store_id`=%d AND
                                       STR_TO_DATE(
                                            CONCAT( DAY(NOW()), '/', i_month, '/', i_year ),
                                            '%%d/%%m/%%Y'
                                       ) %s ",
                                    $this->details_tbl, $kpi_id, $store_id, $DT_BETWEEN_CLAUSE);*/
                    $sql = sprintf("SELECT DATE_FORMAT(rcvd_dt,'%%Y-%%m') `rcvd_dt`, SUM(kpi_val) `kpi_val` FROM
                                        (SELECT
                                                STR_TO_DATE(
                                                        CONCAT( DAY(DATE('%1\$s')), '/', A.`i_month`, '/', A.`i_year` ),
                                                        '%%d/%%m/%%Y'
                                                ) AS `rcvd_dt`,
                                            A.`d_monthly_plan_mark` AS `kpi_val`
                                        FROM
                                            %2\$s A 
                                        WHERE
                                             A.`i_kpi_id`=%3\$d AND
                                             A.`i_store_id`=%4\$d AND
                                             STR_TO_DATE(
                                                        CONCAT( DAY(DATE('%1\$s')), '/', A.i_month, '/', A.i_year ),
                                                        '%%d/%%m/%%Y'
                                             )  BETWEEN DATE('%1\$s') - INTERVAL 12 MONTH AND DATE('%s')
                                    UNION
                                    (SELECT DISTINCT DATE_FORMAT((SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY,'%%Y-%%m-01') erplytrans_date,0 val 
                                    FROM 
                                     (SELECT 0 a UNION SELECT 1 a UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 
                                      UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) d, 
                                    (SELECT 0 b UNION SELECT 10 UNION SELECT 20 UNION SELECT 30 UNION SELECT 40 UNION SELECT 50 
                                         UNION SELECT 60 UNION SELECT 70 UNION SELECT 80 UNION SELECT 90) m,
                                    (SELECT 0 c UNION SELECT 100 UNION SELECT 200 UNION SELECT 300 UNION SELECT 400) y 
                                    WHERE (SELECT Date('%1\$s' - INTERVAL 365 DAY)) + INTERVAL a + b + c DAY < (select date('%1\$s')) 
                                    ORDER BY a + b +c)) T
                                    GROUP BY DATE_FORMAT(rcvd_dt,'%%Y-%%m') ",
                                    $DT_SELECTED, $this->details_tbl, $kpi_id, $store_id);
                }

                # echo $sql;
                $ret_ = DB::select(DB::raw($sql));

                $return_val = 0;
                if( !empty($ret_) ) {
                    $start_index = ( count($ret_)>12 )? (count($ret_)-12): 0;
                    $ret_ = array_slice($ret_, $start_index);
                    
                    # utils::dump($ret_);
                    $return_val = $ret_;
                }

                unset($sql, $ret_);

                return $return_val;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}