<?php

namespace App\models;

use App\Helpers\Utility;
use Illuminate\Database\Eloquent\Model;

use DB;

class ConfigModel extends Model
{
    // overriding default setting(s)...
    protected $table, $master_variable_tbl, $master_weighted_tbl, $config_details_tbl, $config_category_details_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->table = getenv('DB_PREFIX') .'category_master';
        $this->master_variable_tbl = getenv('DB_PREFIX') .'config_variable_master';
        $this->master_weighted_tbl = getenv('DB_PREFIX') .'config_weighted_master';
        $this->config_details_tbl = getenv('DB_PREFIX') .'config_details';
        $this->config_category_details_tbl = getenv('DB_PREFIX') .'config_category_details';
        
        $this->franchisor_category_map_tbl = getenv('DB_PREFIX') .'franchisor_categogy_map';
    }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        //// From Master-Table
        // function to fetch master-record(s) based on limit, offset...
        public function fetchVariableRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry = "SELECT * FROM ". $this->master_variable_tbl;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        
        public function fetchWeightedRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry = "SELECT * FROM ". $this->master_weighted_tbl;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of master-record(s)...
        public function getVariableTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->master_variable_tbl, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

         // function to fetch total number of master-record(s)...
        public function getCategoryTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s A %s ", $this->table, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        //// From Child-Details Table
        // function to fetch details-record(s) based on limit, offset...
        public function fetchConfigDetailRecords($s_where=null, $s_sub_where=null, $s_order_by=null) {

            try
            {
                $s_qry= sprintf("SELECT * FROM %s ", $this->master_variable_tbl);
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                $ret_ = DB::select(DB::raw($s_qry));

                $return_arr = array();
                $count = 0;

                # II: fetching associated franchisee(s)...
                foreach($ret_ as $KPI_plan) {
                    $return_arr[$count]['i_id'] = $KPI_plan->i_id;
                    $return_arr[$count]['s_name'] = $KPI_plan->s_name;

                    $s_sub_qry= sprintf("SELECT `d_mark` FROM %s
                                         WHERE `i_cv_id`=%d AND %s ",
                                         $this->config_details_tbl, $KPI_plan->i_id, $s_sub_where);
                    $sub_ret_ = DB::select(DB::raw($s_sub_qry));

                    if( !empty($sub_ret_) )
                        $return_arr[$count]['cv_val'] = $sub_ret_[0]->d_mark;
                    else
                        $return_arr[$count]['cv_val'] = '';


                    $count++;
                }

                unset($s_qry,$rs,$s_where,$s_sub_where, $i_start,$i_limit);

                //echo '<pre>';print_r($return_arr); echo '</pre>';
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        public function fetchConfigWeightedDetailRecords($s_where=null, $s_sub_where=null, $s_order_by=null) {

            try
            {
                $s_qry= sprintf("SELECT * FROM %s ", $this->master_weighted_tbl);
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                $ret_ = DB::select(DB::raw($s_qry));

                $return_arr = array();
                $count = 0;

                # II: fetching associated franchisee(s)...
                foreach($ret_ as $KPI_plan) {
                    $return_arr[$count]['i_id'] = $KPI_plan->i_id;
                    $return_arr[$count]['s_name'] = $KPI_plan->s_name;

                    $s_sub_qry= sprintf("SELECT `d_mark` FROM %s
                                         WHERE `i_cw_id`=%d AND %s ",
                                         $this->config_details_tbl, $KPI_plan->i_id, $s_sub_where);
                    $sub_ret_ = DB::select(DB::raw($s_sub_qry));

                    if( !empty($sub_ret_) )
                        $return_arr[$count]['cw_val'] = $sub_ret_[0]->d_mark;
                    else
                        $return_arr[$count]['cw_val'] = '';


                    $count++;
                }

                unset($s_qry,$rs,$s_where,$s_sub_where, $i_start,$i_limit);

                # dd($return_arr);
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        
        public function fetchConfigCategoryDetailRecords($s_where=null, $s_sub_where=null, $s_order_by=null) {

            try
            {
                
                /*$SQL1 = sprintf("SELECT
                                     `i_id`, `s_category_name`, `d_weightage`
                                 FROM %s
                                 WHERE `i_parent_id`=0 ", $this->table);
                $ROW1 = DB::select(DB::raw($SQL1));
                
                $loop_index = 0;
                $sub_loop_index = 0;
                $count = 0;
                foreach($ROW1 as $parent_rows) {
                    $return_arr[$loop_index]['id'] = $parent_rows->i_id;
                    $return_arr[$loop_index]['name'] = $parent_rows->s_category_name;
                    $return_arr[$loop_index]['weight'] = $parent_rows->d_weightage;

                    # III: sub-categories (if any)...
                    $SQL2 = "SELECT t1.`i_id`, t1.`s_category_name`, t1.`d_weightage` , t2.d_mark
                                     FROM ".$this->table." t1 
                                     LEFT JOIN ".$this->config_category_details_tbl." t2 ON t1.i_id = t2.i_category_id
                                     WHERE t1.`i_parent_id`=".$parent_rows->i_id."  AND ".$s_sub_where;
                    $ROW2 = DB::select(DB::raw($SQL2));                    

                    if( !empty($ROW2) ){
                        $return_arr[$loop_index]['sub_categories'] = $ROW2;
                    }
                    else{
                            $SQL2 = "SELECT t1.`i_id`, t1.`s_category_name`, t1.`d_weightage` , '' as d_mark
                            FROM ".$this->table." t1 
                            WHERE t1.`i_parent_id`=".$parent_rows->i_id ;
                            $ROW2 = DB::select(DB::raw($SQL2));                    
                            if( !empty($ROW2) ){
                            $return_arr[$loop_index]['sub_categories'] = $ROW2;
                            }
                    }    

                    $loop_index++;
                   
                } --@22.01.16*/
                
                $SQL = sprintf("SELECT A.`i_id`, A.`s_product_group`, A.`s_product_sub_group`,  
                                      (SELECT `d_mark` FROM %s 
                                       WHERE %s) As val
                                FROM
                                    %s A 
                                WHERE
                                    %s
                                ORDER BY
                                    %s ",
                                $this->config_category_details_tbl, $s_sub_where,
                                $this->franchisor_category_map_tbl, $s_where, $s_order_by);
                $ROW = DB::select(DB::raw($SQL));
                
                $loop_index = 0;
                foreach($ROW as $rows) {
                    $return_arr[$loop_index]['i_id'] = $rows->i_id;
                    $return_arr[$loop_index]['s_product_group'] = $rows->s_product_group;
                    $return_arr[$loop_index]['s_product_sub_group'] = $rows->s_product_sub_group;
                    $return_arr[$loop_index]['val'] = $rows->val;
                    
                    $loop_index++;
                }
                
                unset($SQL,$s_where,$s_sub_where,$s_sub_qry,$loop_index);
                

                #unset($SQL1,$SQL2,$s_where,$s_sub_where,$s_sub_qry,$loop_index);

                
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // function to fetch total number of details-record(s)...
        public function getConfigDetailTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->details_tbl, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
