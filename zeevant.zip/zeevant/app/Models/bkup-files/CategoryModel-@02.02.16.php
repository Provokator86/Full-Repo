<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class CategoryModel extends Model
{
    // overriding default setting(s)...
    protected $table;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->table = getenv('DB_PREFIX') .'franchisor_categogy_map';
    }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // function to fetch categories based on limit, offset...
        public function fetchRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry="SELECT * FROM ". $this->table;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $START_INDEX = ( is_numeric($i_start) )
                               ? ($i_start*$i_limit): 0;

                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($START_INDEX) && is_numeric($i_limit)?" LIMIT ".intval($START_INDEX).",".intval($i_limit):"");
                # Pagination [End]
                
                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of categories...
        public function getTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->table, $s_where);
                $rs = DB::select(DB::raw($s_qry));
                $i_cnt = 0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch category-subcategory hierarchy...
        public function fetchCategoryHierarchy($franchisor_id) {

            try
            {
                $return_arr = array();

                # I: fetching only parent-categories...
                
                $SQL1 = sprintf("SELECT
                                     i_id ,s_product_group,s_product_sub_group
                                 FROM %s
                                where i_franchisor_id = ".$franchisor_id." GROUP BY s_product_group,s_product_sub_group
                                ORDER BY s_product_group,s_product_sub_group", $this->table);
                $ROW1 = DB::select(DB::raw($SQL1));
                
                
                
                # II: looping through parent categories...
                $loop_index = 0;
                foreach($ROW1 as $parent_rows) {
                    $return_arr[$loop_index]['i_id'] = $parent_rows->i_id;
                    $return_arr[$loop_index]['product_group'] = $parent_rows->s_product_group;
                    $return_arr[$loop_index]['product_sub_group'] = $parent_rows->s_product_sub_group;
                    $loop_index++;
                }

                unset($SQL1,$ROW1);

                #dd($return_arr);
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        
        // function to fetch category-subcategory hierarchy...
        public function fetchParentCategory() {

            try
            {
                $return_arr = array();

                # I: fetching only parent-categories...
                $SQL1 = sprintf("SELECT
                                     `i_id`, `s_category_name`, `d_weightage`
                                 FROM %s
                                 WHERE `i_parent_id`=0 ", $this->table);
                $ROW1 = DB::select(DB::raw($SQL1));


                # II: looping through parent categories...
                 $loop_index = 0;
                foreach($ROW1 as $parent_rows) {
                    $return_arr[$loop_index]['id'] = $parent_rows->i_id;
                    $return_arr[$loop_index]['name'] = $parent_rows->s_category_name;
                    $return_arr[$loop_index]['weight'] = $parent_rows->d_weightage;
                    $loop_index++;
                }

                unset($SQL1,$ROW1);

                #dd($return_arr);
                return $return_arr;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
