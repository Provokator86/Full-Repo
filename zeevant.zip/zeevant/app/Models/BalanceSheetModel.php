<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class BalanceSheetModel extends Model
{
    // overriding default setting(s)...
    protected $category_tbl, $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->category_tbl = getenv('DB_PREFIX') .'balance_sheet_categories';
        $this->master_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
        $this->inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
    }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        //// ************ BALANCE-SHEET-CATEGORIES...
            //// From Category-Table
            // function to fetch categories(s) based on hierarchy...
            public function fetchCategoryRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

                try
                {
                    $s_qry = "SELECT * FROM ". $this->category_tbl;
                    $s_qry .= ( !empty($s_where) )? $s_where: '';

                    # Pagination [Begin]
                    $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                    $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                    # Pagination [End]

                    $ret_ = DB::select(DB::raw($s_qry));
                    unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                    #dd($ret_);
                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }


            // function to fetch total number of master-record(s)...
            public function getTotalCategoryInfo($s_where=null)
            {
                try
                {
                    $ret_=0;

                    $s_qry = sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->master_tbl, $s_where);
                    $rs = DB::select(DB::raw($s_qry));
                    $i_cnt = 0;
                    if( is_array($rs) )
                    {
                        foreach($rs as $row)
                        {
                            $ret_=intval($row->i_total);
                        }
                    }
                    DB::commit();
                    unset($s_qry,$rs,$row,$i_cnt,$s_where);

                    return $ret_;
                }
                catch(Exception $err_obj)
                {
                    show_error($err_obj->getMessage());
                }

            }


            # function to get Balance-Sheet category & sub-categories in a hierarchical manner...
            public function fetchAllCategories($parent_id=0, $level=1) {

                try {
                    $sql = sprintf("SELECT * FROM %s
                                    WHERE
                                      `i_parent_id`=%d ", $this->category_tbl, $parent_id);
                    $ret_ = DB::select(DB::raw($sql));

                    $in=0;
                    $category=array();
                    $return=array();
                    if($ret_!=NULL)
                    {
                        foreach($ret_ as $row)
                        {
                            $category['id'] = $row->i_id;
                            $category['account_id'] = $row->i_account_id;
                            $category['name'] = $row->s_name;
                            $category['parent_id'] = $row->i_parent_id;
                            $category['level'] = $level++;
                            $category['subCategories'] = $this->fetchAllCategories($row->i_id, $level);

                            $level--;

                            $return[] = $category;
                        }
                        return $return;
                    }

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }

            }


            # function to fetch Balance-Sheet info...
            public function fetchBalanceSheetInfo($s_where=null)
            {

                try {
                    $ret_ = null;
                    $sql = sprintf("SELECT
                                        A.`i_id` `i_master_id`, A.`i_user_id`, A.`i_locked`,
                                        A.`i_month`, A.`i_year`,
                                        IFNULL(A.`dt_updated`, A.`dt_added`) `dt_last_modified`,
                                        B.`i_id` `i_details_id`, B.*,
                                        CONCAT_WS(' ', C.`s_first_name`, C.`s_last_name`) `s_last_modified_by`
                                    FROM
                                        %s A LEFT JOIN %s B
                                          ON A.`i_id`=B.`i_balance_sheet_id`
                                        LEFT JOIN %s C
                                          ON A.`i_user_id`=C.`i_id`
                                    WHERE %s ",
                                    $this->master_tbl, $this->inputs_tbl, $this->users_tbl, $s_where);
                    $ret_ = DB::select(DB::raw($sql));

                    return $ret_;

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }


            }





    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
