<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class DailyDiscountModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'erply_daysales';        
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
        $this->franchisee_tbl  = getenv('DB_PREFIX') .'franchisee_master';
        $this->kpi_tbl  = getenv('DB_PREFIX') .'kpi_details';
        $this->config_tbl  = getenv('DB_PREFIX') .'config_details';
    }

    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================

        
        
        // chart 1
        public function getDiscountMarchingProgressData($store_id, $dt_time_arr) {

            try
            {
               
               
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                $sql_marching =" CALL zev_ds_discount('".$stores."','".$req_date."')"; 
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                $sql_marching =" CALL zev_ds_discount('".$store_id."','".$req_date."')";    
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_marching));  
               
                unset($sql_marching);                   
                # dd($ret_);
                //print_r($ret_);exit;
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        // chart 2
         public function getDiscountDeviationData($store_id, $dt_time_arr) {

            try
            {
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                
                                $sql_deviation =" CALL zev_ds_discount('".$stores."','".$req_date."')"; 
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                               $sql_deviation =" CALL zev_ds_discount('".$store_id."','".$req_date."')";
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 3
        
        public function getDiscountSnapshotData($all_store_id,$store_id, $dt_time_arr) {

            try
            {
               
               
                
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
               
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);
                    
                                $sql_snapshot =" CALL zev_ds_discount_snapshot('".$stores."','".$req_date."')"; 
                               
                               
                                                             

                } else {    // i.e. for a particular-store
                                
                                $sql_snapshot =" CALL zev_ds_discount_snapshot('".$store_id."','".$req_date."')"; 
                                
                                
                }
                
                $ret_ = DB::select(DB::raw($sql_snapshot));                 

                unset($ret_snapshot);
               // print_r($ret_);exit;
                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // tabular data
        public function getDiscountTableData($store_id, $dt_time_arr) {

            try
            {
               
                
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
               
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                                # IA: preparing for MySQL IN clause...
                                $stores = implode(',', $store_id);                   
                                
                                $sql_target =" CALL zev_ds_discount_table('".$stores."','".$req_date."')";
                                //echo $sql_target;
                                
                               
                                                             

                } else {    // i.e. for a particular-store
                               
                               $sql_target =" CALL zev_ds_discount_table('".$store_id."','".$req_date."')";
                               //echo $sql_target;                                
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_target));  
              
               //print_r($ret_);exit;
               unset($sql_target);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}
