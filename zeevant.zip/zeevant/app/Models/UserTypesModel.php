<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class UserTypesModel extends Model
{
    // overriding default setting(s)...
    protected $table;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->table = getenv('DB_PREFIX') .'user_types';
    }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // function to fetch user-types based on limit, offset...
        public function fetchRecords($s_where=null, $i_start=null, $i_limit=null, $s_order_by=null) {

            try
            {
                $s_qry="SELECT * FROM ". $this->table;
                $s_qry .= ( !empty($s_where) )? $s_where: '';

                # Pagination [Begin]
                $s_qry= $s_qry.(trim($s_order_by)!=""? " ORDER BY ".$s_order_by."": " ORDER BY `i_id` ASC");
                $s_qry= $s_qry.(is_numeric($i_start) && is_numeric($i_limit)?" LIMIT ".intval($i_start).",".intval($i_limit):"");
                # Pagination [End]

                $ret_ = DB::select(DB::raw($s_qry));
                unset($s_qry,$rs,$s_where,$i_start,$i_limit);

                #dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


        // function to fetch total number of record(s)...
        public function getTotalInfo($s_where=null)
        {
            try
            {
                $ret_=0;

                $s_qry= sprintf("SELECT COUNT(*) AS i_total FROM %s %s ", $this->table, $s_where);
                $rs=DB::select(DB::raw($s_qry));
                $i_cnt=0;
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                    {
                        $ret_=intval($row->i_total);
                    }
                }
                DB::commit();
                unset($s_qry,$rs,$row,$i_cnt,$s_where);

                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           Custom Function(s) - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
