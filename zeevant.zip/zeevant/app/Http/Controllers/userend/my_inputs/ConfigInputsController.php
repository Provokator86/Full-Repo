<?php

namespace App\Http\Controllers\userend\my_inputs;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\CategoryModel as model_category;
use App\Models\ConfigModel as model_config;
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;


class ConfigInputsController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: My Inputs - Configuration Inputs ::';

        # for menu selection...
        $this->data['selected_menu'] = 'my-inputs';
        $this->data['selected_sub_menu'] = 'configuration-inputs';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;


        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #           Fetching Categories [Begin]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            # 1: getting concerned Franchisor-Admin ID...
                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                       ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                       : $LOGGED_USR_ID;
        
            $order_by = ' `i_id` DESC ';
            $categoryModel = new model_category();
            $records = $categoryModel->fetchCategoryHierarchy($FRANCHISOR_ADMIN_ID);

            $data['categories_arr'] = $records;
            # dump( $records );

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #           Fetching Categories [End]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
        
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #           Fetching Config [Begin]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            //Config Variables
            $where_cond = '';  // i.e. All Config Input(s)
            $configModel = new model_config();
            $order_by = ' i_id ASC ';
            $data['config_variable_arr'] = $configModel->fetchVariableRecords($where_cond);
            
            # dump( $records );
            //Config Masters
            $where_cond = '';  // i.e. All Config Input(s)
            $ConfigModel = new model_config();
            $order_by = ' i_id ASC ';
            $data['config_weighted_arr'] = $ConfigModel->fetchWeightedRecords($where_cond);

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #           Fetching Config [End]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        # show view part...
        return view('userend.my-inputs.configuration-inputs', $data);
    }
    
    
    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_config_plan_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            #$arr_err_index = $arr_success_index = $arr_msg = array();
            $arr_err_CVM_index = $arr_success_CVM_index = $arr_CVM_msg = array();
            $arr_err_CWM_index = $arr_success_CWM_index = $arr_CWM_msg = array();
            $arr_err_SSM_index = $arr_success_SSM_index = $arr_SSM_msg = array();
            
            $reqd_fld_msg = '* required field';

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # Franchisee/Store - Required Field
            $err_franchisee = false;
            if( trim($_POST['i_store'])=='' ) {
                $err_franchisee = true;
            }


            # for KPI Field(s)...
            $config_va_flds = $_POST['config_variable_marks'];
            foreach($config_va_flds as $key=>$val) {

                if( trim($val)=='' ) {
                    #$arr_err_index[] = $key;
                    $arr_err_CVM_index[] = $key;

                    #$arr_msg[] = $reqd_fld_msg;
                    $arr_CVM_msg[] = $reqd_fld_msg;
                } else {
                    #$arr_success_index[] = $key;
                    $arr_success_CVM_index[] = $key;
                }

            }
            
            $config_wt_flds = $_POST['config_weighted_marks'];
            foreach($config_wt_flds as $key=>$val) {

                if( trim($val)=='' ) {
                    #$arr_err_index[] = $key;
                    $arr_err_CWM_index[] = $key;
                    #$arr_msg[] = $reqd_fld_msg;
                    $arr_CWM_msg[] = $reqd_fld_msg;
                } else {
                    #$arr_success_index[] = $key;
                    $arr_success_CWM_index[] = $key;
                }

            }
            
            /*$config_wt0_flds = $_POST['wt_0'];
            foreach($config_wt0_flds as $key=>$val) {

                if( trim($val)=='' ) {
                    #$arr_err_index[] = $key;
                    $arr_err_SSM_index[] = $key;
                    #$arr_msg[] = $reqd_fld_msg;
                    $arr_SSM_msg[] = $reqd_fld_msg;
                } else {
                    #$arr_success_index[] = $key;
                    $arr_success_SSM_index[] = $key;
                }

            }*/
            
            
            /*
            $order_by = ' `i_id` DESC ';
            $categoryModel = new model_category();
            $records = $categoryModel->fetchCategoryHierarchy();            
            
             
            if(!empty($records))  { 
                
                foreach($records as $ind=>$value){  
               
                    if( !empty($value['sub_categories']) ){
                        foreach($value['sub_categories'] as $sub_category) {           
                        //$config_ss_flds[$value['id']] = $_POST['wt_'.$value['id']];
                        $post_val = 'wt_'.$ind.'_';
                        $config_ss_flds[$ind][$sub_category->i_id] = $_POST[$post_val][$sub_category->i_id];
                        }
                    }
                }
           
            
                foreach($config_ss_flds as $key1=>$val1) {

                        foreach($val1 as $key=>$val) {
                                if( trim($val)=='' ) {
                                #$arr_err_index[] = $key;
                                $arr_err_SSM_index[$key1][] = $key;
                                #$arr_msg[] = $reqd_fld_msg;
                                $arr_SSM_msg[$key1][] = $reqd_fld_msg;
                                } else {
                                #$arr_success_index[] = $key;
                                $arr_success_SSM_index[$key1][] = $key;
                                }
                        }

                }
            
            } */
            
            //echo '<pre>';print_r($config_ss_flds);echo '</pre>';
            
           /*dd(array('result' => 'error',
                                       'err_franchisee' => $err_franchisee,
                                       #'arr_err_indices'  => $arr_err_index,

                                       'arr_err_CVM_indices' => $arr_err_CVM_index,
                                       'arr_success_CVM_indices' => $arr_success_CVM_index,

                                       'arr_err_CWM_indices' => $arr_err_CWM_index,
                                       'arr_success_CWM_indices' => $arr_success_CWM_index,
                                       
                                       'arr_err_SSM_indices' => $arr_err_SSM_index,
                                       'arr_success_SSM_indices' => $arr_success_SSM_index,

                                       #'arr_success_indices'  => $arr_success_index,
                                       #'arr_msg' => $arr_msg,

                                       'arr_CVM_msg' => $arr_CVM_msg,
                                       'arr_CWM_msg' => $arr_CWM_msg,
                                       'arr_SSM_msg' => $arr_SSM_msg));*/
            # check if current-month...
            
            $mode = null;
            
            /*$arr_msg = array();
            echo count($arr_msg);
            echo $err_franchisee;*/

            # ADD NEW "KPI-Plan(s)" [if no errors]...
            #if( count($arr_msg)==0 && !$err_franchisee ) {
            
            
            
            
            if( count($arr_CVM_msg)==0 && count($arr_CWM_msg)==0 && count($arr_SSM_msg)==0 && !$err_franchisee ) {

                $this->add_config_plan_AJAX($request);
            }
            else   //// if error occurs...
            {
                echo json_encode(array('result' => 'error',
                                       'err_franchisee' => $err_franchisee,
                                       #'arr_err_indices'  => $arr_err_index,

                                       'arr_err_CVM_indices' => $arr_err_CVM_index,
                                       'arr_success_CVM_indices' => $arr_success_CVM_index,

                                       'arr_err_CWM_indices' => $arr_err_CWM_index,
                                       'arr_success_CWM_indices' => $arr_success_CWM_index,
                                       
                                       'arr_err_SSM_indices' => $arr_err_SSM_index,
                                       'arr_success_SSM_indices' => $arr_success_SSM_index,

                                       #'arr_success_indices'  => $arr_success_index,
                                       #'arr_msg' => $arr_msg,

                                       'arr_CVM_msg' => $arr_CVM_msg,
                                       'arr_CWM_msg' => $arr_CWM_msg,
                                       'arr_SSM_msg' => $arr_SSM_msg));
                exit;
            } 
        }


        # function to Add/Update KPI-Plan [AJAX CALL]...
        public function add_config_plan_AJAX(Request $request) {

           
            //// Now, retrieving submitted/posted values [BEGIN]...
            $config_variable_flds = $_POST['config_variable_marks'];
            $config_weighted_flds = $_POST['config_weighted_marks'];
            //$wt_flds = $_POST['wt_1'];
            

            $config_details_DB = new model_config();
   
            # I: config Details...
            $config_arr = array();
            $config_arr['i_store_id'] = $config_category_arr['i_store_id'] = trim( $request->input('i_store', true) );
            $config_arr['i_usr_id'] = $config_category_arr['i_usr_id']  = \Session::get('user_id');
            $config_arr['dt_added'] = $config_category_arr['dt_added']  = utils::get_db_datetime();
            //// retrieving submitted/posted values [END]...

            //// adding new data to KPI-details table...
            # check if data already exist(s) OR not...
            # if exist(s) then Update otherwise Insert...
            $config_details_tbl = getenv('DB_PREFIX') .'config_details';
            $config_category_details_tbl = getenv('DB_PREFIX') .'config_category_details';
            if( $this->checkExistingData($request) && $this->checkExistingCategoryData($request) ) {  // update accordingly

                // delete data from table 1st...
                \DB::table($config_details_tbl)
                    ->where('i_store_id', $config_arr['i_store_id'])
                    ->where('i_usr_id', $config_arr['i_usr_id'])                    
                    ->delete();
                    
                \DB::table($config_category_details_tbl)
                    ->where('i_store_id', $config_arr['i_store_id'])
                    ->where('i_usr_id', $config_arr['i_usr_id'])                    
                    ->delete();
                    
                $msg_status = "updated";
            } else {    // i.e. Insert New
                $msg_status = "added";
            }

            # inserting into "_kpi_details" table...
            
            
            
            foreach($config_variable_flds as $key=>$plan_val) {
                $i_config_id = $key + 1;
                $config_arr['i_cw_id'] = 0;
                $config_arr['i_cv_id'] = $i_config_id;
                $config_arr['d_mark'] = $plan_val;

                \DB::table($config_details_tbl)
                    ->insert($config_arr);
            }
            
           foreach($config_weighted_flds as $key=>$plan_val) {
                $i_config_id = $key + 1;
                $config_arr['i_cv_id'] = 0;
                $config_arr['i_cw_id'] = $i_config_id;
                $config_arr['d_mark'] = $plan_val;

                \DB::table($config_details_tbl)
                    ->insert($config_arr);
            }
            
            
            
            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            # 1: getting concerned Franchisor-Admin ID...
                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                       ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                       : $LOGGED_USR_ID;
            
            
            $order_by = ' `i_id` DESC ';
            $categoryModel = new model_category();
            //$records = $categoryModel->fetchParentCategory();
            $records = $categoryModel->fetchCategoryHierarchy($FRANCHISOR_ADMIN_ID);            
            
            #print_r($records); exit;
            if(!empty($records))  { 
                
                foreach($records as $ind=>$value){  
               
                        if ($value['product_sub_group']!='')
                        {
                            $val = $value['i_id'];
                            $post_val = 'wt_'.$val;
                            $config_ss_flds[$val] = $_POST[$post_val];
                        }
                        
                }
               #echo '<pre>'; print_r($config_ss_flds); echo '</pre>'; exit;
                
                foreach($config_ss_flds as $key1=>$val1) {
                    
                            
                            $config_category_arr['i_category_id'] = $key1;                                
                            $config_category_arr['d_area_mark'] = $val1;
                             $config_category_arr['d_area_mark'] = $val1;

                            \DB::table($config_category_details_tbl)
                            ->insert($config_category_arr);
                            
                }
                
            }            

            //// redirection URL...
            $redirect = url() ."/my-inputs/configuration-inputs";

            # success message...
            $success_msg = "Configuration Inputs {$msg_status} successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$redirect,
                                   'msg'=>$success_msg));
            exit;

        }
        // end of AJAX Add/Update KPI-Plan function...

            # function to check for already existing data...
            public function checkExistingData(Request $request) {

                $master_tbl = getenv('DB_PREFIX') .'config_variable_master';
                $details_tbl = getenv('DB_PREFIX') .'config_details';

                $STORE_ID = $request->input('i_store', true);                
                $USR_ID   = \Session::get('user_id');

                $SQL = sprintf("SELECT COUNT(*) AS `i_total`
                                FROM %s
                                WHERE
                                    `i_store_id`=%d AND
                                    `i_usr_id`=%d  ",
                                $details_tbl, $STORE_ID, $USR_ID);

                $rs = \DB::select(\DB::raw($SQL));
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                        $ret_=intval($row->i_total);
                }

                if( $ret_ )  // i.e. data exist(s) already...
                    return true;
                else
                    return false;
            }
            
             public function checkExistingCategoryData(Request $request) {

                
                $details_tbl = getenv('DB_PREFIX') .'config_category_details';

                $STORE_ID = $request->input('i_store', true);                
                $USR_ID   = \Session::get('user_id');

                $SQL = sprintf("SELECT COUNT(*) AS `i_total`
                                FROM %s
                                WHERE
                                    `i_store_id`=%d AND
                                    `i_usr_id`=%d  ",
                                $details_tbl, $STORE_ID, $USR_ID);

                $rs = \DB::select(\DB::raw($SQL));
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                        $ret_=intval($row->i_total);
                }

                if( $ret_ )  // i.e. data exist(s) already...
                    return true;
                else
                    return false;
            }

        //// ~~~~~~~~~~~~~~ FEW VALIDATION FUNCTION(S) [BEGIN] ~~~~~~~~~~~~~~      

            # function to load KPI-Plan(s) data (if any)...
            public function load_config_data_AJAX(Request $request) {

                $data = $this->data;
                $data['config_variable_arr'] = array();
                $data['config_weighted_arr'] = array();
                $data['categories_arr'] = array();
                $html = '';
                

                $store_id = $request->input('store_id', true);                
                $usr_id   = \Session::get('user_id');
                
                
                $config_model = new model_config();
                $category_model = new model_category();

                $where_cond = '';
                $sub_where_cond = "`i_store_id`={$store_id} AND
                                   `i_usr_id`={$usr_id}  AND
                                   `i_cv_id`!=''";               
               
                $order_by = ' `i_id` ASC ';
                
                if( $config_model->getVariableTotalInfo($where_cond) ) {
                    $data['config_variable_arr'] = $config_model->fetchConfigDetailRecords($where_cond, $sub_where_cond);
                } 
                $sub_where_cond = "`i_store_id`={$store_id} AND
                                   `i_usr_id`={$usr_id} AND
                                   `i_cw_id`!=''";
                if( $config_model->getVariableTotalInfo($where_cond) ) {
                    $data['config_weighted_arr'] = $config_model->fetchConfigWeightedDetailRecords($where_cond, $sub_where_cond);
                }
               
                
                /*$sub_where_cond = " WHERE `i_store_id`={$store_id} AND
                                   `i_usr_id`={$usr_id}";
                if( $config_model->getCategoryTotalInfo($sub_where_cond) ) {
                    
                } */
                
                
                /*$sub_where_cond_fetch = " `i_store_id`={$store_id} AND `i_usr_id`={$usr_id}";
                $data['categories_arr'] = $config_model->fetchConfigCategoryDetailRecords($sub_where_cond_fetch); */
                
                
                $logged_usr_type = \Session::get('user_type');
                $FRANCHISOR_ADMIN_ID = ( $logged_usr_type!=2 )
                                        ? usr_Helper::getParentFranchisorAdminID( $usr_id )
                                        : $usr_id;
                $MAIN_WHERE_COND = " A.`i_franchisor_id`={$FRANCHISOR_ADMIN_ID} ";
                $SUB_WHERE_COND = " `i_category_id` = A.i_id AND `i_store_id`={$store_id} ";
                $ORDER_BY = " A.`product_group_new`, A.`subgroup_new` ";
                
                $data['categories_arr'] = $config_model->fetchConfigCategoryDetailRecords($MAIN_WHERE_COND, $SUB_WHERE_COND, $ORDER_BY);
                
                
                
               
                /*if( $config_model->getWeightedTotalInfo($where_cond) ) {
                    $data['config_weighted_arr'] = $config_model->fetchWeightedRecords($where_cond, $sub_where_cond);
                }*/
                //die(print_r($data));
                $html = \View::make('userend.my-inputs.ajax-parts.load-config-data-AJAX', $data)->render();
                echo json_encode(array('result'        => 'success',
                                       'html_content'  => $html));
                exit;

            }



        //// ~~~~~~~~~~~~~~ FEW VALIDATION FUNCTION(S) [END] ~~~~~~~~~~~~~~


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================


}