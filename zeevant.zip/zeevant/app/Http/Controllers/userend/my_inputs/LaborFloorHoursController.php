<?php

namespace App\Http\Controllers\userend\my_inputs;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\BalanceSheetModel as model_balance_sheet;
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

class LaborFloorHoursController extends \App\Http\Controllers\userend\BaseController
{
	// constructor definition...
	public function __construct() {

		parent::__construct();

		$this->data['userend_site_title'] = ':: My Inputs - Labor Floor Hours ::';

		# for menu selection...
		$this->data['selected_menu'] = 'my-inputs';
		$this->data['selected_sub_menu'] = 'labor-floor-hours';
	}


	// index function definition...
	public function index() {

		# Page-Specific Settings...
		$data = $this->data;


		# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		#       Load Page-Specific Setting(s) [Begin]
		# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
			$data['logged_usr_type'] = \Session::get('user_type');
	
		# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		#       Load Page-Specific Setting(s) [End]
		# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


		# show view part...
		return view('userend.my-inputs.labor-floor-hours', $data);
	}




	//// ==================================================================================
	////            Section-I: LABOR-FLOOR-HOURS VALIDATION & ADD/UPDATE [BEGIN]
	//// ==================================================================================
	
		# 1: validate Labor-Floor-Hours form [AJAX Call]...
		public function validate_floor_hours_AJAX(Request $request) {
	
			// Error Messages for Required Fields...
			$err_flds = array();
			$REQD_FLD_MSG = ' required field';
			$required_fields = array('d_labor_hours');
	
			// adjusting err-messages part accordingly...
			$arr_messages = array();
	
			////////////// VALIDATION CHECKS - BEGIN //////////////
	
			# validation for singular fields (i.e. appearing once)...
			foreach($required_fields as $required_field) {
	
				if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {
	
					if( !in_array($required_field, $err_flds) )
						$err_flds[] = $required_field;
	
						$arr_messages[$required_field] = $REQD_FLD_MSG;
				}
	
			}
	
	
			//// Validation - "Store Selection" [Begin]
				$no_err = true;
				$err_msg = '';
				# check if no-store is selected...
				if( trim($_POST['i_store'])=='' ) {
					$no_err = false;
					$err_msg = "Please select concerned store";
				}
			//// Validation - "Store Selection" [End]
	
			# if validated "Balance-Sheet" Inputs [if no errors]...
			if( count($arr_messages)==0 && $no_err ) {
	
				$this->add_OR_update_floor_hours_AJAX($request);
			}
			else   //// if error occurs...
			{
				// for success field(s)...
				$success_flds = array_diff($required_fields, $err_flds);
				$success_flds = array_values($success_flds);
	
				echo json_encode(array('result'       => 'error',
									   'arr_messages' => $arr_messages,
									   'success_flds' => $success_flds,
									   'err_store'    => $no_err,
									   'err_store_msg'=> $err_msg
								));
				exit;
			}
	
		}
	
	
		# function to Add-New/Update Labor-Floor-Hours value [AJAX CALL]...
		public function add_OR_update_floor_hours_AJAX(Request $request) {
	
			//// Now, retrieving submitted/posted values [BEGIN]...
			$bSheetModel = new model_balance_sheet();
	
			# I: check record already exists OR not...
			$storeID = $request->input('i_store');
			$year = $request->input('i_year');
			$month = ($request->input('i_month')+1);
			$logged_usr = \Session::get('user_id');
			$WHERE_COND = " A.`i_store_id`={$storeID} AND
							A.`i_month`={$month} AND
							A.`i_year`={$year} ";
			$DATA_ARR = $this->loadBalanceSheetData($WHERE_COND);
	
			$LOGGED_USR_TYPE = \Session::get('user_type');
	

			$FLD_ARR = array('d_bs_11101', 'd_bs_11102', 'd_bs_11200',
							 'd_bs_11300', 'd_bs_11401', 'd_bs_11402',
							 'd_bs_12000', 'd_bs_13000', 'd_bs_21101',
							 'd_bs_21102', 'd_bs_21104', 'd_bs_22000',
							 'd_bs_30000', 'd_bs_11100', 'd_bs_11400',
							 'd_bs_11000', 'd_bs_10000', 'd_bs_21000',
							 'd_bs_20000');
				
			# II: Update OR Insert according to condition...
			if( !empty($DATA_ARR) ) {   // Update

				# II-A: update input(s)...
				$BSHEET_DETAILS_ID = $DATA_ARR[0]->i_details_id;
				$bsheet_arr = array();
				
				//// New Field(s)...
				$bsheet_arr['d_labor_hours'] = trim( $request->input('d_labor_hours', true) );

				$bsheet_arr['dt_updated']    = utils::get_db_datetime();


				$bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
				\DB::table($bsheet_inputs_tbl)
				->where('i_id', $BSHEET_DETAILS_ID)
				->update($bsheet_arr);

				$MSG_FLAG = "updated";

			} else {    // Add New

                # II-A: insert into master table 1st...
	                $master_data_arr = array();
	                $master_data_arr['i_user_id'] = $logged_usr;
	                $master_data_arr['i_store_id'] = $storeID;
	                $master_data_arr['i_month'] = $month;
	                $master_data_arr['i_year'] = $year;
	                $master_data_arr['dt_added'] = utils::get_db_datetime();
	                $master_bsheet_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
	                $BSHEET_ID = \DB::table($master_bsheet_tbl)
	                    			->insertGetId($master_data_arr);
                
                    
				# II-B: insert into balance-sheet input(s)...
					$bsheet_arr = array();
					$bsheet_arr['i_balance_sheet_id'] = $BSHEET_ID;
					foreach($FLD_ARR as $key=>$fld_name)
						$bsheet_arr[$fld_name] = 0;
					
					//// New Field(s)...
					$bsheet_arr['d_labor_hours'] = trim( $request->input('d_labor_hours', true) );
	
					$bsheet_arr['dt_added']      = utils::get_db_datetime();
	
					$bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
					\DB::table($bsheet_inputs_tbl)
						->insert($bsheet_arr);

				$MSG_FLAG = "added";
			}
			//// retrieving submitted/posted values [END]...

			//// redirection URL...
			$REDIRECT = url() ."/my-inputs/labor-floor-hours";

			# success message...
			$SUCCESS_MSG = "Labor floor hours {$MSG_FLAG} successfully";


			echo json_encode(array('result'=>'success',
								   'redirect'=>$REDIRECT,
								   'msg'=>$SUCCESS_MSG));
			exit;
	
		}
		// end of AJAX Add-New/Update Floor-Hours value(s) function...
	
		# load Labor-Floor-Hours data (if any)
		public function loadBalanceSheetData($where_cond=null) {
	
			$bSheetModel = new model_balance_sheet();
			$data_arr = $bSheetModel->fetchBalanceSheetInfo($where_cond);
	
			return $data_arr;
		}
	

	//// ==================================================================================
	////            Section-I: LABOR-FLOOR-HOURS VALIDATION & ADD/UPDATE [END]
	//// ==================================================================================






	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#           MISCELLANEOUS FUNCTION(S) - BEGIN
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	

		# NEW - Load Labor-Floor-Hours Data [AJAX CALL]...
		public function loadFloorHoursDataAJAX(Request $request) {
		
			$data = $this->data;
		
			# I: retrieving required param(s)/data...
			$year = $request->input('yr_val');
			$month = $request->input('month_val') + 1;
			$logged_usr = \Session::get('user_id');
			$storeID = $request->input('store_id');
		
			$WHERE_COND = " A.`i_store_id`={$storeID} AND
							A.`i_month`={$month} AND
							A.`i_year`={$year} ";
		
			# II: Balance-Sheet Variable(s)...
			$DATA_ARR = $this->loadBalanceSheetData($WHERE_COND);
			$data['bsheet_arr'] = ( !empty($DATA_ARR) )? $DATA_ARR[0]: $DATA_ARR;
			$data['bsheet_last_modified'] = $this->fetchLastModifiedByData($data['bsheet_arr']);
		
			# for "Floor Labor Hours"
			$labor_hours = ( !empty($data['bsheet_arr']) )
						   ? $data['bsheet_arr']->d_labor_hours: '';
		
		
			# IV: getting User-Type...
			$data['logged_usr_type'] = \Session::get('user_type');
					
			echo json_encode(array('result'        => 'success',
								   'labor_hrs'     => $labor_hours));
			exit;
		
		}
		
		
		# function to get "Last-Modified-By" info...
		public function fetchLastModifiedByData($data_arr=null) {
	
			$RETURN_STR = '';
			if( !empty($data_arr) ) {
				$RETURN_STR .= "Last modified by <span class='font-bold'>". $data_arr->s_last_modified_by;
				$RETURN_STR .= "</span> on ". date('j M, Y \a\t g:i A', strtotime($data_arr->dt_last_modified));
			}
	
			return $RETURN_STR;
		}
	
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	#           MISCELLANEOUS FUNCTION(S) - END
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}