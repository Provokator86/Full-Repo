<?php

namespace App\Http\Controllers\userend\my_inputs;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\BalanceSheetModel as model_balance_sheet;
use App\Models\IncomeStmtModel as model_income_stmt;
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

class MonthlyFinancialsController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: My Inputs - Monthly Financials ::';

        # for menu selection...
        $this->data['selected_menu'] = 'my-inputs';
        $this->data['selected_sub_menu'] = 'monthly-financials';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;


        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #       Load Page-Specific Setting(s) [Begin]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            $data['bsheet_arr'] = null;
            $data['bsheet_mode'] = $this->checkViewOREditMode(null, $data['bsheet_arr']);

            $data['istmt_arr'] = null;
            $data['istmt_mode'] = $this->checkViewOREditMode(null, $data['istmt_arr']);

            $data['logged_usr_type'] = \Session::get('user_type');

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #       Load Page-Specific Setting(s) [End]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        # show view part...
        return view('userend.my-inputs.monthly-financials', $data);
    }


    //// ==================================================================================
    ////            Section-II: INCOME-STATEMENT VALIDATION & ADD/UPDATE [BEGIN]
    //// ==================================================================================

        # 1: validate Income-Statement form [AJAX Call]...
        public function validate_income_statement_AJAX(Request $request) {

            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('d_is_40100', 'd_is_40200', 'd_is_40300',
                                     'd_is_50100', 'd_is_50200', 'd_is_50300',
                                     'd_is_50400', 'd_is_50500', 'd_is_50600',
                                     'd_is_60100', 'd_is_60200', 'd_is_60300',

                                     'd_is_60400', 'd_is_60500', 'd_is_60600',
                                     'd_is_60700', 'd_is_60800', 'd_is_60900',
                                     'd_is_61000', 'd_is_61100', 'd_is_61200',
                                     'd_is_61300', 'd_is_61400', 'd_is_61500',
                                     'd_is_61600', 'd_is_61700', 'd_is_61800',
                                     'd_is_61900', 'd_is_62000', 'd_is_62100',

                                     'd_is_62200', 'd_is_62300', 'd_is_62400',
                                     'd_is_62500', 'd_is_62600', 'd_is_62700',
                                     'd_is_80100', 'd_is_80200', 'd_is_80300');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

            }



            //// Validation - "I Agree..." [Begin]
                $i_istmt_agree = true;
                $err_istmt_msg = '';
                if( !isset($_POST['i_istmt_agree']) ) {
                    $i_istmt_agree = false;
                    $err_istmt_msg = "Please certify this \"Income-Statement\" data first";
                }
            //// Validation - "I Agree..." [End]

            //// Validation - "Store Selection" [Begin]
                $no_err = true;
                $err_msg = '';
                # check if no-store is selected...
                if( trim($_POST['i_store'])=='' ) {
                    $no_err = false;
                    $err_msg = "Please select concerned store";
                }
            //// Validation - "Store Selection" [End]


            # if validated "Income-Statement" Inputs [if no errors]...
            if( count($arr_messages)==0 && $no_err && $i_istmt_agree ) {

                $this->add_OR_update_income_stmt_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds' => $success_flds,
                                       'err_store'    => $no_err,
                                       'err_store_msg'=> $err_msg,
                                       'err_certify'  => $i_istmt_agree,
                                       'err_certify_msg'=> $err_istmt_msg
                                    ));
                exit;
            }

        }


        # function to Add-New/Update Income-Statement value(s) [AJAX CALL]...
        public function add_OR_update_income_stmt_AJAX(Request $request) {

            //// Now, retrieving submitted/posted values [BEGIN]...
            $iStmtModel = new model_income_stmt();

            # I: check record already exists OR not...
            $storeID = $request->input('i_store');
            $year = $request->input('i_year');
            $month = ($request->input('i_month')+1);
            $logged_usr = \Session::get('user_id');
            $WHERE_COND = " A.`i_store_id`={$storeID} AND
                            A.`i_month`={$month} AND
                            A.`i_year`={$year} ";
            $DATA_ARR = $this->loadIncomeStmtData($WHERE_COND);

            //// NEW - CHECK FOR "Lock It" [BEGIN]
            $LOGGED_USR_TYPE = \Session::get('user_type');
            $ISTMT_LOCKED = 0;
            if( isset($_POST['i_istmt_locked']) )
                $ISTMT_LOCKED = $_POST['i_istmt_locked'];
            //// NEW - CHECK FOR "Lock It" [END]


            //// NEW
            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
						           ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
						           : $LOGGED_USR_ID;
            $FRANCHISOR_ADMIN_ID = usr_Helper::getFranchisorID($FRANCHISOR_ADMIN_ID);

            # II: Update OR Insert according to condition...
            if( !empty($DATA_ARR) ) {   // Update

            	
                # II-A: update master table 1st...
                $master_data_arr = array();
                $master_data_arr['i_user_id'] = $FRANCHISOR_ADMIN_ID;
                $master_data_arr['dt_updated'] = utils::get_db_datetime();
                $ISTMT_ID = $DATA_ARR[0]->i_master_id;
                if( $LOGGED_USR_TYPE==2 ) // iff "Franchisor" only
                    $master_data_arr['i_locked'] = $ISTMT_LOCKED;

                $master_istmt_tbl = getenv('DB_PREFIX') .'income_stmt_master';
                \DB::table($master_istmt_tbl)
                    ->where('i_id', $ISTMT_ID)
                    ->update($master_data_arr);

                # II-B: update input(s)...
                $ISTMT_DETAILS_ID = $DATA_ARR[0]->i_details_id;
                $istmt_arr = array();

                $REVENUE_TOTAL = 0;
                $REVENUE_TOTAL += $istmt_arr['d_is_40100'] = trim( $request->input('d_is_40100', true) );
                $REVENUE_TOTAL += $istmt_arr['d_is_40200'] = trim( $request->input('d_is_40200', true) );
                $REVENUE_TOTAL += $istmt_arr['d_is_40300'] = trim( $request->input('d_is_40300', true) );

                $COGS_TOTAL = 0;
                $COGS_TOTAL += $istmt_arr['d_is_50100'] = trim( $request->input('d_is_50100', true) );
                $COGS_TOTAL += $istmt_arr['d_is_50200'] = trim( $request->input('d_is_50200', true) );
                $COGS_TOTAL += $istmt_arr['d_is_50300'] = trim( $request->input('d_is_50300', true) );
                $COGS_TOTAL += $istmt_arr['d_is_50400'] = trim( $request->input('d_is_50400', true) );
                $COGS_TOTAL += $istmt_arr['d_is_50500'] = trim( $request->input('d_is_50500', true) );
                $COGS_TOTAL += $istmt_arr['d_is_50600'] = trim( $request->input('d_is_50600', true) );


                $EXPENSES_TOTAL = 0;
                $EXPENSES_TOTAL += $istmt_arr['d_is_60100'] = trim( $request->input('d_is_60100', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60200'] = trim( $request->input('d_is_60200', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60300'] = trim( $request->input('d_is_60300', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60400'] = trim( $request->input('d_is_60400', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60500'] = trim( $request->input('d_is_60500', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60600'] = trim( $request->input('d_is_60600', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60700'] = trim( $request->input('d_is_60700', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60800'] = trim( $request->input('d_is_60800', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_60900'] = trim( $request->input('d_is_60900', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61000'] = trim( $request->input('d_is_61000', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61100'] = trim( $request->input('d_is_61100', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61200'] = trim( $request->input('d_is_61200', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61300'] = trim( $request->input('d_is_61300', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61400'] = trim( $request->input('d_is_61400', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61500'] = trim( $request->input('d_is_61500', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61600'] = trim( $request->input('d_is_61600', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61700'] = trim( $request->input('d_is_61700', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61800'] = trim( $request->input('d_is_61800', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_61900'] = trim( $request->input('d_is_61900', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62000'] = trim( $request->input('d_is_62000', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62100'] = trim( $request->input('d_is_62100', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62200'] = trim( $request->input('d_is_62200', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62300'] = trim( $request->input('d_is_62300', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62400'] = trim( $request->input('d_is_62400', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62500'] = trim( $request->input('d_is_62500', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62600'] = trim( $request->input('d_is_62600', true) );
                $EXPENSES_TOTAL += $istmt_arr['d_is_62700'] = trim( $request->input('d_is_62700', true) );

                $OTHER_INCOME_TOTAL = 0;
                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80100'] = trim( $request->input('d_is_80100', true) );
                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80200'] = trim( $request->input('d_is_80200', true) );
                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80300'] = trim( $request->input('d_is_80300', true) );

                # NEW FIELD - Net Income
                $NET_INCOME = ($REVENUE_TOTAL - $COGS_TOTAL - $EXPENSES_TOTAL + $OTHER_INCOME_TOTAL);
                
                
                //// Total Field(s)
                $istmt_arr['d_is_40000'] = $REVENUE_TOTAL;
                $istmt_arr['d_is_50000'] = $COGS_TOTAL;
                $istmt_arr['d_is_60000'] = $EXPENSES_TOTAL;
                $istmt_arr['d_is_80000'] = $OTHER_INCOME_TOTAL;
                $istmt_arr['d_net_income'] = $NET_INCOME;
                $istmt_arr['dt_updated'] = utils::get_db_datetime();

                $istmt_inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
                \DB::table($istmt_inputs_tbl)
                    ->where('i_id', $ISTMT_DETAILS_ID)
                    ->update($istmt_arr);

                $MSG_FLAG = "updated";

            } else {    // Add New

                # II-A: insert into master table 1st...
                    $master_data_arr = array();
                    $master_data_arr['i_user_id'] = $FRANCHISOR_ADMIN_ID;
                    $master_data_arr['i_store_id'] = $storeID;
                    $master_data_arr['i_month'] = $month;
                    $master_data_arr['i_year'] = $year;
                    $master_data_arr['dt_added'] = utils::get_db_datetime();
                    if( $LOGGED_USR_TYPE==2 ) // iff "Franchisor" only
                        $master_data_arr['i_locked'] = $ISTMT_LOCKED;
                    $master_istmt_tbl = getenv('DB_PREFIX') .'income_stmt_master';
                    $ISTMT_ID = \DB::table($master_istmt_tbl)
                                    ->insertGetId($master_data_arr);

                # II-B: insert into income-statement input(s)...
                    $istmt_arr = array();
                    $istmt_arr['i_income_stmt_id'] = $ISTMT_ID;

                    $REVENUE_TOTAL = 0;
                    $REVENUE_TOTAL += $istmt_arr['d_is_40100'] = trim( $request->input('d_is_40100', true) );
                    $REVENUE_TOTAL += $istmt_arr['d_is_40200'] = trim( $request->input('d_is_40200', true) );
                    $REVENUE_TOTAL += $istmt_arr['d_is_40300'] = trim( $request->input('d_is_40300', true) );

                    $COGS_TOTAL = 0;
                    $COGS_TOTAL += $istmt_arr['d_is_50100'] = trim( $request->input('d_is_50100', true) );
                    $COGS_TOTAL += $istmt_arr['d_is_50200'] = trim( $request->input('d_is_50200', true) );
                    $COGS_TOTAL += $istmt_arr['d_is_50300'] = trim( $request->input('d_is_50300', true) );
                    $COGS_TOTAL += $istmt_arr['d_is_50400'] = trim( $request->input('d_is_50400', true) );
                    $COGS_TOTAL += $istmt_arr['d_is_50500'] = trim( $request->input('d_is_50500', true) );
                    $COGS_TOTAL += $istmt_arr['d_is_50600'] = trim( $request->input('d_is_50600', true) );


                    $EXPENSES_TOTAL = 0;
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60100'] = trim( $request->input('d_is_60100', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60200'] = trim( $request->input('d_is_60200', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60300'] = trim( $request->input('d_is_60300', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60400'] = trim( $request->input('d_is_60400', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60500'] = trim( $request->input('d_is_60500', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60600'] = trim( $request->input('d_is_60600', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60700'] = trim( $request->input('d_is_60700', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60800'] = trim( $request->input('d_is_60800', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_60900'] = trim( $request->input('d_is_60900', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61000'] = trim( $request->input('d_is_61000', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61100'] = trim( $request->input('d_is_61100', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61200'] = trim( $request->input('d_is_61200', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61300'] = trim( $request->input('d_is_61300', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61400'] = trim( $request->input('d_is_61400', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61500'] = trim( $request->input('d_is_61500', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61600'] = trim( $request->input('d_is_61600', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61700'] = trim( $request->input('d_is_61700', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61800'] = trim( $request->input('d_is_61800', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_61900'] = trim( $request->input('d_is_61900', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62000'] = trim( $request->input('d_is_62000', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62100'] = trim( $request->input('d_is_62100', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62200'] = trim( $request->input('d_is_62200', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62300'] = trim( $request->input('d_is_62300', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62400'] = trim( $request->input('d_is_62400', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62500'] = trim( $request->input('d_is_62500', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62600'] = trim( $request->input('d_is_62600', true) );
                    $EXPENSES_TOTAL += $istmt_arr['d_is_62700'] = trim( $request->input('d_is_62700', true) );

                    $OTHER_INCOME_TOTAL = 0;
                    $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80100'] = trim( $request->input('d_is_80100', true) );
                    $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80200'] = trim( $request->input('d_is_80200', true) );
                    $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80300'] = trim( $request->input('d_is_80300', true) );

                    # NEW FIELD - Net Income
                    $NET_INCOME = ($REVENUE_TOTAL - $COGS_TOTAL - $EXPENSES_TOTAL + $OTHER_INCOME_TOTAL);
                    
                    //// Total Field(s)
                    $istmt_arr['d_is_40000'] = $REVENUE_TOTAL;
                    $istmt_arr['d_is_50000'] = $COGS_TOTAL;
                    $istmt_arr['d_is_60000'] = $EXPENSES_TOTAL;
                    $istmt_arr['d_is_80000'] = $OTHER_INCOME_TOTAL;
                    $istmt_arr['d_net_income'] = $NET_INCOME;
                    $istmt_arr['dt_added'] = utils::get_db_datetime();

                    $istmt_inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
                    \DB::table($istmt_inputs_tbl)
                        ->insert($istmt_arr);

                $MSG_FLAG = "added";
            }
            //// retrieving submitted/posted values [END]...

            //// redirection URL...
            $REDIRECT = url() ."/my-inputs/monthly-financials";

            # success message...
            $SUCCESS_MSG = "Income-Statement info {$MSG_FLAG} successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }
        // end of AJAX Add-New/Update Income-Statement value(s) function...

        # load Income-Statement data (if any)
        public function loadIncomeStmtData($where_cond=null) {

            $iStmtModel = new model_income_stmt();
            $data_arr = $iStmtModel->fetchIncomeStmtInfo($where_cond);

            return $data_arr;
        }


    //// ==================================================================================
    ////            Section-II: INCOME-STATEMENT VALIDATION & ADD/UPDATE [END]
    //// ==================================================================================




    //// ==================================================================================
    ////            Section-I: BALANCE-SHEET VALIDATION & ADD/UPDATE [BEGIN]
    //// ==================================================================================

        # 1: validate Balance-Sheet form [AJAX Call]...
        public function validate_balance_sheet_AJAX(Request $request) {

            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('d_bs_11101', 'd_bs_11102',
                                     'd_bs_11300', 'd_bs_11401', 'd_bs_11200',
                                     'd_bs_11402', 'd_bs_12000', 'd_bs_13000',
                                     'd_bs_21101', 'd_bs_21102', 'd_bs_21104',
                                     'd_bs_22000', 'd_bs_30000');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

            }



            //// Validation - "I Agree..." [Begin]
                $i_bsheet_agree = true;
                $err_bsheet_msg = '';
                if( !isset($_POST['i_bsheet_agree']) ) {
                    $i_bsheet_agree = false;
                    $err_bsheet_msg = "Please certify this \"Balance-Sheet\" data first";
                }
            //// Validation - "I Agree..." [End]

            //// Validation - "Store Selection" [Begin]
                $no_err = true;
                $err_msg = '';
                # check if no-store is selected...
                if( trim($_POST['i_store'])=='' ) {
                    $no_err = false;
                    $err_msg = "Please select concerned store";
                }
            //// Validation - "Store Selection" [End]

            # if validated "Balance-Sheet" Inputs [if no errors]...
            if( count($arr_messages)==0 && $no_err && $i_bsheet_agree ) {

                $this->add_OR_update_balance_sheet_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds' => $success_flds,
                                       'err_store'    => $no_err,
                                       'err_store_msg'=> $err_msg,
                                       'err_certify'  => $i_bsheet_agree,
                                       'err_certify_msg'=> $err_bsheet_msg
                                      ));
                exit;
            }

        }


        # function to Add-New/Update Balance-Sheet value(s) [AJAX CALL]...
        public function add_OR_update_balance_sheet_AJAX(Request $request) {

            //// Now, retrieving submitted/posted values [BEGIN]...
            $bSheetModel = new model_balance_sheet();

            # I: check record already exists OR not...
            $storeID = $request->input('i_store');
            $year = $request->input('i_year');
            $month = ($request->input('i_month')+1);
            $logged_usr = \Session::get('user_id');
            $WHERE_COND = " A.`i_store_id`={$storeID} AND
                            A.`i_month`={$month} AND
                            A.`i_year`={$year} ";
            $DATA_ARR = $this->loadBalanceSheetData($WHERE_COND);

            //// NEW - CHECK FOR "Lock It" [BEGIN]
                $LOGGED_USR_TYPE = \Session::get('user_type');
                $BSHEET_LOCKED = 0;
                if( isset($_POST['i_bsheet_locked']) )
                    $BSHEET_LOCKED = $_POST['i_bsheet_locked'];
            //// NEW - CHECK FOR "Lock It" [END]


            # II: Update OR Insert according to condition...
            if( !empty($DATA_ARR) ) {   // Update

                # II-A: update master table 1st...
                $master_data_arr = array();
                $master_data_arr['i_user_id'] = $logged_usr;
                $master_data_arr['dt_updated'] = utils::get_db_datetime();
                $BSHEET_ID = $DATA_ARR[0]->i_master_id;
                if( $LOGGED_USR_TYPE==2 ) // iff "Franchisor" only
                    $master_data_arr['i_locked'] = $BSHEET_LOCKED;

                $master_bsheet_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
                \DB::table($master_bsheet_tbl)
                    ->where('i_id', $BSHEET_ID)
                    ->update($master_data_arr);

                # II-B: update input(s)...
                $BSHEET_DETAILS_ID = $DATA_ARR[0]->i_details_id;
                $bsheet_arr = array();
                $bsheet_arr['d_bs_11101'] = trim( $request->input('d_bs_11101', true) );
                $bsheet_arr['d_bs_11102'] = trim( $request->input('d_bs_11102', true) );
                $bsheet_arr['d_bs_11200'] = trim( $request->input('d_bs_11200', true) );
                $bsheet_arr['d_bs_11300'] = trim( $request->input('d_bs_11300', true) );
                $bsheet_arr['d_bs_11401'] = trim( $request->input('d_bs_11401', true) );
                $bsheet_arr['d_bs_11402'] = trim( $request->input('d_bs_11402', true) );
                $bsheet_arr['d_bs_12000'] = trim( $request->input('d_bs_12000', true) );
                $bsheet_arr['d_bs_13000'] = trim( $request->input('d_bs_13000', true) );
                $bsheet_arr['d_bs_21101'] = trim( $request->input('d_bs_21101', true) );
                $bsheet_arr['d_bs_21102'] = trim( $request->input('d_bs_21102', true) );
                $bsheet_arr['d_bs_21104'] = trim( $request->input('d_bs_21104', true) );
                $bsheet_arr['d_bs_22000'] = trim( $request->input('d_bs_22000', true) );
                $bsheet_arr['d_bs_30000'] = trim( $request->input('d_bs_30000', true) );

                //// Total Field(s)
                $bsheet_arr['d_bs_11100'] = ($bsheet_arr['d_bs_11101'] + $bsheet_arr['d_bs_11102']);
                $bsheet_arr['d_bs_11400'] = ($bsheet_arr['d_bs_11401'] + $bsheet_arr['d_bs_11402']);
                $bsheet_arr['d_bs_11000'] = ($bsheet_arr['d_bs_11100'] + $bsheet_arr['d_bs_11200'] + $bsheet_arr['d_bs_11300'] + $bsheet_arr['d_bs_11400']);
                $bsheet_arr['d_bs_10000'] = ($bsheet_arr['d_bs_11000'] + $bsheet_arr['d_bs_12000'] + $bsheet_arr['d_bs_13000']);
                $bsheet_arr['d_bs_21000'] = ($bsheet_arr['d_bs_21101'] + $bsheet_arr['d_bs_21102'] + $bsheet_arr['d_bs_21104']);
                $bsheet_arr['d_bs_20000'] = ($bsheet_arr['d_bs_21000'] + $bsheet_arr['d_bs_22000'] + $bsheet_arr['d_bs_30000']);

                $bsheet_arr['dt_updated']    = utils::get_db_datetime();


                $bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
                \DB::table($bsheet_inputs_tbl)
                    ->where('i_id', $BSHEET_DETAILS_ID)
                    ->update($bsheet_arr);

                $MSG_FLAG = "updated";

            } else {    // Add New

                # II-A: insert into master table 1st...
                $master_data_arr = array();
                $master_data_arr['i_user_id'] = $logged_usr;
                $master_data_arr['i_store_id'] = $storeID;
                $master_data_arr['i_month'] = $month;
                $master_data_arr['i_year'] = $year;
                $master_data_arr['dt_added'] = utils::get_db_datetime();
                if( $LOGGED_USR_TYPE==2 ) // iff "Franchisor" only
                    $master_data_arr['i_locked'] = $BSHEET_LOCKED;
                $master_bsheet_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
                $BSHEET_ID = \DB::table($master_bsheet_tbl)
                    ->insertGetId($master_data_arr);

                # II-B: insert into balance-sheet input(s)...
                $bsheet_arr = array();
                $bsheet_arr['i_balance_sheet_id'] = $BSHEET_ID;
                $bsheet_arr['d_bs_11101'] = trim( $request->input('d_bs_11101', true) );
                $bsheet_arr['d_bs_11102'] = trim( $request->input('d_bs_11102', true) );
                $bsheet_arr['d_bs_11200'] = trim( $request->input('d_bs_11200', true) );
                $bsheet_arr['d_bs_11300'] = trim( $request->input('d_bs_11300', true) );
                $bsheet_arr['d_bs_11401'] = trim( $request->input('d_bs_11401', true) );
                $bsheet_arr['d_bs_11402'] = trim( $request->input('d_bs_11402', true) );
                $bsheet_arr['d_bs_12000'] = trim( $request->input('d_bs_12000', true) );
                $bsheet_arr['d_bs_13000'] = trim( $request->input('d_bs_13000', true) );
                $bsheet_arr['d_bs_21101'] = trim( $request->input('d_bs_21101', true) );
                $bsheet_arr['d_bs_21102'] = trim( $request->input('d_bs_21102', true) );
                $bsheet_arr['d_bs_21104'] = trim( $request->input('d_bs_21104', true) );
                $bsheet_arr['d_bs_22000'] = trim( $request->input('d_bs_22000', true) );
                $bsheet_arr['d_bs_30000'] = trim( $request->input('d_bs_30000', true) );

                //// Total Field(s)
                $bsheet_arr['d_bs_11100'] = ($bsheet_arr['d_bs_11101'] + $bsheet_arr['d_bs_11102']);
                $bsheet_arr['d_bs_11400'] = ($bsheet_arr['d_bs_11401'] + $bsheet_arr['d_bs_11402']);
                $bsheet_arr['d_bs_11000'] = ($bsheet_arr['d_bs_11100'] + $bsheet_arr['d_bs_11200'] + $bsheet_arr['d_bs_11300'] + $bsheet_arr['d_bs_11400']);
                $bsheet_arr['d_bs_10000'] = ($bsheet_arr['d_bs_11000'] + $bsheet_arr['d_bs_12000'] + $bsheet_arr['d_bs_13000']);
                $bsheet_arr['d_bs_21000'] = ($bsheet_arr['d_bs_21101'] + $bsheet_arr['d_bs_21102'] + $bsheet_arr['d_bs_21104']);
                $bsheet_arr['d_bs_20000'] = ($bsheet_arr['d_bs_21000'] + $bsheet_arr['d_bs_22000'] + $bsheet_arr['d_bs_30000']);

                $bsheet_arr['dt_added']      = utils::get_db_datetime();

                $bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
                \DB::table($bsheet_inputs_tbl)
                    ->insert($bsheet_arr);

                $MSG_FLAG = "added";
            }
            //// retrieving submitted/posted values [END]...

            //// redirection URL...
            $REDIRECT = url() ."/my-inputs/monthly-financials";

            # success message...
            $SUCCESS_MSG = "Balance-Sheet info {$MSG_FLAG} successfully";


            echo json_encode(array('result'=>'success',
                'redirect'=>$REDIRECT,
                'msg'=>$SUCCESS_MSG));
            exit;

        }
        // end of AJAX Add-New/Update Balance-Sheet value(s) function...

        # load Balance-Sheet data (if any)
        public function loadBalanceSheetData($where_cond=null) {

            $bSheetModel = new model_balance_sheet();
            $data_arr = $bSheetModel->fetchBalanceSheetInfo($where_cond);

            return $data_arr;
        }


    //// ==================================================================================
    ////            Section-I: BALANCE-SHEET VALIDATION & ADD/UPDATE [END]
    //// ==================================================================================






    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           MISCELLANEOUS FUNCTION(S) - BEGIN
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to determine whether the form would be in
        # View-Only mode or Edit mode...
        public function checkViewOREditMode(Request $request=null, $data_arr=null) {

            $USR_TYPE = \Session::get('user_type');
            $MODE = 'view-only';

            # I: if user-type is Franchisee-User...
                if( $USR_TYPE==4 ) {

                    # IA: check if immediate Last-Month OR not...
                    if( $this->checkIfLastMonth() ) {

                        # IB: further check if already "LOCKED" by Franchisor OR not...
                        if( !$this->checkIfLocked($data_arr) )
                            $MODE = 'edit';
                    }

                } elseif( $USR_TYPE==2 )  { // i.e. Franchisor-Admin
                    $MODE = 'edit';
                } else {
                    # II: if user-type is Franchisor OR Field-Consultant...
                    # then mode will be view only...
                }

            return $MODE;
        }


        # function to check if Immediate last-Month OR Not...
        public function checkIfLastMonth() {

            $last_month = date('m', strtotime("first day of last month"));

            $posted_month_val = \Input::get('month_val');
            $posted_yr_val = \Input::get('yr_val');
            $selected_month = ( empty($posted_month_val) )? $last_month: ($posted_month_val+1);

            if( $selected_month==$last_month )
                return true;
            else
                return false;
        }

        # function to check if the data-already locked by Franchisor OR not...
        public function checkIfLocked($data_arr=null) {

            if( !empty($data_arr) ) {
                if( $data_arr->i_locked )
                    return true;
                else
                    return false;
            } else
                return false;

        }


        # NEW - Load Balance-Sheet & Income-Statement Data [AJAX CALL]...
        public function loadMonthlyFinancialsDataAJAX(Request $request) {

            $data = $this->data;

            # I: retrieving required param(s)/data...
                $year = $request->input('yr_val');
                $month = $request->input('month_val') + 1;
                $logged_usr = \Session::get('user_id');
                $storeID = $request->input('store_id');

                $WHERE_COND = " A.`i_store_id`={$storeID} AND
                                A.`i_month`={$month} AND
                                A.`i_year`={$year} ";

            # II: Balance-Sheet Variable(s)...
                $DATA_ARR = $this->loadBalanceSheetData($WHERE_COND);
                $data['bsheet_arr'] = ( !empty($DATA_ARR) )? $DATA_ARR[0]: $DATA_ARR;
                $data['bsheet_mode'] = $this->checkViewOREditMode(null, $data['bsheet_arr']);
                $data['bsheet_last_modified'] = $this->fetchLastModifiedByData($data['bsheet_arr']);


            # III: Income-Statement Variable(s)...
                $DATA_ARR = $this->loadIncomeStmtData($WHERE_COND);
                $data['istmt_arr'] = ( !empty($DATA_ARR) )? $DATA_ARR[0]: null;
                $data['istmt_mode'] = $this->checkViewOREditMode(null, $data['istmt_arr']);
                $data['istmt_last_modified'] = $this->fetchLastModifiedByData($data['istmt_arr']);

            # IV: getting User-Type...
                $data['logged_usr_type'] = \Session::get('user_type');

            # load view part...
            $HTML = \View::make('userend.my-inputs.ajax-parts.load-monthly-financials-data-AJAX', $data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML,
                                   'bsheet_mode'   => $data['bsheet_mode']));
            exit;

        }




        # function to get "Last-Modified-By" info...
        public function fetchLastModifiedByData($data_arr=null) {

            $RETURN_STR = '';
            if( !empty($data_arr) ) {
                $RETURN_STR .= "Last modified by <span class='font-bold'>". $data_arr->s_last_modified_by;
                $RETURN_STR .= "</span> on ". date('j M, Y \a\t g:i A', strtotime($data_arr->dt_last_modified));
            }

            return $RETURN_STR;
        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #           MISCELLANEOUS FUNCTION(S) - END
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
