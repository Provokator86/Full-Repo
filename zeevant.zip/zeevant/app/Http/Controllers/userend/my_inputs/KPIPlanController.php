<?php

namespace App\Http\Controllers\userend\my_inputs;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\KPIModel as model_kpi;
use App\Helpers\Utility as utils;

class KPIPlanController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: My Inputs - Monthly KPI Plan ::';

        # for menu selection...
        $this->data['selected_menu'] = 'my-inputs';
        $this->data['selected_sub_menu'] = 'monthly-KPI-plan';
    }


    // index function definition...
    public function index($selected_store=null, $selected_month=null, $selected_yr=null) {

        # Page-Specific Settings...
        $data = $this->data;


        //// KPI related data [Begin]
			$ORDER_BY = " `i_fld_order` ";
            if( !empty($selected_store) ) {
                $WHERE_COND = '';
                $SUB_WHERE_COND = "`i_store_id`={$selected_store} AND
                                   `i_month`={$selected_month} AND
                                   `i_year`={$selected_yr} ";
                $KPIModel = new model_kpi();
                $order_by = ' `i_id` ASC ';
                if( $KPIModel->getTotalInfo($WHERE_COND) ) {
                    $data['KPI_arr'] = $KPIModel->fetchKPIDetailRecords($WHERE_COND, $SUB_WHERE_COND, $ORDER_BY);
                }

                $data['selected_store'] = $selected_store;
            } else {
                # II: fetch KPI(s) List...
                $where_cond = '';  // i.e. All KPI(s)
                $KPIModel = new model_kpi();
                $order_by = ' i_id ASC ';
                $data['KPI_arr'] = $KPIModel->fetchRecordsArr($where_cond, null, null, $ORDER_BY);
                
                # utils::dump($data['KPI_arr']);

                $data['selected_store'] = null;
            }

            # utils::dump( $data['KPI_arr'] );

        //// KPI related data [End]


        # show view part...
        return view('userend.my-inputs.KPI-plan', $data);
    }


    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_KPI_plan_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $arr_err_index = $arr_success_index = $arr_msg = array();
            $arr_val_range = utils::getMonthlyKpiPlanRanges('i_fld_order');
            /*$arr_val_range = array(['min'=>15000, 'max'=>40000],
            					   ['min'=>65, 'max'=>74],
            					   [],
            					   ['min'=>14, 'max'=>30],
            					   [], [], [], [], [],
            					   ['min'=>0, 'max'=>10]);*/
            
            $REQD_FLD_MSG = '* required field';
            $VALIDATION_MSG = '* not within valid range';

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # Franchisee/Store - Required Field
            $err_franchisee = false;
            if( trim($_POST['i_store'])=='' ) {
                $err_franchisee = true;
            }


            # NEW - for range validation check [Begin] 
            $KPI_flds = $_POST['kpi_marks'];
            
            foreach($KPI_flds as $key=>$val) {
            	
            	$ARR_RANGE = $arr_val_range[$key];
            	if( !empty($ARR_RANGE) ) {	// I
            		$MIN_RANGE = $ARR_RANGE['min'];
            		$MAX_RANGE = $ARR_RANGE['max'];
            		
            		$FLD_VAL = trim($val);
            		if( $FLD_VAL!='' ) {  // II
            			
            			if( $FLD_VAL>=$MIN_RANGE && $FLD_VAL<=$MAX_RANGE )
            				$arr_success_index[] = $key;
            			else {
            				$arr_err_index[] = $key;
            				$arr_msg[] = $VALIDATION_MSG;
            			}
            				
            		}	// II - end
            		
            	}	// I - end
            	
            }
            # NEW - for range validation check [End]
            
            # for KPI Field(s)...
            /*$KPI_flds = $_POST['kpi_marks'];
            foreach($KPI_flds as $key=>$val) {

                if( trim($val)=='' ) {
                    $arr_err_index[] = $key;
                    $arr_msg[] = $REQD_FLD_MSG;
                } else
                    $arr_success_index[] = $key;

            }*/


            # check if current-month...
            $mode = null;
            if( $this->checkExistingData($request) ) {
                $mode = 'update';
            }



            # ADD NEW "KPI-Plan(s)" [if no errors]...
            if( count($arr_msg)==0 && !$err_franchisee ) {

                $this->add_KPI_plan_AJAX($request);
            }
            else   //// if error occurs...
            {
                echo json_encode(array('result'       => 'error',
                                       'err_franchisee' => $err_franchisee,
                                       'arr_err_indices'  => $arr_err_index,
                                       'arr_success_indices'  => $arr_success_index,
                                       'arr_msg'      => $arr_msg));
                exit;
            }
        }


        # function to Add/Update KPI-Plan [AJAX CALL]...
        public function add_KPI_plan_AJAX(Request $request) {

            //// Now, retrieving submitted/posted values [BEGIN]...
            $KPI_flds = $_POST['kpi_marks'];
            $KPI_IDs = $_POST['kpi_id'];	// NEW

            utils::dump($KPI_IDs);
            
            $kpi_details_DB = new model_kpi();

            # I: KPI Details...
            $KPI_plan_arr = array();
            $SELECTED_STORE = $KPI_plan_arr['i_store_id']    = trim( $request->input('i_store', true) );
            $KPI_plan_arr['i_usr_id']    = \Session::get('user_id');
            $SELECTED_MONTH = $KPI_plan_arr['i_month']     = trim( $request->input('i_month', true) ) + 1;
            $SELECTED_YR = $KPI_plan_arr['i_year']     = trim( $request->input('i_year', true) );
            $KPI_plan_arr['dt_added']    = utils::get_db_datetime();
            //// retrieving submitted/posted values [END]...

            //// adding new data to KPI-details table...
            # check if data already exist(s) OR not...
            # if exist(s) then Update otherwise Insert...
            $kpi_details_tbl = getenv('DB_PREFIX') .'kpi_details';
            if( $this->checkExistingData($request) ) {  // update accordingly

                // delete data from table 1st...
                /*\DB::table($kpi_details_tbl)
                    ->where('i_store_id', $KPI_plan_arr['i_store_id'])
                    ->where('i_month', $KPI_plan_arr['i_month'])
                    ->where('i_year', $KPI_plan_arr['i_year'])
                    ->delete();*/

                $MSG_STATUS = "updated";
            } else {    // i.e. Insert New
                $MSG_STATUS = "added";
            }

            # inserting into "_kpi_details" table...
            foreach($KPI_flds as $key=>$plan_val) {
                #$i_KPI_id = $key + 1;
                /*if( $key==2 )
                	$i_KPI_id = 11;
                else
                	$i_KPI_id = ( $key<2 )? ($key+1): $key;*/
                $i_KPI_id = $KPI_IDs[$key];
            	
                $KPI_plan_arr['i_kpi_id'] = $i_KPI_id;
                $KPI_plan_arr['d_monthly_plan_mark'] = ( !empty($plan_val) )? $plan_val: 0;

               
                utils::dump($KPI_plan_arr);
                /*\DB::table($kpi_details_tbl)
                    ->insert($KPI_plan_arr);*/
            }



            //// redirection URL...
            $REDIRECT = url() ."/my-inputs/monthly-KPI-plan";
            if( !empty($SELECTED_STORE) )
                $REDIRECT .= "/{$SELECTED_STORE}/{$SELECTED_MONTH}/{$SELECTED_YR}";

            # success message...
            $SUCCESS_MSG = "KPI Plan {$MSG_STATUS} successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }
        // end of AJAX Add/Update KPI-Plan function...



        //// ~~~~~~~~~~~~~~ FEW VALIDATION FUNCTION(S) [BEGIN] ~~~~~~~~~~~~~~

            # function - not valid...
            public function checkValidMonth($mode=null) {

                $current_month = date('m');
                $current_yr = date('Y');
                $selected_month = \Input::get('i_month');
                $selected_yr = \Input::get('i_year');
                $selected_month += 1;   # adding 1 since month-index is "0" based...

                if( !empty($mode) ) {   // i.e. update-mode

                    if( $current_yr>=$selected_yr ) {
                        if( $selected_month==($current_month+1) )   // i.e. future-month
                            return true;
                        else
                            return false;
                    } else
                        return true;

                } else {    // i.e. insert-mode

                    if( $current_yr>=$selected_yr ) {

                        if (($selected_month == $current_month)
                            || ($selected_month == ($current_month + 1))
                        )   // i.e. present or future month
                            return true;
                        else
                            return false;
                    } else
                        return true;

                }

            }


            # function to check for already existing data...
            public function checkExistingData(Request $request) {

                $master_tbl = getenv('DB_PREFIX') .'kpi_master';
                $details_tbl = getenv('DB_PREFIX') .'kpi_details';

                $STORE_ID = $request->input('i_store', true);
                $MONTH    = $request->input('i_month', true) + 1;
                $YEAR     = $request->input('i_year', true);
                $USR_ID   = \Session::get('user_id');

                $SQL = sprintf("SELECT COUNT(*) AS `i_total`
                                FROM %s
                                WHERE
                                    `i_store_id`=%d AND
                                    `i_month`=%d AND
                                    `i_year`=%d",
                                $details_tbl, $STORE_ID, $MONTH, $YEAR);

                $rs = \DB::select(\DB::raw($SQL));
                if( is_array($rs) )
                {
                    foreach($rs as $row)
                        $ret_=intval($row->i_total);
                }

                if( $ret_ )  // i.e. data exist(s) already...
                    return true;
                else
                    return false;
            }



            # function to load KPI-Plan(s) data (if any)...
            public function load_plan_data_AJAX(Request $request) {

                $data = $this->data;

                $STORE_ID = $request->input('store_id', true);
                $MONTH    = $request->input('month_val', true) + 1;
                $YEAR     = $request->input('year_val', true);
                $USR_ID   = \Session::get('user_id');

                $WHERE_COND = '';
                $SUB_WHERE_COND = "`i_store_id`={$STORE_ID} AND
                                   `i_month`={$MONTH} AND
                                   `i_year`={$YEAR} ";
                $ORDER_BY = " `i_fld_order` ";
                $KPIModel = new model_kpi();
                $order_by = ' `i_id` ASC ';
                if( $KPIModel->getTotalInfo($WHERE_COND) ) {
                    $data['KPI_arr'] = $KPIModel->fetchKPIDetailRecords($WHERE_COND, $SUB_WHERE_COND, $ORDER_BY);

                    # load view part...
                    $HTML = \View::make('userend.my-inputs.ajax-parts.load-KPI-plan-data-AJAX', $data)->render();
                } else {

                    $data['KPI_arr'] = array();
                    $HTML = '';
                }

                echo json_encode(array('result'        => 'success',
                                       'html_content'  => $HTML));
                exit;

            }



        //// ~~~~~~~~~~~~~~ FEW VALIDATION FUNCTION(S) [END] ~~~~~~~~~~~~~~


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================

}
