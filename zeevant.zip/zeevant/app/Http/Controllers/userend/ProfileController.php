<?php

namespace App\Http\Controllers\userend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

class ProfileController extends BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Zeevant - User Profile ::';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;
       
        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        
        # ====================================================================
        # 			USER PROFILE INFO [BEGIN]
        # ====================================================================
        
			$USR_INFO_ARR = array();
			$mod_users = new \App\Models\Users();
        
			# fetching info based on logged user-type...
			# if franchisor-admin then...
			if( $LOGGED_USR_TYPE==2 ) {
				
				$USR_INFO_ARR = $mod_users->fetchFranchisorUserInfo($LOGGED_USR_ID);
				
			} else {	// field-consultant OR franchisee-user
				
				$USR_INFO_ARR = $mod_users->fetchFranchiseeUserInfo($LOGGED_USR_ID);
								
			}
			
			# utils::dump( $USR_INFO_ARR );
			
			# fetching logged-user-specific store details...
			if( !empty($USR_INFO_ARR) ) {
				
				$stores_arr = $mod_users->fetchFranchiseeDetailsByUserType($LOGGED_USR_ID,
																		   $LOGGED_USR_TYPE);
				
				# utils::dump( $stores_arr );
				
				$this->data['user_info'] = $USR_INFO_ARR;
				$this->data['store_arr'] = $stores_arr;
			}
        
        # ====================================================================
        # 			USER PROFILE INFO [END]
        # ====================================================================
        

        # show view part...
        return view('userend.user-profile', $this->data);
    }


	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# 			Update Profile Info [Begin]
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
		# function to validate form-submission [AJAX CALL]
		public function validateProfileInfoAJAX(Request $request) {
			
			try {

				// Error Messages for Required Fields...
				$err_flds = array();
				$REQD_FLD_MSG = ' required field';
				$required_fields = array('s_first_name', 's_last_name', 's_email');

				// adjusting err-messages part accordingly...
				$arr_messages = array();

				////////////// VALIDATION CHECKS - BEGIN //////////////

				# validation for singular fields (i.e. appearing once)...
				foreach($required_fields as $required_field) {

					if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

						if( !in_array($required_field, $err_flds) )
							$err_flds[] = $required_field;

						$arr_messages[$required_field] = $REQD_FLD_MSG;
					}
					
					// for email duplicate check...	
					if( $required_field == 's_email' && trim($_POST['s_email'])!='' )
					{
						$users_master_tbl = getenv('DB_PREFIX') .'users';
						if (\DB::table($users_master_tbl)
								->where('s_email', '=', $_POST['s_email'])
								->where('i_id', '!=', \Session::get('user_id'))->exists()) {
							$arr_messages['s_email'] = ' already exists';
							$err_flds[] = 's_email';
						}

					}

				}


				# if validated [if no errors]...
				if( count($arr_messages)==0 ) {

					$this->updateProfileInfoAJAX($request);
					
				} else  {	// for success field(s)...
					
					$success_flds = array_diff($required_fields, $err_flds);
					$success_flds = array_values($success_flds);

					echo json_encode(array('result'       => 'error',
										   'arr_messages' => $arr_messages,
										   'success_flds' => $success_flds
										));
					exit;
				}

					
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
		}
		
		
		# function to update profile info update [AJAX Call]...
		public function updateProfileInfoAJAX(Request $request) {
			
			try {

				# logged-in user-id & type...
				$LOGGED_USR_ID = \Session::get('user_id');
				$LOGGED_USR_TYPE = \Session::get('user_type');


				# I: Retrieving submitted value(s)...
				$profile_info_arr = array();
				$profile_info_arr['s_first_name'] = $request->input('s_first_name');
				$profile_info_arr['s_last_name'] = $request->input('s_last_name');
				$profile_info_arr['s_email'] = $request->input('s_email');


				# updating users-master table...
				$users_master_tbl = getenv('DB_PREFIX') .'users';
				\DB::table($users_master_tbl)
					->where('i_id', $LOGGED_USR_ID)
					->update($profile_info_arr);

				//// redirection URL...
				$REDIRECT = url() ."/profile";

				# success message...
				$SUCCESS_MSG = "Profile info updated successfully...";


				echo json_encode(array('result'=>'success',
									   'redirect'=>$REDIRECT,
									   'msg'=>$SUCCESS_MSG));
				exit;

				
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
			
		}


	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	# 			Update Profile Info [End]
	# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	



	# ==========================================================================
	# 			Update Password Info [Begin]
	# ==========================================================================
	
		# function to validate password update [AJAX CALL]
		public function validateAccountPasswordAJAX(Request $request) {
			
			try {

				// Error Messages for Required Fields...
				$err_flds = array();
				$REQD_FLD_MSG = ' required field';
				$required_fields = array('old_passwd', 'new_passwd', 'conf_new_passwd');

				// adjusting err-messages part accordingly...
				$arr_messages = array();

				////////////// VALIDATION CHECKS - BEGIN //////////////

				# validation for singular fields (i.e. appearing once)...
				foreach($required_fields as $required_field) {

					if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

						if( !in_array($required_field, $err_flds) )
							$err_flds[] = $required_field;

						$arr_messages[$required_field] = $REQD_FLD_MSG;
					}

				}

				// old password match check...	
				if( trim($_POST['old_passwd'])!='' )
				{
					$users_master_tbl = getenv('DB_PREFIX') .'users';
					if (!\DB::table($users_master_tbl)
							->where('s_passwd', '=', utils::get_salted_password($_POST['old_passwd']))
							->where('i_id', '=', \Session::get('user_id'))->exists()) {
						$arr_messages['old_passwd'] = ' wrong password given';
						$err_flds[] = 'old_passwd';
					}

				}
				
				
				// new password & confirm password match...
				if( trim($_POST['new_passwd'])!='' ) {
					
					if( trim($_POST['new_passwd'])!=trim($_POST['conf_new_passwd']) ) {
						$arr_messages['new_passwd'] = ' doesn\'t match';
						$err_flds[] = 'new_passwd';
					}
					
				}


				# if validated [if no errors]...
				if( count($arr_messages)==0 ) {

					$this->updateAccountPasswordAJAX($request);
					
				} else  {	// for success field(s)...
					
					$success_flds = array_diff($required_fields, $err_flds);
					$success_flds = array_values($success_flds);

					echo json_encode(array('result'       => 'error',
										   'arr_messages' => $arr_messages,
										   'success_flds' => $success_flds
										));
					exit;
				}

					
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
		}
		
		
		# function to update account-password [AJAX Call]...
		public function updateAccountPasswordAJAX(Request $request) {
			
			try {

				# logged-in user-id & type...
				$LOGGED_USR_ID = \Session::get('user_id');
				$LOGGED_USR_TYPE = \Session::get('user_type');


				# I: Retrieving submitted value(s)...
				$passwd_info_arr = array();
				$passwd_info_arr['s_passwd'] = utils::get_salted_password($request->input('new_passwd'));


				# updating users-master table...
				$users_master_tbl = getenv('DB_PREFIX') .'users';
				\DB::table($users_master_tbl)
					->where('i_id', $LOGGED_USR_ID)
					->update($passwd_info_arr);

				//// redirection URL...
				$REDIRECT = url() ."/profile";

				# success message...
				$SUCCESS_MSG = "Password updated successfully...";


				echo json_encode(array('result'=>'success',
									   'redirect'=>$REDIRECT,
									   'msg'=>$SUCCESS_MSG));
				exit;

				
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
			
		}



	# ==========================================================================
	# 			Update Password Info [End]
	# ==========================================================================
	
}
