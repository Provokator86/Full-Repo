<?php

namespace App\Http\Controllers\userend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;


class BaseController extends Controller
{
    // parent constructor
    public function __construct() {

        $this->data['selected_menu'] = $this->data['selected_sub_menu'] = '';

        # loading site-settings data...
        $this->data['settings_info'] = \App\Models\SiteSettingsModel::first();

        // instantiating Acl class...
        #$this->aclObj = new Acl();

        // site-title...
        $this->setSiteTitle();

        // set site-logo...
        $this->setSiteLogo();

        // setting-up sidebar menu variable(s)...
        $this->setSideBarMenu();

        // set(s) variable(s) if Logged-In...
        $this->setLoggedVars();
        
        // set(s) profile name and logo if Logged-In...
        $this->setProfileNameLogo();

    }


    // function to set site-header...
    public function setSiteTitle() {

        $SITE_TITLE = config('custom.config.default_site_title');
        // 1st: check from site-settings table...
        if(  !empty( $this->data['settings_info']['s_site_title']) )
            $SITE_TITLE = $this->data['settings_info']['s_site_title'];

        $this->data['userend_site_title'] = $SITE_TITLE;
    }


    // function to form user-end sidebar/menu-bar...
    public function setSideBarMenu() {

        try{

            # 1: if not set in cache, 1st put into the cache...
            if( !\Cache::has('sidebar_menu') ) {
                $sidebar_main_arr = config('custom.config.sidebar_arr');
                $sidebar_icons_arr = config('custom.config.sidebar_icons_arr');
                $sidebar_acl_arr = config('custom.config.sidebar_acl_arr');
                
                //// NEW
                $sidebar_store_access_arr = config('custom.config.sidebar_store_wise_access_arr');

                \Cache::forever('sidebar_main', $sidebar_main_arr);
                \Cache::forever('sidebar_icons', $sidebar_icons_arr);
                \Cache::forever('sidebar_acl', $sidebar_acl_arr);
                \Cache::forever('sidebar_store_access', $sidebar_store_access_arr);
            }


            # 2: retrieving from cache...
            $this->data['sidebar_main_arr'] = \Cache::get('sidebar_main');
            $this->data['sidebar_icons_arr'] = \Cache::get('sidebar_icons');
            $this->data['sidebar_acl_arr'] = \Cache::get('sidebar_acl');
            $this->data['store_access_arr'] = \Cache::get('sidebar_store_access');

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }


    // function to set variable(s) if logged-in...
    public function setLoggedVars() {

        try{

            # if logged in...
            $this->data['logged_usr_type'] = null;
            if( \Session::has('usr_loggedin') ) {
                $this->data['logged_usr_type'] = \Session::get('user_type');
            }


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }


    // function to set site-logo if logged-in...
    public function setSiteLogo() {

        try{

            # if logged in...
            if( \Session::has('userend_logo') ) {
                $this->data['site_logo'] = \Session::get('userend_logo');
            }


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }
    
    // function to set profile name and logo if logged-in...
    public function setProfileNameLogo() {

        try{

            # if logged in...
            if( \Session::has('user_id') ) {
                $this->data['s_first_name'] = \Session::get('s_first_name');
                $this->data['s_last_name'] = \Session::get('s_last_name');
                $this->data['userend_logo'] = \Session::get('userend_logo');
            }
        
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

}
