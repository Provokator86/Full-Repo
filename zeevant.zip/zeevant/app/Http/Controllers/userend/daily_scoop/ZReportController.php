<?php

namespace App\Http\Controllers\userend\daily_scoop;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

class ZReportController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Daily Scoop - Z-Report ::';

        # for menu selection...
        $this->data['selected_menu'] = 'daily-scoop';
        $this->data['selected_sub_menu'] = 'z-report';
    }


    // index function definition...
    public function index() {


        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        # 1: getting concerned Franchisor-Admin ID...
        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                               : $LOGGED_USR_ID;


        # Default Load "Month-Scroller"...
        $this->data['default_month_scroller_dt'] = date('d M y', strtotime("previous day"));


        # show view part...
        return view('userend.daily_scoop.zreport', $this->data);
    }



    // AJAX Call - load Table data based on selected store & date...
    public function loadZReportDataAJAX(Request $request) {

        try {

            # 1: loading chart-data...
            $ZREPORT_DATA_ARR = $this->loadZReportTableDataAJAX($request);

            # 2: loading zreport-attendance data...
            $ZREPORT_ATTENDANCE_DATA_ARR = $this->loadZReportAttendanceTableDataAJAX($request);

            # ***************************************************************************
            #       For Data-Table - Begin
            # ***************************************************************************

            	//// NEW - for Date Header [Begin]
            		$DAY = $this->input->post('date_val');
            		$MONTH = $this->input->post('month_val');
            		$YEAR = $this->input->post('yr_val');
            		$LBL_DT_HEADER = date('j M y', mktime(0, 0, 0, $MONTH, $DAY, $YEAR));
            	//// NEW - for Date Header [End]
            
                $this->data['data_tbl_arr'] = $ZREPORT_DATA_ARR;
                $this->data['attendance_data_tbl_arr'] = $ZREPORT_ATTENDANCE_DATA_ARR;
                # utils::dump($this->data['attendance_data_tbl_arr']);

            # ***************************************************************************
            #       For Data-Table - End
            # ***************************************************************************

            # 2: load Data-Table view part...
            $TBL_HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-zreport-tbl-data-AJAX', $this->data)->render();

            # 3: load Attendance-Data-Table view part...
            $TBL_ATTENDANCE_HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-zreport-attendance-tbl-data-AJAX', $this->data)->render();

            # return array...
            echo json_encode(array('result' => 'success',
                                   'tbl_html_content' => $TBL_HTML,
                                   'tbl_attendance' => $TBL_ATTENDANCE_HTML,
            					   'lbl_dt' => $LBL_DT_HEADER));
            exit;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }




    # =============================================================
    #           Generate Data(s) - Begin
    # =============================================================

        //// Top 10 Sellers Data [AJAX Call]...
        public function loadZReportTableDataAJAX(Request $request) {

            try {

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');


                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               DS Chart(s) Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # retrieving submitted value(s)...
                // Date-Time related data...
                    $DT = $request->input('date_val');
                    $MONTH = $request->input('month_val');
                    $YEAR = $request->input('yr_val');

                    $PARAM_DT = date('Y-m-d', mktime(0, 0, 0, $MONTH, $DT, $YEAR));

                // for Store-ID(s)
                    $PARAM_STORE = $request->input('store_id');


                # calling stored-routine (or any)...
                $arr = $this->formZReportDataArray($PARAM_STORE, $PARAM_DT);

                return $arr;

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               DS Chart(s) Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


        //// Z-Report Attendance Data [AJAX Call]...
        public function loadZReportAttendanceTableDataAJAX(Request $request) {

            try {

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Attendance Data Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $DT = $request->input('date_val');
                    $MONTH = $request->input('month_val');
                    $YEAR = $request->input('yr_val');

                    $PARAM_DT = date('Y-m-d', mktime(0, 0, 0, $MONTH, $DT, $YEAR));

                    // for Store-ID(s)
                    $PARAM_STORE = $request->input('store_id');


                    # calling stored-routine (or any)...
                    $arr = $this->formZReportAttendanceDataArray($PARAM_STORE, $PARAM_DT);

                    return $arr;

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Attendance Data Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


    # =============================================================
    #           Generate Data(s) - End
    # =============================================================


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Running Related Queries - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to get ZReport-DATA...
        public function formZReportDataArray($param_store=null, $param_dt=null) {

            try {
                $return_arr = array();

                # Stored-Routine Call [Begin]
                    #$SQL = sprintf("CALL zev_ds_zreport('%d','%s')", $param_store, $param_dt);
                    $SQL = "CALL zev_ds_zreport('". $param_store ."','". $param_dt ."')";
                    $return_data = \DB::select(\DB::raw($SQL));
                # Stored-Routine Call [End]

                $return_arr = $this->prepareDBReturnArray($return_data);
                # utils::dump($return_arr);

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }

        # function to get ZReport-Attendance DATA...
        public function formZReportAttendanceDataArray($param_store=null, $param_dt=null) {

            try {
                $return_arr = array();

                # Stored-Routine Call [Begin]
                $SQL = sprintf("CALL zev_ds_zreport_attendance('%d','%s')", $param_store, $param_dt);
                $return_data = \DB::select(\DB::raw($SQL));
                # Stored-Routine Call [End]

                $return_arr = $this->prepareAttendanceDBReturnArray($return_data);
                # utils::dump($return_arr);

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Running Related Queries - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



    # function to prepare return-array format form db-results...
    public function prepareDBReturnArray($db_result_obj=null) {

        try {

            $RETURN_ARR = null;
            if( !empty($db_result_obj) ) {
                $LOOP_INDEX  = 0;

                # utils::dump($db_result_obj);
                foreach($db_result_obj as $row_obj) {
                    $RETURN_ARR[$LOOP_INDEX]['s_description'] = $row_obj->s_description;
                    $RETURN_ARR[$LOOP_INDEX]['d_value'] = $row_obj->d_value;
                    $RETURN_ARR[$LOOP_INDEX]['s_instruction'] = $row_obj->s_instruction;

                    $LOOP_INDEX++;
                }

            }   // end - if


            return $RETURN_ARR;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }
    

    # function to prepare return-array format form db-results...
    public function prepareAttendanceDBReturnArray($db_result_obj=null) {

        try {

            $RETURN_ARR = null;
            if( !empty($db_result_obj) ) {
                $LOOP_INDEX  = 0;

                # utils::dump($db_result_obj);
                foreach($db_result_obj as $row_obj) {
                    $RETURN_ARR[$LOOP_INDEX]['emp_name'] = $row_obj->emp_name;
                    $RETURN_ARR[$LOOP_INDEX]['clock_in'] = $row_obj->clock_in;
                    $RETURN_ARR[$LOOP_INDEX]['clock_out'] = $row_obj->clock_out;
                    $RETURN_ARR[$LOOP_INDEX]['working_hr'] = $row_obj->working_hr;

                    $LOOP_INDEX++;
                }

            }   // end - if


            return $RETURN_ARR;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

    // testing 
    public function test_run() {
        
        $SQL = "CALL zev_ds_zreport('19','2015-12-22')";
        //$SQL = "CALL zev_ds_top10_sellers_all_store('1,19','2015-12-22')";
        $return_data = \DB::select(\DB::raw($SQL));
        //$return_data = \DB::query($SQL);
        
        utils::dump($return_data);
        
    }


}
