<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

use DB;

class DailyGrossMarginModel extends Model
{
    // overriding default setting(s)...
    protected $master_tbl, $inputs_tbl, $users_tbl;
    protected $primaryKey = 'i_id';
    public $timestamps = false;

    // constructor definition...
    public function __construct() {
        $this->master_tbl = getenv('DB_PREFIX') .'erply_daysales';        
        $this->users_tbl  = getenv('DB_PREFIX') .'users';
        $this->franchisee_tbl  = getenv('DB_PREFIX') .'franchisee_master';
        $this->kpi_tbl  = getenv('DB_PREFIX') .'kpi_details';
        $this->config_tbl  = getenv('DB_PREFIX') .'config_details';
    }

    # =======================================================================
    #           Chart Related Calculation(s) - Begin
    # =======================================================================

        // function to calculate Net-Income from "_income_stmt_master" &
        // "_income_stmt_inputs" table(s)...
        public function getCumRevData($store_id, $dt_time_arr) {

            try
            {
               
                $date = $dt_time_arr['date'];
                $month = $dt_time_arr['month'];
                $year  = $dt_time_arr['year'];
                $req_date = $year.'-'.$month.'-'.$date;
                $prev_date = ($year-1).'-'.$month.'-'.$date;

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                $sql_current ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_current FROM 
                                (SELECT erplytrans_date, AVG(a.gross_sales) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date BETWEEN '".$req_date."' - INTERVAL 30 DAY AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";  
                                // For Previous Year
                                $sql_previous ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_previous FROM 
                                (SELECT erplytrans_date, AVG(a.gross_sales) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date BETWEEN '".$prev_date."' - INTERVAL 30 DAY AND '".$prev_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";  
                                
                                $ret_current = DB::select(DB::raw($sql_current));
                                $ret_previous = DB::select(DB::raw($sql_previous)); 
                                $ret_all = array(); 
                                                             

                } else {    // i.e. for a particular-store

                                # IIA: preparing SQL...fetching planned KPI val of selected store...
                                $sql_current ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_current FROM 
                                (SELECT erplytrans_date, a.gross_sales as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id =".$store_id." AND erplytrans_date BETWEEN '".$req_date."' - INTERVAL 30 DAY AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";  
                                // For Previous Year
                                $sql_previous ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_previous FROM 
                                (SELECT erplytrans_date, a.gross_sales as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id =".$store_id." AND erplytrans_date BETWEEN '".$prev_date."' - INTERVAL 30 DAY AND '".$prev_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";  
                                // For cumulative
                                $sql_all ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_all FROM 
                                (SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where 1 AND erplytrans_date BETWEEN '".$req_date."' - INTERVAL 30 DAY AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";                                 
                                $ret_current = DB::select(DB::raw($sql_current));
                                $ret_previous = DB::select(DB::raw($sql_previous)); 
                                $ret_all = DB::select(DB::raw($sql_all)); 
                                
                }

                
                
                $ret_ = array('ret_current'=>$ret_current,'ret_previous'=>$ret_previous,'ret_all'=>$ret_all);

                /*$return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2);*/

                unset($sql_current,$sql_previous,$sql_all);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        
        // chart 1
        public function getCumRevDetailsData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                
                
                
                $prev_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                //$prev_date = date('Y-m-d', strtotime('-1 day', strtotime($prev_date)));
                
                $prev_req_date =  date('Y-m-d', strtotime('-1 year', strtotime($req_date)));
                $prev_prev_date =  date('Y-m-d', strtotime('-1 year', strtotime($prev_date)));
                
                
                $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));

                if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                                $sql_marching =" CALL zev_ds_margin_marching_progress('".$stores."','".$req_date."')"; 
                               
                                
                                
                                                             

                } else {    // i.e. for a particular-store

                                $sql_marching =" CALL zev_ds_margin_marching_progress('".$store_id."','".$req_date."')";    
                                
                                
                }
                //$ret_ = DB::select(DB::raw($sql_current));
              
                $ret_ = DB::select(DB::raw($sql_marching));  
               
                unset($sql_marching);                   
                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }

        // chart 2
         public function getCumRevisedDetailsData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                             
                                
                                
                                $sql_deviation =" CALL zev_ds_margin_marching_progress('".$stores."','".$req_date."')"; 
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                                
                               $sql_deviation =" CALL zev_ds_margin_marching_progress('".$store_id."','".$req_date."')";
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_deviation));  
                
               
               
               //print_r($ret_);exit;
               unset($sql_deviation);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 3
        public function getCumBaselineDetailsData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                
                                
                             
                                
                              
                                
                                
                                /*$sql_target ="SELECT d.erplytrans_date,d.sum_sales as actual,(d.tar*d4.d_mark) as tar,'0' as target FROM 
                                (SELECT d1.erplytrans_date,d2.sum_pm as tar,d1.store_id, d1.sum_sales 
                                FROM (SELECT erplytrans_date, DATE_FORMAT(erplytrans_date,'%m') as months, DATE_FORMAT(erplytrans_date,'%Y') as years,sum(a.gross_sales) as sum_sales,b.i_id as store_id 
                                FROM ".$this->master_tbl." a
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number and a.company_id <>''
                                where b.i_id IN (".$stores.") and erplytrans_date between '".$previ_date."' and '".$req_date."'
                                GROUP BY erplytrans_date)d1 
                                LEFT JOIN (select ROUND((d_monthly_plan_mark)/".$current_day_no.",2) as sum_pm,i_month,i_year from ".$this->kpi_tbl." where i_kpi_id = '1' and i_store_id IN (".$stores.") and (i_month = '".$current_month."' and i_year = '".$current_year."') 
                                union 
                                select ROUND((d_monthly_plan_mark)/".$prev_day_no.",2) as sum_pm,i_month,i_year 
                                from ".$this->kpi_tbl." where i_kpi_id = '1' and i_store_id IN (".$stores.") and (i_month = '".$prev_month."' and i_year = '".$prev_year."') ) d2 on (d1.months = d2.i_month and d1.years = d2.i_year) 
                                order by d1.erplytrans_date asc) d 
                                LEFT JOIN zeevant_config_details d4 on DATE_FORMAT(erplytrans_date,'%w')+1=d4.i_cw_id and d.store_id = d4.i_store_id 
                                group by erplytrans_date asc";  */
                                
                                $sql_target =" CALL zev_ds_cumulative_revenue_baseplave_vs_revised('".$stores."','".$req_date."')";
                                
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                                # IIA: preparing SQL...fetching planned KPI val of selected store...
                                
                               
                                 /*$sql_target ="SELECT d.erplytrans_date,d.sum_sales as actual,ROUND((d.tar*d4.d_mark)*7/100,2) as target,'0' as target,  DATE_FORMAT(erplytrans_date,'%w')+1 as dw
                                FROM (SELECT d1.erplytrans_date,d2.sum_pm as tar,d1.store_id, d1.sum_sales 
                                FROM (SELECT erplytrans_date, DATE_FORMAT(erplytrans_date,'%m') as months, DATE_FORMAT(erplytrans_date,'%Y') as years,sum(a.gross_sales) as sum_sales,b.i_id as store_id 
                                FROM ".$this->master_tbl." a
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number and a.company_id <>''
                                where b.i_id ='".$store_id."' and erplytrans_date between '".$previ_date."' and '".$req_date."'
                                GROUP BY erplytrans_date)d1 
                                LEFT JOIN (select ROUND((d_monthly_plan_mark)/".$current_day_no.",2) as sum_pm,i_month,i_year from ".$this->kpi_tbl." where i_kpi_id = '1' and i_store_id ='".$store_id."' and (i_month = '".$current_month."' and i_year = '".$current_year."') 
                                union 
                                select ROUND((d_monthly_plan_mark)/".$prev_day_no.",2) as sum_pm,i_month,i_year 
                                from ".$this->kpi_tbl." where i_kpi_id = '1' and i_store_id ='".$store_id."' and (i_month = '".$prev_month."' and i_year = '".$prev_year."') ) d2 on (d1.months = d2.i_month and d1.years = d2.i_year) 
                                order by d1.erplytrans_date asc) d 
                                LEFT JOIN zeevant_config_details d4 on DATE_FORMAT(erplytrans_date,'%w')+1=d4.i_cw_id and d.store_id = d4.i_store_id 
                                group by erplytrans_date asc";*/
                                
                                 $sql_target =" CALL zev_ds_cumulative_revenue_baseplave_vs_revised('".$store_id."','".$req_date."')"; 
                                
                                
                               
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_target));  
               
               
               unset($sql_target);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart 4
        public function getCumSnapshotDetailsData($all_store_id,$store_id, $dt_time_arr) {

            try
            {
               
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                
                $previous_year_year = date('Y', strtotime('-1 year', strtotime($req_date)));
                $previous_year_month = date('m', strtotime('-1 year', strtotime($req_date)));
                
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                 $all_stores = implode(',', $all_store_id);
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);
                    

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                $sql_snapshot =" CALL zev_ds_margin_snapshot('".$stores."','".$req_date."')"; 
                               
                               
                                                             

                } else {    // i.e. for a particular-store

                                # IIA: preparing SQL...fetching planned KPI val of selected store...
                                                               
                                $sql_snapshot =" CALL zev_ds_margin_snapshot('".$store_id."','".$req_date."')"; 
                                
                                
                }
                
                $ret_ = DB::select(DB::raw($sql_snapshot));                
                
                
                
                /*$return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2);*/

                unset($ret_snapshot);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // tabular data
        public function getCumulativeTableData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year                               
                                
                                
                                $sql_target =" CALL zev_ds_cumulative_revenue_table('".$stores."','".$req_date."')";
                                //echo $sql_target;
                                
                               
                                                             

                } else {    // i.e. for a particular-store

                               
                               $sql_target =" CALL zev_ds_cumulative_revenue_table('".$store_id."','".$req_date."')";
                               //echo $sql_target; 
                                
                               
                                
                }
                
                
                $ret_ = DB::select(DB::raw($sql_target));  
              
               
               unset($sql_target);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
        
        // top info
        public function getCumRevTableData($store_id, $dt_time_arr) {

            try
            {
               
                $prev_date = $dt_time_arr['prev_date'];
                $prev_month = $dt_time_arr['prev_month'];
                $prev_year  = $dt_time_arr['prev_year'];
                
                $current_date = $dt_time_arr['current_date'];
                $current_month = $dt_time_arr['current_month'];
                $current_year  = $dt_time_arr['current_year'];
                
                $req_date = $current_year.'-'.$current_month.'-'.$current_date;
                $previ_date = $prev_year.'-'.$prev_month.'-'.$prev_date;
                
                $yesterday = date('Y-m-d', strtotime('-1 day', strtotime($req_date)));
                //$yesterday = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-d'))));
                
                $today_month = date('m');
                $today_year = date('Y');
                
                //$current_day_no = cal_days_in_month(CAL_GREGORIAN, intval($current_month), intval($current_year));
                //$prev_day_no = cal_days_in_month(CAL_GREGORIAN, (int)$prev_month, intval($prev_year));
                       
                
                 $current_day_no =  date('t', mktime(0, 0, 0, $current_month, 1, $current_year));
                 $prev_day_no = date('t', mktime(0, 0, 0, $prev_month, 1, $prev_year));
                 $today_day_no = date('t', mktime(0, 0, 0, date('m'), 1, date('Y')));
                 
                 $prev_date = intval($prev_day_no - $prev_date);
                
                 if( is_array($store_id) ) {   // i.e. for all available store(s)

                    # IA: preparing for MySQL IN clause...
                    $stores = implode(',', $store_id);

                    # IB: preparing SQL...fetching average of Concerned/All store(s)
                                // For Current Year
                                $sql_yesterday ="SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date = '".$yesterday."' 
                                group BY a.erplytrans_date  "; 
                                
                                $sql_achievement ="SELECT erplytrans_date,(@s := @s + sum_sales) as cumulative_current FROM 
                                (SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN (".$stores.") AND erplytrans_date BETWEEN '".$previ_date."'  AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";
                                
                                $sql_target ="select ROUND(sum(get_company_target_day_revenue('".$stores."',erplytrans_date))) as tr from  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id IN ('".$stores."') and a.erplytrans_date between DATE_SUB('".$req_date."', INTERVAL 1 MONTH) AND '".$req_date."'
                                and  a.company_id IS NOT NULL";
                               
                                 
                                $sql_planned ="select ROUND((d_monthly_plan_mark/".$today_day_no."),2) as planned_val from ".$this->kpi_tbl." where i_kpi_id = '1'
                                and i_store_id IN (".$stores.") 
                                and (i_month = '".$current_month."' and i_year = '".$current_year."')";
                               
                                                             

                } else {    // i.e. for a particular-store

                                # IIA: preparing SQL...fetching planned KPI val of selected store...
                                $sql_yesterday ="SELECT erplytrans_date, ROUND(SUM(a.gross_sales),2) as sum_sales FROM ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id ='".$store_id."' AND erplytrans_date = '".$yesterday."' 
                                group BY a.erplytrans_date  "; 
                               
                                $sql_achievement ="SELECT erplytrans_date,ROUND((@s := @s + sum_sales),2) as cumulative_current FROM 
                                (SELECT erplytrans_date, SUM(a.gross_sales) as sum_sales FROM zeevant_erply_daysales a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id ='".$store_id."' AND erplytrans_date BETWEEN '".$previ_date."'  AND '".$req_date."'
                                group BY erplytrans_date ) As T, 
                                (SELECT @s := 0) dm";
                                
                                $sql_target ="select ROUND(sum(get_company_target_day_revenue('".$store_id."',erplytrans_date))) as tr from  ".$this->master_tbl." a 
                                JOIN ".$this->franchisee_tbl." b on a.erply_account_number = b.s_account_number
                                where b.i_id = '".$store_id."' and a.erplytrans_date between DATE_SUB('".$req_date."', INTERVAL 1 MONTH) AND '".$req_date."'
                                and  a.company_id IS NOT NULL";
                                
                                $sql_planned ="select ROUND((d_monthly_plan_mark/".$current_day_no."),2) as planned_val from ".$this->kpi_tbl." where i_kpi_id = '1'
                                and i_store_id ='".$store_id."'
                                and (i_month = '".$current_month."' and i_year = '".$current_year."')";;
                                
                                
                }
                
                $ret_yesterday = DB::select(DB::raw($sql_yesterday));
                $ret_achievement = DB::select(DB::raw($sql_achievement));
                $ret_target = DB::select(DB::raw($sql_target));  
                $ret_planned = DB::select(DB::raw($sql_planned));
                
                if(!empty($ret_yesterday)){
                $ret_yesterday = $ret_yesterday[0]->sum_sales;
                }
                else{
                $ret_yesterday = 0;    
                }
                
                if(!empty($ret_achievement)){
                $ret_achievement = array_reverse($ret_achievement);    
                $ret_achievement = $ret_achievement[0]->cumulative_current/2;
                }
                else{
                $ret_achievement = 0;    
                }
                
                if(!empty($ret_target)){
                $ret_target = $ret_target[0]->tr;
                }
                else{
                $ret_target = 0;    
                }
                
                if(!empty($ret_planned)){
                $ret_planned = $ret_planned[0]->planned_val;
                }
                else{
                $ret_planned = 0;    
                }
                
                $ret_goal =  $ret_target - $ret_achievement;  
               
                
                
               $ret_ = array('ret_yesterday'=>$ret_yesterday,'ret_achievement'=>$ret_achievement,'ret_target'=>$ret_target,'ret_goal'=>$ret_goal,'ret_planned'=>$ret_planned);
               
               
                /*$return_val = 0;
                if( !empty($ret_) )
                    $return_val = number_format($ret_[0]->net_income, 2);*/

                unset($sql_yesterday,$sql_achievement);

                # dd($ret_);
                return $ret_;
            }
            catch(Exception $err_obj)
            {
                show_error($err_obj->getMessage());
            }

        }
    # =======================================================================
    #           Chart Related Calculation(s) - End
    # =======================================================================

}
