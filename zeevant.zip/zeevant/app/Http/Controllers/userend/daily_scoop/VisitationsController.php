<?php

namespace App\Http\Controllers\userend\daily_scoop;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class VisitationsController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Daily Scoop - Visitations ::';

        # for menu selection...
        $this->data['selected_menu'] = 'daily-scoop';
        $this->data['selected_sub_menu'] = 'visitations';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        # show view part...
        return view('userend.daily_scoop.visitations', $data);
    }

}
