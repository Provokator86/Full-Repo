<?php

namespace App\Http\Controllers\userend\daily_scoop;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\CumulativeModel as model_Curv;


class Top10SellersController extends \App\Http\Controllers\userend\BaseController
{
        // constructor definition...
        public function __construct() {

            parent::__construct();

            $this->data['userend_site_title'] = ':: Daily Scoop - Top 10 Sellers ::';

            # for menu selection...
            $this->data['selected_menu'] = 'daily-scoop';
            $this->data['selected_sub_menu'] = 'top-10-sellers';
        }


        // index function definition...
        public function index() {


            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            # 1: getting concerned Franchisor-Admin ID...
            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                    ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                    : $LOGGED_USR_ID;



            # 2: loading chart-data...
                $ALL_DATA_ARR = $this->loadAllStoresChartData();


            # ===========================================================================
            #       For Bar-Chart - Begin
            # ===========================================================================

                $BAR_ALL_DATA_ARR = $this->prepareGChartArray($ALL_DATA_ARR);
                $this->data['all_BAR_data_arr'] = json_encode($BAR_ALL_DATA_ARR);

            # ===========================================================================
            #       For Bar-Chart - Begin
            # ===========================================================================
            
            
            # ***************************************************************************
            #       For Data-Table - Begin
            # ***************************************************************************
            
                $this->data['data_tbl_arr'] = $ALL_DATA_ARR;
            
            # ***************************************************************************
            #       For Data-Table - End
            # ***************************************************************************
            

            # Default Load "Month-Scroller"...
            $this->data['default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));

            $this->data['prev_month_scroller_dt'] = date('d M y', strtotime("-30 days"));
            $this->data['next_month_scroller_dt'] = date('d M y');


            # show view part...
            return view('userend.daily_scoop.top-10-sellers', $this->data);
        }

                
        // AJAX Call - load Chart & Table data based on selected store(s), month & year ETC...
        public function loadTopSellersDataAJAX(Request $request) {

            try {
                
                # 1: loading chart-data...
                $TOP_SELLLERS_DATA_ARR = $this->loadTopSelllersChartDataAJAX($request);
                # utils::dump($TOP_SELLLERS_DATA_ARR);

                # NEW - for Main & Sub Heading(s) based on selected mode...
                $this->data['mode'] = $request->input('mode');
                $lbl_heading = ( $this->data['mode']==1 )? "All Store(s)": "My Store";

                # ===========================================================================
                #       For Bar-Chart - Begin
                # ===========================================================================

                    $BAR_ALL_DATA_ARR = $this->prepareGChartArray($TOP_SELLLERS_DATA_ARR, $this->data['mode']);
                    $this->data['all_BAR_data_arr'] = json_encode($BAR_ALL_DATA_ARR);

                # ===========================================================================
                #       For Bar-Chart - Begin
                # ===========================================================================
                
                
                # ***************************************************************************
                #       For Data-Table - Begin
                # ***************************************************************************
                
                    $this->data['data_tbl_arr'] = $TOP_SELLLERS_DATA_ARR;
                    #utils::dump($this->data['data_tbl_arr']);
                
                # ***************************************************************************
                #       For Data-Table - End
                # ***************************************************************************
                
                # I: load Chart(s) view part...
                $GRAPH_HTML = $TBL_HTML = null;
                $GRAPH_HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-top-10-sellers-graph-data-AJAX', $this->data)->render();

                # II: load Data-Table view part...
                $TBL_HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-top-10-sellers-tbl-data-AJAX', $this->data)->render();
                
                
                
                echo json_encode(array('result' => 'success',
                                       'chart_html_content' => $GRAPH_HTML,
                                       'tbl_html_content' => $TBL_HTML,
                                       'lbl' => $lbl_heading));
                exit;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
                


    # =============================================================
    #           Generate Chart(s) - Begin
    # =============================================================

        # I: INITIAL LOAD
            //// Top 10 Sellers Revenue - All Stores...
            public function loadAllStoresChartData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                           ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                           : $LOGGED_USR_ID;


                    # retrieving submitted value(s)...
                    // Date-Time related data...
                        $dt_time_arr = array();

                        $prev_dt = date('d M y', strtotime("-30 days"));

                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');


                    // for Store-ID(s)
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresDataArray($store_ids, $dt_time_arr);




                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            


            //// Top 10 Sellers Data [AJAX Call]...
            public function loadTopSelllersChartDataAJAX(Request $request) {

                try {

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');
                    
                                           
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # retrieving submitted value(s)...
                            // Date-Time related data...
                            $dt_time_arr = array();
                            $dt_time_arr['current_date'] = $request->input('date_val');
                            $dt_time_arr['current_month'] = $request->input('month_val');
                            $dt_time_arr['current_year'] = $request->input('yr_val');
                            # utils::dump($dt_time_arr);
                            
                            // for Store-ID(s)
                            $store_ids = $request->input('store_id');
                            if( $store_ids==-1 )
                                $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                            
                            # utils::dump($store_ids);
                              
                            // for mode - "All" OR "My Store"...
                            $mode = $request->input('mode');
                            

                        # calling stored-routine (or any)...
                            $arr = $this->formStoresDataArray($store_ids, $dt_time_arr, $mode);



                    return $arr;

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }



            
    # =============================================================
    #           Generate Chart(s) - End
    # =============================================================


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Running Related Queries - Begin
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to get STORES-DATA...
        public function formStoresDataArray($stores_arr=null, $dt_time_arr=null, $mode=1) {

            try {
                $return_arr = array();

                # I: param1 - store-ids...
                $IN_STORE = ( is_array($stores_arr) )? implode(',', $stores_arr): $stores_arr;

                # II: param2 - To-Date...
                $to_date = $dt_time_arr['current_date'];
                $to_month = $dt_time_arr['current_month'];
                $to_year  = $dt_time_arr['current_year'];
                $TO_DT = date('Y-m-d', mktime(0, 0, 0, $to_month, $to_date, $to_year));

                $model_Curv = new model_Curv();
                $return_data = $model_Curv->getTopSellersData($IN_STORE, $TO_DT, $mode);

                $return_arr = $this->prepareDBReturnArray($return_data, $mode);
                # utils::dump($return_arr);

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Running Related Queries - End
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



    # function to prepare return-array format form db-results...
    public function prepareDBReturnArray($db_result_obj=null, $mode=1) {

        try {

            $RETURN_ARR = null;
            if( !empty($db_result_obj) ) {
                $LOOP_INDEX  = 0;

                # utils::dump($db_result_obj);
                foreach($db_result_obj as $row_obj) {
                	
                	$PRODUCT_NAME = $row_obj->product_name;
                	$PRODUCT_NAME .= ( !empty($row_obj->product_code) )? $row_obj->product_code: '';
                	
                    $RETURN_ARR[$LOOP_INDEX]['product_name'] = $PRODUCT_NAME;
                    
                    $RETURN_ARR[$LOOP_INDEX]['top_sellers_amount'] = ( $mode==1 )
                                                                     ? $row_obj->top_sellers_amount
                                                                     : $row_obj->top_seller;
                    $RETURN_ARR[$LOOP_INDEX]['top_seller_percentage'] = $row_obj->top_seller_percentage;
                    
                    $RETURN_ARR[$LOOP_INDEX]['my_store_product'] = ( $mode==1 )
                                                                   ? $row_obj->my_store_product
                                                                   : $row_obj->my_store;
                    $RETURN_ARR[$LOOP_INDEX]['my_store_percentage'] = $row_obj->my_store_percentage;

                    $LOOP_INDEX++;
                }

            }   // end - if

            # dump($RETURN_ARR);

            return $RETURN_ARR;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }


    # prepare chart for Google-Graph...
    public function prepareGChartArray($arr=null, $mode=1) {

        try {
            $return_arr = null;
            $LOGGED_USR_TYPE = \Session::get('user_type');

            if( !empty($arr) ) {

                    //// For Chart-Readable Array [Begin]
					if( $mode==1 )
                    	$return_arr = [['Products', 'Top Seller(s)', 'My Store']]; // for Header Array...
					else
                    	$return_arr = [['Products', 'My Store', 'Top Seller(s)']]; // for Header Array...

                    $sub_arr = array();

                    $loop_counter = 1;
                    foreach($arr as $sorted_arr) {

                        $sub_arr[]   = array(
                            0 => $sorted_arr['product_name'],
                            1 => ( ($mode==1)? floatval($sorted_arr['top_sellers_amount']): floatval($sorted_arr['my_store_product']) ),
                            2 => ( ($mode==1)? floatval($sorted_arr['my_store_product']): floatval($sorted_arr['top_sellers_amount']) )
                        );

                        $loop_counter++;
                    }   // end - foreach

                    $return_arr = array_merge($return_arr, $sub_arr);
                //// For "Normally-Distributed" Chart(s) [End]

            }  else {

                    //// For Chart-Readable Array [Begin]
					if( $mode==1 )
                    	$return_arr = [['Products', 'Top Seller(s)', 'My Store']]; // for Header Array...
					else
                    	$return_arr = [['Products', 'My Store', 'Top Seller(s)']]; // for Header Array...
						
                    $return_arr[] = array(
                        0 => 'Product(s)',
                        1 => 0.00,
                        2 => 0.00
                    );
                    
            }  // end - if


            return $return_arr;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }



}
