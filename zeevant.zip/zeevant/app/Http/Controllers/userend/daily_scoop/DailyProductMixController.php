<?php

namespace App\Http\Controllers\userend\daily_scoop;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\DailyProductMixModel as model_Curv;


class DailyProductMixController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Daily Scoop - Product Mix ::';

        # for menu selection...
        $this->data['selected_menu'] = 'daily-scoop';
        $this->data['selected_sub_menu'] = 'mix-and-shelf-space-optimizer';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        #$data = $this->data;

        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        # 1: getting concerned Franchisor-Admin ID...
        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                : $LOGGED_USR_ID;

        # 2: total no. of Store(s) available...
        $this->data['total_no_of_shops'] = usr_Helper::getAllStoreCount($FRANCHISOR_ADMIN_ID);

        # Load Categories
        $model_Curv = new model_Curv();
        $this->data['all_categories_arr'] = $model_Curv->category_group();

        # Chart Data
        $ALL_REVENUE_DATA_ARR = $this->loadRevenueData();   
        $ALL_SYSTEM_REVENUE_DATA_ARR = $this->loadSystemRevenueData(); 
              
          
        $ALL_CONTRIBUTION_DATA_ARR = $this->loadContributionData();   
        $ALL_SYSTEM_CONTRIBUTION_DATA_ARR = $this->loadSystemContributionData();  
        
        
        $ALL_SHELF_DATA_ARR = $this->loadShelfData();      
        $ALL_SYSTEM_SHELF_DATA_ARR = $this->loadSystemShelfData(); 
        
        
        $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableData();
        
        # ===========================================================================
        #       For Pie Graph(s) - Begin
        # ===========================================================================

            
        $PM_ALL_REVENUE_DATA_ARR = $this->prepareGChartRevenueArray($ALL_REVENUE_DATA_ARR);
        $this->data['all_PM_revenue_data_arr'] = json_encode($PM_ALL_REVENUE_DATA_ARR['data']);
        $this->data['all_PM_revenue_color_arr'] = json_encode($PM_ALL_REVENUE_DATA_ARR['color']);
        
        $PM_ALL_SYSTEM_REVENUE_DATA_ARR = $this->prepareGChartSystemRevenueArray($ALL_SYSTEM_REVENUE_DATA_ARR);
        $this->data['all_PM_system_revenue_data_arr'] = json_encode($PM_ALL_SYSTEM_REVENUE_DATA_ARR['data']);
        $this->data['all_PM_system_revenue_color_arr'] = json_encode($PM_ALL_SYSTEM_REVENUE_DATA_ARR['color']); 
        
        $PM_ALL_CONTRIBUTION_DATA_ARR = $this->prepareGChartContributionArray($ALL_CONTRIBUTION_DATA_ARR);
        $this->data['all_PM_contribution_data_arr'] = json_encode($PM_ALL_CONTRIBUTION_DATA_ARR['data']);
        $this->data['all_PM_contribution_color_arr'] = json_encode($PM_ALL_CONTRIBUTION_DATA_ARR['color']);
        
        $PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR = $this->prepareGChartSystemContributionArray($ALL_SYSTEM_CONTRIBUTION_DATA_ARR);
        $this->data['all_PM_system_contribution_data_arr'] = json_encode($PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR['data']);
        $this->data['all_PM_system_contribution_color_arr'] = json_encode($PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR['color']);
           
        $PM_ALL_SHELF_DATA_ARR = $this->prepareGChartShelfArray($ALL_SHELF_DATA_ARR);
        $this->data['all_PM_shelf_data_arr'] = json_encode($PM_ALL_SHELF_DATA_ARR['data']);
        $this->data['all_PM_shelf_color_arr'] = json_encode($PM_ALL_SHELF_DATA_ARR['color']);
         
        $PM_ALL_SYSTEM_SHELF_DATA_ARR = $this->prepareGChartSystemShelfArray($ALL_SYSTEM_SHELF_DATA_ARR);
        $this->data['all_PM_system_shelf_data_arr'] = json_encode($PM_ALL_SYSTEM_SHELF_DATA_ARR['data']);
        $this->data['all_PM_system_shelf_color_arr'] = json_encode($PM_ALL_SYSTEM_SHELF_DATA_ARR['color']);
         
         
         $this->data['all_PM_table_data_arr'] = $ALL_TABLE_ARR;

        # ===========================================================================
        #      For Pie Graph(s) -  End
        # ===========================================================================


        # Default Load "Month-Scroller"...
        $this->data['default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));
        #utils::dump($data);
        
        $this->data['prev_month_scroller_dt'] = date('d M y', strtotime("-30 days"));
        $this->data['next_month_scroller_dt'] = date('d M y');        
        
        
        # show view part...
        return view('userend.daily_scoop.product-mix', $this->data);
    }


    // AJAX Call - load Chart data based on selected store(s), month & year...
    public function loadProductmixDataAJAX(Request $request) {

        try {

            # Load Categories
            $model_Curv = new model_Curv();
            $this->data['all_categories_arr'] = $model_Curv->category_group();
            
            # 1: loading chart-data...
            $ALL_REVENUE_DATA_ARR = $this->loadRevenueDataAJAX($request);
            $ALL_SYSTEM_REVENUE_DATA_ARR = $this->loadSystemRevenueDataAJAX($request);     
            
            $ALL_CONTRIBUTION_DATA_ARR = $this->loadContributionDataAJAX($request);
            $ALL_SYSTEM_CONTRIBUTION_DATA_ARR = $this->loadSystemContributionDataAJAX($request);
            
            $ALL_SHELF_DATA_ARR = $this->loadShelfDataAJAX($request);
            $ALL_SYSTEM_SHELF_DATA_ARR = $this->loadSystemShelfDataAJAX($request);          
            
            $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableDataAJAX($request);

            # ===========================================================================
            #       For Column Graph(s) - Begin
            # ===========================================================================

            //$chart_type = 'ND';
            
            $PM_ALL_REVENUE_DATA_ARR = $this->prepareGChartRevenueArray($ALL_REVENUE_DATA_ARR);            
            //$this->data['all_PM_revenue_data_arr'] = json_encode($PM_ALL_REVENUE_DATA_ARR);
            $this->data['all_PM_revenue_data_arr'] = json_encode($PM_ALL_REVENUE_DATA_ARR['data']);
            $this->data['all_PM_revenue_color_arr'] = json_encode($PM_ALL_REVENUE_DATA_ARR['color']);

            $PM_ALL_SYSTEM_REVENUE_DATA_ARR = $this->prepareGChartSystemRevenueArray($ALL_SYSTEM_REVENUE_DATA_ARR);
            $this->data['all_PM_system_revenue_data_arr'] = json_encode($PM_ALL_SYSTEM_REVENUE_DATA_ARR['data']);
            $this->data['all_PM_system_revenue_color_arr'] = json_encode($PM_ALL_SYSTEM_REVENUE_DATA_ARR['color']); 
            
            $PM_ALL_CONTRIBUTION_DATA_ARR = $this->prepareGChartContributionArray($ALL_CONTRIBUTION_DATA_ARR);
            $this->data['all_PM_contribution_data_arr'] = json_encode($PM_ALL_CONTRIBUTION_DATA_ARR['data']);
            $this->data['all_PM_contribution_color_arr'] = json_encode($PM_ALL_CONTRIBUTION_DATA_ARR['color']);

            $PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR = $this->prepareGChartSystemContributionArray($ALL_SYSTEM_CONTRIBUTION_DATA_ARR);
            $this->data['all_PM_system_contribution_data_arr'] = json_encode($PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR['data']);
            $this->data['all_PM_system_contribution_color_arr'] = json_encode($PM_ALL_SYSTEM_CONTRIBUTION_DATA_ARR['color']); 
            
            $PM_ALL_SHELF_DATA_ARR = $this->prepareGChartShelfArray($ALL_SHELF_DATA_ARR);
            $this->data['all_PM_shelf_data_arr'] = json_encode($PM_ALL_SHELF_DATA_ARR['data']);
            $this->data['all_PM_shelf_color_arr'] = json_encode($PM_ALL_SHELF_DATA_ARR['color']);

            $PM_ALL_SYSTEM_SHELF_DATA_ARR = $this->prepareGChartSystemShelfArray($ALL_SYSTEM_SHELF_DATA_ARR);
            $this->data['all_PM_system_shelf_data_arr'] = json_encode($PM_ALL_SYSTEM_SHELF_DATA_ARR['data']);
            $this->data['all_PM_system_shelf_color_arr'] = json_encode($PM_ALL_SYSTEM_SHELF_DATA_ARR['color']);
            
            $this->data['all_PM_table_data_arr'] = $ALL_TABLE_ARR;            
                

            # ===========================================================================
            #       For Column Graph(s) - End
            # ===========================================================================
                 
        
            # load view part...
            $HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-product-mix-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

    

        # I: INITIAL LOAD
            ###1
            public function loadRevenueData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';
                       
                    

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        $arr = $this->formRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###2
            public function loadSystemRevenueData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';
                        

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formSystemRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###3            
            public function loadContributionData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';
                    

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        $arr = $this->formContributionDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###4
            public function loadSystemContributionData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);                        
                        
                        $arr = $this->formSystemContributionDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            
            ###5
            public function loadShelfData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';
                    

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        $arr = $this->formShelfDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###6
            public function loadSystemShelfData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);                        
                        
                        $arr = $this->formSystemShelfDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            public function loadAllStoresCumulativeTableData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['default_option_value'] = '';
                        $dt_time_arr['default_type_value'] = '0';

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);

                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
        # II: AJAX LOAD
            ###1
            public function loadRevenueDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

            ###2
            public function loadSystemRevenueDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    
                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formSystemRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }          
            
            ###3
            public function loadContributionDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    
                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formContributionDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###4
            public function loadSystemContributionDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    
                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formSystemContributionDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            
            ###5
            public function loadShelfDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    
                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formShelfDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            ###6
            public function loadSystemShelfDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                    $dt_time_arr['default_type_value'] = $request->input('default_type_value');
                    
                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formSystemShelfDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
    
            public function loadAllStoresCumulativeTableDataAjax(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                        $dt_time_arr['prev_month'] = $request->input('prev_month');
                        $dt_time_arr['prev_year'] = $request->input('prev_yr');

                        $dt_time_arr['current_date'] = $request->input('current_date');                    
                        $dt_time_arr['current_month'] = $request->input('current_month');
                        $dt_time_arr['current_year'] = $request->input('current_yr');

                        $dt_time_arr['default_option_value'] = $request->input('default_option_value');
                        $dt_time_arr['default_type_value'] = $request->input('default_type_value');

                        $store_ids = $request->input('store_id');
                        if( $store_ids==-1 )
                            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        # III: GET DATA


            ###1
            public function formRevenueDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();
                    $ret_previous_arr = array();               
                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getRevenueData($selected_stores_arr, $dt_time_arr);
                    
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_sales'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        
            ###2 
            public function formSystemRevenueDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();

                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getSystemRevenueData($selected_stores_arr, $dt_time_arr);
                   
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_sales'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;               

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        
            ##3
            public function formContributionDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();
                    $ret_previous_arr = array();               
                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getContributionData($selected_stores_arr, $dt_time_arr);
                    
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_contribution'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        
            ###4 
            public function formSystemContributionDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();

                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getSystemContributionData($selected_stores_arr, $dt_time_arr);
                   
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_contribution'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;               

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        
            ###5
            public function formShelfDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();
                    $ret_previous_arr = array();               
                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getShelfData($selected_stores_arr, $dt_time_arr);
                    
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_contribution'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
        
            ###6 
            public function formSystemShelfDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

                try {
                    $return_arr = array();

                    
                    $model_Curv = new model_Curv();
                    $return_arr = $model_Curv->getSystemShelfData($selected_stores_arr, $dt_time_arr);
                   
                    if(empty($return_arr)){
                        $return_arr[] = (object)array('product_group'=>null,'total_contribution'=>0,'color_code'=>'');
                    }
                    
                    return $return_arr;               

                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
           public function formStoresCumulativeDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumulativeTableData($selected_stores_arr, $dt_time_arr);
                //print_r($RETURN_ARR);
               
                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        # IV: PREPARE CHART DATA

            ###1
            public function prepareGChartRevenueArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                
              
                if( !empty($arr) ) {               
                    
                        //// For "Pie" Chart(s) [Begin]
                        $return_arr['data'] = [['Product Group', 'Total Revenue']]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_sales = is_null($sorted_arr->total_sales)?null:floatval($sorted_arr->total_sales);
                            $color_code = is_null($sorted_arr->color_code)?'':$sorted_arr->color_code;

                            $return_arr['data'][] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_sales,                                                   
                                                 );
                            $return_arr['color'][] = $color_code;
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
               //print_r($return_arr); 

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

            ###2
            public function prepareGChartSystemRevenueArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                //print_r($arr);
                //var_ump($arr);
                if( !empty($arr) ) {
                    
                    
                        //// For "Pie" Chart(s) [Begin]
                        $return_arr['data'] = [['Product Group', 'Total Revenue (System)']]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_sales = is_null($sorted_arr->total_sales)?null:floatval($sorted_arr->total_sales);
                            $color_code = is_null($sorted_arr->color_code)?'':$sorted_arr->color_code;

                            $return_arr['data'][] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_sales,                                                   
                                                 );
                                                 
                            $return_arr['color'][] = $color_code;
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }       
        
            ###3
            public function prepareGChartContributionArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
              
                if( !empty($arr) ) {               
                    
                        //// For "Pie" Chart(s) [Begin]
                        $return_arr['data'] = [['Product Group', 'Total Contribution']]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_contribution = is_null($sorted_arr->total_contribution)?null:floatval($sorted_arr->total_contribution);
                            $color_code = is_null($sorted_arr->color_code)?'':$sorted_arr->color_code;

                            $return_arr['data'][] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_contribution,                                                   
                                                 );
                            $return_arr['color'][] = $color_code;
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

            ###4
            public function prepareGChartSystemContributionArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                //print_r($arr);
                //var_ump($arr);
                if( !empty($arr) ) {
                    
                    
                        //// For "Pie" Chart(s) [Begin]
                        $return_arr['data'] = [['Product Group', 'Total Contribution (System)']]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_contribution = is_null($sorted_arr->total_contribution)?null:floatval($sorted_arr->total_contribution);
                            $color_code = is_null($sorted_arr->color_code)?'':$sorted_arr->color_code;

                            $return_arr['data'][] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_contribution,                                                   
                                                 );
                            $return_arr['color'][] = $color_code;
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        
            ###5
            public function prepareGChartShelfArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                $new_array = array();
              
              //print_r($arr);
              
                if( !empty($arr) ) {   
                
                        foreach($arr as $ind=>$val){
                        $new_array[$val->product_group] = $val->total_contribution;
                        $return_arr['color'][] = $val->color_code;
                        }
                        

                      
                        if( !empty($new_array) ) {   
                            //// For "Pie" Chart(s) [Begin]
                            //$return_arr = [['Product Group', 'Total Contribution']]; // for Header Array...
                            //$data_cr= array( array('Days', 'Current', 'Previous', 'All'));
                            
                            $new_arr = array_keys($new_array); // for Header Array...
                            array_unshift($new_arr, "Value");//adding the first one default
                            $return_arr['data'][] = $new_arr;
                           
                            $values = array_values($new_array);
                            array_unshift($values, "My Store");//adding the first one default
                            
                            /*array_walk($values,function($val,$key){
                                return is_null($val)?'a':$val;                                
                            });*/
                            
                            $values = array_map(function($val){
                                return is_null($val)?0:(!is_numeric($val)?$val:floatval($val));                                
                            }, $values);
                            
                            
                            
                            $return_arr['data'][] = $values;

                            /*foreach($new_array as $ind=>$val) {
                               
                                $TOOLTIP = $ind;

                                $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => floatval($val)
                                                 );
                            }*/ // end - foreach
                            //// For "Pie" Chart(s) [End]
                        }// end - if
                        
                        /*if(array_key_exists('color',$return_arr)){
                        array_unshift($return_arr['color'],'');//adding the first one default
                        }*/
          
                }   // end - if                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

            ###6
            public function prepareGChartSystemShelfArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
                $new_array = array();
              
               
              
                if( !empty($arr) ) {   
                
                        foreach($arr as $ind=>$val){
                        $new_array[$val->product_group] = $val->total_contribution;
                        $return_arr['color'][] = $val->color_code;
                        }
                        

                      
                        if( !empty($new_array) ) {   
                            //// For "Pie" Chart(s) [Begin]
                            //$return_arr = [['Product Group', 'Total Contribution']]; // for Header Array...
                            //$data_cr= array( array('Days', 'Current', 'Previous', 'All'));
                            //$return_arr = array(array_keys($new_array)); // for Header Array...
                            
                            $new_arr = array_keys($new_array); // for Header Array...
                            array_unshift($new_arr, "Value");//adding the first one default
                            $return_arr['data'][] = $new_arr;
                           
                            $values = array_values($new_array);
                            array_unshift($values, "System"); //adding the first one default                           
                            
                            /*array_walk($values,function($val,$key){
                                return is_null($val)?'a':$val;                                
                            });*/
                            
                            $values = array_map(function($val){
                                return is_null($val)?0:(!is_numeric($val)?$val:floatval($val));                                
                            }, $values);
                            
                            
                            $return_arr['data'][] = $values;
                            

                            /*foreach($new_array as $ind=>$val) {
                               
                                $TOOLTIP = $ind;

                                $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => floatval($val)
                                                 );
                            }*/ // end - foreach
                            //// For "Pie" Chart(s) [End]
                        }// end - if
                        
                        /*if(array_key_exists('color',$return_arr)){
                        array_unshift($return_arr['color'],'');//adding the first one default
                        }*/
          
                }   // end - if                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
}
