<?php

namespace App\Http\Controllers\userend\benchmark;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\KPIModel as model_KPI;
use App\Models\IncomeStmtModel as model_IStmt;

class LaborEfficiencyController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Benchmark - Labor Efficiency ::';

        # for menu selection...
        $this->data['selected_menu'] = 'benchmark';
        $this->data['selected_sub_menu'] = 'labor-efficiency';
    }


    // index function definition...
    public function index() {

        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        # 1: getting concerned Franchisor-Admin ID...
            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                   : $LOGGED_USR_ID;

        # 2: total no. of Store(s) available...
            $this->data['total_no_of_shops'] = usr_Helper::getAllStoreCount($FRANCHISOR_ADMIN_ID);
        
            
        # 3: loading chart-data...
            $GLOBAL_ALL_DATA_ARR = $this->loadAllStoresChartData();
            $GLOBAL_TOP_10_DATA_ARR = $this->loadTopStoresChartData(10);
            $GLOBAL_TOP_5_DATA_ARR = $this->loadTopStoresChartData();
            $GLOBAL_TOP_10_REVENUE_DATA_ARR = $this->loadTopStoresRevenueChartData(10);
            $GLOBAL_TOP_5_REVENUE_DATA_ARR = $this->loadTopStoresRevenueChartData();
            
            
        # ===========================================================================
        #       For Normally-Distributed Graph(s) - Begin
        # ===========================================================================

            $chart_type = 'ND';
            
            // Array by chart-type...
            $ALL_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_ALL_DATA_ARR, $chart_type);
            $TOP_10_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_DATA_ARR, $chart_type);
            $TOP_5_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_DATA_ARR, $chart_type);
            $TOP_10_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_REVENUE_DATA_ARR, $chart_type);
            $TOP_5_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_REVENUE_DATA_ARR, $chart_type);

            // sort in ascending order...
            if( !empty($ALL_DATA_ARR) ) {
                usort($ALL_DATA_ARR, function($a, $b) {
                    return $a['revenue'] > $b['revenue'];
                });
            }
            if( !empty($TOP_10_DATA_ARR) ) {
                usort($TOP_10_DATA_ARR, function($a, $b) {
                    return $a['revenue'] > $b['revenue'];
                });
            }
            if( !empty($TOP_5_DATA_ARR) ) {
                usort($TOP_5_REVENUE_DATA_ARR, function($a, $b) {
                    return $a['revenue'] > $b['revenue'];
                });
            }
            if( !empty($TOP_10_REVENUE_DATA_ARR) ) {
                usort($TOP_10_REVENUE_DATA_ARR, function($a, $b) {
                    return $a['revenue'] > $b['revenue'];
                });
            }
            if( !empty($TOP_5_REVENUE_DATA_ARR) ) {
                usort($TOP_5_REVENUE_DATA_ARR, function($a, $b) {
                    return $a['revenue'] > $b['revenue'];
                });
            }
            
            $ND_ALL_DATA_ARR = $this->prepareGChartArray($ALL_DATA_ARR, $chart_type);
            $this->data['all_ND_data_arr'] = json_encode($ND_ALL_DATA_ARR);

            $ND_TOP_10_DATA_ARR = $this->prepareGChartArray($TOP_10_DATA_ARR, $chart_type, 10);
            $this->data['top_10_ND_data_arr'] = json_encode($ND_TOP_10_DATA_ARR);

            $ND_TOP_5_DATA_ARR = $this->prepareGChartArray($TOP_5_DATA_ARR, $chart_type, 5);
            $this->data['top_5_ND_data_arr'] = json_encode($ND_TOP_5_DATA_ARR);
            
            $ND_TOP_10_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_10_REVENUE_DATA_ARR, $chart_type, 10);
            $this->data['top_10_ND_revenue_data_arr'] = json_encode($ND_TOP_10_REVENUE_DATA_ARR);

            $ND_TOP_5_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_5_REVENUE_DATA_ARR, $chart_type, 5);
            $this->data['top_5_ND_revenue_data_arr'] = json_encode($ND_TOP_5_REVENUE_DATA_ARR);

        # ===========================================================================
        #       For Normally-Distributed Graph(s) - End
        # ===========================================================================



        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #       For Column Graph(s) - Begin
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            $chart_type = 'column';
            
            // Array by chart-type...
            $ALL_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_ALL_DATA_ARR, $chart_type);
            $TOP_10_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_DATA_ARR, $chart_type);
            $TOP_5_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_DATA_ARR, $chart_type);
            $TOP_10_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_REVENUE_DATA_ARR, $chart_type);
            $TOP_5_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_REVENUE_DATA_ARR, $chart_type);


            $COLUMN_ALL_DATA_ARR = $this->prepareGChartArray($ALL_DATA_ARR, $chart_type);
            $this->data['all_column_data_arr'] = json_encode($COLUMN_ALL_DATA_ARR);

            $COLUMN_TOP_10_DATA_ARR = $this->prepareGChartArray($TOP_10_DATA_ARR, $chart_type);
            $this->data['top_10_column_data_arr'] = json_encode($COLUMN_TOP_10_DATA_ARR);

            $COLUMN_TOP_5_DATA_ARR = $this->prepareGChartArray($TOP_5_DATA_ARR, $chart_type);
            $this->data['top_5_column_data_arr'] = json_encode($COLUMN_TOP_5_DATA_ARR);
            
            $COLUMN_TOP_10_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_10_REVENUE_DATA_ARR, $chart_type);
            $this->data['top_10_revenue_column_data_arr'] = json_encode($COLUMN_TOP_10_REVENUE_DATA_ARR);

            $COLUMN_TOP_5_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_5_REVENUE_DATA_ARR, $chart_type);
            $this->data['top_5_revenue_column_data_arr'] = json_encode($COLUMN_TOP_5_REVENUE_DATA_ARR);


        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #       For Column Graph(s) - End
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        # ***************************************************************************
        #           For "Last 12 month(s)" Revenue Analysis Graph [Begin]
        # ***************************************************************************

            $this->loadAnalyzedData();
            $this->prepareLineChartDBArray();

            $LAST_12_MONTHS_DATA_ARR = $this->prepareGLineChartArray();
            $this->data['last_12_months_data_arr'] = json_encode($LAST_12_MONTHS_DATA_ARR);

        # ***************************************************************************
        #           For "Last 12 month(s)" Revenue Analysis Graph [End]
        # ***************************************************************************
        
        # Default Load "Month-Scroller"...
        $this->data['default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));
            
        # show view part...
        $data = $this->data;
        return view('userend.benchmark.labor-efficiency', $data);
    }
    
    
    // AJAX Call - load Chart data based on selected store(s), month & year...
    public function loadLaborEfficiencyDataAJAX(Request $request) {

        try {

            # loading chart-data...
            $GLOBAL_ALL_DATA_ARR = $this->loadAllStoresChartDataAJAX($request);
            $GLOBAL_TOP_10_DATA_ARR = $this->loadTopStoresChartDataAJAX($request, 10);
            $GLOBAL_TOP_5_DATA_ARR = $this->loadTopStoresChartDataAJAX($request);
            $GLOBAL_TOP_10_REVENUE_DATA_ARR = $this->loadTopStoresRevenueChartDataAJAX($request, 10);
            $GLOBAL_TOP_5_REVENUE_DATA_ARR = $this->loadTopStoresRevenueChartDataAJAX($request);
            
            # ===========================================================================
            #       For Normally-Distributed Graph(s) - Begin
            # ===========================================================================

                $chart_type = 'ND';
                    
                // Array by chart-type...
                $ALL_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_ALL_DATA_ARR, $chart_type);
                $TOP_10_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_DATA_ARR, $chart_type);
                $TOP_5_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_DATA_ARR, $chart_type);
                $TOP_10_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_REVENUE_DATA_ARR, $chart_type);
                $TOP_5_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_REVENUE_DATA_ARR, $chart_type);

                // sort in ascending order...
                if( !empty($ALL_DATA_ARR) ) {
                    usort($ALL_DATA_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }
                if( !empty($TOP_10_DATA_ARR) ) {
                    usort($TOP_10_DATA_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }
                if( !empty($TOP_5_DATA_ARR) ) {
                    usort($TOP_5_DATA_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }
                if( !empty($TOP_10_REVENUE_DATA_ARR) ) {
                    usort($TOP_10_REVENUE_DATA_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }
                if( !empty($TOP_5_REVENUE_DATA_ARR) ) {
                    usort($TOP_5_REVENUE_DATA_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }
                # NEW - for planned value of the selected store [End]
                
                
                $ND_ALL_DATA_ARR = $this->prepareGChartArray($ALL_DATA_ARR, $chart_type);
                $this->data['all_ND_data_arr'] = json_encode($ND_ALL_DATA_ARR);

                $ND_TOP_10_DATA_ARR = $this->prepareGChartArray($TOP_10_DATA_ARR, $chart_type, 10);
                $this->data['top_10_ND_data_arr'] = json_encode($ND_TOP_10_DATA_ARR);

                $ND_TOP_5_DATA_ARR = $this->prepareGChartArray($TOP_5_DATA_ARR, $chart_type, 5);
                $this->data['top_5_ND_data_arr'] = json_encode($ND_TOP_5_DATA_ARR);
                
                $ND_TOP_10_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_10_REVENUE_DATA_ARR, $chart_type, 10);
                $this->data['top_10_ND_revenue_data_arr'] = json_encode($ND_TOP_10_REVENUE_DATA_ARR);

                $ND_TOP_5_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_5_REVENUE_DATA_ARR, $chart_type, 5);
                $this->data['top_5_ND_revenue_data_arr'] = json_encode($ND_TOP_5_REVENUE_DATA_ARR);
                

            # ===========================================================================
            #       For Normally-Distributed Graph(s) - End
            # ===========================================================================



            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #       For Column Graph(s) - Begin
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                $chart_type = 'column';
                    
                // Array by chart-type...
                $ALL_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_ALL_DATA_ARR, $chart_type);
                $TOP_10_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_DATA_ARR, $chart_type);
                $TOP_5_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_DATA_ARR, $chart_type);
                $TOP_10_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_10_REVENUE_DATA_ARR, $chart_type);
                $TOP_5_REVENUE_DATA_ARR = usr_Helper::getArrayByMode($GLOBAL_TOP_5_REVENUE_DATA_ARR, $chart_type);

                $COLUMN_ALL_DATA_ARR = $this->prepareGChartArray($ALL_DATA_ARR, $chart_type);
                $this->data['all_column_data_arr'] = json_encode($COLUMN_ALL_DATA_ARR);

                $COLUMN_TOP_10_DATA_ARR = $this->prepareGChartArray($TOP_10_DATA_ARR, $chart_type);
                $this->data['top_10_column_data_arr'] = json_encode($COLUMN_TOP_10_DATA_ARR);

                $COLUMN_TOP_5_DATA_ARR = $this->prepareGChartArray($TOP_5_DATA_ARR, $chart_type);
                $this->data['top_5_column_data_arr'] = json_encode($COLUMN_TOP_5_DATA_ARR);
                
                $COLUMN_TOP_10_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_10_REVENUE_DATA_ARR, $chart_type);
                $this->data['top_10_revenue_column_data_arr'] = json_encode($COLUMN_TOP_10_REVENUE_DATA_ARR);

                $COLUMN_TOP_5_REVENUE_DATA_ARR = $this->prepareGChartArray($TOP_5_REVENUE_DATA_ARR, $chart_type);
                $this->data['top_5_revenue_column_data_arr'] = json_encode($COLUMN_TOP_5_REVENUE_DATA_ARR);

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #       For Column Graph(s) - End
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            # ***************************************************************************
            #           For "Last 12 month(s)" Revenue Analysis Graph [Begin]
            # ***************************************************************************

                $this->loadAnalyzedDataAJAX($request);
                $this->prepareLineChartDBArray();

                $LAST_12_MONTHS_DATA_ARR = $this->prepareGLineChartArray();
                $this->data['last_12_months_data_arr'] = json_encode($LAST_12_MONTHS_DATA_ARR);

            # ***************************************************************************
            #           For "Last 12 month(s)" Revenue Analysis Graph [End]
            # ***************************************************************************

            # load Chart(s) view part...
            $HTML = \View::make('userend.benchmark.ajax-parts.load-BM-labor-efficiency-data-AJAX', $this->data)->render();


            echo json_encode(array('result'        => 'success',
                                   'chart_html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }
    
    
    
    
    # I: INITIAL LOAD
    //// 1st Chart: My Store VS All Store(s)...
    public function loadAllStoresChartData() {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                       ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                       : $LOGGED_USR_ID;

                # retrieving submitted value(s)...
                // Date-Time related data...
                $dt_time_arr = array();
                $dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                $dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));

                // for Store-ID(s)
                $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);


                return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
    
    //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s)...
    public function loadTopStoresChartData($top=5) {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                   : $LOGGED_USR_ID;

            # retrieving submitted value(s)...
            // Date-Time related data...
            $dt_time_arr = array();
            $dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
            $dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));

            // for Store-ID(s)
            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
            $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2);
            $arr = $this->formTopStoresDataArray($all_store_ids, $dt_time_arr, $store_ids, $top);

            return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
    //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s) For Revenue...
    public function loadTopStoresRevenueChartData($top=5) {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                   : $LOGGED_USR_ID;

            # retrieving submitted value(s)...
            // Date-Time related data...
            $dt_time_arr = array();
            $dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
            $dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));

            // for Store-ID(s)
            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
            $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2);
            $arr = $this->formTopStoresRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids, $top);

            return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
            
    //// 3rd Chart: Last 12 month(s) Analysis [AJAX Call]...
    public function loadAnalyzedDataAJAX(Request $request) {

            try {

                $KPI_ID = 6;    // for "Labor-Efficiency" data...

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # retrieving submitted value(s)...
                // Date-Time related data...
                $MONTH = $request->input('month_val');
                $YEAR = $request->input('yr_val');
                $SELECTED_DT = date('Y-m-d', mktime(0, 0, 0, $MONTH, date('d'), $YEAR));

                // for Store-ID(s)
                $store_ids = $request->input('store_id');
                if( $store_ids==-1 )
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $this->data['planned_data'] = $KPI_model->getLast12MonthsKPIPlanData($KPI_ID,
                                                                                     $store_ids,
                                                                                     $SELECTED_DT);

                // "Actual KPI" data...
                $this->data['actual_data'] = $IStmt_model->getLast12MonthsIncomeStmtData($store_ids, $KPI_ID, $SELECTED_DT);

                // "System-Average KPI" data (this is for All-Stores)...
                if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                    $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                else
                    $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                $this->data['sys_avg_data'] = $IStmt_model->getLast12MonthsIncomeStmtData($all_store_ids, $KPI_ID, $SELECTED_DT);

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

    }
    
    
    //// 3rd Chart: Last 12 month(s) Analysis...
    public function loadAnalyzedData() {

        try {

            $KPI_ID = 6;    // for "Labor-Efficiency" data...

            # logged-in user-id & type...
            $LOGGED_USR_ID = \Session::get('user_id');
            $LOGGED_USR_TYPE = \Session::get('user_type');

            # I: for ALL store(s) assigned to the logged-in user...
            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

            # II: instantiating model(s)...
            $KPI_model = new model_KPI();
            $IStmt_model = new model_IStmt();

            # III: gathering Chart-Data...
            // "Planned KPI" data...
            $this->data['planned_data'] = $KPI_model->getLast12MonthsKPIPlanData($KPI_ID,
                                                                                 $store_ids);

            // "Actual KPI" data...
            $this->data['actual_data'] = $IStmt_model->getLast12MonthsIncomeStmtData($store_ids, $KPI_ID);

            // "System-Average KPI" data (this is for All-Stores)...
            if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
            else
                $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
            $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

            $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
            $this->data['sys_avg_data'] = $IStmt_model->getLast12MonthsIncomeStmtData($all_store_ids, $KPI_ID);

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }
    
    
    # I: AJAX LOAD
    //// 1st Chart: My Store VS All Store(s)...
    public function loadAllStoresChartDataAJAX(Request $request) {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                    ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                    : $LOGGED_USR_ID;

                # retrieving submitted value(s)...
                // Date-Time related data...
                $dt_time_arr = array();
                $dt_time_arr['month'] = $request->input('month_val');
                $dt_time_arr['year'] = $request->input('yr_val');

                // for Store-ID(s)
                $store_ids = $request->input('store_id');
                if( $store_ids==-1 )
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);


                return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
    
    //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s)...
    public function loadTopStoresChartDataAJAX(Request $request, $top=5) {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                    ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                    : $LOGGED_USR_ID;

                # retrieving submitted value(s)...
                // Date-Time related data...
                $dt_time_arr = array();
                $dt_time_arr['month'] = $request->input('month_val');
                $dt_time_arr['year'] = $request->input('yr_val');

                // for Store-ID(s)
                $store_ids = $request->input('store_id');
                if( $store_ids==-1 )
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2);
                $arr = $this->formTopStoresDataArray($all_store_ids, $dt_time_arr, $store_ids, $top);

                return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
    //// 2nd Chart: My Store VS Top 10 OR Top 5 Store(s) For Revenue...
    public function loadTopStoresRevenueChartDataAJAX(Request $request, $top=5) {

        try {

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                    ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                    : $LOGGED_USR_ID;

                # retrieving submitted value(s)...
                // Date-Time related data...
                $dt_time_arr = array();
                $dt_time_arr['month'] = $request->input('month_val');
                $dt_time_arr['year'] = $request->input('yr_val');

                // for Store-ID(s)
                $store_ids = $request->input('store_id');
                if( $store_ids==-1 )
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2);
                $arr = $this->formTopStoresRevenueDataArray($all_store_ids, $dt_time_arr, $store_ids, $top);

                return $arr;

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }
    }
    
    
    
    # function to get ALL-STORES-DATA...
    public function formStoresDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                # =================================================
                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                           ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                           : $LOGGED_USR_ID;
                # =================================================

                $selected_month = $dt_time_arr['month'];
                $selected_year = $dt_time_arr['year'];

                $FLAG_COMPARISON = true;
                if( count($selected_stores_arr)>3 )
                    $FLAG_COMPARISON = false;
                

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //// My Store vs All Store(s)
                    $chart_type = 'labor efficiency';
                    $ALL_OR_SELECTED = ( count($stores_arr)!=count($selected_stores_arr) )
                                       ? ( is_array($selected_stores_arr)? '': $selected_stores_arr ): '';
                    echo $sql = sprintf("CALL zev_bm_revenue_my_store_vs_all('%s', %d, %d, %d, '%s') ",
                                    $chart_type, $FRANCHISOR_ADMIN_ID, $selected_month, $selected_year, $ALL_OR_SELECTED);                                    

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                //echo $sql; exit;
                $ret_ = \DB::select(\DB::raw($sql));
                $RETURN_ARR = $this->prepareDBReturnArray($ret_, $selected_stores_arr, $FLAG_COMPARISON);

                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        
        
        # function to get TOP 10/5 STORES DATA...
        public function formTopStoresDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null, $top=5) {

            try {
                $RETURN_ARR = array();

                # =================================================
                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                           ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                           : $LOGGED_USR_ID;
                # =================================================

                $selected_month = $dt_time_arr['month'];
                $selected_year = $dt_time_arr['year'];

                $FLAG_COMPARISON = true;
                if( count($selected_stores_arr)>3 ) {

                    $FLAG_COMPARISON = false;
                }

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //// My Store vs Top 10/5 Store(s)
                    $chart_type = 'labor efficiency';
                    $ALL_OR_SELECTED = ( count($stores_arr)!=count($selected_stores_arr) )
                                       ? ( is_array($selected_stores_arr)? '': $selected_stores_arr ): '';
                    
                    if( $top==5 ) {
                        $sql = sprintf("CALL zev_bm_revenue_my_store_vs_all_top5('%s', %d, %d, %d, '%s') ",
                                        $chart_type, $FRANCHISOR_ADMIN_ID, $selected_month, $selected_year, $ALL_OR_SELECTED);                            
                    } else {
                        $sql = sprintf("CALL zev_bm_revenue_my_store_vs_all_top10('%s', %d, %d, %d, '%s') ",
                                        $chart_type, $FRANCHISOR_ADMIN_ID, $selected_month, $selected_year, $ALL_OR_SELECTED);                            
                    }
                                    

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                #echo $sql ."<br />====================<br />";

                $ret_ = \DB::select(\DB::raw($sql));
                $RETURN_ARR = $this->prepareDBReturnArray($ret_, $selected_stores_arr, $FLAG_COMPARISON);

                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function ($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        
        # function to get TOP 10/5 STORES DATA For Revenue [i.e. Top Revenue Holder Store(s)]...
        public function formTopStoresRevenueDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null, $top=5) {

            try {
                $RETURN_ARR = array();

                # =================================================
                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                           ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                           : $LOGGED_USR_ID;
                # =================================================

                $selected_month = $dt_time_arr['month'];
                $selected_year = $dt_time_arr['year'];

                $FLAG_COMPARISON = true;
                if( count($selected_stores_arr)>3 )
                    $FLAG_COMPARISON = false;

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    //// My Store vs Top 10/5 Revenue-Holder Store(s)
                    $chart_type = 'labor efficiency';
                    $ALL_OR_SELECTED = ( count($stores_arr)!=count($selected_stores_arr) )
                                       ? ( is_array($selected_stores_arr)? '': $selected_stores_arr ): '';
                    
                    if( $top==5 ) {
                        $sql = sprintf("CALL zev_bm_revenue_my_store_vs_all_top5_revenue('%s', %d, %d, %d, '%s') ",
                                        $chart_type, $FRANCHISOR_ADMIN_ID, $selected_month, $selected_year, $ALL_OR_SELECTED);                            
                    } else {
                        $sql = sprintf("CALL zev_bm_revenue_my_store_vs_all_top10_revenue('%s', %d, %d, %d, '%s') ",
                                        $chart_type, $FRANCHISOR_ADMIN_ID, $selected_month, $selected_year, $ALL_OR_SELECTED);                            
                    }
                                    

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # echo $sql ."<br />====================<br />";

                $ret_ = \DB::select(\DB::raw($sql));
                $RETURN_ARR = $this->prepareDBReturnArray($ret_, $selected_stores_arr, $FLAG_COMPARISON);

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        
        
        # function to prepare return-array format form db-results...
        public function prepareDBReturnArray($db_result_obj=null, $stores_arr=null, $flag_comparison) {

            try {

                $RETURN_ARR = null;
                
                if( !empty($db_result_obj) ) {
                    $LOOP_INDEX  = 0;

                    $MEAN = $SD = null;
                    
                    $mean_N_sd_arr = usr_Helper::getMeanNStdDev($db_result_obj);
                    if( !empty($mean_N_sd_arr) ) {
                        $MEAN = $mean_N_sd_arr['mean_val'];
                        $SD = $mean_N_sd_arr['sd_val'];
                    }
                    
                    
                    # A: for store(s) with FLAG=0 OR 3 (based on Chart-Mode: Normally-Distributed OR Column)
                    $INIT_VAL = $db_result_obj[0]->is_my_store;
                    foreach($db_result_obj as $row_obj) {
                        
                        if( $INIT_VAL!=$row_obj->is_my_store ) {
                            $LOOP_INDEX = 0;
                            $INIT_VAL = $row_obj->is_my_store;
                        } else
                            $LOOP_INDEX = $LOOP_INDEX;
                        #$LOOP_INDEX = ( $INIT_VAL!=$row_obj->is_my_store )? 0: $LOOP_INDEX;
                        
                        if( ($row_obj->is_my_store==0) || ($row_obj->is_my_store==3) ) :
                        
                        // -- NEW : data-array key-wise (i.e. either "ND" or "column")...
                            $ARR_KEY = ( $row_obj->is_my_store==0 )? 'ND': 'column';
                        
                            $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_id'] = $LOOP_INDEX + 1;
                            $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_name'] = ( !empty($row_obj->my_store_name) && ($row_obj->is_my_store==1) )
                                                                     ? $row_obj->my_store_name
                                                                     : '';
                            $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['revenue'] = $row_obj->dv;
                            $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['ND'] = $row_obj->nd;

                            //// NEW - for "Distribution" chart Region(s)' Color...
                                $LOWER_THRESHOLD_VAL = utils::formatNum($MEAN-$SD);
                                $UPPER_THRESHOLD_VAL = utils::formatNum($MEAN+$SD);
                                
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['region_color'] = ( $row_obj->dv < $LOWER_THRESHOLD_VAL )
                                                                           ? '#DAAEAF'
                                                                           : ( ($row_obj->dv>$UPPER_THRESHOLD_VAL)? '#A00000': '#CC7878' );

                                
                            $FLAG_LINE_MARKER = ( ($ARR_KEY=='column') && ($row_obj->my_store_name=='Y') )
                                                ? 3: 0;
                            $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['line_marker'] = $FLAG_LINE_MARKER;
                        
                            $LOOP_INDEX++;
                            
                        endif;
                        
                    }
                    
                    if( empty($row_obj->is_my_store) ) :   // Only for Normally-Distributed Value(s)...
                        
                        # B: for store(s) with FLAG=1
                        $ACTUAL_DATA_ARR = $this->fetchActualDataArray($db_result_obj);
                        
                        
                        if( !empty($ACTUAL_DATA_ARR) )
                            $RETURN_ARR = array_merge_recursive($ACTUAL_DATA_ARR, $RETURN_ARR);
                        
                        # C: for Planned Data Array...
                            $PLANNED_DATA_ARR = $this->fetchPlannedDataArray($db_result_obj);
                            
                            if( !empty($PLANNED_DATA_ARR) ) {
                                $RETURN_ARR = array_merge_recursive($PLANNED_DATA_ARR, $RETURN_ARR);
                            }
                            
                    endif;

                }   // end - if

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        # prepare chart for Google-Graph...
        public function prepareGChartArray($arr=null, $chart_type, $top=null, $order='asc') {

            try {
                $return_arr = null;
                $LOGGED_USR_TYPE = \Session::get('user_type');

                if( !empty($arr) ) {
                    
                    if( $chart_type=='ND' ) :
                        //// For "Normally-Distributed" Chart(s) [Begin]
                            $return_arr = [['Stores', array('role' => 'annotation'), 'Labor Efficiency', array('role' => 'style'), array('role' => 'tooltip')]]; // for Header Array...

                            $sub_arr = array();

                            $loop_counter = 1;
                            foreach($arr as $sorted_arr) {

                                $ANNOTATION_MARKER = ( !empty($sorted_arr['line_marker']) )
                                                     ? (($sorted_arr['line_marker']==1)? $sorted_arr['store_name']:  $sorted_arr['store_name']): null;
                                $TOOLTIP = ( !empty($sorted_arr['line_marker']) || $LOGGED_USR_TYPE==2 )
                                           ? $sorted_arr['revenue']
                                           : '';

                                $sub_arr[]   = array(
                                                         0 => floatval($sorted_arr['revenue']),
                                                         1 => $ANNOTATION_MARKER,
                                                         2 => floatval($sorted_arr['ND']),
                                                         3 => $sorted_arr['region_color'],
                                                         4 => $TOOLTIP
                                                     );

                                $loop_counter++;
                            }   // end - foreach


                        $return_arr = array_merge($return_arr, $sub_arr);
                        //// For "Normally-Distributed" Chart(s) [End]
                    else :
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Stores', 'Labor Efficiency', array('role' => 'style')]]; // for Header Array...

                        $loop_counter = 1;


                        // for column-chart (use Ascending Order)
                            usort($arr, function ($a, $b) use ($order) {
                                if( $order=='asc')
                                    return $a['revenue'] < $b['revenue'];
                                else
                                    return $a['revenue'] > $b['revenue'];
                            });


                        foreach($arr as $sorted_arr) {

                            $TOOLTIP = ( !empty($sorted_arr['line_marker']) || $LOGGED_USR_TYPE==2 )
                                       ? $sorted_arr['revenue']
                                       : '';
                            $CHART_COLOR = ( !empty($sorted_arr['line_marker']) )
                                           ? '#A00000': '#CC7878';

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,
                                                    1 => floatval($sorted_arr['revenue']),
                                                    2 => $CHART_COLOR
                                                 );

                            $loop_counter++;
                        }   // end - foreach
                        //// For "Column" Chart(s) [End]
                    endif;

                }  else {

                    if( $chart_type=='ND' ) :
                        //// For "Normally-Distributed" Chart(s) [Begin]
                        $return_arr = [['Stores', array('role' => 'annotation'), 'Labor Efficiency', array('role' => 'style'), array('role' => 'tooltip')]]; // for Header Array...
                        $return_arr[] = array(
                            0 => 0.00,
                            1 => 0,
                            2 => 0.00,
                            3 => '#CC7878',
                            4 => null
                        );
                    else :
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Stores', 'Labor Efficiency', array('role' => 'style')]]; // for Header Array...
                        $return_arr[] = array(
                            0 => null,
                            1 => 0.00,
                            2 => null
                        );
                    endif;
                }  // end - if


                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        
        # function to prepare return-array format form db-results...
        public function prepareLineChartDBArray() {

            try {

                $PARAM_PLANNED_ARR = $PARAM_ACTUAL_ARR = $PARAM_SYS_AVG_ARR = $PARAM_PROFIT_OR_LOSS_ARR = null;

                $PLANNED_KPI_ARR = $this->data['planned_data'];                
                $ACTUAL_KPI_ARR  = $this->data['actual_data'];
                $SYS_AVG_KPI_ARR  = $this->data['sys_avg_data'];

                if( !empty($PLANNED_KPI_ARR) ) {

                    $LOOP_INDEX  = 0;

                    foreach($PLANNED_KPI_ARR as $key=>$val) {

                        $PARAM_PLANNED_ARR[$LOOP_INDEX]['revenue'] = number_format($PLANNED_KPI_ARR[$key]->kpi_val, 2, '.', '');
                        $PARAM_PLANNED_ARR[$LOOP_INDEX]['month'] = date("M'y", strtotime($PLANNED_KPI_ARR[$key]->rcvd_dt));

                        if(array_key_exists($key,$ACTUAL_KPI_ARR)) {
                            $PARAM_ACTUAL_ARR[$LOOP_INDEX]['revenue'] = number_format($ACTUAL_KPI_ARR[$key]->kpi_val, 2, '.', '');
                            $PARAM_ACTUAL_ARR[$LOOP_INDEX]['month'] = date("M'y", strtotime($ACTUAL_KPI_ARR[$key]->rcvd_dt));
                        } else {
                            $PARAM_ACTUAL_ARR[$LOOP_INDEX]['revenue'] = 0;
                            $PARAM_ACTUAL_ARR[$LOOP_INDEX]['month'] = date("M'y");
                        }


                        if(array_key_exists($key,$SYS_AVG_KPI_ARR)) {
                            $PARAM_SYS_AVG_ARR[$LOOP_INDEX]['revenue'] = number_format($SYS_AVG_KPI_ARR[$key]->kpi_val, 2, '.', '');
                            $PARAM_SYS_AVG_ARR[$LOOP_INDEX]['month'] = date("M'y", strtotime($SYS_AVG_KPI_ARR[$key]->rcvd_dt));
                        } else {
                            $PARAM_SYS_AVG_ARR[$LOOP_INDEX]['revenue'] = 0;
                            $PARAM_SYS_AVG_ARR[$LOOP_INDEX]['month'] = date("M'y");
                        }


                        if(array_key_exists($key,$ACTUAL_KPI_ARR))
                            $PARAM_PROFIT_OR_LOSS_ARR[$LOOP_INDEX]['margin_percent'] = usr_Helper::calculateProfitLossPercent($ACTUAL_KPI_ARR[$key]->kpi_val, $PLANNED_KPI_ARR[$key]->kpi_val);
                        else
                            $PARAM_PROFIT_OR_LOSS_ARR[$LOOP_INDEX]['margin_percent'] = 0;


                        $LOOP_INDEX++;
                    }

                }   // end - if

                $this->data['planned_data_arr'] = $PARAM_PLANNED_ARR;
                $this->data['actual_data_arr'] = $PARAM_ACTUAL_ARR;
                $this->data['sys_avg_data_arr'] = $PARAM_SYS_AVG_ARR;
                $this->data['percent_arr'] = $PARAM_PROFIT_OR_LOSS_ARR;
                #return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }


        # prepare chart for Google-Graph (for Line-Chart)...
        public function prepareGLineChartArray() {

            try {
                $return_arr = null;

                //// For "Line" Chart [Begin]
                $return_arr = [['Month(s)', 'Planned', 'Actual', 'Average']]; // for Header Array...

                if( !empty($this->data['planned_data_arr']) ) {

                    foreach($this->data['planned_data_arr'] as $key=>$val) {

                        $return_arr[] = array(
                            0 => $this->data['planned_data_arr'][$key]['month'],
                            1 => floatval($this->data['planned_data_arr'][$key]['revenue']),
                            2 => floatval($this->data['actual_data_arr'][$key]['revenue']),
                            3 => floatval($this->data['sys_avg_data_arr'][$key]['revenue'])
                        );
                    }   // end - foreach
                    //// For "Line" Chart [End]

                } else {
                    $return_arr[] = array(
                        0 => null,
                        1 => 0,
                        2 => 0,
                        3 => 0
                    );
                }   // end - if


                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        } 

        
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #                                   NEW FUNCTION(S) - BEGIN
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
            // function to get actual data array (if available)...
            public function fetchActualDataArray($db_result_obj=null) {
                
                try {
                    
                    $RETURN_ARR = array();
                    
                    if( !empty($db_result_obj) ) :
                    
                        $LOOP_INDEX = 0;
                        
                        $MEAN = $SD = null;
                        $mean_N_sd_arr = usr_Helper::getMeanNStdDev($db_result_obj);
                        if( !empty($mean_N_sd_arr) ) {
                            $MEAN = $mean_N_sd_arr['mean_val'];
                            $SD = $mean_N_sd_arr['sd_val'];
                        }
                        $LOWER_THRESHOLD_VAL = utils::formatNum($MEAN-$SD);
                        $UPPER_THRESHOLD_VAL = utils::formatNum($MEAN+$SD);
                        
                        $ARR_KEY = 'ND';
                        foreach($db_result_obj as $row_obj) {
                            
                            if( $row_obj->is_my_store==1 && $row_obj->my_store_name=='Actual' ) :
                                
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_id'] = ($LOOP_INDEX+1);
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_name'] = ( !empty($row_obj->my_store_name) && ($row_obj->is_my_store==1) )
                                                                         ? $row_obj->my_store_name
                                                                         : 'Shop '. $RETURN_ARR[$LOOP_INDEX]['store_id'];
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['revenue'] = $row_obj->dv;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['ND'] = $row_obj->nd;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['region_color'] = ( $row_obj->dv < $LOWER_THRESHOLD_VAL )
                                                                           ? '#DAAEAF'
                                                                           : ( ($row_obj->dv>$UPPER_THRESHOLD_VAL)? '#A00000': '#CC7878' );

                                $FLAG_LINE_MARKER = 1;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['line_marker'] = $FLAG_LINE_MARKER;
                                
                                $LOOP_INDEX++;
                                
                            endif;
                                
                        }
                    
                    endif;
                    
                    return $RETURN_ARR;
                    
                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
                
            }
        
            // function to get planned-data array (if available)...
            public function fetchPlannedDataArray($db_result_obj=null) {
                
                try {
                    
                    $RETURN_ARR = array();
                    
                    if( !empty($db_result_obj) ) :
                    
                        $LOOP_INDEX = 0;
                        
                        $MEAN = $SD = null;
                        $mean_N_sd_arr = usr_Helper::getMeanNStdDev($db_result_obj);
                        if( !empty($mean_N_sd_arr) ) {
                            $MEAN = $mean_N_sd_arr['mean_val'];
                            $SD = $mean_N_sd_arr['sd_val'];
                        }
                        $LOWER_THRESHOLD_VAL = utils::formatNum($MEAN-$SD);
                        $UPPER_THRESHOLD_VAL = utils::formatNum($MEAN+$SD);
                        
                        $ARR_KEY = 'ND';
                        foreach($db_result_obj as $row_obj) {
                            
                            if( $row_obj->is_my_store==1 && $row_obj->my_store_name=='Plan' ) :

                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_id'] = ($LOOP_INDEX+1);
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['store_name'] = ( !empty($row_obj->my_store_name) && ($row_obj->is_my_store==1) )
                                                                         ? $row_obj->my_store_name
                                                                         : 'Shop '. $RETURN_ARR[$LOOP_INDEX]['store_id'];
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['revenue'] = $row_obj->dv;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['ND'] = $row_obj->nd;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['region_color'] = ( $row_obj->dv < $LOWER_THRESHOLD_VAL )
                                                                           ? '#DAAEAF'
                                                                           : ( ($row_obj->dv>$UPPER_THRESHOLD_VAL)? '#A00000': '#CC7878' );


                                $FLAG_LINE_MARKER = 2;
                                $RETURN_ARR[$ARR_KEY][$LOOP_INDEX]['line_marker'] = $FLAG_LINE_MARKER;
                                
                                $LOOP_INDEX++;
                                
                            endif;
                                
                        }
                    
                    endif;
                    
                    return $RETURN_ARR;
                    
                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
                
            }
        
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #                                   NEW FUNCTION(S) - END
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
}
