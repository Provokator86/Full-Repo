<?php

namespace App\Http\Controllers\userend\benchmark;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class StoreVisitationController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Benchmark - Store Visitations ::';

        # for menu selection...
        $this->data['selected_menu'] = 'benchmark';
        $this->data['selected_sub_menu'] = 'store-visitations';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        # show view part...
        return view('userend.benchmark.store-visitation', $data);
    }

}
