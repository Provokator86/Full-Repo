<?php

namespace App\Http\Controllers\userend\benchmark;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ConversionRatioController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Benchmark - Conversion Ratio ::';

        # for menu selection...
        $this->data['selected_menu'] = 'benchmark';
        $this->data['selected_sub_menu'] = 'conversion-ratio';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        # show view part...
        return view('userend.benchmark.conversion-ratio', $data);
    }

}
