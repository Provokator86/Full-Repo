<?php

namespace App\Http\Controllers\userend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\PricingToolModel as model_Curv;

class PricingToolController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Daily Scoop - Pricing Tool ::';

        # for menu selection...
        $this->data['selected_menu'] = 'contribution-and-pricing-tools';
        $this->data['selected_sub_menu'] = 'contribution-and-pricing-tools';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        #$data = $this->data;

        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');

        # 1: getting concerned Franchisor-Admin ID...
            $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                   : $LOGGED_USR_ID;

        # 2: total no. of Store(s) available...
            $this->data['total_no_of_shops'] = usr_Helper::getAllStoreCount($FRANCHISOR_ADMIN_ID);

        # Load Categories
        $model_Curv = new model_Curv();
        $this->data['all_pos_categories_arr'] = $model_Curv->pos_category_group();
        $this->data['all_categories_arr'] = $model_Curv->category_group();
        
        # 3: Total Statistics :
        
            //$ALL_DATA_ARR = $this->loadAllStoresChartData();  
            
            $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableData();
            
       
        
        

        # ===========================================================================
        #       For Column Graph(s) - Begin
        # ===========================================================================

            
            /*$CR_ALL_DATA_ARR = $this->prepareGChartAllArray($ALL_DATA_ARR);
            $this->data['all_CR_data_arr'] = json_encode($CR_ALL_DATA_ARR);  */        
            
            $this->data['all_PT_table_data_arr'] = $ALL_TABLE_ARR;
            
            //print_r($ALL_TABLE_ARR);

        # ===========================================================================
        #      For Column Graph(s) -  End
        # ===========================================================================


        # Default Load "Month-Scroller"...
        $this->data['default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));
        #utils::dump($data);
        
        $this->data['prev_month_scroller_dt'] = date('d M y', strtotime("-30 days"));
        $this->data['next_month_scroller_dt'] = date('d M y');   
        
        # show view part...
        
        return view('userend.pricing_tool.pricing-tool', $this->data);
    }

    // AJAX Call - load Chart data based on selected store(s), month & year...
    public function loadPricingtooltableDataAJAX(Request $request) {

        try {

            # 1: loading chart-data...
            //$ALL_DATA_ARR = $this->loadAllStoresChartDataAJAX($request);  
            
            $ALL_TABLE_ARR = $this->loadAllStoresCumulativeTableDataAJAX($request);

            # ===========================================================================
            #       For Column Graph(s) - Begin
            # ===========================================================================
              
                $this->data['all_PT_table_data_arr'] = $ALL_TABLE_ARR;            
                

            # ===========================================================================
            #       For Column Graph(s) - End
            # ===========================================================================
                 
        
            # load view part...
            $HTML = \View::make('userend.pricing_tool.ajax-parts.load-pricingtool-table-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

    // AJAX Call - load Chart data based on selected store(s), month & year...
    public function loadPricingtoolDataAJAX(Request $request) {

        try {

            # 1: loading chart-data...
            $ALL_DATA_ARR = $this->loadAllStoresChartDataAJAX($request);  
            
            

            # ===========================================================================
            #       For Column Graph(s) - Begin
            # ===========================================================================

                //$chart_type = 'ND';
                $CR_ALL_DATA_ARR = $this->prepareGChartAllArray($ALL_DATA_ARR);
                $this->data['all_CR_data_arr'] = json_encode($CR_ALL_DATA_ARR);                

            # ===========================================================================
            #       For Column Graph(s) - End
            # ===========================================================================
                 
        
            # load view part...
            $HTML = \View::make('userend.pricing_tool.ajax-parts.load-pricingtool-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }

    
    public function loadsubcategoryDataAJAX(Request $request) {

        try {

            # 1: loading chart-data...
            
            
            $model_Curv = new model_Curv();
            
            
            $val = $request->input('val');                    
            $type = $request->input('type');

            
            if($type == 1){
                 $this->data['all_sub_categories_arr'] = $model_Curv->pos_sub_category_group($val);                
            }
            if($type == 2){                
                $this->data['all_sub_categories_arr'] = $model_Curv->sub_category_group($val);                
            }        
           
           
            # load view part...
            $HTML = \View::make('userend.pricing_tool.ajax-parts.load-pricingtool-subcategory-data-AJAX', $this->data)->render();
          
            
           
                
           

            # ===========================================================================
            #       For Column Graph(s) - End
            # ===========================================================================
                 
        
            # load view part...
            //$HTML = \View::make('userend.daily_scoop.ajax-parts.load-DS-timeofday-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;
        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }
    # =============================================================
    #           Generate Chart(s) - Begin
    # =============================================================

        # I: INITIAL LOAD
            //// 1st Chart: My Store VS All Store(s)...
            public function loadAllStoresChartData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['week_of_day'] = 0; // default 
                    

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

            
           
             public function loadAllStoresCumulativeTableData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['category'] = ''; // default 
                        $dt_time_arr['subcategory'] = ''; // default 
                        $dt_time_arr['product'] = ''; // default 
                        $dt_time_arr['group'] = '0'; // default 
                        $dt_time_arr['orderby'] = ''; // default 

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);

                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            ###4
            ###3
           

            //// 3rd Chart: Last 12 month(s) Analysis...
            

            public function loadAllStoresTableData() {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $prev_dt = date('d M y', strtotime("-30 days"));
                        
                        $dt_time_arr['prev_date'] = date('d', strtotime("-30 days"));
                        $dt_time_arr['prev_month'] = date('m', strtotime("-30 days"));
                        $dt_time_arr['prev_year'] = date('Y', strtotime("-30 days"));

                        $dt_time_arr['current_date'] = date('d');
                        $dt_time_arr['current_month'] = date('m');
                        $dt_time_arr['current_year'] = date('Y');
                        
                        $dt_time_arr['item_code'] = 0; // default                        
                       

                        // for Store-ID(s)
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresTableDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

        # I: AJAX LOAD
            //// 1st Chart: My Store VS All Store(s)...
            public function loadAllStoresChartDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['item_code'] = $request->input('item_code');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    $arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);


                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }

            
            
            
            //// 3rd Chart: Last 12 month(s) Analysis [AJAX Call]...
           
            
            ///4

            public function loadAllStoresTableDataAJAX(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # logged-in user-id & type...
                    $LOGGED_USR_ID = \Session::get('user_id');
                    $LOGGED_USR_TYPE = \Session::get('user_type');

                    $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                        ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                        : $LOGGED_USR_ID;

                    # retrieving submitted value(s)...
                    // Date-Time related data...
                    $dt_time_arr = array();
                    
                    $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                    $dt_time_arr['prev_month'] = $request->input('prev_month');
                    $dt_time_arr['prev_year'] = $request->input('prev_yr');
                    
                    $dt_time_arr['current_date'] = $request->input('current_date');                    
                    $dt_time_arr['current_month'] = $request->input('current_month');
                    $dt_time_arr['current_year'] = $request->input('current_yr');
                    
                    $dt_time_arr['item_code'] = $request->input('item_code');
                    

                    // for Store-ID(s)
                    $store_ids = $request->input('store_id');
                    if( $store_ids==-1 )
                        $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                    //$arr = $this->formStoresDataArray($all_store_ids, $dt_time_arr, $store_ids);
                    $arr = $this->formStoresTableDataArray($all_store_ids, $dt_time_arr, $store_ids);

                    return $arr;
                    #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
            
            
            public function loadAllStoresCumulativeTableDataAjax(Request $request) {

                try {

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [Begin]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                        # logged-in user-id & type...
                        $LOGGED_USR_ID = \Session::get('user_id');
                        $LOGGED_USR_TYPE = \Session::get('user_type');

                        $FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
                                               ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
                                               : $LOGGED_USR_ID;

                        # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        //$dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
                        //$dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));
                        
                        
                        $dt_time_arr = array();

                        $dt_time_arr['prev_date'] = $request->input('prev_date');                    
                        $dt_time_arr['prev_month'] = $request->input('prev_month');
                        $dt_time_arr['prev_year'] = $request->input('prev_yr');

                        $dt_time_arr['current_date'] = $request->input('current_date');                    
                        $dt_time_arr['current_month'] = $request->input('current_month');
                        $dt_time_arr['current_year'] = $request->input('current_yr');
                       
                        $dt_time_arr['category'] = $request->input('category');
                        $dt_time_arr['subcategory'] = $request->input('subcategory');
                        $dt_time_arr['product'] = $request->input('product');
                        $dt_time_arr['group'] = $request->input('group');
                        $dt_time_arr['orderby'] = $request->input('orderby');
                        
                        
                        $store_ids = $request->input('store_id');
                        if( $store_ids==-1 )
                            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                        $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, 2, true);
                        
                        
                        
                        $arr = $this->formStoresCumulativeDataArray($all_store_ids, $dt_time_arr, $store_ids);


                        return $arr;
                        #utils::dump( $this->data['all_data_arr'] );

                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    #               DS Chart(s) Related [End]
                    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


                } catch(Exception $err_obj) {
                    show_error($err_obj->getMessage());
                }
            }
    # =============================================================
    #           Generate Chart(s) - End
    # =============================================================




        # function to get ALL-STORES-DATA...
        public function formStoresDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $return_arr = array();
                $ret_previous_arr = array();               
                
                $model_Curv = new model_Curv();
                $return_arr = $model_Curv->getCumRevDetailsData($selected_stores_arr, $dt_time_arr);
                
                
               
                
                if(empty($return_arr)){                    
               
                    $return_arr[] = (object)array('unit_sales'=>0,'revenue'=>0,'my_store_revenue'=>0);
                }
                
                //print_r($new_array);exit;

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
        
        ##
       
        
        
        public function formStoresCumulativeDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumulativeTableData($selected_stores_arr, $dt_time_arr);
                //print_r($RETURN_ARR);
               
                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }
         # function to get ALL-STORES-DATA...
       
        public function formStoresTableDataArray($stores_arr=null, $dt_time_arr=null, $selected_stores_arr=null) {

            try {
                $RETURN_ARR = array();

                
                $model_Curv = new model_Curv();
                $RETURN_ARR = $model_Curv->getCumRevTableData($selected_stores_arr, $dt_time_arr);

                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/

                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


        

        # function to prepare return-array format form db-results...
        

        # prepare chart for Google-Graph...
        public function prepareGChartAllArray($arr=null, $chart_type=null) {

            try {
                $return_arr = null;
              
                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Store', 'Item Code', 'Unit Sold']]; // for Header Array...

                        foreach($arr as $sorted_arr) {
                          
                           // $TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $CHART_COLOR =  '#CC7878';

                            $return_arr[] = array(
                                                    0 => $sorted_arr->store_id,                                                    
                                                    1 => intval($sorted_arr->item_code),
                                                    2 => floatval($sorted_arr->unit_sold),                                                   
                                                    //4 => $CHART_COLOR
                                                 );
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    

                }   // end - if
                
                

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

        
        
        
        # prepare chart for Google-Graph...

        
}

