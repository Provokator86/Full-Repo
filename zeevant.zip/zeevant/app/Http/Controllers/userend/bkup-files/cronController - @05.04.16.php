<?php

namespace App\Http\Controllers\userend\cron;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\BalanceSheetModel as model_balance_sheet;
use App\Models\IncomeStmtModel as model_income_stmt;
use App\Helpers\UsersHelper as usrHelper;
use App\Helpers\Utility as utils;

class cronController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

    }


    # auto income statement load...
    public function loadAllIncomeStatements() {

        # 1st, empty the existing data...
        $master_istmt_tbl = getenv('DB_PREFIX') .'income_stmt_master';
        $istmt_inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
        $emptySQL1 = sprintf("TRUNCATE %s ", $master_istmt_tbl);
        $emptySQL2 = sprintf("TRUNCATE %s ", $istmt_inputs_tbl);

        /*\DB::statement($emptySQL1);
        \DB::statement($emptySQL2);*/


        /// NEW - for date-range [Begin]
            $MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
            $MAX_DT = date("Y-m-d");
        /// NEW - for date-range [End]

        # II: preload few required value(s) like Year, Month, Logged-User-ID...
        $LOGGED_USR = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');
        $year = date('Y');

        $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);

        # III: Now, looping through all store(s) under the franchisor-admin...
        for($month=1; $month<=1; $month++) :   // begin - month(s) loop

            foreach($stores_arr as $key=>$storeID) {   // begin - store foreach

                $ISTMT_LOCKED = 0;

                # 1st, check if data already there for that month, year & store-ID...
                $ret_ = null;
                $chkSQL = sprintf("SELECT COUNT(*) AS `counter` FROM %s
	    						   WHERE
	    						   		`i_store_id`=%d AND
	    								`i_month`=%d AND
	    								`i_year`=%d ",
	                			   $master_istmt_tbl, $storeID, $month, $year);
                $ret_ = \DB::select(\DB::raw($chkSQL));
                
                if( empty($ret_[0]->counter) ) {
	                
	                $ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
	
	                # IV-A: insert into master table 1st i.e. "_income_stmt_master"...
	                $master_data_arr = array();
	                $master_data_arr['i_user_id'] = $LOGGED_USR;
	                $master_data_arr['i_store_id'] = $storeID;
	                $master_data_arr['i_month'] = $month;
	                $master_data_arr['i_year'] = $year;
	                $master_data_arr['dt_added'] = $ADD_DT_TIME;
	                $master_data_arr['i_locked'] = $ISTMT_LOCKED;
	
	                $ISTMT_ID = \DB::table($master_istmt_tbl)
	                    ->insertGetId($master_data_arr);
	
	                # II-B: insert into income-statement input(s) i.e. "_income_stmt_inputs"...
	                $istmt_arr = array();
	                $istmt_arr['i_income_stmt_id'] = $ISTMT_ID;
	
	                $REVENUE_TOTAL = 0;
	                $REVENUE_TOTAL += $istmt_arr['d_is_40100'] = mt_rand(12000, 20000);
	                $REVENUE_TOTAL += $istmt_arr['d_is_40200'] = mt_rand(1000, 2000);
	                $REVENUE_TOTAL += $istmt_arr['d_is_40300'] = mt_rand(1000, 2000);
	
	                $COGS_TOTAL = 0;
	                $COGS_TOTAL += $istmt_arr['d_is_50100'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50200'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50300'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50400'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50500'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50600'] = mt_rand(1000, 2000);
	
	
	                $EXPENSES_TOTAL = 0;
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60700'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60800'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60900'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61000'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61700'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61800'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61900'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62000'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62700'] = mt_rand(1000, 2000);
	
	                $OTHER_INCOME_TOTAL = 0;
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80100'] = mt_rand(1000, 2000);
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80200'] = mt_rand(1000, 2000);
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80300'] = mt_rand(1000, 2000);

	                # NEW FIELD - Net Income
	                $NET_INCOME = ($REVENUE_TOTAL - $COGS_TOTAL - $EXPENSES_TOTAL + $OTHER_INCOME_TOTAL);
	                
	                 //// Total Field(s)
	                $istmt_arr['d_is_40000'] = $REVENUE_TOTAL;
	                $istmt_arr['d_is_50000'] = $COGS_TOTAL;
	                $istmt_arr['d_is_60000'] = $EXPENSES_TOTAL;
	                $istmt_arr['d_is_80000'] = $OTHER_INCOME_TOTAL;
	                $istmt_arr['d_net_income'] = $NET_INCOME;
	                $istmt_arr['dt_added'] = $ADD_DT_TIME;
	
	
	                \DB::table($istmt_inputs_tbl)
	                    ->insert($istmt_arr);
	                
                }

            }   // end - store foreach

        endfor; // end - month(s) loop


        // success statement...
        echo "Income-Statement data loaded successfully...";
    }

    # auto KPI revenue load...
    /*public function loadAllKPIRevenue() {

        /// NEW - for date-range [Begin]
        $MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
        $MAX_DT = date("Y-m-d");
        $ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
        /// NEW - for date-range [End]

        # 1st, empty the existing data...
        $kpi_details_tbl = getenv('DB_PREFIX') .'kpi_details';
        $emptySQL = sprintf("TRUNCATE %s ", $kpi_details_tbl);

        \DB::statement($emptySQL);

        $LOGGED_USR = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');
        $year = date('Y');

        $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);

        # Now, looping through all store(s) under the franchisor-admin...
        for($month=1; $month<=12; $month++) :   // begin - month(s) loop

            foreach($stores_arr as $key=>$storeID) {   // begin - store foreach

                # I: KPI Details...
                $KPI_plan_arr = array();
                $KPI_plan_arr['i_store_id'] = $storeID;
                $KPI_plan_arr['i_usr_id'] = $LOGGED_USR;
                $KPI_plan_arr['i_month'] = $month;
                $KPI_plan_arr['i_year'] = $year;
                $KPI_plan_arr['dt_added'] = $ADD_DT_TIME;
                //// retrieving submitted/posted values [END]...

                $KPI_plan_arr['i_kpi_id'] = 1;  // for Revenue - KPI ID...
                $KPI_plan_arr['d_monthly_plan_mark'] = mt_rand(10000, 100000);

                \DB::table($kpi_details_tbl)
                    ->insert($KPI_plan_arr);

            }   // end - store foreach

        endfor;  // end - month(s) loop

        // success statement...
        echo "KPI Revenue data loaded successfully...";
    }*/


    # auto KPI revenue load...
    public function loadAllKPIRevenue() {
        
        /// NEW - for date-range [Begin]
        $MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
        $MAX_DT = date("Y-m-d");
        $ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
        /// NEW - for date-range [End]

        # 1st, empty the existing data...
        $kpi_details_tbl = getenv('DB_PREFIX') .'kpi_details';
        /*$emptySQL = sprintf("TRUNCATE %s ", $kpi_details_tbl);

        \DB::statement($emptySQL);*/

        $LOGGED_USR = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');
        $year = date('Y');

        $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);
        
        // for KPI-array...
        $KPI_arr = array(1, 2, 3, 4, 5, 6, 7, 10);

        # Now, looping through all store(s) under the franchisor-admin...
        for($month=2; $month<=12; $month++) :   // begin - month(s) loop

            foreach($stores_arr as $key=>$storeID) {   // begin - store foreach

                # I: KPI Details...
                $KPI_plan_arr = array();
                $KPI_plan_arr['i_store_id'] = $storeID;
                $KPI_plan_arr['i_usr_id'] = $LOGGED_USR;
                $KPI_plan_arr['i_month'] = $month;
                $KPI_plan_arr['i_year'] = $year;
                $KPI_plan_arr['dt_added'] = $ADD_DT_TIME;
                //// retrieving submitted/posted values [END]...
                
                foreach($KPI_arr as $arr_key=>$kpi_ID) {
                    $KPI_plan_arr['i_kpi_id'] = $kpi_ID;  // for Revenue - KPI ID...

                    $arr = $this->getKPIRange($kpi_ID);
                    $KPI_plan_arr['d_monthly_plan_mark'] = mt_rand($arr['min'], $arr['max']);

                    //utils::dump($KPI_plan_arr);
                    \DB::table($kpi_details_tbl)
                        ->insert($KPI_plan_arr);
                }

            }   // end - store foreach

        endfor;  // end - month(s) loop

        // success statement...
        echo "KPI Revenue data loaded successfully...";
    }
    

    // function to get value range based on KPI-ID...
    public function getKPIRange($kpi_ID) {

        $MIN = $MAX = 0;
        switch($kpi_ID) {
            case 1: $MIN = 15000;
                    $MAX = 40000;
                    break;
            case 2: $MIN = 65;
                    $MAX = 74;
                    break;
            case 3: $MIN = 15000;
                    $MAX = 55000;
                    break;
            case 4: $MIN = 14;
                    $MAX = 30;
                    break;
            case 5: $MIN = 25;
                    $MAX = 95;
                    break;
            case 6: $MIN = 35;
                    $MAX = 95;
                    break;
            case 7: $MIN = 35000;
                    $MAX = 56000;
                    break;
            case 10: $MIN = 0;
                    $MAX = 10;
                    break;
            default: $MIN = 10000;
                     $MAX = 80000;
                     break;
        }

        $return_arr = array('min'=>$MIN,
                            'max'=>$MAX);
        
        return $return_arr;
    }

    
    // NEW - random Balance-Sheet data insertion...
    public function loadAllBalanceSheets() {
    
    	# 1st, empty the existing data...
    	$master_bsheet_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
    	$bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
    	$emptySQL1 = sprintf("TRUNCATE %s ", $master_bsheet_tbl);
    	$emptySQL2 = sprintf("TRUNCATE %s ", $bsheet_inputs_tbl);
    
    	/*\DB::statement($emptySQL1);
    	 \DB::statement($emptySQL2);*/
    
    
    	/// NEW - for date-range [Begin]
    	$MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
    	$MAX_DT = date("Y-m-d");
    	/// NEW - for date-range [End]
    
    	# II: preload few required value(s) like Year, Month, Logged-User-ID...
    	$LOGGED_USR = \Session::get('user_id');
    	$LOGGED_USR_TYPE = \Session::get('user_type');
    	$year = date('Y', strtotime("-1 year"));
    
    	$stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);
    
    	# III: Now, looping through all store(s) under the franchisor-admin...
    	for($month=1; $month<=12; $month++) :   // begin - month(s) loop
    
    	foreach($stores_arr as $key=>$storeID) {   // begin - store foreach
    
    		$BSHEET_LOCKED = 0;
    		
    		
    		# 1st, check if data already there for that month, year & store-ID...
    		$ret_ = null;
    		$chkSQL = sprintf("SELECT COUNT(*) AS `counter` FROM %s
    						   WHERE
    						   		`i_store_id`=%d AND
    								`i_month`=%d AND
    								`i_year`=%d ",
    						   $master_bsheet_tbl, $storeID, $month, $year);
    		$ret_ = \DB::select(\DB::raw($chkSQL));
    		
    		if( empty($ret_[0]->counter) ) {
	    
	    		$ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
	    
	    		# IV-A: insert into master table 1st i.e. "_income_stmt_master"...
	    		$master_data_arr = array();
	    		$master_data_arr['i_user_id'] = $LOGGED_USR;
	    		$master_data_arr['i_store_id'] = $storeID;
	    		$master_data_arr['i_month'] = $month;
	    		$master_data_arr['i_year'] = $year;
	    		$master_data_arr['dt_added'] = $ADD_DT_TIME;
	    		$master_data_arr['i_locked'] = $BSHEET_LOCKED;
	    
	    		$BSHEET_ID = \DB::table($master_bsheet_tbl)
	    		->insertGetId($master_data_arr);
	    
	    		# II-B: insert into income-statement input(s) i.e. "_income_stmt_inputs"...
	    		$bsheet_arr = array();
	    		$bsheet_arr['i_balance_sheet_id'] = $BSHEET_ID;
	    		$bsheet_arr['d_bs_11101'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_11102'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_11200'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_11300'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_11401'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_11402'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_12000'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_13000'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_21101'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_21102'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_21104'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_22000'] = mt_rand(1000, 2000);
	    		$bsheet_arr['d_bs_30000'] = mt_rand(1000, 2000);
	    		
	    		//// Total Field(s)
	    		$bsheet_arr['d_bs_11100'] = ($bsheet_arr['d_bs_11101'] + $bsheet_arr['d_bs_11102']);
	    		$bsheet_arr['d_bs_11400'] = ($bsheet_arr['d_bs_11401'] + $bsheet_arr['d_bs_11402']);
	    		$bsheet_arr['d_bs_11000'] = ($bsheet_arr['d_bs_11100'] + $bsheet_arr['d_bs_11200'] + $bsheet_arr['d_bs_11300'] + $bsheet_arr['d_bs_11400']);
	    		$bsheet_arr['d_bs_10000'] = ($bsheet_arr['d_bs_11000'] + $bsheet_arr['d_bs_12000'] + $bsheet_arr['d_bs_13000']);
	    		$bsheet_arr['d_bs_21000'] = ($bsheet_arr['d_bs_21101'] + $bsheet_arr['d_bs_21102'] + $bsheet_arr['d_bs_21104']);
	    		$bsheet_arr['d_bs_20000'] = ($bsheet_arr['d_bs_21000'] + $bsheet_arr['d_bs_22000'] + $bsheet_arr['d_bs_30000']);
	    		
	    		//// New Field(s)...
	    		$bsheet_arr['d_labor_hours'] = mt_rand(100, 500);
	    		
	    		 
	    		\DB::table($bsheet_inputs_tbl)
	    		->insert($bsheet_arr);
	    		
    		}	// end record exists check...
    
    	}   // end - store foreach
    
    	endfor; // end - month(s) loop
    
    
    	// success statement...
    	echo "Balance-Sheet data loaded successfully...";
    }
    
    
    
    
}
