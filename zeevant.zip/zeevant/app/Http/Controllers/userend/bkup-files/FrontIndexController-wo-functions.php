<?php

namespace App\Http\Controllers\userend;

use App\Http\Controllers\interfaces\userend\DashboardChartGeneratorInterface;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility as utils;
use App\Helpers\UsersHelper as usr_Helper;

use App\Models\KPIModel as model_KPI;
use App\Models\IncomeStmtModel as model_IStmt;

use App\Models\CumulativeModel as model_Curv;
use App\Models\DailyTicketModel as model_Tkt;
use App\Models\DailyGrossMarginModel as model_Grm;
use App\Models\DailyDiscountModel as model_Dsc;
use App\Models\DailyProductMixModel as model_Pmx;
use App\Models\DailyTimeofdayModel as model_Tod;

class FrontIndexController extends BaseController implements \App\Http\Controllers\interfaces\userend\DashboardChartGeneratorInterface
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Welcome to Zeevant - Your Dashboard ::';
        $this->data['selected_menu'] = 'dashboard';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        # logged-in user-id & type...
        $LOGGED_USR_ID = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');


        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #               Benchmark Chart(s) Related [Begin]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            // Date-Time related data...
            $dt_time_arr = array();
            $dt_time_arr['month'] = date('m', strtotime("first day of previous month"));
            $dt_time_arr['year'] = date('Y', strtotime("first day of previous month"));

            # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

            //// 1: REVENUE...
                $data['js_arr_revenue'] = $this->generateRevenueChartData($dt_time_arr,
                                                                          $store_ids);
            //// 2: GROSS-MARGIN...
                $data['js_arr_gross_margin'] = $this->generateGrossMarginChartData($dt_time_arr,
                                                                                   $store_ids);
            //// 3: INTERNET-SALES...
                $data['js_arr_internet_sales'] = $this->generateInternetSalesChartData($dt_time_arr,
                                                                                       $store_ids);
            //// 4: AVERAGE-TICKET...
                $data['js_arr_average_tkt'] = $this->generateAvgTicketChartData($dt_time_arr,
                                                                                $store_ids);

            //// 5: MARKETING (% OF SALES)...
                $data['js_arr_mktg_percent'] = $this->generateMarketingPercentChartData($dt_time_arr,
                                                                                        $store_ids);

            //// 6: LABOR EFFICIENCY...
                $data['js_arr_labor_efficiency'] = $this->generateLaborEfficiencyChartData($dt_time_arr,
                                                                                           $store_ids);

            //// 7: INVENTORY TURNS...
                $data['js_arr_inventory_turns'] = $this->generateInventoryTurnsChartData($dt_time_arr,
                                                                                         $store_ids);

            //// 8: DISCOUNTS %...
                $data['js_arr_discounts_percent'] = $this->generateDiscountsPercentChartData($dt_time_arr,
                                                                                             $store_ids);

            # Default Load "Benchmark-Month-Scroller"
                $data['BM_default_month_scroller_dt'] = date('M y', strtotime("first day of previous month"));

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #               Benchmark Chart(s) Related [End]
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        # ====================================================================
        #               Daily-Scoop Chart(s) Related [Begin]
        # ====================================================================

            // Date-Time related data...
            $dt_time_arr = array();
            /*$dt_time_arr['date'] = date('d');
            $dt_time_arr['month'] = date('m');
            $dt_time_arr['year'] = date('Y');*/
            
            $dt_time_arr['current_date'] = date('d');
            $dt_time_arr['current_month'] = date('m');
            $dt_time_arr['current_year'] = date('Y');
            
            /*$dt_time_arr['current_date'] = '30';
            $dt_time_arr['current_month'] = '12';
            $dt_time_arr['current_year'] = '2015';*/


            # Default Load "Daily-Scoop Month-Scroller"
            $data['DS_default_month_scroller_dt'] = date('d M y');

            $data['ds_js_cu_data'] = $this->generateDSCumulativeChartData($dt_time_arr,$store_ids);
            $data['ds_js_ti_data'] = $this->generateDSTicketChartData($dt_time_arr,$store_ids);
            $data['ds_js_gm_data'] = $this->generateDSGrossmarginChartData($dt_time_arr,$store_ids);
            $data['ds_js_dt_data'] = $this->generateDSDiscountChartData($dt_time_arr,$store_ids);
            $data['ds_js_tod_data'] = $this->generateDSTimeofdayChartData($dt_time_arr,$store_ids);
            
            
            $data['ds_js_tf_data'] = $this->generateDSTop5ChartData($dt_time_arr,$store_ids);           
            $data['ds_js_pmr_data'] = $this->generateDSProductmixRevenueChartData($dt_time_arr,$store_ids);
            $data['ds_js_pmc_data'] = $this->generateDSProductmixContributionChartData($dt_time_arr,$store_ids);
        # ====================================================================
        #               Daily-Scoop Chart(s) Related [End]
        # ====================================================================

        # show view part...
        return view('userend.dashboard.dashboard', $data);
    }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Miscellaneous [Begin]
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # just to get server-info...
        public function server_info() {
            phpinfo();
        }




        # NEW - Load Dashboard Chart(s) Data - Benchmark Data [AJAX CALL]...
        public function loadDashboardBenchmarkDataAJAX(Request $request) {


            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                $this->generateBMCharts($request);

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               Benchmark Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # load view part...
            $HTML = \View::make('userend.dashboard.ajax-parts.load-dashboard-BM-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                                   'html_content'  => $HTML));
            exit;

        }


        # NEW - Load Dashboard Chart(s) Data - DS Data [AJAX CALL]...
        public function loadDashboardDailyScoopDataAJAX(Request $request) {


            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               DS Chart(s) Related [Begin]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            $this->generateDSCharts($request);

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            #               DS Chart(s) Related [End]
            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # load view part...
            $HTML = \View::make('userend.dashboard.ajax-parts.load-dashboard-DS-data-AJAX', $this->data)->render();

            echo json_encode(array('result'        => 'success',
                'html_content'  => $HTML));
            exit;

        }



        # NEW - Load Whole Dashboard Data - Benchmark, Daily-Scoop & ZReport Data [AJAX CALL]...
        public function loadDashboardDataAJAX(Request $request) {

            //// I : BENCHMARK CHART(S)
                # IA: Generate Benchmark Chart(s) with specific data...
                    $this->generateBMCharts($request);

                # IB: load Benchmark Chart(s) view-part...
                $BM_HTML = \View::make('userend.dashboard.ajax-parts.load-dashboard-BM-data-AJAX', $this->data)->render();


            //// II : DAILY-SCOOP CHART(S)
                # IIA: Generate Daily-Scoop Chart(s) with specific data...
                $this->generateDSCharts($request);

                # IIB: load Daily-Scoop Chart(s) view-part...
                $DS_HTML = \View::make('userend.dashboard.ajax-parts.load-dashboard-DS-data-AJAX', $this->data)->render();



            //// III : Z-REPORT
                # IIIA: Load Z-Report with specific data...
                $this->loadZReport($request);

                # IIIB: load Z-Report view-part...
                $ZR_HTML = \View::make('userend.dashboard.ajax-parts.load-dashboard-zreport-data-AJAX', $this->data)->render();


            echo json_encode(array('result'           => 'success',
                                   'html_exists'      => true,
                                   'BM_html_content'  => $BM_HTML,
                                   'DS_html_content'  => $DS_HTML,
                                   'ZR_html_content'  => $ZR_HTML));
            exit;

        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #       Miscellaneous [End]
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



    # =============================================================
    #           Generate Chart(s) - Begin
    # =============================================================

        //// Generate Benchmark Chart(s)
        public function generateBMCharts(Request $request) {

            try {

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');


                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Benchmark Chart(s) Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    # retrieving submitted value(s)...
                        // Date-Time related data...
                        $dt_time_arr = array();
                        $dt_time_arr['month'] = $request->input('BM_month_val');
                        $dt_time_arr['year'] = $request->input('BM_yr_val');

                        // for Store-ID(s) [either a particular store or chain of store(s)]
                        $store_ids = $request->input('store_id');
                        if( $store_ids==-1 )
                            $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                    //// for Revenue-Data [Begin]

                        //// 1: REVENUE...
                        $this->data['js_arr_revenue'] = $this->generateRevenueChartData($dt_time_arr,
                                                                                  $store_ids);
                        //// 2: GROSS-MARGIN...
                        $this->data['js_arr_gross_margin'] = $this->generateGrossMarginChartData($dt_time_arr,
                                                                                           $store_ids);
                        //// 3: INTERNET-SALES...
                        $this->data['js_arr_internet_sales'] = $this->generateInternetSalesChartData($dt_time_arr,
                                                                                               $store_ids);
                        //// 4: AVERAGE-TICKET...
                        $this->data['js_arr_average_tkt'] = $this->generateAvgTicketChartData($dt_time_arr,
                                                                                        $store_ids);
                        //// 5: MARKETING (% OF SALES)...
                        $this->data['js_arr_mktg_percent'] = $this->generateMarketingPercentChartData($dt_time_arr,
                                                                                        $store_ids);

                        //// 6: LABOR EFFICIENCY...
                        $this->data['js_arr_labor_efficiency'] = $this->generateLaborEfficiencyChartData($dt_time_arr,
                                                                                        $store_ids);

                        //// 7: INVENTORY TURNS...
                        $this->data['js_arr_inventory_turns'] = $this->generateInventoryTurnsChartData($dt_time_arr,
                                                                                        $store_ids);

                        //// 8: DISCOUNTS %...
                        $this->data['js_arr_discounts_percent'] = $this->generateDiscountsPercentChartData($dt_time_arr,
                                                                                        $store_ids);

                    //// for Revenue-Data [End]

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Benchmark Chart(s) Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


        //// Generate Daily-Scoop Chart(s)
        public function generateDSCharts(Request $request) {

            try {

                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');


                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Daily-Scoop Chart(s) Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                // Date-Time related data...
                $dt_time_arr = array();
                /*$dt_time_arr['date'] = $request->input('DS_date_val');
                $dt_time_arr['month'] = $request->input('DS_month_val');
                $dt_time_arr['year'] = $request->input('DS_yr_val');*/
                
                $dt_time_arr['current_date'] = $request->input('DS_date_val');
                $dt_time_arr['current_month'] = $request->input('DS_month_val');
                $dt_time_arr['current_year'] = $request->input('DS_yr_val');


                //// for Daily-Scoop-Data [Begin]

                // for Store-ID(s) [either a particular store or chain of store(s)]
                $store_ids = $request->input('store_id');
                if( $store_ids==-1 )
                    $store_ids = usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                ###1 Cumulative    
                $this->data['ds_js_cu_data'] = $this->generateDSCumulativeChartData($dt_time_arr,$store_ids);
                
                ###2 Ticket
                $this->data['ds_js_ti_data'] = $this->generateDSTicketChartData($dt_time_arr,$store_ids);
                
                ###3 Gross Margin
                $this->data['ds_js_gm_data'] = $this->generateDSGrossmarginChartData($dt_time_arr,$store_ids);
                
                ###4 Discount
                $this->data['ds_js_dt_data'] = $this->generateDSDiscountChartData($dt_time_arr,$store_ids);
                
                ###5 TimeofDay
                $this->data['ds_js_tod_data'] = $this->generateDSTimeofdayChartData($dt_time_arr,$store_ids);
                
                ###8 
                $this->data['ds_js_tf_data'] = $this->generateDSTop5ChartData($dt_time_arr,$store_ids);
                
                ###9
                $this->data['ds_js_pmr_data'] = $this->generateDSProductmixRevenueChartData($dt_time_arr,$store_ids);            
                ###10
                $this->data['ds_js_pmc_data'] = $this->generateDSProductmixContributionChartData($dt_time_arr,$store_ids);
                 
                //// for Daily-Scoop-Data [End]

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Daily-Scoop Chart(s) Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }



    //// Load Z-Report
        public function loadZReport(Request $request) {

            try {
                
                $ZREPORT_DATA_ARR = array();
                $SELECTED_STORE = $request->input('store_id');

                if( $SELECTED_STORE!=-1 ) {
                    # I: z-report table data...
                    $ZREPORT_DATA_ARR = $this->loadZReportTableDataAJAX($request);
                }

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Z-Report Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    $this->data['data_tbl_arr'] = $ZREPORT_DATA_ARR;

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               Z-Report Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }


        //// Z-Report Data [AJAX Call]...
        public function loadZReportTableDataAJAX(Request $request) {

            try {

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               DS Chart(s) Related [Begin]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                # retrieving submitted value(s)...
                // Date-Time related data...
                $PARAM_DT = date('Y-m-d', strtotime("previous day"));
                #$PARAM_DT = date('Y-m-d', mktime(0, 0, 0, 12, 15, 2015));

                // for Store-ID(s)
                $PARAM_STORE = $request->input('store_id');


                # calling stored-routine (or any)...
                $arr = $this->formZReportDataArray($PARAM_STORE, $PARAM_DT);

                return $arr;

                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                #               DS Chart(s) Related [End]
                # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }

        # function to get ZReport-DATA...
        public function formZReportDataArray($param_store=null, $param_dt=null) {

            try {
                $return_arr = array();

                # Stored-Routine Call [Begin]
                    $SQL = sprintf("CALL zev_ds_zreport('%d','%s')", $param_store, $param_dt);
                    $return_data = \DB::select(\DB::raw($SQL));
                # Stored-Routine Call [End]

                $return_arr = $this->prepareZReportDBReturnArray($return_data);
                # utils::dump($return_arr);

                return $return_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
        }

        # function to prepare return-array format form db-results...
        public function prepareZReportDBReturnArray($db_result_obj=null) {

            try {

                $RETURN_ARR = null;
                if( !empty($db_result_obj) ) {
                    $LOOP_INDEX  = 0;

                    # utils::dump($db_result_obj);
                    foreach($db_result_obj as $row_obj) {
                        $RETURN_ARR[$LOOP_INDEX]['s_description'] = $row_obj->s_description;
                        $RETURN_ARR[$LOOP_INDEX]['d_value'] = $row_obj->d_value;
                        $RETURN_ARR[$LOOP_INDEX]['s_instruction'] = $row_obj->s_instruction;

                        $LOOP_INDEX++;
                    }

                }   // end - if


                return $RETURN_ARR;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }



    # =============================================================
    #           Generate Chart(s) - End
    # =============================================================




    # *************************************************************
    #           Benchmark Chart Generator(s) - Begin
    # *************************************************************

        //// Chart 1: "Internet Sales"...
        public function generateRevenueChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...
                $COLUMN_ID = 'd_net_income';
                $COLUMN_ALIAS = 'net_income';

                // "Actual KPI" data...
                $actual_data = $IStmt_model->getFieldData($COLUMN_ID,
                                                          $COLUMN_ALIAS,
                                                          $store_ids,
                                                          $dt_time_arr);

                // "System-Average KPI" data (this is for All-Stores)...
                if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                    $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                else
                    $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                $sys_avg_data = $IStmt_model->getFieldData($COLUMN_ID,
                                                           $COLUMN_ALIAS,
                                                           $all_store_ids,
                                                           $dt_time_arr,
                                                           'AVG');

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($actual_data),
                        2 => '#88D2B7',
                        3 => floatval($actual_data)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($sys_avg_data),
                        2 => '#C4BF49',
                        3 => floatval($sys_avg_data)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Revenue";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }



        //// Chart 2: "Gross Margin"...
        public function generateGrossMarginChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Gross Margin"...
                $KPI_ID = 2;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...

                // "Actual KPI" data...
                    $COLUMN_ID = 'd_is_50000';
                    $COLUMN_ALIAS = 'total_COGS';

                    $SUM_OF_COGS = $IStmt_model->getFieldData($COLUMN_ID,
                                                              $COLUMN_ALIAS,
                                                              $store_ids,
                                                              $dt_time_arr);

                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    // "Actual KPI" data...
                    $MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                    $COLUMN_ALIAS,
                                                                    $store_ids,
                                                                    $dt_time_arr);

                    $ACTUAL_GROSS_MARGIN_DATA = ( !empty(intval($MERCHANDISE_SALES)) )
                                                ? utils::formatNum(1-($SUM_OF_COGS/$MERCHANDISE_SALES)): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                    if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                        $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                    else
                        $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                    $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                    $COLUMN_ID = 'd_is_50000';
                    $COLUMN_ALIAS = 'total_COGS';

                    $AVG_SUM_OF_COGS = $IStmt_model->getFieldData($COLUMN_ID,
                                                                  $COLUMN_ALIAS,
                                                                  $all_store_ids,
                                                                  $dt_time_arr,
                                                                  'AVG');

                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    $AVG_MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                        $COLUMN_ALIAS,
                                                                        $all_store_ids,
                                                                        $dt_time_arr,
                                                                        'AVG');

                    $SYS_AVG_GROSS_MARGIN_DATA = ( !empty(intval($AVG_MERCHANDISE_SALES)) )
                                                 ? utils::formatNum(1-($AVG_SUM_OF_COGS/$AVG_MERCHANDISE_SALES)): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_GROSS_MARGIN_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_GROSS_MARGIN_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_GROSS_MARGIN_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_GROSS_MARGIN_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Gross Margin";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }



        //// Chart 3: "Internet Sales"...
        public function generateInternetSalesChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Internet Sales"...
                $KPI_ID = 3;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...
                    $COLUMN_ID = 'd_is_40200';
                    $COLUMN_ALIAS = 'internet_sales';

                // "Actual KPI" data...
                $actual_data = $IStmt_model->getFieldData($COLUMN_ID,
                                                          $COLUMN_ALIAS,
                                                          $store_ids,
                                                          $dt_time_arr);

                // "System-Average KPI" data (this is for All-Stores)...
                if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                    $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                else
                    $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                $sys_avg_data = $IStmt_model->getFieldData($COLUMN_ID,
                                                           $COLUMN_ALIAS,
                                                           $all_store_ids,
                                                           $dt_time_arr,
                                                           'AVG');

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($actual_data),
                        2 => '#88D2B7',
                        3 => floatval($actual_data)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($sys_avg_data),
                        2 => '#C4BF49',
                        3 => floatval($sys_avg_data)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Internet Sales";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }


        //// Chart 4: "Average-Ticket"...
        public function generateAvgTicketChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Average-Ticket"...
                $KPI_ID = 4;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...
                $COLUMN_ID = 'd_is_40100';
                $COLUMN_ALIAS = 'merchandise_sales';

                // "Actual KPI" data...
                $actual_merchandise_sales = $IStmt_model->getFieldData($COLUMN_ID,
                                                                       $COLUMN_ALIAS,
                                                                       $store_ids,
                                                                       $dt_time_arr);

                $TKT_COUNT = usr_Helper::getDaysalesTicketCount($store_ids, $dt_time_arr);

                $ACTUAL_DATA = ( !empty($TKT_COUNT) )
                               ? utils::formatNum($actual_merchandise_sales/$TKT_COUNT): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                    $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                else
                    $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                $sys_avg_merchandise_sales = $IStmt_model->getFieldData($COLUMN_ID,
                                                                        $COLUMN_ALIAS,
                                                                        $all_store_ids,
                                                                        $dt_time_arr,
                                                                        'AVG');
                $TKT_COUNT = usr_Helper::getDaysalesTicketCount($all_store_ids, $dt_time_arr);

                $SYS_AVG_DATA = ( !empty($TKT_COUNT) )
                                ? utils::formatNum($sys_avg_merchandise_sales/$TKT_COUNT): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Internet Sales";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }



        //// Chart 5: "Marketing (% of sales)"...
        public function generateMarketingPercentChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Marketing (% of sales)"...
                $KPI_ID = 5;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                    $store_ids,
                    $dt_time_arr);


                // For "Actual" & "System-Average"...

                // "Actual KPI" data...
                    $COLUMN_ID = 'd_is_60100';
                    $COLUMN_ALIAS = 'adv_n_promotion';

                    $ACTUAL_ADV_N_PROMOTION = $IStmt_model->getFieldData($COLUMN_ID,
                                                                         $COLUMN_ALIAS,
                                                                         $store_ids,
                                                                         $dt_time_arr);

                    $COLUMN_ID = 'd_net_income';
                    $COLUMN_ALIAS = 'net_income';

                    $ACTUAL_NET_INCOME = $IStmt_model->getFieldData($COLUMN_ID,
                                                                    $COLUMN_ALIAS,
                                                                    $store_ids,
                                                                    $dt_time_arr);

                    $ACTUAL_MARKETING_PERCENT_DATA = ( !empty(intval($ACTUAL_NET_INCOME)) )
                                                     ? utils::formatNum($ACTUAL_ADV_N_PROMOTION/$ACTUAL_NET_INCOME): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                    if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                        $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                    else
                        $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                    $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                    $COLUMN_ID = 'd_is_60100';
                    $COLUMN_ALIAS = 'total_COGS';

                    $AVG_ADV_N_PROMOTION = $IStmt_model->getFieldData($COLUMN_ID,
                                                                      $COLUMN_ALIAS,
                                                                      $all_store_ids,
                                                                      $dt_time_arr,
                                                                      'AVG');

                    $COLUMN_ID = 'd_net_income';
                    $COLUMN_ALIAS = 'net_income';

                    $AVG_NET_INCOME = $IStmt_model->getFieldData($COLUMN_ID,
                                                                 $COLUMN_ALIAS,
                                                                 $all_store_ids,
                                                                 $dt_time_arr,
                                                                 'AVG');

                    $SYS_AVG_MARKETING_PERCENT_DATA = ( !empty(intval($AVG_NET_INCOME)) )
                                                      ? utils::formatNum($AVG_ADV_N_PROMOTION/$AVG_NET_INCOME): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_MARKETING_PERCENT_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_MARKETING_PERCENT_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_MARKETING_PERCENT_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_MARKETING_PERCENT_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Marketing (% of Sales)";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }


        //// Chart 6: "Labor Efficiency"...
        public function generateLaborEfficiencyChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Labor Efficiency"...
                $KPI_ID = 6;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...

                // "Actual KPI" data...
                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    $ACTUAL_MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                           $COLUMN_ALIAS,
                                                                           $store_ids,
                                                                           $dt_time_arr);

                    $ACTUAL_HOURS = usr_Helper::getMyInputsHourCount($store_ids, $dt_time_arr);

                    $ACTUAL_LABOR_EFFICIENCY_DATA = ( !empty(intval($ACTUAL_HOURS)) )
                                                    ? (utils::formatNum($ACTUAL_MERCHANDISE_SALES/$ACTUAL_HOURS)): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                    if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                        $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                    else
                        $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                    $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);
                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    $AVG_MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                        $COLUMN_ALIAS,
                                                                        $all_store_ids,
                                                                        $dt_time_arr,
                                                                        'AVG');

                    $AVG_HOURS = usr_Helper::getMyInputsHourCount($all_store_ids, $dt_time_arr);

                    $SYS_AVG_LABOR_EFFICIENCY_DATA = ( !empty(intval($AVG_HOURS)) )
                                                     ? utils::formatNum($AVG_MERCHANDISE_SALES/$AVG_HOURS): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_LABOR_EFFICIENCY_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_LABOR_EFFICIENCY_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_LABOR_EFFICIENCY_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_LABOR_EFFICIENCY_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Marketing (% of Sales)";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }


        //// Chart 7: "Inventory Turns"...
        public function generateInventoryTurnsChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Inventory Turns"...
                $KPI_ID = 7;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                           $store_ids,
                                                           $dt_time_arr);


                // For "Actual" & "System-Average"...

                // "Actual KPI" data...
                    $COLUMN_ID = 'd_is_50000';
                    $COLUMN_ALIAS = 'total_COGS';

                    $ACTUAL_COGS = $IStmt_model->getFieldData($COLUMN_ID,
                                                              $COLUMN_ALIAS,
                                                              $store_ids,
                                                              $dt_time_arr);

                    $COLUMN_ID = 'd_is_50400';
                    $COLUMN_ALIAS = 'inventory';    // Freight In - Inventory Purchases

                    $ACTUAL_INVENTORY = $IStmt_model->getFieldData($COLUMN_ID,
                                                                   $COLUMN_ALIAS,
                                                                   $store_ids,
                                                                   $dt_time_arr);

                    $ACTUAL_INVENTORY_TURNS_DATA = ( !empty(intval($ACTUAL_INVENTORY)) )
                                                   ? utils::formatNum(($ACTUAL_COGS/$ACTUAL_INVENTORY)*12): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                    if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                        $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                    else
                        $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                    $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);

                    $COLUMN_ID = 'd_is_50000';
                    $COLUMN_ALIAS = 'total_COGS';

                    $AVG_COGS = $IStmt_model->getFieldData($COLUMN_ID,
                                                           $COLUMN_ALIAS,
                                                           $all_store_ids,
                                                           $dt_time_arr,
                                                           'AVG');

                    $COLUMN_ID = 'd_is_50400';
                    $COLUMN_ALIAS = 'inventory';    // Freight In - Inventory Purchases

                    $AVG_INVENTORY = $IStmt_model->getFieldData($COLUMN_ID,
                                                                $COLUMN_ALIAS,
                                                                $store_ids,
                                                                $dt_time_arr,
                                                                'AVG');

                    $SYS_AVG_INVENTORY_TURNS_DATA = ( !empty(intval($AVG_INVENTORY)) )
                                                    ? utils::formatNum($AVG_COGS/$AVG_INVENTORY*12): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_INVENTORY_TURNS_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_INVENTORY_TURNS_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_INVENTORY_TURNS_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_INVENTORY_TURNS_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Marketing (% of Sales)";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }


        //// Chart 8: "Discounts %"...
        public function generateDiscountsPercentChartData($dt_time_arr=null, $store_ids=null) {

            try {
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Discounts %/Average Discount"...
                $KPI_ID = 10;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                            ? $store_ids
                            : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);

                # II: instantiating model(s)...
                $KPI_model = new model_KPI();
                $IStmt_model = new model_IStmt();

                # III: gathering Chart-Data...
                // "Planned KPI" data...
                $planned_data = $KPI_model->getKPIPlanData($KPI_ID,
                                                            $store_ids,
                                                            $dt_time_arr);


                // For "Actual" & "System-Average"...

                // "Actual KPI" data...
                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    $ACTUAL_MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                           $COLUMN_ALIAS,
                                                                           $store_ids,
                                                                           $dt_time_arr);

                    $ACTUAL_ERPLY_DISCOUNT = usr_Helper::getSummedDiscount($store_ids, $dt_time_arr);

                    $ACTUAL_DISCOUNT_PERCENT_DATA = ( !empty(intval(($ACTUAL_MERCHANDISE_SALES+$ACTUAL_ERPLY_DISCOUNT))) )
                                                    ? utils::formatNum($ACTUAL_ERPLY_DISCOUNT/($ACTUAL_MERCHANDISE_SALES+$ACTUAL_ERPLY_DISCOUNT)): 0;

                // "System-Average KPI" data (this is for All-Stores)...
                    if( $LOGGED_USR_TYPE!=2 )   // i.e. not a Franchisor-Admin
                        $FRANCHISOR_ADMIN_ID = usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID );
                    else
                        $FRANCHISOR_ADMIN_ID = $LOGGED_USR_ID;  // i.e. logged-in user is Franchisor-Admin himself
                    $FRANCHISOR_ADMIN_TYPE = 2; // fixed one

                    $all_store_ids = usr_Helper::getFranchiseesByUser($FRANCHISOR_ADMIN_ID, $FRANCHISOR_ADMIN_TYPE);

                    $COLUMN_ID = 'd_is_40100';
                    $COLUMN_ALIAS = 'merchandise_sales';

                    $AVG_MERCHANDISE_SALES = $IStmt_model->getFieldData($COLUMN_ID,
                                                                        $COLUMN_ALIAS,
                                                                        $all_store_ids,
                                                                        $dt_time_arr,
                                                                        'AVG');

                    $AVG_ERPLY_DISCOUNT = usr_Helper::getSummedDiscount($all_store_ids, $dt_time_arr);

                    $SYS_AVG_DISCOUNT_PERCENT_DATA = ( !empty(intval($AVG_MERCHANDISE_SALES+$AVG_ERPLY_DISCOUNT)) )
                                                     ? utils::formatNum($AVG_ERPLY_DISCOUNT/($AVG_MERCHANDISE_SALES+$AVG_ERPLY_DISCOUNT)): 0;

                # Finally, preparing the return array...
                $return_arr = null;

                if( !empty($planned_data) ) :
                    // Actual
                    $return_arr[] = array(
                        0 => 'Actual',
                        1 => floatval($ACTUAL_DISCOUNT_PERCENT_DATA),
                        2 => '#88D2B7',
                        3 => floatval($ACTUAL_DISCOUNT_PERCENT_DATA)
                    );

                    // Planned
                    $return_arr[] = array(
                        0 => 'Planned',
                        1 => floatval($planned_data),
                        2 => '#328FF7',
                        3 => floatval($planned_data)
                    );

                    // System-Average
                    $return_arr[] = array(
                        0 => 'System Average',
                        1 => floatval($SYS_AVG_DISCOUNT_PERCENT_DATA),
                        2 => '#C4BF49',
                        3 => floatval($SYS_AVG_DISCOUNT_PERCENT_DATA)
                    );
                endif;


                // form array for Google Chart(s)...
                $HEADER = "Discounts %";
                $chart_arr = json_encode($this->prepareDashboardChartsArray($return_arr, $HEADER));


                return $chart_arr;

            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

    # *************************************************************
    #           Benchmark Chart Generator(s) - End
    # *************************************************************
    
    
    
    ///////////////////////////////////////////////////////////////////////////
    // chart1
    public function generateDSCumulativechartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                
                $return_arr = array();
                $ret_previous_arr = array(); 
                $ret_target_arr = array();                
                $new_array = array();
                $arr = array();
                
                $last_cumulative = 0;
                $cumulative_previous_val = 0;
                $cumulative_target_val = 0;
                $cumulative_previous =0;
                
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Curv = new model_Curv();
                $return_arr = $model_Curv->getCumRevDetailsData($store_ids, $dt_time_arr);
                
                $ret_current = $return_arr['ret_current'];
                $ret_previous = $return_arr['ret_previous'];
                $ret_target = $return_arr['ret_target'];
                
               
                
                if(!empty($ret_target)){
                    foreach($ret_target as $val){                        
                        $ret_target_arr[$val->erplytrans_date] = (object)array('target_val'=>$val->target_sales);
                    }
                }               
                
                
                if(!empty($ret_previous)){
                    foreach($ret_previous as $val){
                        $ret_previous_arr[$val->erplytrans_date] = $val;
                    }
                }
                
              
                // sort in ascending order...
                /*if( !empty($RETURN_ARR) ) {
                    usort($RETURN_ARR, function($a, $b) {
                        return $a['revenue'] > $b['revenue'];
                    });
                }*/
                
                
                if(!empty($ret_current)){
                    
                    $array_length = count($ret_current);
                    if($array_length >0){
                        $prev_month = date('m',strtotime($ret_current[0]->erplytrans_date));
                    }
                    
                    foreach($ret_current as $ind=>$val){
                        
                        
                        /*$cur_month = date('m',strtotime($val->erplytrans_date));
                        if($prev_month != $cur_month){
                        $new_array[] = (object)array('erplytrans_date'=>0,'cumulative_current'=>0);
                        $prev_month = date('m',strtotime($RETURN_ARR[$ind]->erplytrans_date));
                        }                        
                        $new_array[] = $val;
                        */
                       
                        $previous_year_date =  date('Y-m-d', strtotime('-1 year', strtotime($val->erplytrans_date)));
                        
                        $cur_month = date('m',strtotime($val->erplytrans_date));
                        //$cur_date = date('N',strtotime($val->erplytrans_date));
                        $cumulative_previous += (!(empty($ret_previous_arr)) && array_key_exists($previous_year_date,$ret_previous_arr))?
                                                $ret_previous_arr[$previous_year_date]->cumulative_previous :
                                                $cumulative_previous_val;
                                                
                        $cumulative_target_val =  (!(empty($ret_target_arr)) && array_key_exists($val->erplytrans_date,$ret_target_arr))?
                                                $ret_target_arr[$val->erplytrans_date]->target_val : $cumulative_target_val;
                                                
                        $cumulative_default_val =  (!(empty($ret_target_arr)) && array_key_exists($val->erplytrans_date,$ret_target_arr))?
                                                $ret_target_arr[$val->erplytrans_date]->target_val : 0;                                               
                        
                        
                        if($prev_month != $cur_month){
                            //$arr[] = (object)array('erplytrans_date'=>null,'cumulative_current'=>null,'cumulative_previous'=>null,'cumulative_target'=>null);
                            $prev_month = date('m',strtotime($ret_current[$ind]->erplytrans_date));
                            $prev_index = $ind-1;
                            $last_cumulative = $ret_current[$prev_index]->cumulative_current;
                            $cumulative_target_val =$cumulative_default_val;
                            $arr[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current-$last_cumulative), 'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                        elseif($cur_month !=date('m',strtotime($ret_current[0]->erplytrans_date)) && $prev_month == $cur_month){
                            $arr[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current-$last_cumulative),
                            'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                        else{
                            $arr[] = (object)array('erplytrans_date'=>date('m/d',strtotime($val->erplytrans_date)),'cumulative_current'=>($val->cumulative_current),
                            'cumulative_previous'=>$cumulative_previous,'cumulative_target'=>$cumulative_target_val);
                        }
                    }
                }
                
                else{
                    $arr[] = (object)array('erplytrans_date'=>null,'cumulative_current'=>0,'cumulative_previous'=>$cumulative_previous_val,'cumulative_target'=>$cumulative_target_val);
                }
                

                
                    
                    //// For "Column" Chart(s) [Begin]
                        $return_arr = [['Date', 'Previous Revenues', 'Targetted Revenues', 'Revenues',  array('role' => 'style')]]; // for Header Array...
                        
                        
                        $count = 0;
                        $arr = array_reverse($arr);
                        
                        foreach($arr as $sorted_arr) {
                          
                            //$TOOLTIP = $sorted_arr->erplytrans_date ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#CC7878';
                            $cumulative_previous = is_null($sorted_arr->cumulative_previous)?null:floatval($sorted_arr->cumulative_previous);
                            $cumulative_target = is_null($sorted_arr->cumulative_target)?null:floatval($sorted_arr->cumulative_target);
                            $cumulative_current = is_null($sorted_arr->cumulative_current)?null:floatval($sorted_arr->cumulative_current);

                            $new_arr[] = array(
                                                    0 => $TOOLTIP,                                                    
                                                    1 => $cumulative_previous,
                                                    2 => $cumulative_target,
                                                    3 => $cumulative_current,
                                                    4 => $CHART_COLOR
                                                 );
                            
                           $count++;
                           if($count >7) break;                      
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                    
                        $new_arr = array_reverse($new_arr);                       
               
                 $return_arr = array_merge($return_arr,$new_arr);                 
                
                /*$data_cr= array( array('Days', 'Current', 'Previous', 'All'));
                if(!empty($data_cr) && !empty($datas['ret_current'])){
                    foreach($datas['ret_current'] as $ind=>$val){
                        if(!empty($datas['ret_pevious']) && array_key_exists($ind,$datas['ret_pevious'])){
                            $cumulative_previous = $datas['ret_previous'][$ind]->cumulative_previous;
                        }
                        else{
                            $cumulative_previous = 0;
                        }

                        if(!empty($datas['ret_all']) && array_key_exists($ind,$datas['ret_all'])){
                            $cumulative_all = $datas['ret_all'][$ind]->cumulative_all;
                        }
                        else{
                            $cumulative_all = 0;
                        }
                        $data_cr[]= array(0=>$val->erplytrans_date,1=>floatval($val->cumulative_current),2=>floatval($cumulative_previous),3=>floatval($cumulative_all));
                    }
                }
                else{
                    $data_cr[]= array(0=>0,1=>0,2=>0,3=>0);
                }*/
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }

        // chart2
        public function generateDSTicketchartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $new_arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Tkt = new model_Tkt();
                $arr = $model_Tkt->getCumRevDetailsData($store_ids, $dt_time_arr);
                
                
                $return_arr = [['Date', 'Avg Ticket',  array('role' => 'style')]]; // for Header Array...

                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        
                        $count = 0;
                        $arr = array_reverse($arr);
                        foreach($arr as $ind=>$sorted_arr) {
                          
                            //$TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#1790E1';   
                            $avg_tickets = is_null($sorted_arr->avg_tickets)?null:floatval($sorted_arr->avg_tickets);

                            $new_arr[] = array(
                                                    0 => $TOOLTIP,  
                                                    1 => $avg_tickets,
                                                    2 => $CHART_COLOR
                                                 );
                           $count++;
                           if($count >6) break;                      
                            
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                        
                        $new_arr = array_reverse($new_arr);
                        //$return_arr += $new_arr;
                        $return_arr = array_merge($return_arr,$new_arr); 
                    

                }   // end - if
                else{
                    $return_arr[]= array(0=>0,1=>0,2=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart3
        
        public function generateDSGrossmarginChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $new_arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Grm = new model_Grm();
                $arr = $model_Grm->getCumRevDetailsData($store_ids, $dt_time_arr);
                
                
                $return_arr = [['Date', 'Margin %',  array('role' => 'style')]]; // for Header Array...

                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        
                        $count = 0;
                        $arr = array_reverse($arr);
                        foreach($arr as $ind=>$sorted_arr) {
                          
                            //$TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#1790E1';   
                            $margin = is_null($sorted_arr->margin)?null:floatval($sorted_arr->margin);

                            $new_arr[] = array(
                                                    0 => $TOOLTIP,  
                                                    1 => $margin,
                                                    2 => $CHART_COLOR
                                                 );
                           $count++;
                           if($count >6) break;                      
                            
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                        
                        $new_arr = array_reverse($new_arr);
                        //$return_arr += $new_arr;
                        $return_arr = array_merge($return_arr,$new_arr); 
                    

                }   // end - if
                else{
                    $return_arr[]= array(0=>0,1=>0,2=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart4
        public function generateDSDiscountChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $new_arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Dsc = new model_Dsc();
                $arr = $model_Dsc->getDiscountMarchingProgressData($store_ids, $dt_time_arr);
                
                
                $return_arr = [['Date', 'Discount %',  array('role' => 'style')]]; // for Header Array...

                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        
                        $count = 0;
                        $arr = array_reverse($arr);
                        foreach($arr as $ind=>$sorted_arr) {
                          
                            //$TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $TOOLTIP = is_null($sorted_arr->erplytrans_date)?null:date('m/d',strtotime($sorted_arr->erplytrans_date));
                            $CHART_COLOR =  '#1790E1';   
                            $discount = is_null($sorted_arr->discount)?null:floatval($sorted_arr->discount);

                            $new_arr[] = array(
                                                    0 => $TOOLTIP,  
                                                    1 => $discount,
                                                    2 => $CHART_COLOR
                                                 );
                           $count++;
                           if($count >6) break;                      
                            
                        } // end - foreach
                        //// For "Column" Chart(s) [End]
                        
                        $new_arr = array_reverse($new_arr);
                        //$return_arr += $new_arr;
                        $return_arr = array_merge($return_arr,$new_arr); 
                    

                }   // end - if
                else{
                    $return_arr[]= array(0=>0,1=>0,2=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        
        // chart5
        public function generateDSTimeofdayChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $new_arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Tod = new model_Tod();
                $arr = $model_Tod->getCumRevDetailsData($store_ids, $dt_time_arr);
                
                
                $return_arr = [['Clock In', 'Employee Clock In', 'Total Sales']]; // for Header Array...

                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        
                        foreach($arr as $sorted_arr) {
                          
                           // $TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $CHART_COLOR =  '#CC7878';

                            $return_arr[] = array(
                                                    0 => $sorted_arr->clock_in,                                                    
                                                    1 => intval($sorted_arr->emp_clock_in),
                                                    2 => floatval($sorted_arr->total_sales),                                                   
                                                    //4 => $CHART_COLOR
                                                 );
                        } // end - foreach
                        //// For "Column" Chart(s) [End]

                }   // end - if
                else{
                    $return_arr[]= array(0=>0,1=>0,2=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        // chart8
        public function generateDSTop5ChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $new_arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
                             
                $model_Pmx = new model_Pmx();
                $arr = $model_Pmx->getTop10ProductData($store_ids, $dt_time_arr);                                
                
                
                $return_arr = [['Product Name', 'Seller %',  array('role' => 'style')]]; // for Header Array...

                if( !empty($arr) ) {
                    
                //print_r($arr);exit;
                    
                        //// For "Column" Chart(s) [Begin]
                        
                        $count = 0;
                        
                        foreach($arr as $ind=>$sorted_arr) {
                          
                            //$TOOLTIP = date('m/d',strtotime($sorted_arr->erplytrans_date)) ;
                            $TOOLTIP = $sorted_arr->product_name;
                            $CHART_COLOR =  '#3A7F3C';   
                            $amount = is_null($sorted_arr->top_seller_percentage)?null:floatval($sorted_arr->top_seller_percentage);

                            $return_arr[] = array(
                                                    0 => $TOOLTIP,  
                                                    1 => $amount,
                                                    2 => $CHART_COLOR
                                                 );
                           $count++;
                           if($count >4) break;                      
                            
                        } // end - foreach
                        //// For "Column" Chart(s) [End]  
                    

                }   // end - if
                else{
                    $return_arr[]= array(0=>0,1=>0,2=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        ///9
        public function generateDSProductmixRevenueChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
              
                $model_Pmx = new model_Pmx();
                $arr = $model_Pmx->getRevenueData($store_ids, $dt_time_arr);                                
                
                $return_arr = [['Product Group', 'Total Revenue']]; // for Header Array...

                if( !empty($arr) ) {               
                      
                        //// For "Pie" Chart(s) [Begin]
                        

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_sales = is_null($sorted_arr->total_sales)?null:floatval($sorted_arr->total_sales);

                            $return_arr[] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_sales,                                                   
                                                 );
                                                 
                       
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
                else{
                    $return_arr[]= array(0=>null,1=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
        
        ///10
        public function generateDSProductmixContributionChartData($dt_time_arr=null, $store_ids=null) {

            try {
                
                $return_arr = array();
                $arr = array();
                # logged-in user-id & type...
                $LOGGED_USR_ID = \Session::get('user_id');
                $LOGGED_USR_TYPE = \Session::get('user_type');

                # I: KPI-ID for "Revenue"...
                $KPI_ID = 1;

                # I: for ALL store(s) assigned to the logged-in user...
                $store_ids = ( !empty($store_ids) )
                             ? $store_ids
                             : usr_Helper::getFranchiseesByUser($LOGGED_USR_ID, $LOGGED_USR_TYPE);
                             
              
                $model_Pmx = new model_Pmx();
                $arr = $model_Pmx->getContributionData($store_ids, $dt_time_arr);

                $return_arr = [['Product Group', 'Total Contribution']]; // for Header Array...
                
                
                if( !empty($arr) ) {               
                    
                        //// For "Pie" Chart(s) [Begin]
                        

                        foreach($arr as $sorted_arr) {
                           
                            $tooltip = is_null($sorted_arr->product_group)?null:$sorted_arr->product_group;                           
                            $total_contribution = is_null($sorted_arr->total_contribution)?null:floatval($sorted_arr->total_contribution);

                            $return_arr[] = array(
                                                    0 => $tooltip,                                                    
                                                    1 => $total_contribution,                                                   
                                                 );
                        } // end - foreach
                        //// For "Pie" Chart(s) [End]
                    

                }   // end - if
                
                else{
                    $return_arr[]= array(0=>null,1=>0);
                }
                
                return json_encode($return_arr);
            
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }

        }
    ////////////////////////////////////////////////////////////////////////////



    # function to form Array-Data for Google-Graph...
    public function prepareDashboardChartsArray($arr=null, $header_fld) {

        try {
            $return_arr = null;

            //// For "Line" Chart [Begin]
            $return_arr = [['Params', "{$header_fld}", array('role' => 'style'), array('role' => 'annotation')]]; // for Header Array...

            if( !empty($arr) ) {

                foreach($arr as $data_arr) {

                    $return_arr[] = array(
                        0 => $data_arr[0],
                        1 => $data_arr[1],
                        2 => $data_arr[2],
                        3 => $data_arr[3]
                    );
                }   // end - foreach
                //// For "Line" Chart [End]

            } else {
                $return_arr[] = array(
                    0 => null,
                    1 => 0,
                    2 => null,
                    3 => 0
                );
            }   // end - if


            return $return_arr;

        } catch(Exception $err_obj) {
            show_error($err_obj->getMessage());
        }

    }



}