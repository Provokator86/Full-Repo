<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\Users as model_users;
use App\Helpers\Utility as utils;

class ManageFranchiseeUsersController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Manage Franchisee User(s) ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'franchisee-users';
    }


    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Franchisee-User(s) [Begin]
        $record_index = $page-1;
        $where_cond = ' WHERE `i_user_type`=4 AND `i_parent_userid`='. \Session::get('user_id');  // i.e. All Franchisee-User(s) of Logged-In Franchisee-User
        $usrModel = new model_users();
        $order_by = ' `i_id` DESC ';
        $records = $usrModel->fetchFranchiseeUserRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) && $page>1 ) {
            $page--;
            $record_index = $page-1;
            $records = $usrModel->fetchFranchiseeUserRecords($where_cond,
                                                            $record_index,
                                                            $data['settings_info']->i_items_per_page,
                                                            $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $usrModel->getTotalFranchiseeUserInfo($where_cond);
        // for fetching Franchisee-User(s) [End]

        $franchisee_users = new \App\Libraries\MyPaginator($records, $total_records,
                                                    $data['settings_info']->i_items_per_page,
                                                    route('franchisee-users'), $page);
        $data['franchisee_user_arr'] = $franchisee_users;
        #dd( franchisee_user_arr );
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('userend.franchisee.manage-franchisee-users', $data);
    }


    # function to delete selected franchisee...
    public function delete_franchisee_user_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $FRANCHISEE_USR_ID = intval( $request->input('franchisee_usr_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected franchisee data from table...
        $usrModel = new model_users();
        
        if( $usrModel->deleteFranchiseeUser($FRANCHISEE_USR_ID) ) {

			# successful message...
			$SUCCESS_MSG = "Franchisee-User deleted successfully.";

			# redirect message...
			#$REDIRECT_URL = url() ."/franchisee/manage-franchisee-users/{$CURRENT_PG_NDEX}";
			$REDIRECT_URL = url() ."/franchisee/franchisee-users/store-users";

			echo json_encode(array('result'=>'success',
								   'msg'=>$SUCCESS_MSG,
								   'redirect'=>$REDIRECT_URL));
				
		} else {
			
			# error message...
			$ERROR_MSG = "Some error happenned!!";

			echo json_encode(array('result'=>'error',
								   'msg'=>$ERROR_MSG));
		}

        exit(0);
    }
}
