<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Models\Users as model_usr;
use App\Helpers\UrlHelper;
use App\Helpers\Utility as utils;

class AddFieldExecutiveController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Add Field-Consultant ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'franchisee-users';
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        //// Page Specific Data [Begin]

        $usrModel = new model_usr();
        $WHERE_COND = " i_franchisor_id=". \Session::get('user_id');
        # 1: Fld. Consultant(s)
        $data['franchisee_arr'] = $usrModel->fetchFranchiseeRecords(" WHERE {$WHERE_COND} ");
        //// Page Specific Data [End]

        # show view part...
        return view('userend.franchisee.add-field-executive', $data);
    }


    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

    # function to validate form-submission [AJAX CALL]
    public function validate_field_executive_AJAX(Request $request)
    {
        // Error Messages for Required Fields...
        $err_flds = array();
        $REQD_FLD_MSG = ' required field';

        $required_fields = array('s_fld_username', 's_fld_passwd', 's_fld_email',
                                 's_fld_first_name');

        $email_flds = array('s_fld_email');

        // adjusting err-messages part accordingly...
        $arr_messages = array();

        ////////////// VALIDATION CHECKS - BEGIN //////////////

        # validation for singular fields (i.e. appearing once)...
        foreach($required_fields as $required_field) {

            if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                if( !in_array($required_field, $err_flds) )
                    $err_flds[] = $required_field;

                $arr_messages[$required_field] = $REQD_FLD_MSG;
            }

            if( $required_field == 's_fld_username')
            {
                if (\App\Models\Users::where('s_username', '=', \Input::get('s_fld_username'))->exists()) {
                    $arr_messages[$required_field] = ' already exists';
                    $err_flds[] = 's_fld_username';
                }

            }


        }

        # for Field-Consultant...
        if( !isset($_POST['i_fld_franchisee_id'])  ) {
            if( !in_array('i_fld_franchisee_id', $err_flds) )
                $err_flds[] = 'i_fld_franchisee_id';

            $arr_messages['i_fld_franchisee_id'] = $REQD_FLD_MSG;
        }



        # email address validate....
        foreach($email_flds as $email_fld) {

            if( $_POST[$email_fld]!='' ) {

                if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                    if( !in_array($email_fld, $err_flds) )
                        $err_flds[] = $email_fld;

                    $arr_messages[$email_fld] = ' invalid email-id';
                }

            }
        }


        # ADD NEW "FIELD-EXECUTIVE" [if no errors]...
        if( count($arr_messages)==0 ) {

            $this->add_field_executive_AJAX($request);
        }
        else   //// if error occurs...
        {
            // for success field(s)...
            $success_flds = array_diff($required_fields, $err_flds);
            $success_flds = array_values($success_flds);

            echo json_encode(array('result'       => 'error',
                                    'arr_messages' => $arr_messages,
                                    'success_flds' => $success_flds));
            exit;
        }
    }


    # function to Add New Field-Consultant [AJAX CALL]...
    public function add_field_executive_AJAX(Request $request) {

        $USR_TYPE = 3;

        //// Now, retrieving submitted/posted values [BEGIN]...
        $user_DB = new model_usr();

        # I: User Personal/Login Credentials...
        $usr_arr = array();
        $usr_arr['s_username']       = htmlspecialchars($request->input('s_fld_username', true), ENT_QUOTES, 'utf-8');
        $usr_passwd = trim( $request->input('s_fld_passwd', true) );
        $usr_arr['s_passwd']         = utils::get_salted_password($usr_passwd);
        $usr_arr['s_email']          = trim( $request->input('s_fld_email', true) );
        $usr_arr['i_franchisor_id']  = \Session::get('user_id');
        $usr_arr['i_parent_userid']  = \Session::get('user_id');
        $usr_arr['s_first_name']     = trim( $request->input('s_fld_first_name', true) );
        $usr_arr['s_last_name']      = trim( $request->input('s_fld_last_name', true) );
        $usr_arr['i_user_type']      = $USR_TYPE;
        $usr_arr['dt_added']         = utils::get_db_datetime();
        //// retrieving submitted/posted values [END]...

        
        //// NEW - for "single-store-owner" check [Begin]
        	$STORE_COUNT = 0;
        	$selected_franchisees = $request->input('i_fld_franchisee_id', true);
        	if( is_array($selected_franchisees) )
        		$STORE_COUNT = count($selected_franchisees);
        	$usr_arr['i_single_store_owner'] = ( $STORE_COUNT==1 )? 1: 0;
        //// NEW - for "single-store-owner" check [End]
        
        
        //// adding new data to users-master table...
        # 1: inserting into "_users" table...
        $usr_tbl = getenv('DB_PREFIX') .'users';
        $NEW_USR_ID = \DB::table($usr_tbl)
                            ->insertGetId($usr_arr);

        # 2: inserting into "franchisee_users" table...
        $franchisee_usr_arr = array();
        $franchisee_usr_arr['i_user_id'] = $NEW_USR_ID;
        $franchisee_usr_arr['dt_added']  = utils::get_db_datetime();


        $franchisee_usr_tbl = getenv('DB_PREFIX') .'franchisee_users';
        if( is_array($selected_franchisees) ) { // Fld. Consultants
        	
            foreach($selected_franchisees as $key=>$val) {
                $franchisee_usr_arr['i_franchisee_id'] = $val;

                \DB::table($franchisee_usr_tbl)
                    ->insert($franchisee_usr_arr);
            }

        } else {    // Franchisee User(s)
            $franchisee_usr_arr['i_franchisee_id'] = $selected_franchisees;

            \DB::table($franchisee_usr_tbl)
                ->insert($franchisee_usr_arr);
        }


        //// redirection URL...
        #$REDIRECT = url() ."/franchisee/manage-field-consultants";
        $REDIRECT = url() ."/franchisee/franchisee-users";

        # success message...
        $SUCCESS_MSG = "New Field-Consultant info added successfully";


        echo json_encode(array('result'=>'success',
                                'redirect'=>$REDIRECT,
                                'msg'=>$SUCCESS_MSG));
        exit;

    }
    // end of AJAX Add-Franchisor function...


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================

}
