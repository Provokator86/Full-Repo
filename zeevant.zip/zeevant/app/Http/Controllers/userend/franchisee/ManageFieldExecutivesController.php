<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\Users as model_users;
use App\Helpers\Utility as utils;

class ManageFieldExecutivesController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Manage Field-Consultant(s) ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'franchisee-users';
    }


    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Field-Executive(s) [Begin]
        $record_index = $page-1;
        $where_cond = ' WHERE `i_user_type`=3 AND `i_parent_userid`='. \Session::get('user_id');  // i.e. All Franchisee-User(s) of Logged-In Franchisee-User
        $usrModel = new model_users();
        $order_by = ' `i_id` DESC ';
        $records = $usrModel->fetchFranchiseeUserRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) && $page>1 ) {
            $page--;
            $record_index = $page-1;
            $records = $usrModel->fetchFranchiseeUserRecords($where_cond,
                                                             $record_index,
                                                             $data['settings_info']->i_items_per_page,
                                                             $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $usrModel->getTotalFranchiseeUserInfo($where_cond);
        // for fetching Franchisee-User(s) [End]

        $field_executives = new \App\Libraries\MyPaginator($records, $total_records,
                                                           $data['settings_info']->i_items_per_page,
                                                           route('field-executives'), $page);
        $data['field_executives_arr'] = $field_executives;
        #dd( field_executives_arr );
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('userend.franchisee.manage-field-executives', $data);
    }


    # function to delete selected field-executive...
    public function delete_field_executive_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $FLD_CONSULTANT_ID = intval( $request->input('fld_consultant_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected franchisee data from table...
        $usrModel = new model_users();
        
        if( $usrModel->deleteFranchiseeUser($FLD_CONSULTANT_ID) ) {

			# successful message...
			$SUCCESS_MSG = "Field-Consultant deleted successfully.";

			# redirect message...
			#$REDIRECT_URL = url() ."/franchisee/manage-field-consultants/{$CURRENT_PG_NDEX}";
			$REDIRECT_URL = url() ."/franchisee/franchisee-users";

			echo json_encode(array('result'=>'success',
								   'msg'=>$SUCCESS_MSG,
								   'redirect'=>$REDIRECT_URL));
				
		} else {
			
			# error message...
			$ERROR_MSG = "Some error happenned!!";

			echo json_encode(array('result'=>'error',
								   'msg'=>$ERROR_MSG));
		}

        exit(0);
    }
}
