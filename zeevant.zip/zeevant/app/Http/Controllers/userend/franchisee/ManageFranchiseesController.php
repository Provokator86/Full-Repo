<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\Users as model_users;
use App\Helpers\Utility as utils;

class ManageFranchiseesController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Manage Franchisees ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'manage-franchisees';
    }


    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Franchisor(s) [Begin]
        $record_index = $page-1;
        $where_cond = " WHERE `i_franchisor_id`=". \Session::get('user_id');  // i.e. All Franchisee(s) of the logged-in franchisor
        $usrModel = new model_users();
        $order_by = ' `i_id` DESC ';
        $records = $usrModel->fetchFranchiseeRecords($where_cond,
                                                     $record_index,
                                                     $data['settings_info']->i_items_per_page,
                                                     $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) && $page>1 ) {
            $page--;
            $record_index = $page-1;
            $records = $usrModel->fetchFranchiseeRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $usrModel->getTotalFranchiseeInfo($where_cond);
        // for fetching Franchisor(s) [End]

        $franchisees = new \App\Libraries\MyPaginator($records, $total_records,
                                                      $data['settings_info']->i_items_per_page,
                                                      route('franchisees'), $page);
        $data['franchisee_arr'] = $franchisees;
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('userend.franchisee.manage-franchisees', $data);
    }


    # function to delete selected franchisee...
    public function delete_franchisee_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $FRANCHISEE_ID = intval( $request->input('franchisee_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected franchisee data from table...
        $usrModel = new model_users();
        
        if( $usrModel->deleteFranchisee($FRANCHISEE_ID) ) {

			# successful message...
			$SUCCESS_MSG = "Franchisee deleted successfully.";

			# redirect message...
			$REDIRECT_URL = url() ."/franchisee/manage-franchisees/{$CURRENT_PG_NDEX}";

			echo json_encode(array('result'=>'success',
								   'msg'=>$SUCCESS_MSG,
								   'redirect'=>$REDIRECT_URL));
				
		} else {
			
			# error message...
			$ERROR_MSG = "Some error happenned!!";

			echo json_encode(array('result'=>'error',
								   'msg'=>$ERROR_MSG));
		}

        exit(0);
    }
}
