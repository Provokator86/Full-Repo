<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\Users as model_users;
use App\Helpers\Utility as utils;

class FranchiseeUsersController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Manage Franchisee-User(s) ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'franchisee-users';
    }


    // index function definition...
    public function index($usr_type=null) {

    	# Page-Specific Settings...
    	$data = $this->data;
    	
    	
    	# Records for pagination [Begin]
    	$page = ( empty($page) )? 1: $page;
    	
    	$data['usr_type_id'] = $USR_TYPE_ID = ( !empty($usr_type) )? 4: 3;
    	
    	// for fetching Field-Executive(s) [Begin]
    	$record_index = $page-1;
    	$where_cond = " WHERE `i_user_type`={$USR_TYPE_ID} AND `i_parent_userid`=". \Session::get('user_id');  // i.e. All Franchisee-User(s) of Logged-In Franchisee-User
    	$usrModel = new model_users();
    	$order_by = ' `i_id` DESC ';
    	$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
    			$record_index,
    			$data['settings_info']->i_items_per_page,
    			$order_by);
    	
    	# ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
    	if( empty($records) && $page>1 ) {
    		$page--;
    		$record_index = $page-1;
    		$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
    				$record_index,
    				$data['settings_info']->i_items_per_page,
    				$order_by);
    	}
    	# ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~
    	
    	
    	$total_records = $usrModel->getTotalFranchiseeUserInfo($where_cond);
    	// for fetching Franchisee-User(s) [End]
    	
    	$field_executives = new \App\Libraries\MyPaginator($records, $total_records,
    			$data['settings_info']->i_items_per_page,
    			route('field-executives'), $page);
    	$data['field_executives_arr'] = $field_executives;
    	#dd( field_executives_arr );
    	$data['current_page_index'] = $page;
    	# Records for pagination [End]
    	
    	# show view part...
        return view('userend.franchisee.franchisee-users-dashboard', $data);
    }

    
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # 			AJAX Function(s) - BEGIN
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    	// function to load field-consultant(s)...
    	public function load_field_consultants_AJAX(Request $request) {
    		
    		try {
    			
    			$data = $this->data;
    			
    			# ================================================================
  	 			# 			FIELD CONSULTANT(S) - BEGIN
    			# ================================================================
	    			
	    			# Records for pagination [Begin]
	    			$page = 1;
	    			
	    			// for fetching Field-Executive(s) [Begin]
	    			$record_index = $page-1;
	    			$where_cond = ' WHERE `i_user_type`=3 AND `i_parent_userid`='. \Session::get('user_id');  // i.e. All Franchisee-User(s) of Logged-In Franchisee-User
	    			$usrModel = new model_users();
	    			$order_by = ' `i_id` DESC ';
	    			$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
												    				 $record_index,
												    				 $data['settings_info']->i_items_per_page,
												    				 $order_by);
	    			
	    			# ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
	    			if( empty($records) && $page>1 ) {
	    				$page--;
	    				$record_index = $page-1;
	    				$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
											    						 $record_index,
											    						 $data['settings_info']->i_items_per_page,
											    						 $order_by);
	    			}
	    			# ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~
	    			
	    			
	    			$total_records = $usrModel->getTotalFranchiseeUserInfo($where_cond);
	    			// for fetching Franchisee-User(s) [End]
	    			
	    			$field_executives = new \App\Libraries\MyPaginator($records,
	    															   $total_records,
												    				   $data['settings_info']->i_items_per_page,
												    				   route('field-executives'), $page);
	    			$data['field_consultants_arr'] = $field_executives;
	    			$data['current_page_index'] = $page;
	    			# Records for pagination [End]
	    			
    			# ================================================================
    			# 			FIELD CONSULTANT(S) - END
    			# ================================================================
    			    
    			# load HTML listing...
    			$HTML = \View::make('userend.franchisee.ajax-parts.load-field-consultants-AJAX', $data)->render();
    			
    			# button part...
    			$BTN_HTML = '<button id="add-fld-consultant" class="btn btn-primary" type="button">Add Field-Consultant</button>';
    			 
    			echo json_encode(array('result'        => 'success',
    								   'html_content'  => $HTML,
    								   'btn_html'	   => $BTN_HTML));
    			exit;
    			 
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    		
    	}

    	// function to load franchisee-user(s)...
    	public function load_franchisee_users_AJAX(Request $request) {
    	
    		try {
    			 
    			$data = $this->data;
    			 
    			# ================================================================
    			# 			FRANCHISEE USER(S) - BEGIN
    			# ================================================================
    	
    			# Records for pagination [Begin]
    			$page = 1;
    	
    			// for fetching Franchisee-User(s) [Begin]
    			$record_index = $page-1;
    			$where_cond = ' WHERE `i_user_type`=4 AND `i_parent_userid`='. \Session::get('user_id');  // i.e. All Franchisee-User(s) of Logged-In Franchisee-User
    			$usrModel = new model_users();
    			$order_by = ' `i_id` DESC ';
    			$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
										    					 $record_index,
										    					 $data['settings_info']->i_items_per_page,
										    					 $order_by);
    	
    			# ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
    			if( empty($records) && $page>1 ) {
    				$page--;
    				$record_index = $page-1;
    				$records = $usrModel->fetchFranchiseeUserRecords($where_cond,
										    						 $record_index,
										    						 $data['settings_info']->i_items_per_page,
										    						 $order_by);
    			}
    			# ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~
    	
    	
    			$total_records = $usrModel->getTotalFranchiseeUserInfo($where_cond);
    			// for fetching Franchisee-User(s) [End]
    	
    			$field_executives = new \App\Libraries\MyPaginator($records,
											    					$total_records,
											    					$data['settings_info']->i_items_per_page,
											    					route('franchisee-users'), $page);
    			$data['franchisee_user_arr'] = $field_executives;
    			$data['current_page_index'] = $page;
    			# Records for pagination [End]
    	
    			# ================================================================
    			# 			FRANCHISEE USER(S) - END
    			# ================================================================
    				
    			# load listing...
    			$HTML = \View::make('userend.franchisee.ajax-parts.load-franchisee-users-AJAX', $data)->render();

    			# button part...
    			$BTN_HTML = '<button id="add-franchisee-user" class="btn btn-primary" type="button">Add Franchisee-User</button>';
    			
    			echo json_encode(array('result'        => 'success',
				    				   'html_content'  => $HTML,
				    				   'btn_html'	   => $BTN_HTML));
    			 exit;
    	
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    	
    	}
    	 
    	
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # 			AJAX Function(s) - END
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

}
