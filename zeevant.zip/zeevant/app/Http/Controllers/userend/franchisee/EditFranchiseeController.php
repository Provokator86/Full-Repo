<?php

namespace App\Http\Controllers\userend\franchisee;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;
use App\Helpers\Utility as utils;

class EditFranchiseeController extends \App\Http\Controllers\userend\BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Franchisee(s) - Edit Franchisee ::';

        # for menu selection...
        $this->data['selected_menu'] = 'franchisee';
        $this->data['selected_sub_menu'] = 'manage-franchisees';
    }

    // index function definition...
    public function index($franchisee_id) {

        # Page-Specific Settings...
        $data = $this->data;

        //// Retrieving Franchisee-Specific data [Begin]
            $usrModel = new \App\Models\Users();
            $data['franchisee_info'] = $usrModel->fetchFranchiseeInfo($franchisee_id);
            # utils::dump($data['franchisee_info']);
        //// Retrieving Franchisee-Specific data [End]

        # show view part...
        return view('userend.franchisee.edit-franchisee', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_franchisee_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('s_name', 's_email', 's_address_1',
                                     's_city', 's_state', 's_zipcode', 's_timezone');
            $email_flds = array('s_email');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

                if( $required_field == 's_name')
                {
                    $franchisee_tbl = getenv('DB_PREFIX') .'franchisee_master';
                    if (\DB::table($franchisee_tbl)
                            ->where('s_name', '=', \Input::get('s_name'))
                            ->where('i_id', '!=', \Input::get('franchisee_id'))->exists()) {
                        $arr_messages[$required_field] = ' already exists';
                        $err_flds[] = 's_name';
                    }

                }

            }


            # email address validate....
            foreach($email_flds as $email_fld) {

                if( $_POST[$email_fld]!='' ) {

                    if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                        if( !in_array($email_fld, $err_flds) )
                            $err_flds[] = $email_fld;

                        $arr_messages[$email_fld] = ' invalid email-id';
                    }

                }
            }


            # IP-Address field validation...
            if( $_POST['s_ip']!='' ) {
            	 
            	if( !filter_var($_POST['s_ip'], FILTER_VALIDATE_IP) )
            		$arr_messages['s_ip'] = ' invalid IP-Address';
            		 
            }
            
            
            # UPDATE "FRANCHISEE" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->edit_franchisee_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds' => $success_flds));
                exit;
            }
        }
        // end of AJAX update Franchisee function...


        # function to update existing Franchisee [AJAX CALL]...
        public function edit_franchisee_AJAX(Request $request) {

            # db info array...
            $SELECTED_FRANCHISEE_ID = intval($request->input('franchisee_id', true));

            //// Now, retrieving submitted/posted values [BEGIN]...
            # I: Franchisee Details...
            $franchisee_arr = array();
            $franchisee_arr['s_name'] = htmlspecialchars($request->input('s_name', true), ENT_QUOTES, 'utf-8');
            $franchisee_arr['s_account_number'] = htmlspecialchars($request->input('s_account_number', true), ENT_QUOTES, 'utf-8');
            $franchisee_arr['s_email']          = trim( $request->input('s_email', true) );
            $franchisee_arr['s_phone_number']   = trim( $request->input('s_phone_number', true) );
            $franchisee_arr['s_address_1']      = trim( $request->input('s_address_1', true) );
            $franchisee_arr['s_address_2']      = trim( $request->input('s_address_2', true) );
            $franchisee_arr['s_city']           = trim( $request->input('s_city', true) );
            $franchisee_arr['s_state']          = trim( $request->input('s_state', true) );
            $franchisee_arr['s_zipcode']        = trim( $request->input('s_zipcode', true) );
            
            # NEW - For Timezone [Begin]
            	$timezone_val = trim( $request->input('s_timezone', true) );
            	$tz_arr = explode(' ', $timezone_val);
            	$TZ_OFFSET = $tz_arr[0];
            	$TZONE = $tz_arr[1];
            
	            $franchisee_arr['s_timezone_offset'] = $TZ_OFFSET;
	            $franchisee_arr['s_timezone']        = $TZONE;
            # NEW - For Timezone [End]
            

            //// NEW - "Door-Counter" fields [Begin]
	            $franchisee_arr['s_device_id']     = trim( $request->input('s_device_id', true) );
	            $franchisee_arr['s_api_key']       = trim( $request->input('s_api_key', true) );
	            $franchisee_arr['s_ip']       	   = trim( $request->input('s_ip', true) );
            //// NEW - "Door-Counter" fields [End]
            
	            $franchisee_arr['dt_updated']       = utils::get_db_datetime();
            //// retrieving submitted/posted values [END]...

            //// updating users-master & then franchisee-master table(s)...
            $franchisee_tbl = getenv('DB_PREFIX') .'franchisee_master';
            \DB::table($franchisee_tbl)
                ->where('i_id', $SELECTED_FRANCHISEE_ID)
                ->update($franchisee_arr);


            //// redirection URL...
            $REDIRECT = url() ."/franchisee/manage-franchisees";

            # success message...
            $SUCCESS_MSG = "Franchisee info updated successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================

}
