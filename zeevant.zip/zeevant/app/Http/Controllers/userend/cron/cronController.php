<?php

namespace App\Http\Controllers\userend\cron;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# Helper(s) & Model(s)...
use App\Models\BalanceSheetModel as model_balance_sheet;
use App\Models\IncomeStmtModel as model_income_stmt;
use App\Models\CategoryModel as model_category;
use App\Models\ConfigModel as model_config;
use App\Helpers\UsersHelper as usrHelper;
use App\Helpers\Utility as utils;

class cronController extends \App\Http\Controllers\userend\BaseController
{
    protected $tmp_day_sales_tbl,
    		  $tmp_cogs_by_day_tbl,
    		  $tmp_sales_tbl,
    		  $tmp_sales_group_by_day_tbl,
    		  $tmp_sales_history_daily_tbl,
    		  $tmp_store_item_tbl,
    		  $tmp_time_attendance_tbl,
    		  $tmp_zreport_tbl;
    
    protected $src_day_sales_tbl,
    		  $src_cogs_by_day_tbl,
    		  $src_sales_tbl,
    		  $src_sales_group_by_day_tbl,
    		  $src_sales_history_daily_tbl,
    		  $src_store_item_tbl,
    		  $src_time_attendance_tbl,
    		  $src_zreport_tbl;
    
    protected $dst_day_sales_tbl,
    		  $dst_cogs_by_day_tbl,
    		  $dst_sales_tbl,
    		  $dst_sales_group_by_day_tbl,
    		  $dst_sales_history_daily_tbl,
    		  $dst_store_item_tbl,
    		  $dst_time_attendance_tbl,
    		  $dst_zreport_tbl;
    
    protected $SRC_DB_HOST,
    		  $SRC_DB_USERNAME,
    		  $SRC_DB_PASSWD,
    		  $SRC_DB_NAME;
    
    protected $DST_DB_HOST,
    		  $DST_DB_USERNAME,
    		  $DST_DB_PASSWD,
    		  $DST_DB_NAME;
    		  
    		  
    // constructor definition...
    public function __construct() {

        parent::__construct();
        
        # temporary table(s)...
	        $this->tmp_day_sales_tbl = "tmp_erply_daysales";
	        $this->tmp_cogs_by_day_tbl = "tmp_erply_inventory_value_and_cogs_by_day";
	        $this->tmp_sales_tbl = "tmp_erply_sales";
	        $this->tmp_sales_group_by_day_tbl = "tmp_erply_sales_by_product_group_by_day";
	        $this->tmp_sales_history_daily_tbl = "tmp_erply_sales_history_daily";
	        $this->tmp_store_item_tbl = "tmp_erply_store_item";
	        $this->tmp_time_attendance_tbl = "tmp_erply_time_attendance";
	        $this->tmp_zreport_tbl = "tmp_erply_zreport";

	    # source table(s) [from portal DB]...
	        $this->src_day_sales_tbl = "erply_daysales";
	        $this->src_cogs_by_day_tbl = "erply_inventory_value_and_cogs_by_day";
	        $this->src_sales_tbl = "erply_sales";
	        $this->src_sales_group_by_day_tbl = "erply_sales_by_product_group_by_day";
	        $this->src_sales_history_daily_tbl = "erply_sales_history_daily";
	        $this->src_store_item_tbl = "erply_store_item";
	        $this->src_time_attendance_tbl = "erply_time_attendance";
	        $this->src_zreport_tbl = "erply_zreport";

	    # destination table(s) [zeevant DB]...
	        $this->dst_day_sales_tbl = "zeevant_erply_daysales";
	        $this->dst_cogs_by_day_tbl = "zeevant_erply_inventory_value_and_cogs_by_day";
	        $this->dst_sales_tbl = "zeevant_erply_sales";
	        $this->dst_sales_group_by_day_tbl = "zeevant_erply_sales_by_product_group_by_day";
	        $this->dst_sales_history_daily_tbl = "zeevant_erply_sales_history_daily";
	        $this->dst_store_item_tbl = "zeevant_erply_store_item";
	        $this->dst_time_attendance_tbl = "zeevant_erply_time_attendance";
	        $this->dst_zreport_tbl = "zeevant_erply_zreport";
	        
	    # Source & Destination DB Credential(s)...
	    	$this->SRC_DB_HOST = "104.156.51.147";
	    	$this->SRC_DB_USERNAME = "portalsp_usr";
	    	$this->SRC_DB_PASSWD = "@Dm1n!tste$";
	        $this->SRC_DB_NAME = "portalsp_portal";
	        
	        $this->DST_DB_HOST = "localhost";
	        $this->DST_DB_USERNAME = "root";
	        $this->DST_DB_PASSWD = "shld123";
	        $this->DST_DB_NAME = "zeevant_app";
	        
	}


    # auto income statement load...
    public function loadAllIncomeStatements() {

        # 1st, empty the existing data...
        $master_istmt_tbl = getenv('DB_PREFIX') .'income_stmt_master';
        $istmt_inputs_tbl = getenv('DB_PREFIX') .'income_stmt_inputs';
        $emptySQL1 = sprintf("TRUNCATE %s ", $master_istmt_tbl);
        $emptySQL2 = sprintf("TRUNCATE %s ", $istmt_inputs_tbl);

        /*\DB::statement($emptySQL1);
        \DB::statement($emptySQL2);*/


        /// NEW - for date-range [Begin]
            $MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
            $MAX_DT = date("Y-m-d");
        /// NEW - for date-range [End]

        # II: preload few required value(s) like Year, Month, Logged-User-ID...
        $LOGGED_USR = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');
        $year = date('Y');

        $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);

        # III: Now, looping through all store(s) under the franchisor-admin...
        for($month=1; $month<=1; $month++) :   // begin - month(s) loop

            foreach($stores_arr as $key=>$storeID) {   // begin - store foreach

                $ISTMT_LOCKED = 0;

                # 1st, check if data already there for that month, year & store-ID...
                $ret_ = null;
                $chkSQL = sprintf("SELECT COUNT(*) AS `counter` FROM %s
	    						   WHERE
	    						   		`i_store_id`=%d AND
	    								`i_month`=%d AND
	    								`i_year`=%d ",
	                			   $master_istmt_tbl, $storeID, $month, $year);
                $ret_ = \DB::select(\DB::raw($chkSQL));
                
                if( empty($ret_[0]->counter) ) {
	                
	                $ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
	
	                # IV-A: insert into master table 1st i.e. "_income_stmt_master"...
	                $master_data_arr = array();
	                $master_data_arr['i_user_id'] = $LOGGED_USR;
	                $master_data_arr['i_store_id'] = $storeID;
	                $master_data_arr['i_month'] = $month;
	                $master_data_arr['i_year'] = $year;
	                $master_data_arr['dt_added'] = $ADD_DT_TIME;
	                $master_data_arr['i_locked'] = $ISTMT_LOCKED;
	
	                $ISTMT_ID = \DB::table($master_istmt_tbl)
	                    ->insertGetId($master_data_arr);
	
	                # II-B: insert into income-statement input(s) i.e. "_income_stmt_inputs"...
	                $istmt_arr = array();
	                $istmt_arr['i_income_stmt_id'] = $ISTMT_ID;
	
	                $REVENUE_TOTAL = 0;
	                $REVENUE_TOTAL += $istmt_arr['d_is_40100'] = mt_rand(20000, 75000);
	                $REVENUE_TOTAL += $istmt_arr['d_is_40200'] = mt_rand(1000, 2000);
	                $REVENUE_TOTAL += $istmt_arr['d_is_40300'] = mt_rand(100, 200);
	
	                $COGS_TOTAL = 0;
	                $COGS_TOTAL += $istmt_arr['d_is_50100'] = mt_rand(5600, 21000);
	                $COGS_TOTAL += $istmt_arr['d_is_50200'] = mt_rand(500, 700);
	                $COGS_TOTAL += $istmt_arr['d_is_50300'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50400'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50500'] = mt_rand(1000, 2000);
	                $COGS_TOTAL += $istmt_arr['d_is_50600'] = mt_rand(1000, 2000);
	
	
	                $EXPENSES_TOTAL = 0;
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60700'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60800'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_60900'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61000'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61700'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61800'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_61900'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62000'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62100'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62200'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62300'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62400'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62500'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62600'] = mt_rand(1000, 2000);
	                $EXPENSES_TOTAL += $istmt_arr['d_is_62700'] = mt_rand(1000, 2000);
	
	                $OTHER_INCOME_TOTAL = 0;
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80100'] = mt_rand(1000, 2000);
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80200'] = mt_rand(1000, 2000);
	                $OTHER_INCOME_TOTAL += $istmt_arr['d_is_80300'] = mt_rand(1000, 2000);

	                # NEW FIELD - Net Income
	                $NET_INCOME = ($REVENUE_TOTAL - $COGS_TOTAL - $EXPENSES_TOTAL + $OTHER_INCOME_TOTAL);
	                
	                 //// Total Field(s)
	                $istmt_arr['d_is_40000'] = $REVENUE_TOTAL;
	                $istmt_arr['d_is_50000'] = $COGS_TOTAL;
	                $istmt_arr['d_is_60000'] = $EXPENSES_TOTAL;
	                $istmt_arr['d_is_80000'] = $OTHER_INCOME_TOTAL;
	                $istmt_arr['d_net_income'] = $NET_INCOME;
	                $istmt_arr['dt_added'] = $ADD_DT_TIME;
	
	
	                \DB::table($istmt_inputs_tbl)
	                    ->insert($istmt_arr);
	                
                }

            }   // end - store foreach

        endfor; // end - month(s) loop


        // success statement...
        echo "Income-Statement data loaded successfully...";
    }



    # auto KPI revenue load...
    public function loadAllKPIRevenue() {
        
        /// NEW - for date-range [Begin]
        $MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
        $MAX_DT = date("Y-m-d");
        $ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
        /// NEW - for date-range [End]

        # 1st, empty the existing data...
        $kpi_details_tbl = getenv('DB_PREFIX') .'kpi_details';
        /*$emptySQL = sprintf("TRUNCATE %s ", $kpi_details_tbl);

        \DB::statement($emptySQL);*/

        $LOGGED_USR = \Session::get('user_id');
        $LOGGED_USR_TYPE = \Session::get('user_type');
        $year = date('Y');	// date("Y",strtotime("-1 year"))

        $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);
        
        // for KPI-array...
        $KPI_arr = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11);

        # Now, looping through all store(s) under the franchisor-admin...
        for($month=1; $month<=12; $month++) :   // begin - month(s) loop

            foreach($stores_arr as $key=>$storeID) {   // begin - store foreach

                # I: KPI Details...
                $KPI_plan_arr = array();
                $KPI_plan_arr['i_store_id'] = $storeID;
                $KPI_plan_arr['i_usr_id'] = $LOGGED_USR;
                $KPI_plan_arr['i_month'] = $month;
                $KPI_plan_arr['i_year'] = $year;
                $KPI_plan_arr['dt_added'] = $ADD_DT_TIME;
                //// retrieving submitted/posted values [END]...
                
                foreach($KPI_arr as $arr_key=>$kpi_ID) {
                	
                    $KPI_plan_arr['i_kpi_id'] = $kpi_ID;  // for Revenue - KPI ID...

                    $arr = $this->getKPIRange($kpi_ID);
                    $KPI_plan_arr['d_monthly_plan_mark'] = mt_rand($arr['min'], $arr['max']);

                    //utils::dump($KPI_plan_arr);
                    \DB::table($kpi_details_tbl)
                        ->insert($KPI_plan_arr);
                }

            }   // end - store foreach

        endfor;  // end - month(s) loop

        // success statement...
        echo "KPI Revenue data loaded successfully...";
    }
    

    // function to get value range based on KPI-ID...
    public function getKPIRange($kpi_ID) {

        $MIN = $MAX = 0;
        switch($kpi_ID) {
            case 1: $MIN = 15000;
                    $MAX = 60000;
                    break;
            case 2: $MIN = 68;
                    $MAX = 73;
                    break;
            case 3: $MIN = 100;
                    $MAX = 1400;
                    break;
            case 4: $MIN = 20;
                    $MAX = 30;
                    break;
            case 5: $MIN = 1;
                    $MAX = 3;
                    break;
            case 6: $MIN = 50;
                    $MAX = 70;
                    break;
            case 7: $MIN = 4;
                    $MAX = 8;
                    break;
            case 8: $MIN = 10;
                    $MAX = 15;
                    break;
           	case 9: $MIN = 1500;
                    $MAX = 6000;
                    break;
            case 10: $MIN = 1;
                    $MAX = 8;
                    break;
            case 11: $MIN = 68;
                    $MAX = 73;
                    break;
            default: $MIN = 15000;
                     $MAX = 60000;
                     break;
        }

        $return_arr = array('min'=>$MIN,
                            'max'=>$MAX);
        
        return $return_arr;
    }

    
    // NEW - random Balance-Sheet data insertion...
    public function loadAllBalanceSheets() {
    
    	# 1st, empty the existing data...
    	$master_bsheet_tbl = getenv('DB_PREFIX') .'balance_sheet_master';
    	$bsheet_inputs_tbl = getenv('DB_PREFIX') .'balance_sheet_inputs';
    	$emptySQL1 = sprintf("TRUNCATE %s ", $master_bsheet_tbl);
    	$emptySQL2 = sprintf("TRUNCATE %s ", $bsheet_inputs_tbl);
    
    	/*\DB::statement($emptySQL1);
    	 \DB::statement($emptySQL2);*/
    
    
    	/// NEW - for date-range [Begin]
    	$MIN_DT = date("Y-m-d", strtotime("first day of previous month"));
    	$MAX_DT = date("Y-m-d");
    	/// NEW - for date-range [End]
    
    	# II: preload few required value(s) like Year, Month, Logged-User-ID...
    	$LOGGED_USR = \Session::get('user_id');
    	$LOGGED_USR_TYPE = \Session::get('user_type');
    	$year = date('Y', strtotime("-1 year"));
    
    	$stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR, $LOGGED_USR_TYPE);
    
    	# III: Now, looping through all store(s) under the franchisor-admin...
    	for($month=1; $month<=12; $month++) :   // begin - month(s) loop
    
    	foreach($stores_arr as $key=>$storeID) {   // begin - store foreach
    
    		$BSHEET_LOCKED = 0;
    		
    		
    		# 1st, check if data already there for that month, year & store-ID...
    		$ret_ = null;
    		$chkSQL = sprintf("SELECT COUNT(*) AS `counter` FROM %s
    						   WHERE
    						   		`i_store_id`=%d AND
    								`i_month`=%d AND
    								`i_year`=%d ",
    						   $master_bsheet_tbl, $storeID, $month, $year);
    		$ret_ = \DB::select(\DB::raw($chkSQL));
    		
    		if( empty($ret_[0]->counter) ) {
	    
	    		$ADD_DT_TIME = utils::generate_rand_datetime($MIN_DT, $MAX_DT);
	    
	    		# IV-A: insert into master table 1st i.e. "_income_stmt_master"...
	    		$master_data_arr = array();
	    		$master_data_arr['i_user_id'] = $LOGGED_USR;
	    		$master_data_arr['i_store_id'] = $storeID;
	    		$master_data_arr['i_month'] = $month;
	    		$master_data_arr['i_year'] = $year;
	    		$master_data_arr['dt_added'] = $ADD_DT_TIME;
	    		$master_data_arr['i_locked'] = $BSHEET_LOCKED;
	    
	    		$BSHEET_ID = \DB::table($master_bsheet_tbl)
	    		->insertGetId($master_data_arr);
	    
	    		# II-B: insert into income-statement input(s) i.e. "_income_stmt_inputs"...
	    		$bsheet_arr = array();
	    		$bsheet_arr['i_balance_sheet_id'] = $BSHEET_ID;
	    		$bsheet_arr['d_bs_11101'] = mt_rand(200, 500);
	    		$bsheet_arr['d_bs_11102'] = mt_rand(100, 1000);
	    		$bsheet_arr['d_bs_11200'] = mt_rand(500, 1000);
	    		$bsheet_arr['d_bs_11300'] = mt_rand(12000, 30000);
	    		$bsheet_arr['d_bs_11401'] = mt_rand(500, 2500);
	    		$bsheet_arr['d_bs_11402'] = mt_rand(100, 1000);
	    		$bsheet_arr['d_bs_12000'] = mt_rand(10000, 20000);
	    		$bsheet_arr['d_bs_13000'] = mt_rand(50, 1000);
	    		$bsheet_arr['d_bs_21101'] = mt_rand(100, 500);
	    		$bsheet_arr['d_bs_21102'] = mt_rand(200, 500);
	    		$bsheet_arr['d_bs_21104'] = mt_rand(100, 500);
	    		$bsheet_arr['d_bs_22000'] = mt_rand(100, 1000);
	    		$bsheet_arr['d_bs_30000'] = mt_rand(23450, 54500);
	    		
	    		//// Total Field(s)
	    		$bsheet_arr['d_bs_11100'] = ($bsheet_arr['d_bs_11101'] + $bsheet_arr['d_bs_11102']);
	    		$bsheet_arr['d_bs_11400'] = ($bsheet_arr['d_bs_11401'] + $bsheet_arr['d_bs_11402']);
	    		$bsheet_arr['d_bs_11000'] = ($bsheet_arr['d_bs_11100'] + $bsheet_arr['d_bs_11200'] + $bsheet_arr['d_bs_11300'] + $bsheet_arr['d_bs_11400']);
	    		$bsheet_arr['d_bs_10000'] = ($bsheet_arr['d_bs_11000'] + $bsheet_arr['d_bs_12000'] + $bsheet_arr['d_bs_13000']);
	    		$bsheet_arr['d_bs_21000'] = ($bsheet_arr['d_bs_21101'] + $bsheet_arr['d_bs_21102'] + $bsheet_arr['d_bs_21104']);
	    		$bsheet_arr['d_bs_20000'] = ($bsheet_arr['d_bs_21000'] + $bsheet_arr['d_bs_22000'] + $bsheet_arr['d_bs_30000']);
	    		
	    		//// New Field(s)...
	    		$bsheet_arr['d_labor_hours'] = mt_rand(280, 500);
	    		
	    		 
	    		\DB::table($bsheet_inputs_tbl)
	    		->insert($bsheet_arr);
	    		
    		}	// end record exists check...
    
    	}   // end - store foreach
    
    	endfor; // end - month(s) loop
    
    
    	// success statement...
    	echo "Balance-Sheet data loaded successfully...";
    }

    
    # *******************************************************************
    # 		NEW - Configuration Inputs(s) [Begin]
    # *******************************************************************
    
    	// function to load Configuration-Inputs...
    	public function loadConfigurationInputs() {
    		
    		try {
    			
    			# I: table(s)...
	    			$CONFIG_DETAILS_TBL = getenv('DB_PREFIX') .'config_details';
	    			$CONFIG_CATEGORY_DETAILS_TBL = getenv('DB_PREFIX') .'config_category_details';
    			
    			# II: empty table(s) 1st...
    				$this->truncateTbl($CONFIG_DETAILS_TBL);
    				$this->truncateTbl($CONFIG_CATEGORY_DETAILS_TBL);
    				
    			# III: load data...
    				$this->loadVariableCosts();
    				$this->loadWeightedCosts();
    				$this->loadShelfSpaceInputs();
    				
    			
    			echo "Data inserted successfully...";
    			
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    		
    	}
    	
    	
    	// function to load Variable-Costs...
    	public function loadVariableCosts() {
    		
    		try {
    			
    			# I: config-details table...
	    			$CONFIG_DETAILS_TBL = getenv('DB_PREFIX') .'config_details';
    			
    			# II: Config Variables...
	    			$where_cond = '';  // i.e. All Config Input(s)
	    			$configModel = new model_config();
	    			$order_by = ' i_id ASC ';
	    			$config_variable_arr = $configModel->fetchVariableRecords($where_cond);
		            
		        
		        # III: fetching available store(s)...
		        	$LOGGED_USR_ID = \Session::get('user_id');
		        	$LOGGED_USR_TYPE = \Session::get('user_type');
		        	$stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR_ID,
		        												  $LOGGED_USR_TYPE);
		        	
		        # IV: finally, loading Variable-Costs for all available store(s)...
	        		$config_arr = array();
		        	foreach ($stores_arr as $loop_index=>$store_id) {
		        		
		        		$config_arr['i_store_id'] = $store_id;
		        		$config_arr['i_usr_id'] = \Session::get('user_id');
		        		$config_arr['dt_added'] = utils::get_db_datetime();
		        		
		        		// looping thru config-variables...
		        		foreach($config_variable_arr as $CV_Info) {
		        			$config_arr['i_cw_id'] = 0;
		        			$config_arr['i_cv_id'] = $CV_Info->i_id;
		        			$config_arr['d_mark'] = $this->getVariableCostsRange($CV_Info->i_id);
		        		
		        			\DB::table($CONFIG_DETAILS_TBL)
		        				->insert($config_arr);
		        		}
		        	}
	    			
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    		
    	}
    
    	
    	// function to load Daywise Weighted-Costs...
    	public function loadWeightedCosts() {
    	
    		try {

    			# I: config-details table...
	    			$CONFIG_DETAILS_TBL = getenv('DB_PREFIX') .'config_details';
    			 
    			# II: Weighted-Costs...
	    			$where_cond = '';  // i.e. All Config Input(s)
	    			$configModel = new model_config();
	    			$order_by = ' i_id ASC ';
    				$config_weighted_arr = $configModel->fetchWeightedRecords($where_cond);
    			
    			
    			# III: fetching available store(s)...
	    			$LOGGED_USR_ID = \Session::get('user_id');
	    			$LOGGED_USR_TYPE = \Session::get('user_type');
	    			$stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR_ID,
	    														  $LOGGED_USR_TYPE);
    			 
    			# IV: finally, loading Daywise Weighted-Costs for all available store(s)...
	    			$config_arr = array();
	    			foreach ($stores_arr as $loop_index=>$store_id) {
	    			
	    				$config_arr['i_store_id'] = $store_id;
	    				$config_arr['i_usr_id'] = \Session::get('user_id');
	    				$config_arr['dt_added'] = utils::get_db_datetime();
	    			
	    				// looping thru weighted-costs...
	    				foreach($config_weighted_arr as $WC_Info) {
	    					
	    					$config_arr['i_cv_id'] = 0;
	    					$config_arr['i_cw_id'] = $WC_Info->i_id;
	    					$config_arr['d_mark'] = $this->getWeightedCostsRange($WC_Info->i_id);
	    			
	    					\DB::table($CONFIG_DETAILS_TBL)
	    						->insert($config_arr);
	    				}
	    			}
    			
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    	
    	}
    	
 
    	// function to load Shelf-Space Inputs...
    	public function loadShelfSpaceInputs() {

    		try {
    		
    			# I: config-category-details table...
    				$CONFIG_CATEGORY_DETAILS_TBL = getenv('DB_PREFIX') .'config_category_details';
    			
    			# II: fetching categories...
    				# logged-in user-id & type...
    				$LOGGED_USR_ID = \Session::get('user_id');
    				$LOGGED_USR_TYPE = \Session::get('user_type');
    				
    				# 1: getting concerned Franchisor-Admin ID...
    				$FRANCHISOR_ADMIN_ID = ( $LOGGED_USR_TYPE!=2 )
						    			   ? usr_Helper::getParentFranchisorAdminID( $LOGGED_USR_ID )
						    			   : $LOGGED_USR_ID;
    				
    				
    				$order_by = ' `i_id` DESC ';
    				$categoryModel = new model_category();
    				$records = $categoryModel->fetchCategoryHierarchy($FRANCHISOR_ADMIN_ID);
    				
    			# III: loading Shelf-Input values...
    				if(!empty($records))  {
    				
    					foreach($records as $ind=>$value){
    						if ($value['product_sub_group']!='')
    						{
    							$val = $value['i_id'];
    							$config_ss_flds[$val] = $this->getShelfSpaceInputsRange($val);
    						}
    					}
    				
			            $config_category_arr = array();
			            
			            # IV: fetching available store(s)...
			            $stores_arr = usrHelper::getFranchiseesByUser($LOGGED_USR_ID,
			            											  $LOGGED_USR_TYPE);
			            
			            # V: looping through store(s)...
			            foreach ($stores_arr as $loop_index=>$store_id) {
			            	
				            $config_category_arr['i_store_id'] = $store_id;
				            $config_category_arr['i_usr_id']  = $LOGGED_USR_ID;
				            $config_category_arr['dt_added']  = utils::get_db_datetime();
				            
	    					foreach($config_ss_flds as $key1=>$val1) {
	    						$config_category_arr['i_category_id'] = $key1;
	    						$config_category_arr['d_area_mark'] = $val1;
	    				
	    						\DB::table($CONFIG_CATEGORY_DETAILS_TBL)
	    							->insert($config_category_arr);
	    					}
	    					
			            }
			            
    				
    				}
    				
    			
    				
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    		 
    	}
    	
    	
    	// function to truncate table...
    	public function truncateTbl($tbl_name) {
    		
    		try {
    			
    			$sql = sprintf("TRUNCATE TABLE `%s` ", $tbl_name);
    			\DB::statement($sql);
    			
    		} catch(Exception $err_obj) {
    			show_error($err_obj->getMessage());
    		}
    		
    	}
    	
    	
    	# ======= Input Variable(s) Range(s) [Begin]
    	
    		# I: Variable-Cost(s) Range...
    		public function getVariableCostsRange($variableID) {
    			
    			try {
    				
    				$val = 0;
    				
    				switch ($variableID) {
    					case 1: $val = 7;	// Royalty
    							break;
    					case 2: $val = 7;	// SDF
    							break;
    					case 3: $val = mt_rand(1, 3);	// Shipping as a Percentage of revenue
    							break;
    					case 4: $val = mt_rand(3, 6);	// Other Variable Costs
    							break;
    					default: $val = 7;
    							break;
    				}
    				
    				return $val;
    				
    			} catch(Exception $err_obj) {
    				show_error($err_obj->getMessage());
    			}
    		}

    		
    		# II: Daywise Weighted-Cost(s) Range...
    		public function getWeightedCostsRange($variableID) {
    			 
    			try {
    		
    				$val = 0;
    		
    				switch ($variableID) {
    					case 1: $val = 10;	//Sunday
    							break;
    					case 2: $val = 15;	//Monday
    							break;
    					case 3: $val = 9;	//Tuesday
    							break;
    					case 4: $val = 11;	//Wednesday
    							break;
    					case 5: $val = 13;	//Thursday
    							break;
    					case 6: $val = 12;	//Friday
    							break;
    					case 7: $val = 30;	//Saturday
    							break;
    					default: $val = 10;
    							 break;
    				}
    		
    				return $val;
    		
    			} catch(Exception $err_obj) {
    				show_error($err_obj->getMessage());
    			}
    		}
    		

    		# III: Shelf-Space Input(s) Range...
    		public function getShelfSpaceInputsRange($variableID) {
    		
    			try {
    		
    				$val = 0;
    		
    				switch ($variableID) {
    					case 10: $val = 0;
			    				 break;
    					case 6: $val = mt_rand(3, 5);
    							break;
    					case 5: $val = mt_rand(3, 5);
    							break;
    					case 7: $val = mt_rand(3, 5);
    							break;
    					case 2: $val = mt_rand(5, 8);
    							break;
    					case 8: $val = mt_rand(4, 5);
    							break;
    					case 4: $val = mt_rand(2, 3);
    							break;
    					case 9: $val = mt_rand(1, 1);
    							break;
    					case 3: $val = mt_rand(20, 25);
    							break;
    					case 47: $val = mt_rand(6, 7);
    							 break;
    					case 59: $val = 0;
    							 break;
    					case 17: $val = mt_rand(48, 52);
    							 break;
    					case 27: $val = mt_rand(4, 5);
    							 break;
    					case 16: $val = mt_rand(4, 5);
    							 break;
    					case 29: $val = mt_rand(2, 3);
    							 break;
    					case 12: $val = mt_rand(40, 45);
    							 break;
    					case 32: $val = mt_rand(60, 70);
    							 break;
    					case 57: $val = mt_rand(16, 19);
    							 break;
    					case 52: $val = 0;
    							 break;
    					case 48: $val = mt_rand(4, 5);
    							 break;
    					default: $val = mt_rand(32, 40);
    							 break;
    				}
    		
    				return $val;
    		
    			} catch(Exception $err_obj) {
    				show_error($err_obj->getMessage());
    			}
    		}
    		
    		
    	# ======= Input Variable(s) Range(s) [End]
    	   
    	
    # *******************************************************************
    # 		NEW - Configuration Inputs(s) [End]
    # *******************************************************************
    
    
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// 		NEW - DB Sync [Begin]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
		# function to run db-sync...
		public function runDbSync() {
			
			try {
				
				# I: creating 8 erply temporary table(s)...
					/*$this->createTmpDaySalesTbl();
					$this->createTmpCogsByDayTbl();
					$this->createTmpSalesTbl();*/
					$this->createTmpGroupByDayTbl();
					/*$this->createTmpSalesHistoryTbl();
					$this->createTmpStoreItemTbl();
					$this->createTmpTimeAttendanceTbl();
					$this->createTmpZReportTbl();*/
					exit;
				
				
				# II: load data into local-file from source-db...
					$SRC_TBL_ARR = array($this->src_day_sales_tbl,
										 $this->src_cogs_by_day_tbl,
										 $this->src_sales_tbl,
										 $this->src_sales_group_by_day_tbl,
										 $this->src_sales_history_daily_tbl,
										 $this->src_store_item_tbl,
										 $this->src_time_attendance_tbl,
										 $this->src_zreport_tbl);
					
					foreach($SRC_TBL_ARR as $key=>$src_tbl)
						$this->loadDataOntoFile($src_tbl);
					
				
				# III: load data from local-file into source-db...
					foreach($SRC_TBL_ARR as $key=>$tmp_tbl)
						$this->loadDataFromFile($tmp_tbl);
						
				# IV: renaming existing table(s) as bkup table(s)...
					$DST_TBL_ARR = array($this->dst_day_sales_tbl,
										 $this->dst_cogs_by_day_tbl,
										 $this->dst_sales_tbl,
										 $this->dst_sales_group_by_day_tbl,
										 $this->dst_sales_history_daily_tbl,
										 $this->dst_store_item_tbl,
										 $this->dst_time_attendance_tbl,
										 $this->dst_zreport_tbl);
					foreach($DST_TBL_ARR as $key=>$dst_tbl)
						$this->makeBkUpTbls($dst_tbl);
						
				# IV: renaming existing table(s) as bkup table(s)...
					foreach($SRC_TBL_ARR as $key=>$tbl)
						$this->makeLiveTbls($tbl);
						
				# V: Finally, cleaning up csv file(s)...
					foreach ($SRC_TBL_ARR as $src_index=>$src_tbl_name)
						$this->cleanUpDataCSVFiles($src_tbl_name);
						
						
				//// Send a Test-Mail (to check for CRON)...
					#$this->sendEmail();
				
				# echo "DB-Sync completed successfully...";		
				
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
			
		}
		
		
		// NEW - function to run cron for few specific table(s)
		// which need more frequent sync(s)...
		public function runTableSync() {
			
			try {
				
				$DELIMITER = '|';

				# I: creating erply temporary table(s) [attendance & zreport]...
					$this->createTmpTimeAttendanceTbl();
					#$this->createTmpZReportTbl();
				
				
				# II: load data into local-file from source-db...
					/*$SRC_TBL_ARR = array($this->src_time_attendance_tbl,
										 $this->src_zreport_tbl);*/
					$SRC_TBL_ARR = array($this->src_time_attendance_tbl);
					
					foreach($SRC_TBL_ARR as $key=>$src_tbl)
						$this->loadDataOntoFile($src_tbl, $DELIMITER);
						
				
				# III: load data from local-file into source-db...
					foreach($SRC_TBL_ARR as $key=>$tmp_tbl)
						$this->loadDataFromFile($tmp_tbl, $DELIMITER);
				
				# IV: renaming existing table(s) as bkup table(s)...
					#$DST_TBL_ARR = array($this->dst_time_attendance_tbl,
					#					 $this->dst_zreport_tbl);
					$DST_TBL_ARR = array($this->dst_time_attendance_tbl);
					
					foreach($DST_TBL_ARR as $key=>$dst_tbl)
						$this->makeBkUpTbls($dst_tbl);
		
				# IV: renaming existing table(s) as bkup table(s)...
					foreach($SRC_TBL_ARR as $key=>$tbl)
						$this->makeLiveTbls($tbl);
	
				# V: Finally, cleaning up csv file(s)...
					foreach ($SRC_TBL_ARR as $src_index=>$src_tbl_name)
						$this->cleanUpDataCSVFiles($src_tbl_name);
	

				//// Send a Test-Mail (to check for CRON)...
					#$this->sendEmail();

				# echo "DB-Sync completed successfully...";
				
			} catch(Exception $err_obj) {
				show_error($err_obj->getMessage());
			}
			
		}
		
		
		
		# ========= Form Temporary Table(s) - Begin =========
    		
			# A: Create Temporary "day-sales"...
			public function createTmpDaySalesTbl() {
				
				try {
					
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_day_sales_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) unsigned NOT NULL,
											  `erplytrans_date` date DEFAULT NULL,
											  `company_id` int(11) DEFAULT NULL,
											  `erply_account_number` varchar(50) DEFAULT NULL,
											  `sales_before_discount` decimal(7,2) DEFAULT NULL,
											  `gross_sales` decimal(7,2) DEFAULT NULL,
											  `returns` decimal(7,2) DEFAULT NULL,
											  `promotional` decimal(7,2) DEFAULT NULL,
											  `discount` decimal(7,2) DEFAULT NULL,
											  `tax_exempt_sales` decimal(7,2) DEFAULT NULL,
											  `taxable_sales` decimal(7,2) DEFAULT NULL,
											  `taxes` decimal(7,2) DEFAULT NULL,
											  `tickets` int(11) DEFAULT NULL,
											  `gc_sold` decimal(7,2) DEFAULT NULL,
											  `gc_redeemed` decimal(7,2) DEFAULT NULL,
											  `master_card` decimal(7,2) DEFAULT NULL,
											  `visa` decimal(7,2) DEFAULT NULL,
											  `discover` decimal(7,2) DEFAULT NULL,
											  `amex` decimal(7,2) DEFAULT NULL,
											  `debit` decimal(7,2) DEFAULT NULL,
											  `check_amount` decimal(7,2) DEFAULT NULL,
											  `others_cc` decimal(7,2) DEFAULT NULL,
											  `cash_sales` decimal(7,2) DEFAULT NULL,
											  `store_credit` decimal(7,2) DEFAULT NULL,
											  `other_payment_types` decimal(7,2) DEFAULT NULL,
											  `waybill` decimal(7,2) DEFAULT NULL,
											  `created_ts` datetime DEFAULT NULL,
											  `modified_ts` datetime DEFAULT NULL
											) ENGINE=MyISAM DEFAULT CHARSET=latin1",
											$this->tmp_day_sales_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
										  ADD PRIMARY KEY (`id`),
										  ADD KEY `company_id` (`company_id`),
										  ADD KEY `erply_account_number` (`erply_account_number`),
										  ADD KEY `erplytrans_date` (`erplytrans_date`)",
										$this->tmp_day_sales_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%1\$s`
  									  		MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										  $this->tmp_day_sales_tbl);
					
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
				
			}

			# B: Create Temporary "inventory-value-and-cogs-by-day"...
			public function createTmpCogsByDayTbl() {
			
				try {
						
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_cogs_by_day_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
										  `id` int(11) unsigned NOT NULL,
										  `company_id` int(11) DEFAULT NULL,
										  `erply_account_number` varchar(50) DEFAULT NULL,
										  `invetory_date` date DEFAULT NULL,
										  `pos_invetory_value_start_of_day` decimal(7,2) DEFAULT NULL,
										  `pos_invetory_value_end_of_day` decimal(7,2) DEFAULT NULL,
										  `sum_of_stock_purchase` decimal(7,2) DEFAULT NULL,
										  `daily_stock_cogs` decimal(10,4) DEFAULT NULL,
										  `daily_net_stocktaking_acts` decimal(7,2) DEFAULT NULL,
										  `daily_promotional_write_offs` decimal(7,2) DEFAULT NULL,
										  `daily_transfers_out` decimal(7,2) DEFAULT NULL,
										  `daily_non_promotional_write_offs` decimal(7,2) DEFAULT NULL,
										  `daily_net_other_stock_adjustment` decimal(7,2) DEFAULT NULL,
										  `calculated_inventory_value` decimal(7,2) DEFAULT NULL,
										  `inventory_value_error` decimal(7,2) DEFAULT NULL,
										  `created_ts` datetime DEFAULT NULL,
										  `modified_ts` datetime DEFAULT NULL
										) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										$this->tmp_cogs_by_day_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
										  ADD PRIMARY KEY (`id`),
										  ADD KEY `company_id` (`company_id`),
										  ADD KEY `erply_account_number` (`erply_account_number`),
										  ADD KEY `invetory_date` (`invetory_date`)",
										$this->tmp_cogs_by_day_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
										  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										  $this->tmp_cogs_by_day_tbl);
					
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
					
						
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
			
			}
				
			# C: Create Temporary "sales"...
			public function createTmpSalesTbl() {
					
				try {
						
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_sales_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) NOT NULL,
											  `invoice_number` varchar(25) NOT NULL,
											  `invoice_date` date NOT NULL,
											  `time_stamp` time NOT NULL,
											  `partner_id` int(11) NOT NULL,
											  `erply_account_number` varchar(50) NOT NULL,
											  `customer_fname` varchar(200) DEFAULT NULL,
											  `customer_lname` varchar(150) DEFAULT NULL,
											  `email` varchar(250) NOT NULL,
											  `customer_group` varchar(50) DEFAULT NULL,
											  `payment_type` varchar(10) NOT NULL,
											  `total` double(7,2) NOT NULL,
											  `tax` double(7,2) NOT NULL,
											  `cogs` decimal(10,4) NOT NULL,
											  `created_ts` datetime NOT NULL,
											  `modified_ts` datetime NOT NULL
										) ENGINE=InnoDB DEFAULT CHARSET=latin1",
										$this->tmp_sales_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
										  ADD PRIMARY KEY (`id`),
										  ADD KEY `company_id` (`partner_id`)",
										$this->tmp_sales_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
										  	  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT",
										  $this->tmp_sales_tbl);
					
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}
				
			# D: Create Temporary "sales-by-product-group-by-day"...
			public function createTmpGroupByDayTbl() {
			
				try {
						
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_sales_group_by_day_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) unsigned NOT NULL,
											  `date` date DEFAULT NULL,
											  `company_id` int(11) DEFAULT NULL,
											  `erply_account_number` varchar(50) DEFAULT NULL,
											  `product_group` varchar(50) DEFAULT NULL,
											  `subgroup` varchar(50) DEFAULT NULL,
											  `sold_quantity` decimal(7,2) DEFAULT NULL,
											  `net_sales_total` decimal(7,2) DEFAULT NULL,
											  `warehouse_value` decimal(7,2) DEFAULT NULL,
											  `net_discount` decimal(7,2) DEFAULT NULL,
											  `created_ts` datetime DEFAULT NULL,
											  `modified_ts` datetime DEFAULT NULL
										) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										$this->tmp_sales_group_by_day_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
									  		ADD PRIMARY KEY (`id`)",
										$this->tmp_sales_group_by_day_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
									  		  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										   $this->tmp_sales_group_by_day_tbl);
					$indexSQL = sprintf("CREATE INDEX `grp_idx` ON %s (`product_group`, `subgroup`) USING BTREE", $this->tmp_sales_group_by_day_tbl);
					
						
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
					\DB::statement($indexSQL);
						
					} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
			
			}

			# E: Create Temporary "sales-history"...
			public function createTmpSalesHistoryTbl() {
			
				try {
						
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_sales_history_daily_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) unsigned NOT NULL,
											  `date` date DEFAULT NULL,
											  `company_id` int(11) DEFAULT NULL,
											  `erply_account_number` varchar(50) DEFAULT NULL,
											  `code` varchar(50) DEFAULT NULL,
											  `name` varchar(50) DEFAULT NULL,
											  `sold_quantity` decimal(7,2) DEFAULT NULL,
											  `warehouse_value` decimal(7,2) DEFAULT NULL,
											  `net_sales_total` decimal(7,2) DEFAULT NULL,
											  `net_discount` decimal(7,2) DEFAULT NULL,
											  `profit` decimal(7,2) DEFAULT NULL,
											  `created_ts` datetime DEFAULT NULL,
											  `modified_ts` datetime DEFAULT NULL
										) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										$this->tmp_sales_history_daily_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
									  		ADD PRIMARY KEY (`id`)",
										$this->tmp_sales_history_daily_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
									  		  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										   $this->tmp_sales_history_daily_tbl);
						
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
			
			}
				
			# F: Create Temporary "store-item"...
			public function createTmpStoreItemTbl() {
					
				try {
			
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_store_item_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) NOT NULL,
											  `partner_id` int(11) NOT NULL,
											  `erply_account_number` varchar(50) NOT NULL,
											  `erply_item_id` int(11) NOT NULL,
											  `erply_item_name` varchar(100) NOT NULL,
											  `erply_item_code` varchar(30) NOT NULL,
											  `erply_item_code2` varchar(50) DEFAULT NULL,
											  `erply_item_code3` varchar(50) DEFAULT NULL,
											  `product_number` varchar(20) NOT NULL,
											  `erply_item_group` varchar(150) NOT NULL,
											  `erply_item_status` varchar(25) NOT NULL,
											  `price` decimal(7,2) NOT NULL,
											  `created_ts` datetime NOT NULL,
											  `modified_ts` datetime NOT NULL
										) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										$this->tmp_store_item_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
										  ADD PRIMARY KEY (`id`),
										  ADD KEY `ItemCodeIndex` (`erply_item_code`),
										  ADD KEY `partnerIDIndex` (`partner_id`)",
										$this->tmp_store_item_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
										  	  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT",
										   $this->tmp_store_item_tbl);
						
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
			
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}
			
			# G: Create Temporary "time-attendance"...
			public function createTmpTimeAttendanceTbl() {
					
				try {
						
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_time_attendance_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) unsigned NOT NULL,
											  `company_id` int(11) DEFAULT NULL,
											  `erply_account_number` varchar(50) DEFAULT NULL,
											  `emp_name` varchar(100) DEFAULT NULL,
											  `erply_employee_id` int(11) DEFAULT NULL,
											  `employee_id` varchar(100) DEFAULT NULL,
											  `clock_in_date` date DEFAULT NULL,
											  `clock_in_time` time DEFAULT NULL,
											  `clock_out_date` date DEFAULT NULL,
											  `clock_out_time` time DEFAULT NULL,
											  `working_hours_hm` varchar(30) DEFAULT NULL,
											  `working_hours_decimal` decimal(7,2) DEFAULT NULL,
											  `no_clock_out` varchar(1) DEFAULT NULL,
											  `created_ts` datetime DEFAULT NULL,
											  `modified_ts` datetime DEFAULT NULL
										 ) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										 $this->tmp_time_attendance_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
											  ADD PRIMARY KEY (`id`),
											  ADD KEY `company_id` (`company_id`),
											  ADD KEY `erply_account_number` (`erply_account_number`),
											  ADD KEY `employee_id` (`employee_id`),
											  ADD KEY `clock_in_date` (`clock_in_date`),
											  ADD KEY `clock_out_time` (`clock_out_time`)",
										$this->tmp_time_attendance_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
										  	  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										   $this->tmp_time_attendance_tbl);
						
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
						
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}
				
			# H: Create Temporary "zreport"...
			public function createTmpZReportTbl() {
					
				try {
			
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s`", $this->tmp_zreport_tbl);
					$createSQL = sprintf("CREATE TABLE IF NOT EXISTS `%s` (
											  `id` int(11) unsigned NOT NULL,
											  `company_id` int(11) DEFAULT NULL,
											  `erply_account_number` varchar(50) DEFAULT NULL,
											  `pos_date` datetime DEFAULT NULL,
											  `register` int(11) DEFAULT NULL,
											  `data_type` varchar(30) DEFAULT NULL,
											  `amount` decimal(7,2) DEFAULT NULL,
											  `created_ts` datetime DEFAULT NULL,
											  `modified_ts` datetime DEFAULT NULL
										) ENGINE=MyISAM DEFAULT CHARSET=latin1",
										$this->tmp_zreport_tbl);
					$PKeySQL = sprintf("ALTER TABLE `%s`
										  ADD PRIMARY KEY (`id`),
										  ADD KEY `company_id` (`company_id`),
										  ADD KEY `erply_account_number` (`erply_account_number`),
										  ADD KEY `pos_date` (`pos_date`)",
										$this->tmp_zreport_tbl);
					$AutoIncSQL = sprintf("ALTER TABLE `%s`
										  	  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT",
										   $this->tmp_zreport_tbl);
						
					\DB::statement($dropSQL);
					\DB::statement($createSQL);
					\DB::statement($PKeySQL);
					\DB::statement($AutoIncSQL);
			
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}
			
		# ========= Form Temporary Table(s) - End =========
		
			
		
		# ********* Load into local-file from Source-DB [Begin] *********
		
			// function to load data onto local-file...
			public function loadDataOntoFile($src_tbl, $delimiter=',') {
				
				try {
					
					$CSV_PATH = public_path() ."/uploaded/db-sync-files/";
					$FILE_NAME = "db_{$src_tbl}.csv";
					$pathToCsv = $CSV_PATH . $FILE_NAME;
					
					$sql = "SELECT * FROM {$src_tbl}";
					$command = sprintf("mysql -h %s -u %s  --password=%s -D %s -e '%s' | sed 's/\t/{$delimiter}/g' > %s",
										$this->SRC_DB_HOST,
										$this->SRC_DB_USERNAME,
										$this->SRC_DB_PASSWD,
										$this->SRC_DB_NAME,
										$sql,
										$pathToCsv);
					/*$command = sprintf("mysql -h %s -u %s  --password=%s -D %s -e '%s' | sed 's/\t/\",\"/g;s/^/\"/;s/$/\"/;' > %s",
										$this->SRC_DB_HOST,
										$this->SRC_DB_USERNAME,
										$this->SRC_DB_PASSWD,
										$this->SRC_DB_NAME,
										$sql,
										$pathToCsv);*/
					exec($command, $output, $return);
					
					if( !$return )
						return true;
					
					return false;
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
				
			}
			
		
		# ********* Load into local-file from Source-DB [End] *********
					
			// Load from local-file tom Temporary-DB [Begin]
			public function loadDataFromFile($tbl_name, $delimiter=',') {
			
				try {
						
					$CSV_PATH = public_path() ."/uploaded/db-sync-files/";
					$FILE_NAME = "db_{$tbl_name}.csv";
					$pathToCsv = $CSV_PATH . $FILE_NAME;
					
					$tmpTblName = "tmp_{$tbl_name}";
		    		$sql = "LOAD DATA LOCAL INFILE '{$pathToCsv}'
				    		INTO TABLE {$tmpTblName}
				    		FIELDS TERMINATED BY '{$delimiter}'
				    		IGNORE 1 LINES ";
		    		
		    		$TAsql = '';
		    		/*if( $tbl_name==$this->src_time_attendance_tbl) {
		    			$TAsql = "(id, company_id, erply_account_number,
		    					   emp_name, erply_employee_id, employee_id,
		    					   @clock_in_date, @clock_in_time, @clock_out_date,
		    					   @clock_out_time, working_hours_hm, working_hours_decimal,
		    					   no_clock_out, @created_ts, @modified_ts)
		    					  SET
		    						 clock_in_date = str_to_date(@clock_in_date, '%%Y-%%m-%%d'),
		    						 clock_in_time = str_to_date(@clock_in_time, '%%h:%%i:%%s'),
		    						 clock_out_date = str_to_date(@clock_out_date, '%%Y-%%m-%%d'),
		    						 clock_out_time = str_to_date(@clock_out_time, '%%h:%%i:%%s'),
		    						 created_ts = str_to_date(@created_ts, '%%Y-%%m-%%d %%h:%%i:%%s'),
		    						 modified_ts = str_to_date(@modified_ts, '%%Y-%%m-%%d %%h:%%i:%%s')
		    					  ";
		    		}*/
		    			
		    		$sql.= $TAsql;
		    		$SQL_COMMAND = sprintf("mysql -u %s -h %s --password=%s --local_infile=1 -e \"%s\" %s",
		    								$this->DST_DB_USERNAME,
		    								$this->DST_DB_HOST,
		    								$this->DST_DB_PASSWD,
		    								$sql,
		    								$this->DST_DB_NAME);
		    		echo $SQL_COMMAND;
		    		echo "<br />======================================<br />";
		    		system($SQL_COMMAND);
							
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
			
			}

			
			
			// Rename existing table(s) as bkup table(s)...
			public function makeBkUpTbls($tbl_name) {
					
				try {
			
					$tblName = $tbl_name;
					$bkupTblName = "{$tbl_name}-bkup";
					
					$dropSQL = sprintf("DROP TABLE IF EXISTS `%s` ", $bkupTblName);
					\DB::statement($dropSQL);
					
					$renameSQL = sprintf("RENAME TABLE `%s` TO `%s`",
										  $tblName, $bkupTblName);
					
					\DB::statement($renameSQL);
						
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}

			
			// Rename new table(s) as live table(s)...
			public function makeLiveTbls($tbl_name) {
					
				try {
						
					$fromTblName = "tmp_{$tbl_name}";
					$toTblName = "zeevant_{$tbl_name}";
					$renameSQL = sprintf("RENAME TABLE `%s` TO `%s`",
										  $fromTblName, $toTblName);
						
					\DB::statement($renameSQL);
			
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
					
			}
				

			// Delete all those data "csv" file(s)...
			public function cleanUPDataCSVFiles($src_tbl) {
				
				try {
					
					$CSV_PATH = public_path() ."/uploaded/db-sync-files/";
					$FILE_NAME = "db_{$src_tbl}.csv";
					$pathToCsv = $CSV_PATH . $FILE_NAME;
					
					@unlink($pathToCsv);
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
				
			}
			
			// sending mail...
			public function sendEmail() {
				
				try {
					
					# I - email HTML template...
					$view_file = "userend.emails.response";
					
					# II - send mail...
					\Mail::send($view_file, null, function ($message) {
						
						$FROM = 'support@zeevant.com';
						$TO = 'sdas@codeuridea.com';
						$CC = 'hereissuman@gmail.com';
						
						$message->from($FROM, 'Zeevant Support Team');
						$message->to($TO, 'Suman')->subject('cron ran successfully :)');
						$message->cc($CC, 'Suman');
						
					});
					
				} catch(Exception $err_obj) {
					show_error($err_obj->getMessage());
				}
				
			}
			
			
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // 		NEW - DB Sync [End]
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
}
