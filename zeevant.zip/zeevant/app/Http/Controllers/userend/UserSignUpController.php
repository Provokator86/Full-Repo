<?php

namespace App\Http\Controllers\userend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserSignUpController extends BaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();

        $this->data['userend_site_title'] = ':: Zeevant - User SignUp ::';
    }


    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;

        # show view part...
        return view('userend.user-signup', $data);
    }

}
