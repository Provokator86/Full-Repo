<?php

namespace App\Http\Controllers\interfaces\userend;

interface DashboardChartGeneratorInterface
{
    # =============================================================
    #       Benchmark Chart Generating Function(s) - Begin
    # =============================================================

        //// Chart 1: "Revenue"...
        public function generateRevenueChartData();

        //// Chart 2: "Gross-Margin"...
        public function generateGrossMarginChartData();

        //// Chart 3: "Internet-Sales"...
        public function generateInternetSalesChartData();

        //// Chart 4: "Average Ticket"...
        public function generateAvgTicketChartData();

        //// Chart 5: "Marketing (% of Sales)"...
        public function generateMarketingPercentChartData();

        //// Chart 6: "Labor Efficiency"...
        public function generateLaborEfficiencyChartData();

        //// Chart 7: "Inventory Turns"...
        public function generateInventoryTurnsChartData();

        //// Chart 8: "Discounts %"...
        public function generateDiscountsPercentChartData();

    # =============================================================
    #       Benchmark Chart Generating Function(s) - End
    # =============================================================
}
