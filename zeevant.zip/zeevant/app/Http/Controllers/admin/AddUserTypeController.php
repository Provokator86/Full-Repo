<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UrlHelper;
use App\Helpers\Utility;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AddUserTypeController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Add New User-Type';
        $data['page_header_SMALL'] = 'Form Preview';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'user-types';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('manage-usr-types', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('User Type(s)', route('user-types'));
        });
        # setting breadcrumb(s) [End]...


        # show view part...
        return view('admin.users.add-user-type', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_user_type_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('s_user_type');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) )
                    $arr_messages[$required_field] = $REQD_FLD_MSG;

                if( $required_field == 's_user_type')
                {
                    if (\App\Models\UserTypesModel::where('s_user_type', '=', \Input::get('s_user_type'))->exists())
                        $arr_messages[$required_field] = ' already exists';
                }
            }

            # ADD "USER TYPE" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->add_new_user_type_AJAX($request);
            }
            else   //// if error occurs...
            {
                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages));
                exit;
            }
        }
        // end of AJAX create new User-Type function...


        # function to create new User-Type [AJAX CALL]...
        public function add_new_user_type_AJAX(Request $request) {

            # db info array...
            $user_types_DB = new \App\Models\UserTypesModel;

            //// Now, retrieving submitted/posted values [BEGIN]...

                $user_types_DB->s_user_type = htmlspecialchars($request->input('s_user_type', true), ENT_QUOTES, 'utf-8');
                $user_types_DB->dt_added    = Utility::get_db_datetime();

            //// retrieving submitted/posted values [END]...

            //// inserting into user-types table...
            $user_types_DB->save();

            //// redirection URL...
            $REDIRECT = UrlHelper::admin_base_url() ."manage-user-types";

            # success message...
            $SUCCESS_MSG = "User-Type added successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }

    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================



}
