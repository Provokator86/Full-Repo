<?php

namespace App\Http\Controllers\admin\users;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;
use App\Helpers\Utility as utils;

class AddFranchisorUserController extends \App\Http\Controllers\admin\AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Add New Franchisor User';
        $data['page_header_SMALL'] = '';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'franchisor-users';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('add-franchisor-users', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('Add Franchisor-User', route('add-franchisor-user'));
        });
        # setting breadcrumb(s) [End]...


        # show view part...
        return view('admin.users.franchisors.add-franchisor-user', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_franchisor_user_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('s_username', 's_passwd', 's_email',
                                     's_first_name', 'i_franchisor_id');
            $email_flds = array('s_email');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

                if( $required_field == 's_username')
                {
                    if (\App\Models\Users::where('s_username', '=', \Input::get('s_username'))->exists()) {
                        $arr_messages[$required_field] = ' already exists';
                        $err_flds[] = 's_username';
                    }

                }

            }


            # email address validate....
            foreach($email_flds as $email_fld) {

                if( $_POST[$email_fld]!='' ) {

                    if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                        if( !in_array($email_fld, $err_flds) )
                            $err_flds[] = $email_fld;

                        $arr_messages[$email_fld] = ' invalid email-id';
                    }

                }
            }


            # ADD NEW "FRANCHISOR-USER" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->add_franchisor_user_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds' => $success_flds));
                exit;
            }
        }


        # function to Add New Franchisor-User [AJAX CALL]...
        public function add_franchisor_user_AJAX(Request $request) {

            //// Now, retrieving submitted/posted values [BEGIN]...
            $user_DB = new \App\Models\Users();

            # I: User Personal/Login Credentials...
            $usr_arr = array();
            $usr_arr['s_username']       = htmlspecialchars($request->input('s_username', true), ENT_QUOTES, 'utf-8');
            $usr_passwd = trim( $request->input('s_passwd', true) );
            $usr_arr['s_passwd']         = utils::get_salted_password($usr_passwd);
            $usr_arr['s_email']          = trim( $request->input('s_email', true) );
            $usr_arr['i_franchisor_id']  = trim( $request->input('i_franchisor_id', true) );
            $usr_arr['s_first_name']     = trim( $request->input('s_first_name', true) );
            $usr_arr['s_last_name']      = trim( $request->input('s_last_name', true) );
            $usr_arr['dt_added']         = utils::get_db_datetime();
            //// retrieving submitted/posted values [END]...

            //// adding new data to users-master table...
            $usr_tbl = getenv('DB_PREFIX') .'users';
            \DB::table($usr_tbl)
                ->insert($usr_arr);

            //// redirection URL...
            $REDIRECT = UrlHelper::admin_base_url() ."manage-franchisor-users";

            # success message...
            $SUCCESS_MSG = "New Franchisor-User info added successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }
        // end of AJAX Add-Franchisor function...


        # function to save logo image into proper place...
        public function saveLogoImg(Request $request) {

            # I: logo dimension(s)...
            $LOGO_WIDTH  = config('custom.config.logo_width');
            $LOGO_HEIGHT = config('custom.config.logo_height');

            # II: logo saving...
            $LOGO_PATH = public_path() ."/uploaded/franchisor-logos/";

            // A: processing uploaded logo filename...
            $LOGO_NAME = pathinfo(\Input::file('s_logo')->getClientOriginalName(), PATHINFO_FILENAME);
            $LOGO_EXT  = pathinfo(\Input::file('s_logo')->getClientOriginalName(), PATHINFO_EXTENSION);
            $LOGO_NAME = utils::createImageName( $LOGO_NAME );  // make it hyphenated

            if( utils::test_file($LOGO_PATH.$LOGO_NAME.'.'.$LOGO_EXT) ) {
                for( $i=0; utils::test_file($LOGO_PATH.$LOGO_NAME.'-'.$i.'.'.$LOGO_EXT); $i++ ) {
                }

                $NEW_LOGO_NAME = $LOGO_NAME.'-'.$i;
            }
            else {
                $NEW_LOGO_NAME = $LOGO_NAME;
            }

            $LOGO_FULL = $NEW_LOGO_NAME .'.'. $LOGO_EXT;

            // B: Saving & Resizing (if necessary) Logo-Pic...
            # check uploaded image height & width...
            list($uploaded_width, $uploaded_height) = getimagesize(\Input::file('s_logo'));

            if( $uploaded_width<$LOGO_WIDTH && $uploaded_height<$LOGO_HEIGHT )  // i.e. within preferred limits
            {
                // upload file to destination-path...
                \Input::file('s_logo')->move($LOGO_PATH, $LOGO_FULL);

            } else {    // i.e. bigger then preferred dimensions

                // 1: make image instance...
                \Input::file('s_logo')->move($LOGO_PATH, $LOGO_FULL);
                $img = \Image::make($LOGO_PATH . $LOGO_FULL);

                // 2: resize image...
                if( $uploaded_width>$uploaded_height ) {
                    $img->resize($LOGO_WIDTH, null, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($LOGO_PATH . $LOGO_FULL);
                } else {
                    $img->resize(null, $LOGO_HEIGHT, function ($constraint) {
                        $constraint->aspectRatio();
                    })->save($LOGO_PATH . $LOGO_FULL);
                }

            }

            return $LOGO_FULL;

        }


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================

}
