<?php

namespace App\Http\Controllers\admin\users;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;

class ManageFranchisorUsersController extends \App\Http\Controllers\admin\AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage Franchisor Users';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'franchisor-users';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('manage-franchisor-users', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('Franchisor Users', route('franchisor-users'));
        });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Franchisor-User(s) [Begin]
        $record_index = $page-1;
        $where_cond = ' WHERE A.`i_user_type`=2 ';  // i.e. All Franchisor-User(s)
        $data['selected_franchisor'] = -1;
        if( \Session::has('selected_franchisor') ) {
            $where_cond .= " AND A.`i_franchisor_id`=". \Session::get('selected_franchisor');
            $data['selected_franchisor'] = \Session::get('selected_franchisor');
        }

        $usrModel = new \App\Models\Users();
        $order_by = ' `i_id` DESC ';
        $records = $usrModel->fetchFranchisorUserRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) && $page>1 ) {
            $page--;
            $record_index = $page-1;
            $records = $usrModel->fetchFranchisorUserRecords($where_cond,
                                                             $record_index,
                                                             $data['settings_info']->i_items_per_page,
                                                             $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $usrModel->getTotalFranchisorUsersInfo($where_cond);
        // for fetching Franchisor(s) [End]

        $franchisor_users = new \App\Libraries\MyPaginator($records, $total_records,
                                                           $data['settings_info']->i_items_per_page,
                                                           route('franchisor-users'), $page);
        $data['franchisor_user_arr'] = $franchisor_users;
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('admin.users.franchisors.manage-franchisor-users', $data);
    }


    // function to delete selected franchisor-user...
    public function delete_franchisor_user_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $USR_ID = intval( $request->input('franchisor_user_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected franchisor-user data from table...
        $usrObj = \App\Models\Users::find($USR_ID);
        $usrObj->delete();


        # successful message...
        $SUCCESS_MSG = "Franchisor-User deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."manage-franchisor-users/{$CURRENT_PG_NDEX}";

        echo json_encode(array('result'=>'success',
                               'msg'=>$SUCCESS_MSG,
                               'redirect'=>$REDIRECT_URL));
        exit(0);
    }


    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //           Miscellaneous Function(s) - Begin
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        # function to load User(s)-Listing based on Franchisor selection [AJAX CALL]...
        public function load_franchisor_users_AJAX() {

            # I: retrieving selected franchisorID...
            $selected_franchisor = \Input::get('franchisor_id');

            # II: set session based on selection...
            if( $selected_franchisor=="-1" ) {

                if( \Session::has('selected_franchisor') )
                    \Session::forget('selected_franchisor');

            } else
                \Session::put('selected_franchisor', $selected_franchisor);

            \Session::save();

            # III: redirect URL...
            $REDIRECT_URL = 'manage-franchisor-users';

            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT_URL));
            exit(0);
        }

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //           Miscellaneous Function(s) - End
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
