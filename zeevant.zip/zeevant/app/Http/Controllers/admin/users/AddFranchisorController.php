<?php

namespace App\Http\Controllers\admin\users;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;
use App\Helpers\Utility as utils;

class AddFranchisorController extends \App\Http\Controllers\admin\AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Add New Franchisor';
        $data['page_header_SMALL'] = '';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'franchisors';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('manage-franchisors', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('Add Franchisor', route('add-franchisor'));
        });
        # setting breadcrumb(s) [End]...


        # show view part...
        return view('admin.users.franchisors.add-franchisor', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_franchisor_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('s_company_name', 's_company_email', 's_address_1',
                                     's_city', 's_state', 's_zipcode');
            $img_required_fields = array('s_logo');
            $VALID_IMG_FILES = config('custom.config.valid_img_ext');
            $email_flds = array('s_company_email');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

                if( $required_field == 's_company_name')
                {
                    $franchisor_tbl = getenv('DB_PREFIX') .'franchisor_details';
                    if( \DB::table($franchisor_tbl)
                            ->where('s_company_name', '=', \Input::get('s_company_name'))
                            ->exists() ) {
                    #if (\App\Models\Users::where('s_company_name', '=', \Input::get('s_company_name'))->exists()) {
                        $arr_messages[$required_field] = ' already exists';
                        $err_flds[] = 's_company_name';
                    }

                }

            }


            // for image empty-check validation...
            foreach($img_required_fields as $img_field) {

                # if image-file is not selected...
                if( \Input::hasFile($img_field) ) {
                    $img_file = \Input::file($img_field)->getClientOriginalName();

                    $UPLOADED_FILE_EXT = strtolower(utils::get_extension($img_file));
                    $UPLOADED_FILE_EXT = substr($UPLOADED_FILE_EXT, strpos($UPLOADED_FILE_EXT, '.') + 1);

                    if (!in_array($UPLOADED_FILE_EXT, $VALID_IMG_FILES))   // not a valid image-type...
                        $arr_messages[$img_field] = ' not a valid image file';

                } else {
                    $arr_messages[$img_field] = $REQD_FLD_MSG;
                }

            }

            # email address validate....
            foreach($email_flds as $email_fld) {

                if( $_POST[$email_fld]!='' ) {

                    if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                        if( !in_array($email_fld, $err_flds) )
                            $err_flds[] = $email_fld;

                        $arr_messages[$email_fld] = ' invalid email-id';
                    }

                }
            }

            # phone number validation (if Non-Empty)...
            $pattern = '/^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/i';
            $SITE_PHONE_NO = $request->input('s_phone');

            if( !empty($SITE_PHONE_NO) ) {
                if (!preg_match($pattern, $SITE_PHONE_NO)) {
                    if (!in_array('s_phone', $err_flds))
                        $err_flds[] = 's_phone';

                    $arr_messages['s_phone'] = '* invalid phone-number';
                }
            }

            # UPDATE "FRANCHISOR" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->add_franchisor_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds' => $success_flds));
                exit;
            }
        }


        # function to Add New Franchisor [AJAX CALL]...
        public function add_franchisor_AJAX(Request $request) {

            //// Now, retrieving submitted/posted values [BEGIN]...
                # I: Franchisor Details...
                $franchisor_arr = array();
                $franchisor_arr['s_company_name'] = htmlspecialchars($request->input('s_company_name', true), ENT_QUOTES, 'utf-8');
                $franchisor_arr['s_company_email']= trim( $request->input('s_company_email', true) );
                $franchisor_arr['s_phone']        = trim( $request->input('s_phone', true) );
                $franchisor_arr['s_address1']     = trim( $request->input('s_address_1', true) );
                $franchisor_arr['s_address2']     = trim( $request->input('s_address_2', true) );
                $franchisor_arr['s_city']         = trim( $request->input('s_city', true) );
                $franchisor_arr['s_state']        = trim( $request->input('s_state', true) );
                $franchisor_arr['s_zipcode']      = trim( $request->input('s_zipcode', true) );
                $LOGO = $this->saveLogoImg($request);
                if( !empty($LOGO) )
                    $franchisor_arr['s_logo']     = $LOGO;
                $franchisor_arr['dt_added']       = utils::get_db_datetime();
            //// retrieving submitted/posted values [END]...

            //// adding new data to franchisor-details table(s)...
                $franchisor_tbl = getenv('DB_PREFIX') .'franchisor_details';
                \DB::table($franchisor_tbl)
                    ->insert($franchisor_arr);

            //// redirection URL...
            $REDIRECT = UrlHelper::admin_base_url() ."manage-franchisors";

            # success message...
            $SUCCESS_MSG = "New Franchisor info added successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }
        // end of AJAX Add-Franchisor function...


        # function to save logo image into proper place...
        public function saveLogoImg(Request $request) {

            # I: logo dimension(s)...
                $LOGO_WIDTH  = config('custom.config.logo_width');
                $LOGO_HEIGHT = config('custom.config.logo_height');

            # II: logo saving...
                $LOGO_PATH = public_path() ."/uploaded/franchisor-logos/";

                // A: processing uploaded logo filename...
                $LOGO_NAME = pathinfo(\Input::file('s_logo')->getClientOriginalName(), PATHINFO_FILENAME);
                $LOGO_EXT  = pathinfo(\Input::file('s_logo')->getClientOriginalName(), PATHINFO_EXTENSION);
                $LOGO_NAME = utils::createImageName( $LOGO_NAME );  // make it hyphenated

                if( utils::test_file($LOGO_PATH.$LOGO_NAME.'.'.$LOGO_EXT) ) {
                    for( $i=0; utils::test_file($LOGO_PATH.$LOGO_NAME.'-'.$i.'.'.$LOGO_EXT); $i++ ) {
                    }

                    $NEW_LOGO_NAME = $LOGO_NAME.'-'.$i;
                }
                else {
                    $NEW_LOGO_NAME = $LOGO_NAME;
                }

                $LOGO_FULL = $NEW_LOGO_NAME .'.'. $LOGO_EXT;

                // B: Saving & Resizing (if necessary) Logo-Pic...
                # check uploaded image height & width...
                list($uploaded_width, $uploaded_height) = getimagesize(\Input::file('s_logo'));

                if( $uploaded_width<$LOGO_WIDTH && $uploaded_height<$LOGO_HEIGHT )  // i.e. within preferred limits
                {
                    // upload file to destination-path...
                    \Input::file('s_logo')->move($LOGO_PATH, $LOGO_FULL);

                } else {    // i.e. bigger then preferred dimensions

                    // 1: make image instance...
                    \Input::file('s_logo')->move($LOGO_PATH, $LOGO_FULL);
                    $img = \Image::make($LOGO_PATH . $LOGO_FULL);

                    // 2: resize image...
                    if( $uploaded_width>$uploaded_height ) {
                        $img->resize($LOGO_WIDTH, null, function ($constraint) {
                            $constraint->aspectRatio();
                        })->save($LOGO_PATH . $LOGO_FULL);
                    } else {
                        $img->resize(null, $LOGO_HEIGHT, function ($constraint) {
                            $constraint->aspectRatio();
                        })->save($LOGO_PATH . $LOGO_FULL);
                    }

                }

            return $LOGO_FULL;

        }


    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================

}
