<?php

namespace App\Http\Controllers\admin\users;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;

class ManageFranchisorsController extends \App\Http\Controllers\admin\AdminBaseController
{

    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage Franchisors';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'franchisors';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('manage-franchisors', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('Franchisors', route('franchisors'));
        });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Franchisor(s) [Begin]
        $record_index = $page-1;
        $where_cond = '';  // i.e. All Franchisor(s)
        $usrModel = new \App\Models\Users();
        $order_by = ' `i_id` DESC ';
        $records = $usrModel->fetchFranchisorRecords($where_cond,
                                                     $record_index,
                                                     $data['settings_info']->i_items_per_page,
                                                     $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) && $page>1 ) {
            $page--;
            $record_index = $page-1;
            $records = $usrModel->fetchFranchisorRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $usrModel->getTotalFranchisorInfo($where_cond);
        // for fetching Franchisor(s) [End]

        $franchisors = new \App\Libraries\MyPaginator($records, $total_records,
                                                      $data['settings_info']->i_items_per_page,
                                                      route('franchisors'), $page);
        $data['franchisor_arr'] = $franchisors;
        $data['current_page_index'] = $page;
        $data['logo_path'] = url() ."/uploaded/franchisor-logos/";
        # Records for pagination [End]

        # show view part...
        return view('admin.users.franchisors.manage-franchisors', $data);
    }


    # function to delete selected franchisor...
    public function delete_franchisor_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $USR_TYPE_ID = intval( $request->input('company_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected company data from table...
        $usrTypeObj = \App\Models\CompanyModel::find(1);
        $usrTypeObj->delete();


        # successful message...
        $SUCCESS_MSG = "Company deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."manage-companies/{$CURRENT_PG_NDEX}";

        echo json_encode(array('result'=>'success',
            'msg'=>$SUCCESS_MSG,
            'redirect'=>$REDIRECT_URL));
        exit(0);
    }
}
