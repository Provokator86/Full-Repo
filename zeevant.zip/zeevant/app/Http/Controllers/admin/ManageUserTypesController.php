<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;

class ManageUserTypesController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage User-Type(s)';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'user-types';


        # setting breadcrumb(s) [Begin]...
            \Breadcrumbs::register('home', function($breadcrumbs) {
                $breadcrumbs->push('Home', route('home'));
            });
            \Breadcrumbs::register('users', function($breadcrumbs) {
                $breadcrumbs->parent('home');
                $breadcrumbs->push('Users');
            });
            \Breadcrumbs::register('manage-usr-types', function($breadcrumbs) {
                $breadcrumbs->parent('users');
                $breadcrumbs->push('User Type(s)', route('user-types'));
            });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
            $page = ( empty($page) )? 1: $page;

            // for fetching User-Type(s) [Begin]
                $record_index = $page-1;
                $where_cond = ' WHERE 1 ';  // i.e. All Record(s)
                $userTypesModel = new \App\Models\UserTypesModel();
                $order_by = ' `i_id` DESC ';
                $records = $userTypesModel->fetchRecords($where_cond,
                                                         $record_index,
                                                         $data['settings_info']->i_items_per_page,
                                                         $order_by);

                # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
                    if( empty($records) ) {
                        $page--;
                        $record_index = $page-1;
                        $records = $userTypesModel->fetchRecords($where_cond,
                                                                 $record_index,
                                                                 $data['settings_info']->i_items_per_page,
                                                                 $order_by);
                    }
                # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


                $total_records = $userTypesModel->getTotalInfo($where_cond);
            // for fetching User-Type(s) [End]

            $user_types = new \App\Libraries\MyPaginator($records, $total_records,
                                                         $data['settings_info']->i_items_per_page,
                                                         route('user-types'), $page);
            $data['user_types_arr'] = $user_types;
            $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('admin.users.manage-user-types', $data);
    }

    # function to change status of the selected user-type...
    public function change_usertype_status_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $ID = intval( $request->input('usr_type_id', true) );

        $USR_TYPE = \App\Models\UserTypesModel::find($ID);

        $USR_TYPE_STATUS = $USR_TYPE->i_active;

        if( $USR_TYPE_STATUS ) {

            $TOGGLE_STATUS_LABEL = 'Inactive';
            $TOGGLE_BUTTON_LABEL = 'Make Active';
            $TOGGLE_ICON = 'check';
            $USR_TYPE_TOGGLE_STATUS   = 0;

        } else {

            $TOGGLE_STATUS_LABEL = 'Active';
            $TOGGLE_BUTTON_LABEL = 'Make Inactive';
            $TOGGLE_ICON = 'close';
            $USR_TYPE_TOGGLE_STATUS   = 1;

        }

        # updating status accordingly...
        $USR_TYPE->i_active = $USR_TYPE_TOGGLE_STATUS;

        # Now, update it...
        $USR_TYPE->save();

        echo json_encode(array('result'=> 'success',
                               'lbl'   => $TOGGLE_STATUS_LABEL,
                               'btn'   => $TOGGLE_BUTTON_LABEL,
                               'icon'  => $TOGGLE_ICON,
                               'toggle_status'=> $USR_TYPE_TOGGLE_STATUS));
        exit(0);
    }

    # function to delete selected user-type...
    public function delete_usr_type_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $USR_TYPE_ID = intval( $request->input('usr_type_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected user-type data from table...
            $usrTypeObj = \App\Models\UserTypesModel::find(1);
            $usrTypeObj->delete();


        # successful message...
        $SUCCESS_MSG = "User-Type deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."manage-user-types/{$CURRENT_PG_NDEX}";

        echo json_encode(array('result'=>'success',
                               'msg'=>$SUCCESS_MSG,
                               'redirect'=>$REDIRECT_URL));
        exit(0);
    }


    # ACL - display page
    public function access_control_page() {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'ACL';
        $data['page_header_SMALL'] = 'Manage';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'user-types';

        dd(config());
        /*echo config('custom.config.test');
        echo \Config::get('custom/config.test');*/

        return view('admin.users.view-acl-page', $data);
    }

}
