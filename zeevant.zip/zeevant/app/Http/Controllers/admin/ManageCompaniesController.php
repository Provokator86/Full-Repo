<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\UrlHelper;

class ManageCompaniesController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage Companies';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'companies';


        # setting breadcrumb(s) [Begin]...
            \Breadcrumbs::register('home', function($breadcrumbs) {
                $breadcrumbs->push('Home', route('home'));
            });
            \Breadcrumbs::register('users', function($breadcrumbs) {
                $breadcrumbs->parent('home');
                $breadcrumbs->push('Users');
            });
            \Breadcrumbs::register('manage-companies', function($breadcrumbs) {
                $breadcrumbs->parent('users');
                $breadcrumbs->push('Companies', route('companies'));
            });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
            $page = ( empty($page) )? 1: $page;

            // for fetching User-Type(s) [Begin]
                $record_index = $page-1;
                $where_cond = ' WHERE 1 ';  // i.e. All Record(s)
                $companyModel = new \App\Models\CompanyModel();
                $order_by = ' `i_id` DESC ';
                $records = $companyModel->fetchRecords($where_cond,
                                                       $record_index,
                                                       $data['settings_info']->i_items_per_page,
                                                       $order_by);

                # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
                if( empty($records) ) {
                    $page--;
                    $record_index = $page-1;
                    $records = $companyModel->fetchRecords($where_cond,
                                                           $record_index,
                                                           $data['settings_info']->i_items_per_page,
                                                           $order_by);
                }
                # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


                $total_records = $companyModel->getTotalInfo($where_cond);
            // for fetching User-Type(s) [End]

            $companies = new \App\Libraries\MyPaginator($records, $total_records,
                                                        $data['settings_info']->i_items_per_page,
                                                        route('companies'), $page);
            $data['companies_arr'] = $companies;
            $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('admin.users.manage-companies', $data);
    }


    # function to delete selected company...
    public function delete_company_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $USR_TYPE_ID = intval( $request->input('company_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );

        # delete the selected company data from table...
        $usrTypeObj = \App\Models\CompanyModel::find(1);
        $usrTypeObj->delete();


        # successful message...
        $SUCCESS_MSG = "Company deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."manage-companies/{$CURRENT_PG_NDEX}";

        echo json_encode(array('result'=>'success',
                               'msg'=>$SUCCESS_MSG,
                               'redirect'=>$REDIRECT_URL));
        exit(0);
    }
}
