<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UrlHelper;
use App\Helpers\Utility;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class EditCompanyController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($company_id) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Edit Company';
        $data['page_header_SMALL'] = 'Form Preview';
        $data['parent_menu'] = 'users';
        $data['child_menu'] = 'companies';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('users', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Users');
        });
        \Breadcrumbs::register('manage-companies', function($breadcrumbs) {
            $breadcrumbs->parent('users');
            $breadcrumbs->push('Companies', route('companies'));
        });
        # setting breadcrumb(s) [End]...


        # loading specific record [Begin]
            $data['company_info'] = \App\Models\CompanyModel::find($company_id);
        # loading specific record [End]


        # show view part...
        return view('admin.users.edit-company', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

        # function to validate form-submission [AJAX CALL]
        public function validate_company_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('s_company_name', 's_email', 'i_no_employees',
                                     'i_no_stores', 's_address_1', 's_city',
                                     's_state', 's_zipcode');
            $email_flds = array('s_email');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( trim($_POST[$required_field])=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }

                if( $required_field == 's_company_name')
                {
                    if (\App\Models\CompanyModel::where('s_company_name', '=', \Input::get('s_company_name'))
                                                ->where('i_id', '!=', \Input::get('company_id'))->exists()) {
                        $arr_messages[$required_field] = ' already exists';
                        $err_flds[] = 's_company_name';
                    }

                }
            }


            # email address validate....
            foreach($email_flds as $email_fld) {

                if( $_POST[$email_fld]!='' ) {

                    if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                        if( !in_array($email_fld, $err_flds) )
                            $err_flds[] = $email_fld;

                        $arr_messages[$email_fld] = '* invalid email-id';
                    }

                }
            }

            # phone number validation (if Non-Empty)...
            $pattern = '/^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/i';
            $SITE_PHONE_NO = $request->input('s_phone');

            if( !empty($SITE_PHONE_NO) ) {
                if (!preg_match($pattern, $SITE_PHONE_NO)) {
                    if (!in_array('s_phone', $err_flds))
                        $err_flds[] = 's_phone';

                    $arr_messages['s_phone'] = '* invalid phone-number';
                }
            }

            # UPDATE "COMPANY" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->edit_company_AJAX($request);
            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'       => 'error',
                                       'arr_messages' => $arr_messages,
                                       'success_flds'  => $success_flds));
                exit;
            }
        }
        // end of AJAX update Company function...


        # function to update existing Company [AJAX CALL]...
        public function edit_company_AJAX(Request $request) {

            # db info array...
            $SELECTED_COMPANY_ID = intval($request->input('company_id', true));
            $company_DB = \App\Models\CompanyModel::find($SELECTED_COMPANY_ID);

            //// Now, retrieving submitted/posted values [BEGIN]...

                $company_DB->s_company_name     = htmlspecialchars($request->input('s_company_name', true), ENT_QUOTES, 'utf-8');
                $company_DB->s_email            = trim( $request->input('s_email', true) );
                $company_DB->s_phone            = trim( $request->input('s_phone', true) );
                $company_DB->i_no_employees     = trim( $request->input('i_no_employees', true) );
                $company_DB->i_corporate_users  = trim( $request->input('i_corporate_users', true) );
                $company_DB->i_field_executives = trim( $request->input('i_field_executives', true) );
                $company_DB->i_no_stores        = trim( $request->input('i_no_stores', true) );
                $company_DB->s_address_1        = trim( $request->input('s_address_1', true) );
                $company_DB->s_address_2        = trim( $request->input('s_address_2', true) );
                $company_DB->s_city             = trim( $request->input('s_city', true) );
                $company_DB->s_state            = trim( $request->input('s_state', true) );
                $company_DB->s_zipcode          = trim( $request->input('s_zipcode', true) );
                $company_DB->s_authorized_person = trim( $request->input('s_authorized_person', true) );
                $company_DB->i_created_by       = \Session::get('admin_user_id');
                $company_DB->dt_updated         = Utility::get_db_datetime();

            //// retrieving submitted/posted values [END]...

            //// updating company table...
            $company_DB->save();

            //// redirection URL...
            $REDIRECT = UrlHelper::admin_base_url() ."manage-companies";

            # success message...
            $SUCCESS_MSG = "Company info updated successfully";


            echo json_encode(array('result'=>'success',
                                   'redirect'=>$REDIRECT,
                                   'msg'=>$SUCCESS_MSG));
            exit;

        }

    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================


}
