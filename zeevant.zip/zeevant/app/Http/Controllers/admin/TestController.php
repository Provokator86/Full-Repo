<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Image;

class TestController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // function for image-manipulations...
    public function image_actions() {

        $path = public_path();

        // create instance
        $img = Image::make($path .'/testing/demo2.jpg');

        // resize image to fixed size
        $img->resize(300, 200)->save($path .'/testing/thumbs/demo-fixed-size.jpg');

        // resize only the width of the image
        $img->resize(300, null)->save($path .'/testing/thumbs/demo-fixed-width.jpg');

        // resize only the height of the image
        $img->resize(null, 300)->save($path .'/testing/thumbs/demo-fixed-height.jpg');

        // resize the image to a width of 300 and constrain aspect ratio (auto height)
        $img->resize(300, null, function ($constraint) {
            $constraint->aspectRatio();
        })->save($path .'/testing/thumbs/demo-width-aspect.jpg');

        // resize the image to a height of 200 and constrain aspect ratio (auto width)
        $img->resize(null, 250, function ($constraint) {
            $constraint->aspectRatio();
        })->save($path .'/testing/thumbs/demo-height-aspect.jpg');

        // prevent possible upsizing
        $img->resize(null, 300, function ($constraint) {
            $constraint->aspectRatio();
            $constraint->upsize();
        })->save($path .'/testing/thumbs/demo-upsizing.jpg');

        echo "image(s) resized perfectly!!";

    }
}
