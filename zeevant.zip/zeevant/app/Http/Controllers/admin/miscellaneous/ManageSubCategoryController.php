<?php

namespace App\Http\Controllers\admin\miscellaneous;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# using Model(s) & Helper(s)
use App\Helpers\UrlHelper;
use App\Models\CategoryModel as modCategory;


class ManageSubCategoryController extends \App\Http\Controllers\admin\AdminBaseController
{

    // constructor definition...
    public function __construct() {
        parent::__construct();
    }

    // index function definition...
    public function index($parent_category_id) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage Sub-Categories';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'miscellaneous';
        $data['child_menu'] = 'categories';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('misc', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Miscellaneous');
        });
        \Breadcrumbs::register('manage-categories', function($breadcrumbs) {
            $breadcrumbs->parent('misc');
            $breadcrumbs->push('Category Master', route('category-master'));
        });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Parent-Categories [Begin]
        $record_index = $page-1;
        $where_cond = " WHERE `i_parent_id`={$parent_category_id} ";  // i.e. All Sub-Categories
        $categoryModel = new modCategory();
        $order_by = ' `i_id` DESC ';
        $records = $categoryModel->fetchRecords($where_cond,
                                                $record_index,
                                                $data['settings_info']->i_items_per_page,
                                                $order_by);

        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) ) {
            $page--;
            $record_index = $page-1;
            $records = $categoryModel->fetchRecords($where_cond,
                                                    $record_index,
                                                    $data['settings_info']->i_items_per_page,
                                                    $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $categoryModel->getTotalInfo($where_cond);
        // for fetching Sub-Categories [End]

        $sub_categories = new \App\Libraries\MyPaginator($records, $total_records,
                                                         $data['settings_info']->i_items_per_page,
                                                         route('category-master'), $page);
        $data['sub_categories_arr'] = $sub_categories;
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('admin.miscellaneous.sub-category-master', $data);
    }

}