<?php

namespace App\Http\Controllers\admin\miscellaneous;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# using Model(s) & Helper(s)
use App\Helpers\UrlHelper;
use App\Models\CategoryModel as modCategory;


class CategoryMasterController extends \App\Http\Controllers\admin\AdminBaseController
{

    // constructor definition...
    public function __construct() {
        parent::__construct();
        
        $this->category_map_tbl = getenv('DB_PREFIX') .'category_map';
    }

    // index function definition...
    public function index($page=null) {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Manage Categories';
        $data['page_header_SMALL'] = 'Listing';
        $data['parent_menu'] = 'miscellaneous';
        $data['child_menu'] = 'categories';


        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('misc', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Miscellaneous');
        });
        \Breadcrumbs::register('manage-categories', function($breadcrumbs) {
            $breadcrumbs->parent('misc');
            $breadcrumbs->push('Category Master', route('category-master'));
        });
        # setting breadcrumb(s) [End]...


        # Records for pagination [Begin]
        $page = ( empty($page) )? 1: $page;

        // for fetching Parent-Categories [Begin]
        $record_index = $page-1;
        $where_cond = ' WHERE 1 ';  // i.e. All Parent-Category Record(s)
        $categoryModel = new modCategory();
        $order_by = ' `product_group`,`subgroup` ASC ';
        $records = $categoryModel->fetchCategoryRecords($where_cond,
                                                        $record_index,
                                                        $data['settings_info']->i_items_per_page,
                                                        $order_by);
        
        # ~~~~~~~~~~~ If no record(s) available [Begin] ~~~~~~~~~~~
        if( empty($records) ) {
            $page--;
            $record_index = $page-1;
            $records = $categoryModel->fetchCategoryRecords($where_cond,
                                                            $record_index,
                                                            $data['settings_info']->i_items_per_page,
                                                            $order_by);
        }
        # ~~~~~~~~~~~ If no record(s) available [End] ~~~~~~~~~~~


        $total_records = $categoryModel->getTotalInfo($where_cond);
        // for fetching Parent-Categories [End]

        $categories = new \App\Libraries\MyPaginator($records, $total_records,
                                                     $data['settings_info']->i_items_per_page,
                                                     route('category-master'), $page);
        $data['categories_arr'] = $categories;
        $data['current_page_index'] = $page;
        # Records for pagination [End]

        # show view part...
        return view('admin.miscellaneous.category-master', $data);
    }
    
    # function to delete selected user-type...
    public function delete_category_AJAX_OLD(Request $request)
    {
        # retrieving REQUEST parameters...
        $USR_TYPE_ID = intval( $request->input('category_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );
        $PRODUCT_SUB_GROUP =  $request->input('selected_category_prd_sub_group', true) ;
        $PRODUCT_GROUP =  $request->input('selected_category_prd_group', true) ;

        # delete the selected user-type data from table...
        if ($PRODUCT_SUB_GROUP)
        {    
            $usrTypeObj = \App\Models\CategoryModel::find($USR_TYPE_ID);
            $usrTypeObj->delete();
        }
        else
        {
            \App\Models\CategoryModel::where('s_product_group', $PRODUCT_GROUP)->delete();
        }

        # successful message...
        $SUCCESS_MSG = "Category deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."miscellaneous/category-master";

        echo json_encode(array('result'=>'success',
                               'msg'=>$SUCCESS_MSG,
                               'redirect'=>$REDIRECT_URL));
        exit(0);
    }

    /// NEW - delete
    public function delete_category_AJAX(Request $request)
    {
        # retrieving REQUEST parameters...
        $CATEGORY_ID = intval( $request->input('category_id', true) );
        $CURRENT_PG_NDEX = intval( $request->input('pg_index', true) );
        $PRODUCT_SUB_GROUP =  $request->input('selected_category_prd_sub_group', true) ;
        $PRODUCT_GROUP =  $request->input('selected_category_prd_group', true) ;

        # delete the selected category data from table...
        \DB::table($this->category_map_tbl)->where('i_id', $CATEGORY_ID)->delete();
        
        # successful message...
        $SUCCESS_MSG = "Category deleted successfully.";

        # redirect message...
        $REDIRECT_URL = urlHelper::admin_base_url() ."miscellaneous/category-master";

        echo json_encode(array('result'=>'success',
                               'msg'=>$SUCCESS_MSG,
                               'redirect'=>$REDIRECT_URL));
        exit(0);
    }
}