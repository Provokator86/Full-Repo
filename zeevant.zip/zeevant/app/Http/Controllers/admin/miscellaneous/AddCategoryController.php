<?php

namespace App\Http\Controllers\admin\miscellaneous;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# using Model(s) & Helper(s)
use App\Helpers\UrlHelper;
use App\Helpers\Utility as utils;
use App\Models\CategoryModel as modCategory;


class AddCategoryController extends \App\Http\Controllers\admin\AdminBaseController
{
    // constructor definition...
    public function __construct() {
        parent::__construct();
        
        $this->category_map_tbl = getenv('DB_PREFIX') .'category_map';
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
        $data = $this->data;
        $data['page_header_BIG'] = 'Add Category';
        $data['page_header_SMALL'] = 'Form Preview';
        $data['parent_menu'] = 'miscellaneous';
        $data['child_menu'] = 'categories';
        

        # setting breadcrumb(s) [Begin]...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        \Breadcrumbs::register('misc', function($breadcrumbs) {
            $breadcrumbs->parent('home');
            $breadcrumbs->push('Miscellaneous');
        });
        \Breadcrumbs::register('manage-categories', function($breadcrumbs) {
            $breadcrumbs->parent('misc');
            $breadcrumbs->push('Category Master', route('category-master'));
        });
        # setting breadcrumb(s) [End]...

        
        # show view part...
        return view('admin.miscellaneous.add-category', $data);
    }



    //// ==================================================================================
    ////            AJAX CALLS [BEGIN]
    //// ==================================================================================

    # function to validate form-submission [AJAX CALL]
    public function validate_category_AJAX_OLD(Request $request)
    {
        // Error Messages for Required Fields...
        $err_flds = array();
        $REQD_FLD_MSG = ' required field';
        $required_fields = array('p_category', 's_category_name', 'franchisors_id', 'color_code');

        // adjusting err-messages part accordingly...
        $arr_messages = array();

        ////////////// VALIDATION CHECKS - BEGIN //////////////

        # validation for singular fields (i.e. appearing once)...
        foreach($required_fields as $required_field) {

            if( $_POST[$required_field]=='' && in_array($required_field, $required_fields) )
                $arr_messages[$required_field] = $REQD_FLD_MSG;

            /*if( $required_field == 's_category_name')
            {
                if (\App\Models\CategoryModel::where('s_category_name', '=', \Input::get('s_category_name'))
                    ->where('i_id', '!=', \Input::get('category_id'))->exists())
                    $arr_messages[$required_field] = ' already exists';
            } */
        }

        # UPDATE "CATEGORY" [if no errors]...
        if( count($arr_messages)==0 ) {

            $this->add_category_AJAX($request);
        }
        else   //// if error occurs...
        {
            echo json_encode(array('result' => 'error',
                'arr_messages' => $arr_messages));
            exit;
        }
    }
    // end of AJAX edit Category function...


    # function to update existing Category [AJAX CALL]...
    public function add_category_AJAX_OLD(Request $request) {

        # db info array...
        $category_DB = new \App\Models\CategoryModel;

        //// Now, retrieving submitted/posted values [BEGIN]...

        $p_cat  = $request->input('p_category', true);
        
        if ($p_cat == -1)
        {
            $category_DB->s_product_group     = htmlspecialchars($request->input('s_category_name', true), ENT_QUOTES, 'utf-8');
        }
        else
        {
            $category_DB->s_product_sub_group     = htmlspecialchars($request->input('s_category_name', true), ENT_QUOTES, 'utf-8');
            $category_DB->s_product_group     = htmlspecialchars($request->input('p_category', true), ENT_QUOTES, 'utf-8'); 
        }
        $category_DB->i_franchisor_id     = htmlspecialchars($request->input('franchisors_id', true), ENT_QUOTES, 'utf-8');
        //// retrieving submitted/posted values [END]...

        //// inserting into companies table...
        $category_DB->save();

        //// redirection URL...
        $REDIRECT = UrlHelper::admin_base_url() ."miscellaneous/category-master";

        # success message...
        $SUCCESS_MSG = "Category info updated successfully";


        echo json_encode(array('result'=>'success',
                               'redirect'=>$REDIRECT,
                               'msg'=>$SUCCESS_MSG));
        exit;

    }

    
        //// NEW - load sub-categories based on Category selection...
        public function load_zeevant_subcategories_AJAX(Request $request) {
            
            try {
                # I: selected Category...
                $data['category_name'] = $request->input('category', true);
                
                # II: load Sub-Categories...
                $HTML = \View::make('admin.miscellaneous.ajax-parts.load-zeevant-subcategories-data-AJAX', $data)->render();

                echo json_encode(array('result'        => 'success',
                                       'html_content'  => $HTML));
                exit;
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }
    
        //// NEW - add new sub-category [AJAX CALL - Selectize]...
        public function add_new_zeevant_subcategory_AJAX(Request $request) {
            
            try {
                # I: new subcategory-name...
                $POS_CATEGORY = $data['pos_category_name'] = $request->input('pos_cat', true);
                $POS_SUBCATEGORY = $data['pos_subcategory_name'] = $request->input('pos_subcat', true);
                $ZEEVANT_CATEGORY = $data['category_name'] = $request->input('category_name', true);
                $ZEEVANT_SUBCATEGORY = $data['subcategory_name'] = $request->input('subcategory_name', true);
                $SELECTED_FRANCHISOR = $data['franchisor_id'] = $request->input('franchisor_id', true);
                $SELECTED_COLOR = $data['color_code'] = $request->input('color', true);
                
                $required_fields = array('pos_cat'=>'POS Category',
                                         'pos_subcat'=>'POS Sub-Category',
                                         'category_name'=>'Zeevant Category',
                                         'subcategory_name'=>'Zeevant Sub-category',
                                         'franchisor_id'=>'Franchisor',
                                         'color'=>'Color Code');
                # validation for singular fields (i.e. appearing once)...
                $arr_flds = array();
                foreach($required_fields as $key=>$fld_name) {
                    
                    if( $_POST[$key]=='' ) {
                        $arr_flds[] = $fld_name;
                    }

                }
                
                
                if( empty($arr_flds) ) {
                
                    # II: check if category already exists OR not...
                    $category_DB = new \App\Models\CategoryModel;
                    $chkWhere = " WHERE
                                    `product_group_new`='{$ZEEVANT_CATEGORY}' AND
                                    `subgroup_new`='{$ZEEVANT_SUBCATEGORY}' ";
                    if( !$category_DB->getCategoryTotalInfo($chkWhere) ) {
                        $category_DB->product_group = $POS_CATEGORY;
                        $category_DB->subgroup      = $POS_SUBCATEGORY;
                        $category_DB->product_group_new = $ZEEVANT_CATEGORY;
                        $category_DB->subgroup_new  = $ZEEVANT_SUBCATEGORY;
                        $category_DB->i_franchisor_id  = $SELECTED_FRANCHISOR;
                        $category_DB->color_code    = $SELECTED_COLOR;
                        
                        // save new...
                        //$category_DB->save();
                        
                        echo json_encode(array('mode' => 'success'));
                        exit;
                    }
                    
                } else {
                    
                    $EMPTY_FLDS = implode(', ', $arr_flds);
                    $ERR_MSG = "{$EMPTY_FLDS} fields are required...";
                    
                    echo json_encode(array('mode' => 'error',
                                           'msg'  => $ERR_MSG));
                    exit;
                    
                }
                
                
            } catch(Exception $err_obj) {
                show_error($err_obj->getMessage());
            }
            
        }
    
        
        # NEW - function to validate form-submission [AJAX CALL]
        public function validate_category_AJAX(Request $request)
        {
            // Error Messages for Required Fields...
            $err_flds = array();
            $REQD_FLD_MSG = ' required field';
            $required_fields = array('product_group', 'product_group_new',
                                     'subgroup_new', 'i_franchisor_id', 'color_code');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( $_POST[$required_field]=='' && in_array($required_field, $required_fields) )
                    $arr_messages[$required_field] = $REQD_FLD_MSG;

            }

            # ADD "CATEGORY" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->add_category_AJAX($request);
            }
            else   //// if error occurs...
            {
                echo json_encode(array('result' => 'error',
                    'arr_messages' => $arr_messages));
                exit;
            }
        }
        
        //// NEW - function to add Category [AJAX CALL]...
        public function add_category_AJAX(Request $request) {

            $category_DB = new modCategory();
            
            # db info array...
            $category_arr = array();

            //// Now, retrieving submitted/posted values [BEGIN]...
                $POS_CATEGORY = $category_arr['product_group'] = htmlspecialchars($request->input('product_group', true), ENT_QUOTES, 'utf-8');
                $POS_SUBCATEGORY = htmlspecialchars($request->input('subgroup', true), ENT_QUOTES, 'utf-8');
                $category_arr['subgroup'] = ( !empty($POS_SUBCATEGORY) )? $POS_SUBCATEGORY: null;
                $ZEEVANT_CATEGORY = $category_arr['product_group_new'] = htmlspecialchars($request->input('product_group_new', true), ENT_QUOTES, 'utf-8');
                $ZEEVANT_SUBCATEGORY = $category_arr['subgroup_new'] = htmlspecialchars($request->input('subgroup_new', true), ENT_QUOTES, 'utf-8');
                $category_arr['i_franchisor_id'] = htmlspecialchars($request->input('i_franchisor_id', true), ENT_QUOTES, 'utf-8');
                $category_arr['color_code'] = htmlspecialchars($request->input('color_code', true), ENT_QUOTES, 'utf-8');
            //// retrieving submitted/posted values [END]...

            //// inserting into category-map table...
                    $SUBGROUP_COND = ( !empty($POS_SUBCATEGORY) )
                                     ? " `subgroup`='{$POS_SUBCATEGORY}' "
                                     : " `subgroup` IS NULL ";
                    $chkWhere = " WHERE
                                    `product_group`='{$POS_CATEGORY}' AND
                                    {$SUBGROUP_COND} AND
                                    `product_group_new`='{$ZEEVANT_CATEGORY}' AND
                                    `subgroup_new`='{$ZEEVANT_SUBCATEGORY}' ";
                    if( !$category_DB->getCategoryTotalInfo($chkWhere) ) {
                        
                        # updating field(s)...
                        \DB::table($this->category_map_tbl)
                            ->insert($category_arr);

                        //// redirection URL...
                        $REDIRECT = UrlHelper::admin_base_url() ."miscellaneous/category-master";

                        # success message...
                        $SUCCESS_MSG = "Category info added successfully";


                        echo json_encode(array('result'=>'success',
                                               'redirect'=>$REDIRECT,
                                               'msg'=>$SUCCESS_MSG));
                    } else {
                        # error message...
                        $ERR_MSG = "Category already exists!!";

                        echo json_encode(array('result'=>'error',
                                               'msg'=>$ERR_MSG));
                    }
            exit;

        }
        
        
    //// ==================================================================================
    ////            AJAX CALLS [END]
    //// ==================================================================================


}