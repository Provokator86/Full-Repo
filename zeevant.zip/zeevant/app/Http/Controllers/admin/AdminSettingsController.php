<?php

namespace App\Http\Controllers\admin;

use App\Helpers\UrlHelper;
use App\Models\SiteSettingsModel;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminSettingsController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();
    }

    // index function definition...
    public function index() {

        # Page-Specific Settings...
            $data = $this->data;
            $data['page_header_BIG'] = 'Site Settings Page';
            $data['page_header_SMALL'] = 'Preview';
            $data['parent_menu'] = 'general';
            $data['child_menu'] = 'site-settings';


        # setting breadcrumb(s) [Begin]...
            \Breadcrumbs::register('home', function($breadcrumbs) {
                $breadcrumbs->push('Home', route('home'));
            });
            \Breadcrumbs::register('settings', function($breadcrumbs) {
                $breadcrumbs->parent('home');
                $breadcrumbs->push('Settings', route('settings'));
            });
        # setting breadcrumb(s) [End]...


        # show view part...
        return view('admin.admin-settings', $data);
    }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               EDIT FORM SUBMISSION [BEGIN]
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        public function validate_admin_settings_AJAX(Request $request) {

            // Error Messages for Required Fields...
            $REQD_FLD_MSG = ' required field';
            $err_flds = array();
            $required_fields = array('s_admin_mail', 's_contact_mail', 'i_items_per_page');
            $email_flds = array('s_admin_mail', 's_contact_mail');

            // adjusting err-messages part accordingly...
            $arr_messages = array();

            ////////////// VALIDATION CHECKS - BEGIN //////////////

            # validation for singular fields (i.e. appearing once)...
            foreach($required_fields as $required_field) {

                if( $_POST[$required_field]=='' && in_array($required_field, $required_fields) ) {

                    if( !in_array($required_field, $err_flds) )
                        $err_flds[] = $required_field;

                    $arr_messages[$required_field] = $REQD_FLD_MSG;
                }
            }

            # email address validate....
            foreach($email_flds as $email_fld) {

                if( $_POST[$email_fld]!='' ) {

                    if( !filter_var($_POST[$email_fld], FILTER_VALIDATE_EMAIL) ) {
                        if( !in_array($email_fld, $err_flds) )
                            $err_flds[] = $email_fld;

                        $arr_messages[$email_fld] = '* not a valid email address';
                    }

                }
            }

            # phone number validation (if Non-Empty)...
                $pattern = '/^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/i';
                $SITE_PHONE_NO = $request->input('s_site_phone');

                if( !empty($SITE_PHONE_NO) ) {
                    if (!preg_match($pattern, $SITE_PHONE_NO)) {
                        if (!in_array('s_site_phone', $err_flds))
                            $err_flds[] = 's_site_phone';

                        $arr_messages['s_site_phone'] = '* not a valid phone-number';
                    }
                }

            # EDIT "SITE SETTINGS" [if no errors]...
            if( count($arr_messages)==0 ) {

                $this->edit_site_settings_AJAX( $request );

            }
            else   //// if error occurs...
            {
                // for success field(s)...
                $success_flds = array_diff($required_fields, $err_flds);
                $success_flds = array_values($success_flds);

                echo json_encode(array('result'=> 'error',
                                       'arr_messages'  => $arr_messages,
                                       'success_flds'  => $success_flds));
                exit;
            }

        }


        public function edit_site_settings_AJAX(Request $request) {

            # db info array...
            $arr_item = array();

            //// Now, retrieving submitted/posted values [BEGIN]...
            $ADMIN_EMAIL   = trim( $request->input('s_admin_mail', true) );
            $CONTACT_EMAIL = trim( $request->input('s_contact_mail', true) );
            $SITE_PHONE_NO = trim( $request->input('s_site_phone', true) );
            $ITEM_PER_PG   = trim( $request->input('i_items_per_page', true) );
            $SITE_TITLE    = trim( $request->input('s_site_title', true) );

            //// updating "Settings" table...
            $SETTINGS_ID = $request->input('h_id');
            $arr_site_settings = array();
            $arr_site_settings['s_admin_mail'] = $ADMIN_EMAIL;
            $arr_site_settings['s_contact_mail'] = $CONTACT_EMAIL;
            $arr_site_settings['s_site_phone'] = $SITE_PHONE_NO;
            $arr_site_settings['i_items_per_page'] = $ITEM_PER_PG;
            $arr_site_settings['s_site_title'] = $SITE_TITLE;

            # updating the db...
            SiteSettingsModel::where('i_id', $SETTINGS_ID)
                              ->update($arr_site_settings);

            # success message...
            $SUCCESS_MSG = "Settings saved successfully";

            # redirect page...
            $REDIRECT_PG = UrlHelper::admin_base_url();

            echo json_encode(array('result'=>'success',
                                   'msg'=>$SUCCESS_MSG,
                                   'redirect'=>$REDIRECT_PG
            ));
            exit;

        }


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #               EDIT FORM SUBMISSION [END]
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
