<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

# custom Helper(s) & Model(s)
use App\Helpers\Utility;    # use Helper
use App\Models\Users;       # use Model

class LoginController extends AdminBaseController
{
    // index function definition...
    public function index() {

        # view part...
        return view('admin.admin-login');
    }


    // function for admin login authentication [AJAX call]
    public function authenticate_AJAX(Request $request) {

        $arr_messages = array();

        # error message trapping...
        if( trim($request->input('username'))=='')
            $arr_messages['username'] = '*';
        if( trim($request->input('passwd'))=='')
            $arr_messages['passwd'] = '*';


        if( count($arr_messages)==0 )
        {
            $hash = '';
            if( $request->input('hash')!='' ) {
                $hash = $request->input('hash');
            }


            $default_redirect_url = url()."/admin/";

            if( $request->input('referrer')!='' && url_exists(base64_decode($request->input('referrer'))) )
            {
                $redirect_url =  base64_decode($request->input('referrer')).$hash ;
            }

            $pattern = '/[\s]*\'[\s]*(.*)[\s]*\'[\s]*/';

            $login_data['s_username'] = preg_replace($pattern, "$1", $request->input( 'username'));
            $login_data['s_password'] = preg_replace($pattern, "$1", $request->input( 'passwd'));

            # instantiating model...
            $users_model = new Users();
            $loggedin = $users_model->authenticate($login_data);

            if(!empty($loggedin))
            {
                /* start of Remeber me */
                if($request->input('chkRem')=='true')
                {
                    setcookie("BI[username]", $request->input('username', true ), time()+2592000, "/");
                    setcookie("BI[password]", $request->input('passwd', true), time()+2592000, "/");
                    setcookie("BI[remember]", $request->input('chkRem'), time()+2592000, "/");


                }
                else
                {
                    setcookie("BI[username]", "", time() - 3600, "/");
                    setcookie("BI[password]", "", time() - 3600, "/");
                    setcookie("BI[remember]", "", time() - 3600, "/");
                }
                /* end of Remenber me */


                $REDIRECT_URL = url() ."/admin/";
                echo json_encode( array('result'=>'success',
                                        'msg'   => 'Login Successful',
                                        'redirect_url'=>$REDIRECT_URL) );

                exit;
            }
            else
            {
                echo json_encode( array('result'=>'error',
                                        'msg'=>'Invalid username / password!',
                                        'alert_type'=>'error',
                                        'arr_messages'=>$arr_messages) );

                exit;
            }



        } else {
            echo json_encode(array('result'=>'error',
                'msg'=>'Login failed!',
                'alert_type'=>'block',
                'arr_messages'=>$arr_messages));
            exit;
        }

    }


    // function to logout from admin-section...
    public function logout() {

        # delete all session variable(s)...
        \Session::flush();

        # redirect to admin-login...
        return redirect('/admin/');
    }
}
