<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use DB;

class DashboardController extends AdminBaseController
{
    // constructor definition...
    public function __construct() {

        parent::__construct();
    }

    // index function definition...
    public function index() {

        $data = $this->data;
        $data['page_header_BIG'] = 'Dashboard';
        $data['page_header_SMALL'] = 'Preview';
        $data['parent_menu'] = 'general';
        $data['child_menu'] = 'dashboard';

        # setting breadcrumb(s)...
        \Breadcrumbs::register('home', function($breadcrumbs) {
            $breadcrumbs->push('Home', route('home'));
        });
        
        
        # Satic Data For Preparing Chart
        
        $arr = array    (
                            array("label"=>"Jan","value"=>"420000"),
                            array("label"=>"Feb","value"=>"810000"), 
                            array("label"=>"Mar","value"=>"720000"), 
                            array("label"=>"Apr","value"=>"550000"), 
                        );
                        
        $data['map'] =  json_encode($arr) ;    
        
         /*$tasks = DB::select("select udf_NORMDIST(val,(select FORMAT(avg(a.val),2) as avg_value from dev a),(select FORMAT(stddev(b.val),2) as std_value from dev b)) as nd,val dv, IF(user_id = 1, '1','2') as status from dev order by dv ASC");*/
         
         $tasks = DB::select("select udf_NORMDIST(val, 468.523810 , 279.707435)  as nd,
(val-468.523810)/279.707435 as dv, val, '1' as status 
 from dev order by dv ASC");
 
                
                $category = $datas = array();
                 
                if(!empty($tasks))  {   
                
                    foreach($tasks as $ind=>$val){
                        
                           /** for standard deviation grouping
                           $category[] = array('label' =>$val->dv);
                           $data[]  = array('value' => $val->nd);
                           */
                            
                           /** for normal deviation */
                           $datas[]  = array('value' => $val->nd*100);
                           $category[] = array('label' =>$val->val);    
                           
                           /*if($val->status != 1)
                           $category[] = array('label' =>$val->dv);
                           else
                           $category[] = array('label' =>$val->dv, 
                                                  'vline'=>'true',
                                                        'lineposition'=>'0',
                                                        'color'=>'#6baa01',
                                                        'labelHAlign'=>'right',
                                                        'labelPosition'=>'0',
                                                       
                                               ); */
                         
                                               
                         
                         
                              
                    }   
                    
                }
                
                
                $data['jsonEncodedData'] = array($category,$datas);
                
               
                         

        # show view part...
        return view('admin.dashboard', $data);
        //return view('admin.dashboard')->with('data',$data);
    }
}
