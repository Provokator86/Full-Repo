<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use Illuminate\Support\Str;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class AdminBaseController extends Controller
{
    protected $data = array();

    // parent constructor
    public function __construct() {

        $this->data['page_header_BIG'] = '';
        $this->data['page_header_SMALL'] = '';

        $this->data['menu_arr'] = config('app.sidebar_arr');
        $this->data['icon_arr'] = config('app.icons_arr');
        $this->data['url_arr']  = config('app.url_arr');
        $this->data['parent_menu'] = $this->data['child_menu'] = '';

        # loading site-settings data...
        $this->data['settings_info'] = \App\Models\SiteSettingsModel::first();

    }
}