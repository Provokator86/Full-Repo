<?php namespace App\Http\Middleware;

use Closure;

class VerifyInput {

	public function handle($request, Closure $next)
    {
        if (!in_array(strtolower($request->method()), ['put', 'post','get'])) {
            return $next($request);
        }

        $input = $request->all();

        array_walk_recursive($input, function(&$input) {
           
            $input = strip_tags($input);
            $input = filter_var($input, FILTER_SANITIZE_STRING);
                
        });

        $request->merge($input);

        return $next($request);
    }

}
