<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

    //// TO GET SERVER-SIDE INFO
    Route::get('/info', 'userend\FrontIndexController@server_info');


# *************************************************************************** #
#               User/Franchisee Specific Route(s) - Begin                     #
# *************************************************************************** #

    # user-end sign-up...
    Route::get('/registration', 'userend\UserSignUpController@index');

    # user-end login...
    Route::get('/login', 'userend\LoginController@index');
    Route::post('/login/authenticate-AJAX', 'userend\LoginController@authenticate_AJAX');
    Route::get('/logout', 'userend\LoginController@logout');

    Route::group(['namespace'=>'userend',
                  'middleware'=>['usr_auth']], function () {

        # front-page (DashBoard)...
            Route::get('/', 'FrontIndexController@index');
            Route::post('/dashboard/load-dashboard-benchmark-data-AJAX', 'FrontIndexController@loadDashboardBenchmarkDataAJAX');
            Route::post('/dashboard/load-dashboard-ds-data-AJAX', 'FrontIndexController@loadDashboardDailyScoopDataAJAX');
            Route::post('/dashboard/load-dashboard-data-AJAX', 'FrontIndexController@loadDashboardDataAJAX');
            //// NEW
            Route::post('/dashboard/load-dashboard-ds-N-zreport-data-AJAX', 'FrontIndexController@loadDashboardDailyScoopNZreportDataAJAX');
            Route::post('/dashboard/load-dashboard-zreport-data-AJAX', 'FrontIndexController@loadDashboardZreportDataAJAX');
            Route::get('/generate-password', 'FrontIndexController@genPassword');


        # profile-page...
            Route::get('/profile', 'ProfileController@index');
            Route::post('/profile/validate-profile-info-AJAX', 'ProfileController@validateProfileInfoAJAX');
            Route::post('/profile/validate-account-password-AJAX', 'ProfileController@validateAccountPasswordAJAX');


        # Benchmark Link(s)...
            // Revenue Distribution
                Route::get('/benchmark/revenue-distribution', 'benchmark\RevenueDistributionController@index');
                Route::post('/benchmark/revenue-distribution/load-revenue-distribution-data-AJAX', 'benchmark\RevenueDistributionController@loadRevenueDistributionDataAJAX');


           // Gross Margin Distribution
            Route::get('/benchmark/gross-margin', 'benchmark\GrossMarginController@index');
            Route::post('/benchmark/gross-margin/load-gross-margin-data-AJAX', 'benchmark\GrossMarginController@loadGrossMarginDataAJAX');
            
            // Internet Sales Distribution  
            Route::get('/benchmark/internet-sales', 'benchmark\InternetSalesController@index');
            Route::post('/benchmark/internet-sales/load-internet-sales-data-AJAX', 'benchmark\InternetSalesController@loadInternetSalesDataAJAX');
            
            // Average Ticket(s) Distribution
            Route::get('/benchmark/avg-ticket', 'benchmark\AvgTicketController@index');
            Route::post('/benchmark/avg-ticket/load-avg-ticket-data-AJAX', 'benchmark\AvgTicketController@loadAverageTicketDataAJAX');
            
            // Marketing-Percentage-Sales Distribution
            Route::get('/benchmark/percentage-sales', 'benchmark\PercentageSalesController@index');
            Route::post('/benchmark/percentage-sales/load-percentage-sales-data-AJAX', 'benchmark\PercentageSalesController@loadPercentageSalesDataAJAX');
            
            // Labor-Efficiency Distribution
            Route::get('/benchmark/labor-efficiency', 'benchmark\LaborEfficiencyController@index');
            Route::post('/benchmark/labor-efficiency/load-labor-efficiency-data-AJAX', 'benchmark\LaborEfficiencyController@loadLaborEfficiencyDataAJAX');
            
            // Inventory-Turns Distribution
            Route::get('/benchmark/inventory-turns', 'benchmark\InventoryTurnsController@index');
            Route::post('/benchmark/inventory-turns/load-inventory-turns-data-AJAX', 'benchmark\InventoryTurnsController@loadInventoryTurnsDataAJAX');
            
            Route::get('/benchmark/conversion-ratio', 'benchmark\ConversionRatioController@index');
            Route::get('/benchmark/store-visitation', 'benchmark\StoreVisitationController@index');
            
            // Average Discount Distribution
            Route::get('/benchmark/avg-discount', 'benchmark\AvgDiscountController@index');
            Route::post('/benchmark/avg-discount/load-avg-discount-data-AJAX', 'benchmark\AvgDiscountController@loadAverageDiscountDataAJAX');



        # Daily-Scoop Link(s)...
            Route::get('/daily-scoop/cumulative-revenue', 'daily_scoop\CumulativeRevenueController@index');          
            Route::post('/daily-scoop/cumulative-revenue/load-cumulative-revenue-data-AJAX', 'daily_scoop\CumulativeRevenueController@loadCumulativeRevenueDataAJAX');
            Route::get('/daily-scoop/cumulative-revenue', 'daily_scoop\CumulativeRevenueController@index');
            
            Route::get('/daily-scoop/gross-margin', 'daily_scoop\DailyGrossMarginController@index');
            Route::post('/daily-scoop/gross-margin/load-cumulative-revenue-data-AJAX', 'daily_scoop\DailyGrossMarginController@loadCumulativeRevenueDataAJAX');
            
            Route::get('/daily-scoop/ticket', 'daily_scoop\DailyTicketController@index');
            Route::post('/daily-scoop/ticket/load-ticket-data-AJAX', 'daily_scoop\DailyTicketController@loadTicketDataAJAX');
            
            Route::get('/daily-scoop/discount', 'daily_scoop\DailyDiscountController@index');
            Route::post('/daily-scoop/discount/load-discount-data-AJAX', 'daily_scoop\DailyDiscountController@loadDiscountDataAJAX');
            
            Route::get('/daily-scoop/time-of-day', 'daily_scoop\DailyTimeofdayController@index');
            Route::post('/daily-scoop/time-of-day/load-timeofday-data-AJAX', 'daily_scoop\DailyTimeofdayController@loadTimeofdayDataAJAX');
            
           // Route::get('/daily-scoop/time-of-day', 'daily_scoop\TimeOfDayController@index');
            //// Top 10 Sellers...
            Route::get('/daily-scoop/top-10-sellers', 'daily_scoop\Top10SellersController@index');
            Route::post('/daily-scoop/top-10-sellers/load-top-10-sellers-data-AJAX', 'daily_scoop\Top10SellersController@loadTopSellersDataAJAX');

            //// ZReport...
            Route::get('/daily-scoop/zreport', 'daily_scoop\ZReportController@index');
            Route::post('/daily-scoop/zreport/load-zreport-data-AJAX', 'daily_scoop\ZReportController@loadZReportDataAJAX');
            Route::get('/daily-scoop/zreport/test', 'daily_scoop\ZReportController@test_run');

            Route::get('/daily-scoop/product-mix', 'daily_scoop\DailyProductMixController@index');
            Route::post('/daily-scoop/product-mix/load-product-mix-data-AJAX', 'daily_scoop\DailyProductMixController@loadProductmixDataAJAX');
            
            Route::get('/daily-scoop/visitations', 'daily_scoop\VisitationsController@index');
            
            Route::get('/pricing-tool', 'PricingToolController@index');
            Route::post('/pricing-tool/load-sub-data-AJAX', 'PricingToolController@loadsubcategoryDataAJAX');
            Route::post('/pricing-tool/load-pricing-tool-table-data-AJAX', 'PricingToolController@loadPricingtooltableDataAJAX');
            Route::post('/pricing-tool/load-pricing-tool-data-AJAX', 'PricingToolController@loadPricingtoolDataAJAX');




        # My-Input(s) Link(s)...
            Route::get('/my-inputs/configuration-inputs', 'my_inputs\ConfigInputsController@index');
            Route::post('/my-inputs/configuration-inputs/validate-config-plan-AJAX', 'my_inputs\ConfigInputsController@validate_config_plan_AJAX');
            Route::post('/my-inputs/configuration-inputs/load-config-data-AJAX', 'my_inputs\ConfigInputsController@load_config_data_AJAX');

            //// Monthly-KPI-Plan
                Route::get('/my-inputs/monthly-KPI-plan', 'my_inputs\KPIPlanController@index');
                Route::post('/my-inputs/monthly-KPI-plan/validate-KPI-plan-AJAX', 'my_inputs\KPIPlanController@validate_KPI_plan_AJAX');
                Route::post('/my-inputs/monthly-KPI-plan/load-plan-data-AJAX', 'my_inputs\KPIPlanController@load_plan_data_AJAX');
            //// Monthly-Financials
                Route::get('/my-inputs/monthly-financials', 'my_inputs\MonthlyFinancialsController@index');
                Route::post('/my-inputs/monthly-financials/validate-balance-sheet-AJAX', 'my_inputs\MonthlyFinancialsController@validate_balance_sheet_AJAX');
                Route::post('/my-inputs/monthly-financials/validate-income-statement-AJAX', 'my_inputs\MonthlyFinancialsController@validate_income_statement_AJAX');

                Route::post('/my-inputs/monthly-financials/load-monthly-financials-data-AJAX', 'my_inputs\MonthlyFinancialsController@loadMonthlyFinancialsDataAJAX');
            //// NEW - Labor-Floor-Hours
                Route::get('/my-inputs/labor-floor-hours', 'my_inputs\LaborFloorHoursController@index');
                Route::post('/my-inputs/labor-floor-hours/validate-floor-hours-AJAX', 'my_inputs\LaborFloorHoursController@validate_floor_hours_AJAX');
                Route::post('/my-inputs/labor-floor-hours/load-floor-hours-data-AJAX', 'my_inputs\LaborFloorHoursController@loadFloorHoursDataAJAX');
                

        # Franchisee Link(s)...
            //// Manage Franchisee(s)...
            Route::get('/franchisee/manage-franchisees/{page?}', ['as'=> 'franchisees',
                                                                  'uses'=>'franchisee\ManageFranchiseesController@index']);
            Route::get('/franchisee/add-new-franchisee', ['as'=> 'add-franchisee',
                                            'uses'=>'franchisee\AddFranchiseeController@index']);
            Route::post('/franchisee/add-new-franchisee/validate-franchisee-AJAX', 'franchisee\AddFranchiseeController@validate_franchisee_AJAX');
            Route::get('/franchisee/edit-franchisee/{id}/{slug}', ['as'=> 'edit-franchisee',
                'uses'=>'franchisee\EditFranchiseeController@index']);
            Route::post('/franchisee/edit-franchisee/validate-franchisee-AJAX', 'franchisee\EditFranchiseeController@validate_franchisee_AJAX');
            Route::post('/franchisee/manage-franchisees/delete-franchisee-AJAX', 'franchisee\ManageFranchiseesController@delete_franchisee_AJAX');

            # NEW - ERPLY DUMP-DATA...
            Route::get('/franchisee/load-live-data', ['as'=> 'load-franchisee-data',
                                                      'uses'=>'franchisee\ManageFranchiseesController@load_live_data']);


			# NEW - Manage Franchisee User(s)
            Route::get('/franchisee/franchisee-users', ['as'=> 'franchisee-users-dashboard',
                										'uses'=>'franchisee\FranchiseeUsersController@index']);
            Route::get('/franchisee/franchisee-users/{slug}', 'franchisee\FranchiseeUsersController@index');
            Route::post('/franchisee/franchisee-users/load-field-consultants-AJAX', 'franchisee\FranchiseeUsersController@load_field_consultants_AJAX');
            Route::post('/franchisee/franchisee-users/load-franchisee-users-AJAX', 'franchisee\FranchiseeUsersController@load_franchisee_users_AJAX');
            
            //// Franchisee-User(s)...
            Route::get('/franchisee/manage-franchisee-users/{page?}', ['as'=> 'franchisee-users',
                'uses'=>'franchisee\ManageFranchiseeUsersController@index']);
            Route::get('/franchisee/add-franchisee-user', ['as'=> 'add-franchisee-user',
                                                    'uses'=>'franchisee\AddFranchiseeUsersController@index']);
            Route::post('/franchisee/add-franchisee-user/validate-franchisee-user-AJAX', 'franchisee\AddFranchiseeUsersController@validate_franchisee_user_AJAX');
            Route::get('/franchisee/edit-franchisee-user/{id}/{slug}', ['as'=> 'edit-franchisee',
                'uses'=>'franchisee\EditFranchiseeUserController@index']);
            Route::post('/franchisee/edit-franchisee-user/validate-franchisee-user-AJAX', 'franchisee\EditFranchiseeUserController@validate_franchisee_user_AJAX');
            Route::post('/franchisee/manage-franchisee-users/delete-franchisee-user-AJAX', 'franchisee\ManageFranchiseeUsersController@delete_franchisee_user_AJAX');

            #// Field-Consultant(s)
            Route::get('/franchisee/manage-field-consultants/{page?}', ['as'=> 'field-executives',
                                'uses'=>'franchisee\ManageFieldExecutivesController@index']);
            Route::get('/franchisee/add-field-consultant', ['as'=> 'add-field-executive',
                'uses'=>'franchisee\AddFieldExecutiveController@index']);
            Route::post('/franchisee/add-field-consultant/validate-field-consultant-AJAX', 'franchisee\AddFieldExecutiveController@validate_field_executive_AJAX');
            Route::get('/franchisee/edit-field-consultant/{id}/{slug}', ['as'=> 'edit-franchisee',
                                'uses'=>'franchisee\EditFieldExecutiveController@index']);
            Route::post('/franchisee/edit-field-consultant/validate-field-consultant-AJAX', 'franchisee\EditFieldExecutiveController@validate_field_executive_AJAX');
            Route::post('/franchisee/manage-field-consultants/delete-field-consultant-AJAX', 'franchisee\ManageFieldExecutivesController@delete_field_executive_AJAX');




        # ~~~~~~~~~~~ Few CRON Route(s) [Begin]

            Route::get('/cron/load-all-income-statements', ['as'=> 'load-all-istmts',
                                                            'uses'=>'cron\cronController@loadAllIncomeStatements']);
            Route::get('/cron/load-all-kpi-revenue', ['as'=> 'load-all-revenue',
                                                      'uses'=>'cron\cronController@loadAllKPIRevenue']);
            Route::get('/cron/load-all-balance-sheets', ['as'=> 'load-all-bsheets',
            											 'uses'=>'cron\cronController@loadAllBalanceSheets']);
            Route::get('/cron/load-config-inputs', ['as'=> 'load-config-inputs',
            										'uses'=>'cron\cronController@loadConfigurationInputs']);
            
        # ~~~~~~~~~~~ Few CRON Route(s) [End]
    });

# *************************************************************************** #
#               User/Franchisee Specific Route(s) - End                       #
# *************************************************************************** #


    //// DB-Sync CronJob
    Route::get('/cron/run-db-sync', ['as'=> 'db-sync',
    								 'uses'=>'userend\cron\cronController@runDbSync']);

    //// Specific Table(s)-Sync CronJob
    Route::get('/cron/run-tbl-sync', ['as'=> 'tbl-sync',
    								  'uses'=>'userend\cron\cronController@runTableSync']);
    

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
//              Admin Specific Route(s) - Begin                               //
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //

    Route::get('/admin/login', 'admin\LoginController@index');
    Route::post('/admin/login/admin-authenticate-AJAX', 'admin\LoginController@authenticate_AJAX');
    Route::get('/admin/logout', 'admin\LoginController@logout');

    # for logged-in page(s)...
    Route::group(['prefix'=>'admin',
                  'namespace'=>'admin',
                  'middleware'=>['chk']], function () {

        # Admin Route(s)...
        Route::get('/', ['as'=> 'home', 'uses'=>'DashboardController@index']);
        Route::get('/settings-page', ['as'=> 'settings', 'uses'=>'AdminSettingsController@index']);
        Route::post('/settings-page/validate-account-settings-AJAX',
                    'AdminSettingsController@validate_admin_settings_AJAX');

        // User-Type(s)
        Route::get('/manage-user-types/{page?}', ['as'=> 'user-types',
                                                 'uses'=>'ManageUserTypesController@index']);
        Route::post('/manage-user-types/change-usertype-status-AJAX', 'ManageUserTypesController@change_usertype_status_AJAX');
        Route::get('/add-user-type', ['as'=> 'add-user-type',
                                      'uses'=>'AddUserTypeController@index']);
        Route::post('/add-user-type/validate-user-type-AJAX', 'AddUserTypeController@validate_user_type_AJAX');
        Route::get('/edit-user-type/{id}/{slug}', ['as'=> 'edit-user-type',
                                                   'uses'=>'EditUserTypeController@index']);
        Route::post('/edit-user-type/validate-user-type-AJAX', 'EditUserTypeController@validate_user_type_AJAX');
        Route::post('/manage-user-types/delete-usr-type-AJAX', 'ManageUserTypesController@delete_usr_type_AJAX');
        Route::get('/user-type-access-controls/{id}/{slug}', ['as'=> 'manage-acl',
                                                              'uses'=>'ManageUserTypesController@access_control_page']);
        Route::post('/manage-acl/validate-form-AJAX', 'ManageUserTypesController@manage_acl_AJAX');


        // Companies...
        Route::get('/manage-companies/{page?}', ['as'=> 'companies',
                                                 'uses'=>'ManageCompaniesController@index']);
        Route::get('/add-company', ['as'=> 'add-company',
                                    'uses'=>'AddCompanyController@index']);
        Route::post('/add-company/validate-company-AJAX', 'AddCompanyController@validate_company_AJAX');
        Route::get('/edit-company/{id}/{slug}', ['as'=> 'edit-company',
                                                 'uses'=>'EditCompanyController@index']);
        Route::post('/edit-company/validate-company-AJAX', 'EditCompanyController@validate_company_AJAX');
        Route::post('/manage-companies/delete-company-AJAX', 'ManageCompaniesController@delete_company_AJAX');


        // Franchisor(s)...
        Route::get('/manage-franchisors/{page?}', ['as'=> 'franchisors',
                                                   'uses'=>'users\ManageFranchisorsController@index']);
        Route::get('/add-new-franchisor', ['as'=> 'add-franchisor',
                                           'uses'=>'users\AddFranchisorController@index']);
        Route::post('/add-new-franchisor/validate-franchisor-AJAX', 'users\AddFranchisorController@validate_franchisor_AJAX');
        Route::get('/edit-franchisor/{id}/{slug}', ['as'=> 'edit-franchisor',
                                                    'uses'=>'users\EditFranchisorController@index']);
        Route::post('/edit-franchisor/validate-franchisor-AJAX', 'users\EditFranchisorController@validate_franchisor_AJAX');
        Route::post('/manage-franchisors/delete-franchisor-AJAX', 'users\ManageFranchisorsController@delete_franchisor_AJAX');


        // Franchisor-User(s)...
        Route::get('/manage-franchisor-users/{page?}', ['as'=> 'franchisor-users',
                                                        'uses'=>'users\ManageFranchisorUsersController@index']);
        Route::get('/add-new-franchisor-user', ['as'=> 'add-franchisor-user',
            'uses'=>'users\AddFranchisorUserController@index']);
        Route::post('/add-new-franchisor-user/validate-franchisor-user-AJAX', 'users\AddFranchisorUserController@validate_franchisor_user_AJAX');
        Route::get('/edit-franchisor-user/{id}/{slug}', ['as'=> 'edit-franchisor-user',
            'uses'=>'users\EditFranchisorUserController@index']);
        Route::post('/edit-franchisor-user/validate-franchisor-user-AJAX', 'users\EditFranchisorUserController@validate_franchisor_user_AJAX');
        Route::post('/manage-franchisor-users/delete-franchisor-user-AJAX', 'users\ManageFranchisorUsersController@delete_franchisor_user_AJAX');
        Route::post('/manage-franchisor-users/load-franchisor-users-AJAX', 'users\ManageFranchisorUsersController@load_franchisor_users_AJAX');

        # for benchmark data [Begin]
            Route::get('/benchmark/benchmark-revenue-data', ['as'=> 'bm-revenue-data',
                                                             'uses'=>'benchmark\BenchmarkRevenueDataController@show_revenue_data']);
        # for benchmark data [End]


        # for Miscellaneous Settings etc [Begin]...
            # Category-Master Related
            
            Route::get('/miscellaneous/category-master/{page?}', ['as'=> 'category-master',
                                                                  'uses'=>'miscellaneous\CategoryMasterController@index']);
            Route::get('/miscellaneous/edit-category/{id}/{slug}', ['as'=> 'edit-category',
                                                                    'uses'=>'miscellaneous\EditCategoryController@index']);
            Route::post('/miscellaneous/edit-category/validate-form-AJAX', 'miscellaneous\EditCategoryController@validate_category_AJAX');
            
            Route::post('/miscellaneous/category-master/delete-category-AJAX', 'miscellaneous\CategoryMasterController@delete_category_AJAX');
            
            Route::get('/miscellaneous/add-category/', ['as'=> 'add-category',
                                                                    'uses'=>'miscellaneous\AddCategoryController@index']);
            Route::post('/miscellaneous/add-category/validate-form-AJAX', 'miscellaneous\AddCategoryController@validate_category_AJAX');
            
            // NEW
            Route::post('/miscellaneous/category-master/load-zeevant-subcategories-AJAX', 'miscellaneous\AddCategoryController@load_zeevant_subcategories_AJAX');
            Route::post('/miscellaneous/category-master/add-new-zeevant-subcategory-AJAX', 'miscellaneous\AddCategoryController@add_new_zeevant_subcategory_AJAX');

            # Sub-Category Related
            Route::get('/miscellaneous/manage-sub-category/{id}/{slug}', ['as'=> 'manage-sub-category',
                                                                          'uses'=>'miscellaneous\ManageSubCategoryController@index']);

        # for Miscellaneous Settings etc [End]...



        # for testing...
            Route::get('/test-page/image-demo', ['as'=> 'image-demo',
                                                 'uses'=>'TestController@image_demo']);
            Route::get('/test-page/image', ['as'=> 'test-image',
                                            'uses'=>'TestController@image_actions']);
            Route::post('/test-page/image-demo/validate-img-AJAX', 'TestController@validate_img_AJAX');
            Route::get('/test-acl', ['as'=> 'test-acl',
                                     'uses'=>'ManageUserTypesController@test_acl']);
            Route::get('/test-acl-rules', ['as'=> 'test-acl-rules',
                                           'uses'=>'ManageUserTypesController@test_acl_rules']);
            Route::get('/test-data', ['as'=> 'test-data',
                                      'uses'=>'TestController@test_data']);

    });


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
//              Admin Specific Route(s) - End                                 //
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
